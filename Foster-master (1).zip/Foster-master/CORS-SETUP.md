# CORS Configuration for Foster Project

This document explains how to properly configure Cross-Origin Resource Sharing (CORS) between the Foster frontend and backend during development.

## What is CORS?

CORS (Cross-Origin Resource Sharing) is a security feature implemented by browsers that restricts web pages from making requests to a different domain than the one that served the web page. This helps prevent malicious sites from making unauthorized requests on behalf of users.

## How CORS is Configured in Foster

### Backend (Django)

In the Django backend, CORS is handled by the `django-cors-headers` package with the following settings:

```python
# CORS settings in foster/settings.py
CORS_ALLOW_ALL_ORIGINS = DEBUG  # Only in development
CORS_ALLOWED_ORIGINS = ['http://localhost:3000', 'http://127.0.0.1:3000']
CORS_ALLOW_CREDENTIALS = True
```

This configuration:
- Allows requests from the specified origins (localhost:3000 and 127.0.0.1:3000)
- Permits credentials to be included in cross-domain requests
- Defines allowed methods and headers

### Frontend (React)

The frontend API service is configured to:
- Include credentials in cross-domain requests
- Set appropriate headers for CORS requests

```javascript
// In src/config/api.js
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,  // Enable sending cookies in cross-domain requests
});
```

## Testing CORS Configuration

1. Start both the frontend and backend servers using the provided script:
   ```
   run_development_servers.bat
   ```

2. Open the CORS test page in your browser:
   - Navigate to: http://localhost:3000/test-cors.html
   - Click the "Test Health Endpoint" button to check if CORS is working correctly

3. Check browser developer console:
   - Press F12 to open Developer Tools
   - Look for CORS-related errors in the Console tab

## Troubleshooting CORS Issues

If you encounter CORS errors:

1. Verify the backend server is running and accessible
2. Check that frontend requests are going to the correct URL
3. Ensure the backend CORS settings include your frontend's origin
4. Inspect the network requests in Developer Tools to see specific errors
5. Confirm that credentials are properly handled if using authentication

## Common CORS Error Messages

- `Access to fetch at '...' from origin '...' has been blocked by CORS policy`
  - This means the server didn't include the necessary CORS headers

- `The value of the 'Access-Control-Allow-Origin' header does not match the supplied origin`
  - The server's allowed origins don't include the requesting origin

## Manual CORS Testing

You can test a specific endpoint using:

```javascript
fetch('http://localhost:8000/api/health/', {
  method: 'GET',
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json',
  },
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));
```

## Checking CORS Headers

A properly configured response from the backend should include headers like:
- `Access-Control-Allow-Origin: http://localhost:3000`
- `Access-Control-Allow-Credentials: true`
- `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
- `Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With` 