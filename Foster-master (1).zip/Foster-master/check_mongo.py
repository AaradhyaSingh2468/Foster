from pymongo import MongoClient
import os

# MongoDB connection settings
mongo_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
mongo_db_name = os.environ.get('MONGO_DB_NAME', 'foster_db')

print(f"Connecting to MongoDB at {mongo_uri}, database: {mongo_db_name}")

try:
    # Connect to MongoDB
    mongo_client = MongoClient(mongo_uri)
    mongo_db = mongo_client[mongo_db_name]
    
    # Test connection
    mongo_client.server_info()
    print(f"MongoDB connection established successfully.")
    print(f"MongoDB server version: {mongo_client.server_info()['version']}")
    print(f"MongoDB Database: {mongo_db.name}")
    
    # List collections
    collections = mongo_db.list_collection_names()
    print(f"MongoDB Collections: {collections}")
    
    # Check for study_sets collection
    if 'study_sets' in collections:
        print("\nStudy Sets Collection:")
        study_sets = list(mongo_db['study_sets'].find())
        print(f"Found {len(study_sets)} study sets")
        for i, doc in enumerate(study_sets):
            print(f"{i+1}. ID: {doc.get('_id')}, Title: {doc.get('title')}, Source: {doc.get('source')}, User ID: {doc.get('user_id')}")
    else:
        print("\nNo study_sets collection found.")
        # Create a test study set
        print("Creating a test study set...")
        from datetime import datetime
        
        # Use a valid Firebase UID for testing (replace with an actual UID if you have one)
        firebase_uid = "KiB6MrgUQETGrmWwV1oYQK3ynlt1"  # Example Firebase UID 
        
        result = mongo_db['study_sets'].insert_one({
            'user_id': firebase_uid,  # Using Firebase UID
            'title': 'Test PDF Document',
            'description': 'Test PDF for debugging',
            'subject': 'Test',
            'source': 'pdf',
            'is_public': False,
            'created_at': datetime.now(),
            'updated_at': datetime.now(),
            'stats': {
                'mastered': 0
            }
        })
        print(f"Created test document with ID: {result.inserted_id}")
    
    # Check for flashcards collection
    if 'flashcards' in collections:
        print("\nFlashcards Collection:")
        flashcards = list(mongo_db['flashcards'].find().limit(5))
        print(f"Found {mongo_db['flashcards'].count_documents({})} flashcards (showing first 5)")
        for i, doc in enumerate(flashcards):
            print(f"{i+1}. ID: {doc.get('_id')}, Study Set ID: {doc.get('study_set_id')}")
    else:
        print("\nNo flashcards collection found.")
    
except Exception as e:
    print(f"Failed to connect to MongoDB: {str(e)}") 