# Foster API URL Standards

## URL Path Conventions

To maintain consistency and avoid common issues with Django/React integration, follow these standards:

### Django Backend URLs

All URL patterns in Django should include trailing slashes:

```python
# Correct
path('users/', UserListView.as_view())
path('users/<int:id>/', UserDetailView.as_view())

# Incorrect
path('users', UserListView.as_view())  # Missing trailing slash
path('users/<int:id>', UserDetailView.as_view())  # Missing trailing slash
```

### Frontend API Requests

All API requests from the frontend should include trailing slashes:

```javascript
// Correct
api.get('/users/')
api.post('/users/')
api.get(`/users/${userId}/`)

// Incorrect
api.get('/users')  // Missing trailing slash
api.post('/users')  // Missing trailing slash
api.get(`/users/${userId}`)  // Missing trailing slash
```

## Django Settings

The Django `settings.py` includes `APPEND_SLASH = True`, which will automatically redirect URLs without trailing slashes to URLs with trailing slashes. However, this creates an unnecessary redirect and should not be relied upon.

## Common Issues

### 404 Errors

If you're seeing 404 errors for API endpoints, check:

1. That both the Django URL patterns and the frontend requests include trailing slashes
2. That the URL path is correct (e.g., `/api/users/statistics/` not `/api/user/statistics/`)
3. That the endpoint actually exists in the backend

### CORS Errors

If you're seeing CORS errors:

1. Ensure Django `CORS_ALLOWED_ORIGINS` includes your frontend origin
2. Check that the frontend is making requests to the correct backend URL
3. Verify CORS middleware is properly configured in Django settings

## Debugging

For debugging API issues:

1. Check browser console network tab for request/response details
2. Look at Django server logs for incoming requests
3. Use the API interceptors in `api.js` to log request/response details

## Additional Resources

- [Django URL Dispatcher Documentation](https://docs.djangoproject.com/en/stable/topics/http/urls/)
- [Django CORS Headers Documentation](https://github.com/adamchainz/django-cors-headers)
- [Axios Documentation](https://axios-http.com/docs/intro) 