# PowerShell script to create a Jupyter notebook from pipeline files
$notebookPath = "pipeline_analysis.ipynb"
$pipelinePath = "."

# Function to create a markdown cell
function Create-MarkdownCell {
    param (
        [string]$content
    )
    return @{
        "cell_type" = "markdown"
        "metadata" = @{}
        "source" = @($content)
    }
}

# Function to create a code cell
function Create-CodeCell {
    param (
        [string]$content
    )
    return @{
        "cell_type" = "code"
        "execution_count" = $null
        "metadata" = @{}
        "outputs" = @()
        "source" = @($content)
    }
}

# Initialize notebook structure
$notebook = @{
    "cells" = @()
    "metadata" = @{
        "kernelspec" = @{
            "display_name" = "Python 3"
            "language" = "python"
            "name" = "python3"
        }
        "language_info" = @{
            "codemirror_mode" = @{
                "name" = "ipython"
                "version" = 3
            }
            "file_extension" = ".py"
            "mimetype" = "text/x-python"
            "name" = "python"
            "nbconvert_exporter" = "python"
            "pygments_lexer" = "ipython3"
            "version" = "3.8.0"
        }
    }
    "nbformat" = 4
    "nbformat_minor" = 4
}

# Add title cell
$notebook.cells += Create-MarkdownCell "# Pipeline Analysis Notebook`n`nThis notebook contains the analysis of the pipeline codebase."

# Function to process files
function Process-Files {
    param (
        [string]$directory
    )
    
    # Get all Python files in the directory, excluding __init__.py
    $files = Get-ChildItem -Path $directory -Filter "*.py" -File | 
        Where-Object { $_.Name -ne "__init__.py" }
    
    foreach ($file in $files) {
        $fileName = $file.Name
        $content = Get-Content -Path $file.FullName -Raw
        
        # Add file header with just the file name
        $notebook.cells += Create-MarkdownCell "## $fileName"
        
        # Add code cell with file content
        $notebook.cells += Create-CodeCell $content
        
        # Add separator
        $notebook.cells += Create-MarkdownCell "---`n"
    }
}

# Process main directory
Process-Files $pipelinePath

# Process subdirectories (excluding examples and empty folders)
$subdirectories = Get-ChildItem -Path $pipelinePath -Directory | 
    Where-Object { $_.Name -ne "examples" -and (Get-ChildItem -Path $_.FullName -File).Count -gt 0 }

foreach ($dir in $subdirectories) {
    Process-Files $dir.FullName
}

# Convert notebook to JSON and save
$notebookJson = $notebook | ConvertTo-Json -Depth 10
$notebookJson | Out-File -FilePath $notebookPath -Encoding UTF8

Write-Host "Notebook created at: $notebookPath" 