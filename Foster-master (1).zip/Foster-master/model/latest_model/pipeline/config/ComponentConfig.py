"""
Component Configuration Classes
------------------------------
Defines typed, validated configuration classes for all workflow components.
Ensures proper configuration validation at initialization time.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union, Any
import os
from enum import Enum


class OCRQuality(Enum):
    """OCR quality levels"""
    LOW = "low"
    STANDARD = "standard" 
    HIGH = "high"
    HIGHEST = "highest"


class VideoQuality(Enum):
    """Video quality levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    ULTRA = "ultra"
    
    @classmethod
    def from_string(cls, quality_name: str) -> 'VideoQuality':
        """Get quality enum from string name"""
        try:
            return cls(quality_name.lower())
        except ValueError:
            return cls.HIGH  # Default to HIGH if not found


@dataclass
class PDFExtractorConfig:
    """Configuration for PDF extraction"""
    # Feature toggles
    extract_images: bool = True
    extract_tables: bool = True
    extract_equations: bool = True
    
    # OCR configuration
    ocr_quality: OCRQuality = OCRQuality.HIGH
    ocr_language: str = "eng"
    multi_language_detection: bool = False
    tesseract_path: Optional[str] = None
    
    # Scanned document options
    process_scanned: bool = True
    deskew_pages: bool = True
    denoise_images: bool = True
    contrast_enhancement: bool = False
    
    # Storage
    output_dir: Optional[str] = None
    
    def validate(self) -> None:
        """Validate the configuration"""
        if self.ocr_language and not isinstance(self.ocr_language, str):
            raise ValueError("OCR language must be a string")
        
        if self.output_dir and not os.path.exists(self.output_dir):
            raise ValueError(f"Output directory does not exist: {self.output_dir}")


@dataclass
class ContentAnalysisConfig:
    """Configuration for content analysis"""
    domain: str = "general"
    domain_focus: Optional[str] = None
    depth_level: str = "standard"
    grade_level: str = "general"
    detail_level: str = "standard"
    use_domain_specific: bool = True
    domain_confidence_threshold: float = 0.7
    apply_iterative_refinement: bool = True
    context_preservation: bool = True
    semantic_enrichment: bool = True
    knowledge_graph_integration: bool = True
    include_quiz: bool = False
    language: str = "en"
    learning_style: str = "balanced"
    
    def validate(self) -> None:
        """Validate the configuration"""
        valid_domains = ["general", "auto", "mathematics", "physics", 
                        "chemistry", "biology", "computer_science", 
                        "history", "literature"]
        
        if self.domain not in valid_domains and not self.domain.startswith("custom_"):
            raise ValueError(f"Invalid domain: {self.domain}")
        
        if self.domain_focus is not None and self.domain_focus not in valid_domains:
            raise ValueError(f"Invalid domain focus: {self.domain_focus}")
        
        valid_depth = ["basic", "standard", "deep", "comprehensive"]
        if self.depth_level not in valid_depth:
            raise ValueError(f"Invalid depth level: {self.depth_level}")
        
        valid_grade_levels = ["elementary", "middle_school", "high_school", "university", "general"]
        if self.grade_level not in valid_grade_levels:
            raise ValueError(f"Invalid grade level: {self.grade_level}")
        
        valid_detail_levels = ["basic", "standard", "comprehensive"]
        if self.detail_level not in valid_detail_levels:
            raise ValueError(f"Invalid detail level: {self.detail_level}")
        
        valid_languages = ["en", "es", "fr", "de", "it", "pt", "nl", "ru", "zh", "ja", "ko"]
        if self.language not in valid_languages:
            raise ValueError(f"Invalid language: {self.language}")
        
        valid_learning_styles = ["visual", "auditory", "kinesthetic", "reading", "balanced"]
        if self.learning_style not in valid_learning_styles:
            raise ValueError(f"Invalid learning style: {self.learning_style}")
        
        if not 0.0 <= self.domain_confidence_threshold <= 1.0:
            raise ValueError("Domain confidence threshold must be between 0 and 1")


@dataclass
class ScriptStyleConfig:
    """Configuration for script generation style"""
    tone: str = "neutral"
    verbosity: str = "moderate"
    target_audience: str = "general"
    language: str = "en-US"
    
    def validate(self) -> None:
        """Validate the configuration"""
        valid_tones = ["formal", "neutral", "friendly", "enthusiastic", "professional"]
        if self.tone not in valid_tones:
            raise ValueError(f"Invalid tone: {self.tone}")
        
        valid_verbosity = ["minimal", "moderate", "detailed", "comprehensive"]
        if self.verbosity not in valid_verbosity:
            raise ValueError(f"Invalid verbosity: {self.verbosity}")


@dataclass
class AnimationStyleConfig:
    """Configuration for animation style"""
    style: str = "modern"
    color_scheme: str = "educational"
    animation_level: str = "standard"
    scheduler_type: str = "ddim"
    
    def validate(self) -> None:
        """Validate the configuration"""
        valid_styles = ["modern", "classic", "minimalist", "vibrant", "technical"]
        if self.style not in valid_styles:
            raise ValueError(f"Invalid style: {self.style}")
        
        valid_schemes = ["educational", "vibrant", "monochrome", "pastel", "high-contrast"]
        if self.color_scheme not in valid_schemes:
            raise ValueError(f"Invalid color scheme: {self.color_scheme}")
        
        valid_animation = ["simple", "standard", "complex"]
        if self.animation_level not in valid_animation:
            raise ValueError(f"Invalid animation level: {self.animation_level}")


@dataclass
class VoiceOptionsConfig:
    """Configuration for voice generation"""
    voice_id: str = "neutral"
    speed: float = 1.0
    pitch: int = 0
    language_code: str = "en-US"
    
    def validate(self) -> None:
        """Validate the configuration"""
        if not 0.5 <= self.speed <= 2.0:
            raise ValueError("Speed must be between 0.5 and 2.0")
        
        if not -10 <= self.pitch <= 10:
            raise ValueError("Pitch must be between -10 and 10")


class MultimediaOptions:
    """Configuration options for multimedia generation"""
    def __init__(self, script_style: Optional[Dict[str, Any]] = None,
                animation_style: Optional[Dict[str, Any]] = None,
                voice_options: Optional[Dict[str, Any]] = None,
                video_format: str = "mp4",
                video_quality: Union[str, VideoQuality] = VideoQuality.HIGH,
                huggingface_api_key: Optional[str] = None,
                mistral_api_key: Optional[str] = None):
        """
        Initialize multimedia options
        
        Args:
            script_style: Script generation style options
            animation_style: Animation generation style options
            voice_options: Text-to-speech options
            video_format: Output video format
            video_quality: Video quality level (string or VideoQuality enum)
            huggingface_api_key: Hugging Face API key for image generation
            mistral_api_key: Mistral API key for script generation
        """
        # Handle nested configs
        if isinstance(script_style, ScriptStyleConfig):
            self.script_style = script_style
        else:
            self.script_style = ScriptStyleConfig(**(script_style or {}))
            
        if isinstance(animation_style, AnimationStyleConfig):
            self.animation_style = animation_style
        else:
            self.animation_style = AnimationStyleConfig(**(animation_style or {}))
            
        if isinstance(voice_options, VoiceOptionsConfig):
            self.voice_options = voice_options
        else:
            self.voice_options = VoiceOptionsConfig(**(voice_options or {}))
        
        # Handle video quality
        if isinstance(video_quality, str):
            self.video_quality = VideoQuality.from_string(video_quality)
        elif isinstance(video_quality, VideoQuality):
            self.video_quality = video_quality
        else:
            self.video_quality = VideoQuality.HIGH  # Default
            
        self.video_format = video_format
        self.huggingface_api_key = huggingface_api_key
        self.mistral_api_key = mistral_api_key

    def validate(self) -> None:
        """Validate the configuration"""
        # Validate nested configurations
        self.script_style.validate()
        self.animation_style.validate()
        self.voice_options.validate()
        
        # Validate video format
        valid_formats = ["mp4", "webm", "mov"]
        if self.video_format not in valid_formats:
            raise ValueError(f"Invalid video format: {self.video_format}")
        
        # Validate video quality
        if not isinstance(self.video_quality, VideoQuality):
            raise ValueError(f"Invalid video quality: {self.video_quality}")

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'MultimediaOptions':
        """Create from dictionary"""
        # Handle video quality conversion before passing to __init__
        video_quality = config_dict.get("video_quality", "high")
        if isinstance(video_quality, str):
            video_quality = VideoQuality.from_string(video_quality)
            
        return cls(
            script_style=config_dict.get("script_style"),
            animation_style=config_dict.get("animation_style"),
            voice_options=config_dict.get("voice_options"),
            video_format=config_dict.get("video_format", "mp4"),
            video_quality=video_quality,
            huggingface_api_key=config_dict.get("huggingface_api_key"),
            mistral_api_key=config_dict.get("mistral_api_key")
        )


@dataclass
class AdaptiveLearningConfig:
    """Configuration for adaptive learning"""
    difficulty_adjustment: bool = True
    personalization_level: str = "medium"
    focus_areas: List[str] = field(default_factory=list)
    
    def validate(self) -> None:
        """Validate the configuration"""
        valid_levels = ["low", "medium", "high"]
        if self.personalization_level not in valid_levels:
            raise ValueError(f"Invalid personalization level: {self.personalization_level}")


@dataclass
class WorkflowConfig:
    """Master configuration for the complete workflow"""
    extraction_options: PDFExtractorConfig = field(default_factory=PDFExtractorConfig)
    analysis_options: ContentAnalysisConfig = field(default_factory=ContentAnalysisConfig)
    multimedia_options: MultimediaOptions = field(default_factory=MultimediaOptions)
    adaptive_options: AdaptiveLearningConfig = field(default_factory=AdaptiveLearningConfig)
    
    # System-level configuration
    output_dir: str = "output"
    async_processing: bool = False
    use_distributed: bool = False
    
    # Auto-scaling options
    auto_scaling: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": False,
        "cpu_threshold": 0.8,
        "memory_threshold": 0.8,
        "time_threshold": 300
    })
    
    def validate(self) -> None:
        """Validate the entire configuration"""
        # Validate component configs
        self.extraction_options.validate()
        self.analysis_options.validate()
        self.multimedia_options.validate()
        self.adaptive_options.validate()
        
        # Validate system config
        if not os.path.exists(self.output_dir):
            try:
                os.makedirs(self.output_dir, exist_ok=True)
            except Exception as e:
                raise ValueError(f"Could not create output directory: {e}")
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'WorkflowConfig':
        """Create a typed configuration from a dictionary"""
        # Extract component configs
        extraction_dict = config_dict.get("extraction_options", {})
        analysis_dict = config_dict.get("analysis_options", {})
        multimedia_dict = config_dict.get("multimedia_options", {})
        adaptive_dict = config_dict.get("adaptive_options", {})
        
        # Create component configs
        extraction_config = PDFExtractorConfig(**extraction_dict)
        analysis_config = ContentAnalysisConfig(**analysis_dict)
        multimedia_config = MultimediaOptions(**multimedia_dict)
        adaptive_config = AdaptiveLearningConfig(**adaptive_dict)
        
        # Create the main config
        return cls(
            extraction_options=extraction_config,
            analysis_options=analysis_config,
            multimedia_options=multimedia_config,
            adaptive_options=adaptive_config,
            output_dir=config_dict.get("output_dir", "output"),
            async_processing=config_dict.get("async_processing", False),
            use_distributed=config_dict.get("use_distributed", False),
            auto_scaling=config_dict.get("auto_scaling", {"enabled": False})
        ) 