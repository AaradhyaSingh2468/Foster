"""
Analysis Result Class
-------------------
Represents the results of content analysis with metadata and extracted information.
"""

from typing import Dict, List, Optional, Any

class AnalysisResult:
    def __init__(self, 
                 metadata: Optional[Dict[str, Any]] = None,
                 key_concepts: Optional[List[str]] = None,
                 entities: Optional[List[Dict[str, Any]]] = None,
                 domain: Optional[str] = None):
        """
        Initialize AnalysisResult with extracted content information.
        
        Args:
            metadata: Dictionary containing metadata like title, audience, tone
            key_concepts: List of key concepts from the content
            entities: List of extracted entities with importance scores
            domain: Subject domain of the content
        """
        self.metadata = metadata or {}
        self.key_concepts = key_concepts or []
        self.entities = entities or []
        self.domain = domain or "general" 