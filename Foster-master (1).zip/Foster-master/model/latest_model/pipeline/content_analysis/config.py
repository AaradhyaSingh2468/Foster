"""
Configuration management for the VisualizationElementExtractor module.

This module provides centralized configuration for the visualization element extraction
pipeline, making it easier to adjust parameters for different environments 
(development, testing, production).
"""

import os
import logging
from typing import Dict, Any

class Config:
    """Configuration class for the VisualizationElementExtractor module."""
    
    # Environment settings
    ENV = os.getenv("EXTRACTION_ENV", "development")  # development, testing, production
    
    # Logging configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE = os.getenv("LOG_FILE", "extraction_pipeline.log")
    
    # Processing parameters
    BATCH_SIZE = int(os.getenv("BATCH_SIZE", "10"))
    MAX_WORKERS = int(os.getenv("MAX_WORKERS", "4"))
    
    # Image preprocessing parameters
    GAUSSIAN_BLUR_KERNEL = (5, 5)
    CANNY_THRESHOLD1 = 50
    CANNY_THRESHOLD2 = 150
    BINARY_THRESHOLD = 127
    
    # Extraction parameters
    MIN_CONTOUR_AREA = 500
    MIN_LINE_LENGTH = 50
    LINE_GAP = 10
    HOUGH_THRESHOLD = 50
    
    # OCR parameters
    TESSERACT_CONFIG = "--oem 3 --psm 6"
    TESSERACT_LANG = "eng"
    
    # Caching
    ENABLE_CACHE = os.getenv("ENABLE_CACHE", "False").lower() == "true"
    CACHE_DIR = os.getenv("CACHE_DIR", "/tmp/extraction_cache")
    CACHE_TTL = int(os.getenv("CACHE_TTL", "3600"))  # seconds
    
    # Output settings
    OUTPUT_FORMAT = os.getenv("OUTPUT_FORMAT", "json")  # json, csv, xml
    
    @classmethod
    def get_env_config(cls) -> Dict[str, Any]:
        """Get environment-specific configuration."""
        if cls.ENV == "production":
            return {
                "LOG_LEVEL": "WARNING",
                "ENABLE_CACHE": True,
                "BATCH_SIZE": 50,
                "MAX_WORKERS": 8,
            }
        elif cls.ENV == "testing":
            return {
                "LOG_LEVEL": "DEBUG",
                "ENABLE_CACHE": False,
                "BATCH_SIZE": 2,
                "MAX_WORKERS": 2,
            }
        else:  # development
            return {
                "LOG_LEVEL": "DEBUG",
                "ENABLE_CACHE": True,
                "BATCH_SIZE": 5,
                "MAX_WORKERS": 2,
            }
    
    @classmethod
    def setup_logging(cls):
        """Configure logging based on current settings."""
        log_level = getattr(logging, cls.LOG_LEVEL)
        logging.basicConfig(
            level=log_level,
            format=cls.LOG_FORMAT,
            handlers=[
                logging.FileHandler(cls.LOG_FILE),
                logging.StreamHandler()
            ]
        )
        
    @classmethod
    def update_from_env(cls):
        """Update configuration from environment variables."""
        env_config = cls.get_env_config()
        for key, value in env_config.items():
            if hasattr(cls, key):
                setattr(cls, key, value)


# Initialize configuration
Config.update_from_env() 