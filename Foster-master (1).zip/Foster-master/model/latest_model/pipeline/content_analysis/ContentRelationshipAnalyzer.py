from ContentAnalyzer import ContentAnalyzer

class ContentRelationshipAnalyzer:
    def __init__(self, content_analyzer=None):
        """
        Initialize the ContentRelationshipAnalyzer for understanding relationships between content elements.
        """
        # Store the content extraction result for analysis
        self.extraction_result = None
        
        # Internal data structures for analysis
        self.concept_graph = None
        self.dependency_tree = None
        self.concept_index = {}
        
        # Use composition to leverage ContentAnalyzer
        self.content_analyzer = content_analyzer if content_analyzer else ContentAnalyzer()
        
    def build_concept_graph(self, extraction_result):
        """
        Create a graph of related concepts in the document.
        
        Args:
            extraction_result (dict): The extraction result containing document content
            
        Returns:
            Dictionary representing a graph of concepts and their relationships
        """
        self.extraction_result = extraction_result
        
        # Initialize concept graph structure
        concept_graph = {
            'nodes': [],
            'edges': []
        }
        
        # Extract concepts from the document
        concepts = self._extract_concepts(extraction_result)
        
        # Add concepts as nodes to the graph
        for i, concept in enumerate(concepts):
            concept_node = {
                'id': f"concept_{i}",
                'label': concept['term'],
                'type': concept['type'],
                'frequency': concept['frequency'],
                'locations': concept['locations']
            }
            concept_graph['nodes'].append(concept_node)
            
            # Build index for quick lookup
            self.concept_index[concept['term']] = i
        
        # Build edges between related concepts
        for i, concept_a in enumerate(concepts):
            for j, concept_b in enumerate(concepts):
                if i == j:
                    continue
                
                # Calculate relationship strength between concepts
                relationship = self._calculate_concept_relationship(concept_a, concept_b)
                
                if relationship['strength'] > 0.3:  # Threshold for meaningful relationships
                    edge = {
                        'source': f"concept_{i}",
                        'target': f"concept_{j}",
                        'weight': relationship['strength'],
                        'type': relationship['type']
                    }
                    concept_graph['edges'].append(edge)
        
        self.concept_graph = concept_graph
        return concept_graph
    
    def _extract_concepts(self, extraction_result):
        """
        Extract concepts from document content with positions and types.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            List of concept dictionaries with term, type, frequency, and locations
        """
        concepts = []
        text_content = extraction_result.get('text_content', '')
        
        # First check if domain analysis is available - class-specific logic
        if 'domain_analysis' in extraction_result:
            domain_analysis = extraction_result['domain_analysis']
            domain_entities = domain_analysis.get('domain_entities', {})
            
            # Add domain-specific entities as concepts
            for entity_type, entities in domain_entities.items():
                if isinstance(entities, list):
                    for entity in entities:
                        if isinstance(entity, dict) and 'name' in entity:
                            entity_name = entity['name']
                            concepts.append({
                                'term': entity_name,
                                'type': entity_type,
                                'frequency': self._count_term_occurrences(text_content, entity_name),
                                'locations': self._find_term_locations(text_content, entity_name)
                            })
                        elif isinstance(entity, str):
                            concepts.append({
                                'term': entity,
                                'type': entity_type,
                                'frequency': self._count_term_occurrences(text_content, entity),
                                'locations': self._find_term_locations(text_content, entity)
                            })
        
        # Extract key terms from headings - class-specific logic
        structure = extraction_result.get('document_structure', [])
        heading_terms = set()
        for section in structure:
            if 'heading' in section:
                heading = section['heading']
                # Extract noun phrases from heading
                terms = self._extract_noun_phrases(heading)
                heading_terms.update(terms)
        
        # Add heading terms as concepts
        for term in heading_terms:
            if not any(concept['term'] == term for concept in concepts):
                concepts.append({
                    'term': term,
                    'type': 'heading_term',
                    'frequency': self._count_term_occurrences(text_content, term),
                    'locations': self._find_term_locations(text_content, term)
                })
        
        # Use ContentAnalyzer for core extraction - leverage the core class!
        domain = getattr(self.content_analyzer, 'domain', None)
        analysis_result = self.content_analyzer.extract_keywords_with_positions(text_content, domain)
        
        # Add keywords as concepts
        for term in analysis_result['keywords']:
            if not any(concept['term'] == term for concept in concepts):
                concepts.append({
                    'term': term,
                    'type': 'frequent_term',
                    'frequency': analysis_result['word_frequencies'].get(term, 0),
                    'locations': analysis_result['term_positions'].get(term, [])
                })
                
        # Add bigrams as concepts
        for term in analysis_result.get('bigrams', []):
            if not any(concept['term'] == term for concept in concepts):
                concepts.append({
                    'term': term,
                    'type': 'bigram_term',
                    'frequency': self._count_bigram_frequency(text_content, term),
                    'locations': analysis_result['term_positions'].get(term, [])
                })
        
        return concepts 

    def _count_bigram_frequency(self, text, bigram):
        """Count frequency of a bigram in text"""
        words = text.lower().split()
        count = 0
        bigram_parts = bigram.lower().split()
        
        if len(bigram_parts) != 2:
            return 0
            
        for i in range(len(words) - 1):
            if words[i] == bigram_parts[0] and words[i+1] == bigram_parts[1]:
                count += 1
        
        return count
    
    def _extract_noun_phrases(self, text):
        """
        Extract noun phrases from text.
        
        Args:
            text (str): Text to extract noun phrases from
            
        Returns:
            List of noun phrases
        """
        # Simple implementation using basic patterns
        # In a production environment, you would use a more sophisticated NLP library
        import re
        
        # Pattern for simple noun phrases
        noun_phrase_pattern = re.compile(r'(?:[A-Z][a-z]+\s)?(?:[A-Z][a-z]+\s)?[A-Z]?[a-z]+')
        matches = noun_phrase_pattern.findall(text)
        
        # Filter short phrases and common words
        stop_words = {'the', 'and', 'of', 'to', 'a', 'in', 'for', 'is', 'on', 'that', 'by', 'this', 'with'}
        phrases = [match for match in matches if len(match) > 4 and match.lower() not in stop_words]
        
        return phrases
    
    def _extract_frequent_terms(self, text_content, max_terms=30):
        """
        Extract frequent terms from text content.
        
        Args:
            text_content (str): Text to analyze
            max_terms (int): Maximum number of terms to extract
            
        Returns:
            List of (term, frequency) tuples sorted by frequency
        """
        # Delegate to the content analyzer for core extraction logic
        return self.content_analyzer.extract_frequent_terms(text_content, max_terms)
    
    def _count_term_occurrences(self, text, term):
        return self.content_analyzer.text_processor.count_term_occurrences(text, term)
    
    def _find_term_locations(self, text, term):
        return self.content_analyzer.text_processor.find_term_locations(text, term)
    
    def _calculate_concept_relationship(self, concept_a, concept_b):
        """
        Calculate relationship between two concepts.
        
        Args:
            concept_a (dict): First concept
            concept_b (dict): Second concept
            
        Returns:
            Dictionary with relationship type and strength
        """
        # Calculate co-occurrence proximity
        proximity_score = self._calculate_proximity(concept_a['locations'], concept_b['locations'])
        
        # Check for term similarity
        similarity_score = self._calculate_term_similarity(concept_a['term'], concept_b['term'])
        
        # Check if one is a subterm of the other
        subterm_score = 0
        if concept_a['term'].lower() in concept_b['term'].lower():
            subterm_score = 0.8
        elif concept_b['term'].lower() in concept_a['term'].lower():
            subterm_score = 0.8
        
        # Calculate overall relationship strength
        strength = max(proximity_score, similarity_score, subterm_score)
        
        # Determine relationship type
        relationship_type = 'related'
        if subterm_score > 0:
            relationship_type = 'is_a'
        elif proximity_score > 0.6:
            relationship_type = 'co_occurs'
        elif similarity_score > 0.7:
            relationship_type = 'similar_to'
        
        return {
            'strength': strength,
            'type': relationship_type
        }
    
    def _calculate_proximity(self, locations_a, locations_b, max_distance=500):
        """
        Calculate proximity score based on locations.
        
        Args:
            locations_a (list): List of locations for first term
            locations_b (list): List of locations for second term
            max_distance (int): Maximum distance to consider for proximity
            
        Returns:
            Proximity score between 0 and 1
        """
        if not locations_a or not locations_b:
            return 0
        
        # Find minimum distance between any two locations
        min_distance = float('inf')
        for loc_a in locations_a:
            for loc_b in locations_b:
                distance = abs(loc_a - loc_b)
                min_distance = min(min_distance, distance)
        
        # Convert distance to proximity score
        if min_distance == float('inf') or min_distance > max_distance:
            return 0
        
        return 1 - (min_distance / max_distance)
    
    def _calculate_term_similarity(self, term_a, term_b):
        return self.content_analyzer.keyword_extractor.calculate_term_similarity(term_a, term_b)
    
    def identify_prerequisites(self, sections):
        """
        Determine which sections depend on understanding other sections.
        
        Args:
            sections (list): List of section dictionaries with content
            
        Returns:
            Dictionary mapping section IDs to their prerequisites
        """
        if not sections:
            return {}
        
        prerequisites = {}
        
        # Build terminology dictionary for each section
        section_terms = {}
        for i, section in enumerate(sections):
            section_id = section.get('id', f"section_{i}")
            content = section.get('content', '')
            
            # Extract key terms from this section
            if isinstance(content, str):
                terms = self._extract_key_terms(content)
            else:
                # If content is not a string (e.g., a list or dict), convert it
                content_str = str(content)
                terms = self._extract_key_terms(content_str)
            
            section_terms[section_id] = terms
        
        # For each section, identify which earlier sections introduce terms it uses
        for i, section in enumerate(sections):
            section_id = section.get('id', f"section_{i}")
            content = section.get('content', '')
            
            if not content:
                continue
            
            # Convert content to string if it's not already
            if not isinstance(content, str):
                content = str(content)
            
            # Find terms from previous sections that appear in this section
            section_prerequisites = {}
            
            for j, prior_section in enumerate(sections[:i]):
                prior_id = prior_section.get('id', f"section_{j}")
                prior_terms = section_terms.get(prior_id, [])
                
                # Count how many terms from the prior section appear in this section
                referenced_terms = []
                for term, _ in prior_terms:
                    if term in content and len(term) > 4:  # Minimum length to avoid common words
                        referenced_terms.append(term)
                
                if referenced_terms:
                    section_prerequisites[prior_id] = {
                        'strength': len(referenced_terms) / max(1, len(prior_terms)),
                        'referenced_terms': referenced_terms
                    }
            
            # Store prerequisites with strength above threshold
            filtered_prerequisites = {
                section_id: data
                for section_id, data in section_prerequisites.items()
                if data['strength'] > 0.2  # Threshold for prerequisite relationship
            }
            
            if filtered_prerequisites:
                prerequisites[section_id] = filtered_prerequisites
        
        return prerequisites
    
    def _extract_key_terms(self, text, max_terms=20):
        """
        Extract key terms from text using the ContentAnalyzer.
        
        Args:
            text (str): Text to analyze
            max_terms (int): Maximum number of terms to extract
            
        Returns:
            List of (term, importance) tuples sorted by importance
        """
        # Use the content analyzer for core extraction logic
        return self.content_analyzer.extract_key_terms_with_importance(text, max_terms)
    
    def find_related_content(self, concept, extraction_result):
        """
        Find all content related to a specific concept.
        
        Args:
            concept (str): The concept to find related content for
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary of related content sections
        """
        if not extraction_result:
            return {}
        
        related_content = {
            'sections': [],
            'mentions': [],
            'related_concepts': []
        }
        
        # First, ensure we have built the concept graph
        if not self.concept_graph:
            self.build_concept_graph(extraction_result)
        
        # Find the concept in our index
        concept_id = None
        for i, node in enumerate(self.concept_graph.get('nodes', [])):
            if node['label'].lower() == concept.lower():
                concept_id = node['id']
                break
        
        # If concept not found, try substring matching
        if not concept_id:
            for i, node in enumerate(self.concept_graph.get('nodes', [])):
                if concept.lower() in node['label'].lower() or node['label'].lower() in concept.lower():
                    concept_id = node['id']
                    break
        
        # If still not found, return empty result
        if not concept_id:
            return related_content
        
        # Find all edges connected to this concept
        related_concept_ids = []
        for edge in self.concept_graph.get('edges', []):
            if edge['source'] == concept_id:
                related_concept_ids.append(edge['target'])
            elif edge['target'] == concept_id:
                related_concept_ids.append(edge['source'])
        
        # Get the related concepts
        for node in self.concept_graph.get('nodes', []):
            if node['id'] in related_concept_ids:
                related_concepts = related_content['related_concepts']
                related_concepts.append({
                    'term': node['label'],
                    'type': node['type'],
                    'frequency': node['frequency']
                })
        
        # Get content sections that mention the concept
        text_content = extraction_result.get('text_content', '')
        document_structure = extraction_result.get('document_structure', [])
        
        # Find the concept node
        concept_node = None
        for node in self.concept_graph.get('nodes', []):
            if node['id'] == concept_id:
                concept_node = node
                break
        
        if concept_node:
            concept_term = concept_node['label']
            
            # Find all sections that mention the concept
            for section in document_structure:
                section_content = section.get('content', '')
                if not isinstance(section_content, str):
                    section_content = str(section_content)
                
                if concept_term.lower() in section_content.lower():
                    related_content['sections'].append({
                        'heading': section.get('heading', 'Untitled Section'),
                        'level': section.get('level', 1),
                        'content_preview': self._get_context_around_term(section_content, concept_term)
                    })
            
            # Find specific mentions with context
            related_content['mentions'] = self._find_mentions_with_context(text_content, concept_term)
        
        return related_content
    
    def _get_context_around_term(self, text, term, context_size=100):
        """
        Get text context around a term.
        
        Args:
            text (str): The text to search in
            term (str): The term to find context for
            context_size (int): Number of characters around the term
            
        Returns:
            String with context
        """
        import re
        
        # Find all occurrences of the term
        matches = list(re.finditer(r'\b' + re.escape(term) + r'\b', text, re.IGNORECASE))
        
        if not matches:
            return ""
        
        # Use the first occurrence
        match = matches[0]
        start_pos = max(0, match.start() - context_size)
        end_pos = min(len(text), match.end() + context_size)
        
        # Extract context
        context = text[start_pos:end_pos]
        
        # Add ellipsis if needed
        if start_pos > 0:
            context = "..." + context
        if end_pos < len(text):
            context = context + "..."
        
        return context
    
    def _find_mentions_with_context(self, text, term, max_mentions=5, context_size=100):
        """
        Find mentions of a term with surrounding context.
        
        Args:
            text (str): The text to search in
            term (str): The term to find mentions of
            max_mentions (int): Maximum number of mentions to return
            context_size (int): Number of characters around each mention
            
        Returns:
            List of mention dictionaries with context
        """
        import re
        
        # Find all occurrences of the term
        pattern = r'\b' + re.escape(term) + r'\b'
        matches = list(re.finditer(pattern, text, re.IGNORECASE))
        
        mentions = []
        for match in matches[:max_mentions]:
            start_pos = max(0, match.start() - context_size)
            end_pos = min(len(text), match.end() + context_size)
            
            # Extract context
            context = text[start_pos:end_pos]
            
            # Add ellipsis if needed
            if start_pos > 0:
                context = "..." + context
            if end_pos < len(text):
                context = context + "..."
            
            mentions.append({
                'position': match.start(),
                'context': context
            })
        
        return mentions
    
    def create_dependency_tree(self, extraction_result):
        """
        Build a tree showing how concepts build upon each other.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary representing a dependency tree of concepts
        """
        # Ensure we have built the concept graph
        if not self.concept_graph:
            self.build_concept_graph(extraction_result)
        
        # Create dependency tree structure
        dependency_tree = {
            'nodes': [],
            'links': []
        }
        
        # Use document structure to identify concept ordering
        document_structure = extraction_result.get('document_structure', [])
        
        # Extract concepts in order of appearance
        ordered_concepts = []
        for section in document_structure:
            section_content = section.get('content', '')
            if not isinstance(section_content, str):
                section_content = str(section_content)
            
            # Find concepts mentioned in this section
            section_concepts = []
            for node in self.concept_graph.get('nodes', []):
                concept_term = node['label']
                if concept_term.lower() in section_content.lower():
                    section_concepts.append({
                        'id': node['id'],
                        'term': concept_term,
                        'first_position': section_content.lower().find(concept_term.lower())
                    })
            
            # Sort concepts by order of appearance
            section_concepts.sort(key=lambda x: x['first_position'])
            
            # Add to ordered concepts
            ordered_concepts.extend(section_concepts)
        
        # Remove duplicates while preserving order
        seen_concepts = set()
        ordered_concepts_unique = []
        for concept in ordered_concepts:
            if concept['id'] not in seen_concepts:
                seen_concepts.add(concept['id'])
                ordered_concepts_unique.append(concept)
        
        # Build the dependency tree
        # The tree is built based on concept ordering and relationships
        for i, concept in enumerate(ordered_concepts_unique):
            # Add node to tree
            dependency_tree['nodes'].append({
                'id': concept['id'],
                'label': concept['term'],
                'level': self._determine_concept_level(concept, ordered_concepts_unique[:i])
            })
            
            # Link to prerequisite concepts
            prerequisites = self._identify_concept_prerequisites(concept, ordered_concepts_unique[:i])
            for prereq in prerequisites:
                dependency_tree['links'].append({
                    'source': prereq['id'],
                    'target': concept['id'],
                    'strength': prereq['strength']
                })
        
        self.dependency_tree = dependency_tree
        return dependency_tree
    
    def _determine_concept_level(self, concept, prior_concepts):
        """
        Determine the hierarchy level of a concept.
        
        Args:
            concept (dict): The concept to determine level for
            prior_concepts (list): List of concepts that appear earlier
            
        Returns:
            Integer level (1 is highest level, higher numbers are more specific/dependent)
        """
        # If no prior concepts, this is a root concept (level 1)
        if not prior_concepts:
            return 1
        
        # Check if this concept is a subterm of any prior concept
        for prior in prior_concepts:
            # If this concept is a more specific version of a prior concept, increase level
            if concept['term'].lower() != prior['term'].lower() and concept['term'].lower() in prior['term'].lower():
                return 2
            
            # If this concept contains a prior concept, it might be a higher level concept
            if prior['term'].lower() in concept['term'].lower():
                return 1
        
        # Default level based on position
        return min(3, 1 + len(prior_concepts) // 5)
    
    def _identify_concept_prerequisites(self, concept, prior_concepts, max_prereqs=3):
        """
        Identify prerequisite concepts for a given concept.
        
        Args:
            concept (dict): The concept to find prerequisites for
            prior_concepts (list): List of concepts that appear earlier
            max_prereqs (int): Maximum number of prerequisites to identify
            
        Returns:
            List of prerequisite concepts with strength scores
        """
        if not prior_concepts:
            return []
        
        prerequisites = []
        
        # Calculate relationship strengths with prior concepts
        for prior in prior_concepts:
            # Skip if same concept
            if concept['id'] == prior['id']:
                continue
            
            # Calculate relationship strength
            term_similarity = self._calculate_term_similarity(concept['term'], prior['term'])
            
            # Check if prior concept is contained in this concept
            subterm_score = 0
            if prior['term'].lower() in concept['term'].lower():
                subterm_score = 0.7
            
            # Check if concepts are connected in the concept graph
            graph_connection = 0
            for edge in self.concept_graph.get('edges', []):
                if (edge['source'] == concept['id'] and edge['target'] == prior['id']) or \
                   (edge['target'] == concept['id'] and edge['source'] == prior['id']):
                    graph_connection = edge['weight']
                    break
            
            # Calculate overall prerequisite strength
            strength = max(term_similarity * 0.5, subterm_score, graph_connection)
            
            if strength > 0.3:  # Threshold for prerequisite relationship
                prerequisites.append({
                    'id': prior['id'],
                    'term': prior['term'],
                    'strength': strength
                })
        
        # Sort by strength and return top prerequisites
        prerequisites.sort(key=lambda x: x['strength'], reverse=True)
        return prerequisites[:max_prereqs]