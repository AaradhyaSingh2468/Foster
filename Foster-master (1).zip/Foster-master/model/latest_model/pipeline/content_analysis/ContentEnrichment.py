from pipeline.content_analysis.ContentAnalyzer import ContentAnalyzer
import re
from collections import defaultdict

class ContentEnrichmentProcessor:
    def __init__(self, knowledge_base=None, content_analyzer=None):
        # Initialize with optional knowledge base
        self.knowledge_base = knowledge_base
        # Use composition to leverage ContentAnalyzer
        self.content_analyzer = content_analyzer if content_analyzer else ContentAnalyzer()
        
    def enrich_content(self, extraction_result):
        # Add contextual information to extraction result
        # Handle both dict and object types
        if hasattr(extraction_result, 'copy'):
            enriched_result = extraction_result.copy()
        elif isinstance(extraction_result, dict):
            enriched_result = extraction_result.copy()
        else:
            enriched_result = extraction_result
        
        # Extract concepts and terms for enrichment
        concepts = self.extract_concepts(enriched_result)
        
        # Add explanations for complex terms
        enriched_result = self.generate_explanations(enriched_result, concepts)
        
        # Add cross-references between related sections
        enriched_result = self.add_cross_references(enriched_result)
        
        # Suggest additional learning resources
        enriched_result = self.suggest_learning_resources(enriched_result, concepts)
        
        return enriched_result
        
    def extract_concepts(self, extraction_result):
        """Extract key concepts and terms from the extraction result with knowledge base enrichment"""
        concepts = []
        
        # Check if there's content to analyze
        if not extraction_result:
            return concepts
            
        # Get content text from extraction result
        text = self._extract_text_from_result(extraction_result)
        if not text:
            return concepts
            
        # Use ContentAnalyzer to extract keywords - leverage the core class!
        analysis_result = self.content_analyzer.extract_keywords_and_concepts(text)
        
        # Get keywords from the analysis result
        if isinstance(analysis_result, dict) and 'keywords' in analysis_result:
            # Handle case where keywords are returned as tuples of (word, frequency)
            if analysis_result['keywords'] and isinstance(analysis_result['keywords'][0], tuple):
                concepts = [keyword[0] for keyword in analysis_result['keywords']]
            else:
                concepts = analysis_result['keywords']
        
        # Add domain-specific enrichment
        if self.knowledge_base:
            # Filter concepts based on domain knowledge
            domain_concepts = []
            for concept in concepts:
                # Check if concept exists in our knowledge base
                if concept in self.knowledge_base:
                    # Prioritize concepts that are in our knowledge base
                    domain_concepts.append(concept)
            
            # Add specialized domain concepts from knowledge base that might be relevant
            for key in self.knowledge_base:
                # If term is in the text but wasn't caught by frequency analysis
                if key.lower() in text.lower() and key not in concepts:
                    domain_concepts.append(key)
            
            # If we found domain-specific concepts, prioritize them
            if domain_concepts:
                # Combine domain concepts with general concepts, prioritizing domain ones
                remaining_slots = max(20 - len(domain_concepts), 0)
                general_concepts = [c for c in concepts if c not in domain_concepts]
                concepts = domain_concepts + general_concepts[:remaining_slots]
        
        # Process multi-word concepts (which may not be caught by frequency analysis)
        section_titles = self._extract_section_titles(extraction_result)
        if section_titles:
            for title in section_titles:
                # Extract potential multi-word concepts
                matches = re.findall(r'[A-Z][a-z]+(?:\s+[a-z]+){1,3}', title)
                for match in matches:
                    if match.lower() in text.lower() and match not in concepts:
                        concepts.append(match)
        
        return concepts
    
    def _extract_text_from_result(self, extraction_result):
        """Helper method to extract text content from different extraction result formats"""
        if hasattr(extraction_result, 'content'):
            content = extraction_result.content
            return ' '.join(content) if isinstance(content, list) else content
        elif isinstance(extraction_result, dict):
            if 'content' in extraction_result:
                content = extraction_result['content']
                return ' '.join(content) if isinstance(content, list) else content
            elif 'text_content' in extraction_result:
                return extraction_result['text_content']
            elif 'sections' in extraction_result:
                # Extract text from sections
                sections_text = []
                for section in extraction_result['sections']:
                    if isinstance(section, dict):
                        if 'content' in section:
                            sections_text.append(section['content'])
                        elif 'text' in section:
                            sections_text.append(section['text'])
                return ' '.join(sections_text)
        return ""
    
    def _extract_section_titles(self, extraction_result):
        """Helper method to extract section titles from different extraction result formats"""
        section_titles = []
        
        if hasattr(extraction_result, 'sections'):
            for section in extraction_result.sections:
                if hasattr(section, 'title'):
                    section_titles.append(section.title)
                elif isinstance(section, dict) and 'title' in section:
                    section_titles.append(section['title'])
        elif isinstance(extraction_result, dict) and 'sections' in extraction_result:
            for section in extraction_result['sections']:
                if isinstance(section, dict) and 'title' in section:
                    section_titles.append(section['title'])
        
        return section_titles
        
    def generate_explanations(self, extraction_result, complex_terms):
        """Generate explanations for complex terms or concepts"""
        # Handle both object and dictionary access patterns
        if hasattr(extraction_result, 'explanations'):
            explanations = extraction_result.explanations
        elif isinstance(extraction_result, dict):
            if 'explanations' not in extraction_result:
                extraction_result['explanations'] = {}
            explanations = extraction_result['explanations']
        else:
            # If it's not a dict or doesn't have explanations attribute, attach one
            extraction_result.explanations = {}
            explanations = extraction_result.explanations
            
        for term in complex_terms:
            if self.knowledge_base and term in self.knowledge_base:
                explanations[term] = self.knowledge_base[term]
            else:
                # Generate explanation based on surrounding context
                context = self._find_term_context(self._extract_text_from_result(extraction_result), term)
                if context:
                    explanations[term] = f"Based on context: {context}"
                else:
                    explanations[term] = f"Term related to the document's subject matter"
                
        return extraction_result
    
    def _find_term_context(self, text, term, window_size=100):
        """Find a term in text and return surrounding context"""
        if not text or not term:
            return ""
            
        pattern = re.compile(r'\b' + re.escape(term) + r'\b', re.IGNORECASE)
        match = pattern.search(text)
        
        if not match:
            return ""
            
        start = max(0, match.start() - window_size)
        end = min(len(text), match.end() + window_size)
        
        # Get context and format it
        context = text[start:end].strip()
        if start > 0:
            context = "..." + context
        if end < len(text):
            context = context + "..."
            
        return context
        
    def add_cross_references(self, extraction_result):
        """Add references to related sections within the document"""
        # Handle both object and dictionary access patterns
        if hasattr(extraction_result, 'cross_references'):
            cross_references = extraction_result.cross_references
        elif isinstance(extraction_result, dict):
            if 'cross_references' not in extraction_result:
                extraction_result['cross_references'] = {}
            cross_references = extraction_result['cross_references']
        else:
            # If it's not a dict or doesn't have cross_references attribute, attach one
            extraction_result.cross_references = {}
            cross_references = extraction_result.cross_references
            
        # Build section index
        sections = {}
        if hasattr(extraction_result, 'sections'):
            for i, section in enumerate(extraction_result.sections):
                # Extract key terms from section
                if hasattr(section, 'title'):
                    section_title = section.title
                    section_content = section.content if hasattr(section, 'content') else ""
                elif isinstance(section, dict):
                    section_title = section.get('title', f"Section {i}")
                    section_content = section.get('content', '')
                else:
                    continue
                    
                sections[section_title] = {
                    'index': i,
                    'content': section_content,
                    'key_terms': self._extract_key_terms_from_text(section_content)
                }
        elif isinstance(extraction_result, dict) and 'sections' in extraction_result:
            for i, section in enumerate(extraction_result['sections']):
                if isinstance(section, dict):
                    section_title = section.get('title', f"Section {i}")
                    section_content = section.get('content', '')
                    sections[section_title] = {
                        'index': i,
                        'content': section_content,
                        'key_terms': self._extract_key_terms_from_text(section_content)
                    }
        
        # Find cross-references between sections based on shared key terms
        for title, section_data in sections.items():
            related_sections = []
            for other_title, other_data in sections.items():
                if title != other_title:
                    # Check for shared key terms
                    shared_terms = set(section_data['key_terms']) & set(other_data['key_terms'])
                    if shared_terms and len(shared_terms) >= 2:  # Require at least 2 shared terms
                        related_sections.append({
                            'title': other_title,
                            'index': other_data['index'],
                            'shared_terms': list(shared_terms)
                        })
            
            if related_sections:
                cross_references[title] = sorted(
                    related_sections, 
                    key=lambda x: len(x['shared_terms']), 
                    reverse=True
                )
                
        return extraction_result
    
    def _extract_key_terms_from_text(self, text):
        """Extract key terms from a section's text"""
        if not text:
            return []
            
        # Use ContentAnalyzer to extract terms
        analysis_result = self.content_analyzer.extract_keywords_and_concepts(text, max_terms=10)
        
        # Get keywords from the analysis result
        if isinstance(analysis_result, dict) and 'keywords' in analysis_result:
            # Handle case where keywords are returned as tuples of (word, frequency)
            if analysis_result['keywords'] and isinstance(analysis_result['keywords'][0], tuple):
                return [keyword[0] for keyword in analysis_result['keywords']]
            else:
                return analysis_result['keywords']
        
        return []
        
    def suggest_learning_resources(self, extraction_result, concepts):
        """Suggest additional resources for understanding concepts"""
        # Handle both object and dictionary access patterns
        if hasattr(extraction_result, 'learning_resources'):
            learning_resources = extraction_result.learning_resources
        elif isinstance(extraction_result, dict):
            if 'learning_resources' not in extraction_result:
                extraction_result['learning_resources'] = {}
            learning_resources = extraction_result['learning_resources']
        else:
            # If it's not a dict or doesn't have learning_resources attribute, attach one
            extraction_result.learning_resources = {}
            learning_resources = extraction_result.learning_resources
        
        # Map concepts to resource types based on their characteristics
        resource_types = {
            'article': ['introduction', 'overview', 'guide'],
            'video': ['tutorial', 'demonstration', 'explanation'],
            'interactive': ['exercise', 'practice', 'quiz']
        }
        
        # For a real implementation, would connect to a resource database
        # Generate more realistic resource suggestions based on concept
        for concept in concepts[:5]:  # Limit to top 5 concepts
            resources = []
            
            # Generate different types of resources
            for resource_type, prefixes in resource_types.items():
                # Choose a prefix randomly for variety
                import random
                prefix = random.choice(prefixes)
                
                # Generate a resource with realistic URL patterns
                concept_slug = concept.lower().replace(' ', '-')
                
                if resource_type == 'article':
                    resources.append({
                        'title': f"{prefix.capitalize()} to {concept.capitalize()}",
                        'type': resource_type,
                        'url': f"https://learn.example.com/articles/{concept_slug}",
                        'description': f"A comprehensive {prefix} covering the fundamentals of {concept}"
                    })
                elif resource_type == 'video':
                    resources.append({
                        'title': f"{concept.capitalize()} {prefix} video",
                        'type': resource_type,
                        'url': f"https://example.com/videos/{concept_slug}",
                        'duration': f"{random.randint(5, 20)} min",
                        'description': f"Visual {prefix} of {concept} with examples"
                    })
                elif resource_type == 'interactive':
                    resources.append({
                        'title': f"{concept.capitalize()} {prefix}",
                        'type': resource_type,
                        'url': f"https://practice.example.com/{prefix}/{concept_slug}",
                        'estimated_time': f"{random.randint(10, 30)} min",
                        'description': f"Hands-on {prefix} to test your understanding of {concept}"
                    })
            
            learning_resources[concept] = resources
            
        return extraction_result