import cv2
import numpy as np
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
from PIL import Image
import pytesseract
from typing import Dict, List, Tuple, Any, Optional
import logging
import os
import traceback

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("visualization_extractor.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("VisualizationElementExtractor")

# Configuration class for settings
class Config:
    """Configuration settings for visualization extraction"""
    # Threshold values
    MIN_CONTOUR_AREA_RATIO = 0.001
    MIN_CIRCULAR_AREA = 10
    MAX_CIRCULAR_AREA_RATIO = 0.05
    CIRCULARITY_MIN = 0.6
    CIRCULARITY_MAX = 1.4
    
    # Detector parameters
    CANNY_THRESHOLD1 = 50
    CANNY_THRESHOLD2 = 150
    HOUGH_THRESHOLD = 30
    HOUGH_MIN_LINE_LENGTH_RATIO = 0.05
    HOUGH_MAX_LINE_GAP = 20
    
    # Preprocessing parameters
    GAUSSIAN_KERNEL_SIZE = (5, 5)
    GAUSSIAN_SIGMA = 0
    
    # Visualization settings
    MAX_VISUALIZATION_DIM = 1200
    
    # OCR settings
    OCR_CONFIG = "--psm 11"


class VisualizationElementExtractor:
    """
    A class focused on identifying and processing visual elements beyond just images in PDFs.
    This includes diagrams, charts, graphs, and understanding their relationships with text.
    """
    
    def __init__(self, ocr_engine=None, diagram_classifier=None):
        """
        Initialize visualization analysis tools.
        
        Args:
            ocr_engine: Optional OCR engine to use (defaults to pytesseract if None)
            diagram_classifier: Optional pre-trained classifier for diagram types
        """
        self.ocr_engine = ocr_engine or pytesseract
        self.diagram_classifier = diagram_classifier
        logger.info("VisualizationElementExtractor initialized")
        
    def extract_diagrams(self, extraction_result: Dict) -> Dict:
        """
        Identify and classify diagrams (flow charts, process diagrams, etc.)
        
        Args:
            extraction_result: Dictionary containing PDF extraction results
            
        Returns:
            Dictionary with identified diagrams and their classification
        """
        try:
            logger.info("Starting diagram extraction")
            diagrams = []
            
            for idx, image_info in enumerate(extraction_result.get('images', [])):
                image = image_info.get('image_data')
                if image is None:
                    logger.warning(f"Image data is None for image index {idx}")
                    continue
                    
                # Determine if the image is a diagram
                if self._is_diagram(image):
                    try:
                        diagram_type = self._classify_diagram(image)
                        diagram_text = self._extract_diagram_text(image)
                        diagram_components = self._identify_diagram_components(image)
                        
                        diagrams.append({
                            'id': f"diagram_{idx}",
                            'page_num': image_info.get('page_num'),
                            'position': image_info.get('position'),
                            'type': diagram_type,
                            'text': diagram_text,
                            'components': diagram_components,
                            'connections': self._extract_component_connections(image, diagram_components)
                        })
                        logger.info(f"Extracted diagram of type {diagram_type} from image {idx}")
                    except Exception as e:
                        logger.error(f"Error processing diagram {idx}: {str(e)}")
                        logger.debug(traceback.format_exc())
            
            # Add diagrams to the extraction result
            extraction_result['diagrams'] = diagrams
            logger.info(f"Completed diagram extraction. Found {len(diagrams)} diagrams")
            return extraction_result
        except Exception as e:
            logger.error(f"Error in extract_diagrams: {str(e)}")
            logger.debug(traceback.format_exc())
            # In production, we should return the original result with an error flag
            # rather than raising the exception
            extraction_result['error'] = str(e)
            extraction_result['diagrams'] = []
            return extraction_result
    
    def analyze_figures(self, extraction_result: Dict) -> Dict:
        """
        Analyze figures, charts, and graphs to extract data and meaning.
        
        Args:
            extraction_result: Dictionary containing PDF extraction results
            
        Returns:
            Dictionary with analyzed figures and their data
        """
        figures = []
        
        for idx, image_info in enumerate(extraction_result.get('images', [])):
            image = image_info.get('image_data')
            if image is None:
                continue
                
            # Check if image is a chart or graph
            visualization_type = self.classify_visualization_types(image)
            
            if visualization_type in ['chart', 'graph', 'plot']:
                figure_data = {
                    'id': f"figure_{idx}",
                    'page_num': image_info.get('page_num'),
                    'position': image_info.get('position'),
                    'type': visualization_type,
                    'subtype': self._get_chart_subtype(image, visualization_type),
                    'axes_labels': self._extract_axes_labels(image),
                    'legend_items': self._extract_legend(image),
                    'data_points': self._extract_data_points(image, visualization_type),
                    'chart_title': self._extract_chart_title(image)
                }
                figures.append(figure_data)
        
        # Add figures to the extraction result
        extraction_result['figures'] = figures
        return extraction_result
    
    def extract_visual_relationships(self, extraction_result: Dict) -> Dict:
        """
        Understand relationships between visuals and text in the document.
        
        Args:
            extraction_result: Dictionary containing PDF extraction results
            
        Returns:
            Dictionary with visual-text relationships identified
        """
        visual_relationships = []
        
        # Get all visual elements (images, diagrams, figures)
        visuals = (
            extraction_result.get('images', []) + 
            extraction_result.get('diagrams', []) + 
            extraction_result.get('figures', [])
        )
        
        text_blocks = extraction_result.get('text_blocks', [])
        
        for visual in visuals:
            page_num = visual.get('page_num')
            visual_position = visual.get('position')
            
            # Skip if missing critical information
            if not page_num or not visual_position:
                continue
            
            # Find related text based on proximity and references
            related_text = self._find_related_text(visual, text_blocks, page_num)
            
            # Determine relationship type (caption, explanation, reference)
            relationship_type = self._determine_relationship_type(visual, related_text)
            
            visual_relationships.append({
                'visual_id': visual.get('id'),
                'visual_type': visual.get('type', 'image'),
                'page_num': page_num,
                'related_text_blocks': related_text,
                'relationship_type': relationship_type,
                'visual_context': self._extract_visual_context(visual, related_text)
            })
        
        # Add visual relationships to the extraction result
        extraction_result['visual_relationships'] = visual_relationships
        return extraction_result
    
    def classify_visualization_types(self, image: np.ndarray) -> str:
        """
        Determine the type of visualization (chart, diagram, graph, etc.)
        
        Args:
            image: Image data as numpy array
            
        Returns:
            String identifying the visualization type
        """
        # Convert to grayscale if it's not already
        if len(image.shape) > 2 and image.shape[2] > 1:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Extract features that help identify visualization type
        edge_density = self._calculate_edge_density(gray)
        text_density = self._calculate_text_density(image)
        has_grid_lines = self._detect_grid_lines(gray)
        color_variety = self._calculate_color_variety(image)
        
        # Use features to classify
        if edge_density > 0.15 and edge_density < 0.3 and text_density < 0.1:
            if has_grid_lines:
                return "chart"
            else:
                return "diagram"
        elif has_grid_lines and text_density > 0.1:
            return "graph"
        elif color_variety > 20 and text_density < 0.05:
            return "illustration"
        elif text_density > 0.2:
            return "text_with_visuals"
        else:
            return "image"
    
    def _is_diagram(self, image: np.ndarray) -> bool:
        """
        Determine if an image is likely a diagram rather than a photo or other image type.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            Boolean indicating if the image is likely a diagram
        """
        # Convert to grayscale if needed
        if len(image.shape) > 2 and image.shape[2] > 1:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Calculate features indicative of diagrams
        edge_density = self._calculate_edge_density(gray)
        color_count = self._count_distinct_colors(image)
        text_regions = self._count_text_regions(image)
        
        # Diagrams typically have:
        # 1. High edge density
        # 2. Limited color palette
        # 3. Multiple text regions
        return edge_density > 0.1 and color_count < 20 and text_regions > 3
    
    def _classify_diagram(self, image: np.ndarray) -> str:
        """
        Classify the type of diagram.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            String identifying the diagram type
        """
        # If a pre-trained classifier was provided, use it
        if self.diagram_classifier:
            return self.diagram_classifier.predict(image)
        
        # Otherwise use heuristics to classify
        # Convert to grayscale if needed
        if len(image.shape) > 2 and image.shape[2] > 1:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Detect lines in the image
        edges = cv2.Canny(gray, 50, 150)
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=50, maxLineGap=10)
        
        if lines is None:
            return "unknown_diagram"
            
        # Count horizontal, vertical, and diagonal lines
        h_lines, v_lines, d_lines = 0, 0, 0
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = np.abs(np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi)
            
            if angle < 10 or angle > 170:
                h_lines += 1
            elif 80 < angle < 100:
                v_lines += 1
            else:
                d_lines += 1
        
        # Extract text to look for keywords
        text = self._extract_diagram_text(image).lower()
        
        # Classify based on features
        if "flow" in text or "process" in text or (h_lines > 5 and v_lines > 5 and d_lines > 5):
            return "flowchart"
        elif "class" in text or "uml" in text or (h_lines > 10 and v_lines > 10 and d_lines < 5):
            return "uml_diagram"
        elif "entity" in text or "relationship" in text or (h_lines > 10 and v_lines > 10):
            return "er_diagram"
        elif "network" in text or "topology" in text or (d_lines > h_lines + v_lines):
            return "network_diagram"
        elif "sequence" in text or (h_lines > v_lines and d_lines < 5):
            return "sequence_diagram"
        else:
            return "general_diagram"
    
    def _extract_diagram_text(self, image: np.ndarray) -> str:
        """
        Extract text from a diagram using OCR.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            String containing extracted text
        """
        # Use the OCR engine to extract text
        if isinstance(self.ocr_engine, type(pytesseract)):
            text = pytesseract.image_to_string(Image.fromarray(image))
        else:
            # Assuming the OCR engine has a compatible interface
            text = self.ocr_engine.extract_text(image)
            
        return text
    
    def _identify_diagram_components(self, image: np.ndarray) -> List[Dict]:
        """
        Identify components within a diagram (boxes, circles, arrows, etc.)
        
        Args:
            image: Image data as numpy array
            
        Returns:
            List of dictionaries containing component information
        """
        components = []
        
        # Convert to grayscale if needed
        if len(image.shape) > 2 and image.shape[2] > 1:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Threshold the image
        _, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for i, contour in enumerate(contours):
            # Skip small contours
            if cv2.contourArea(contour) < 100:
                continue
                
            # Get bounding box
            x, y, w, h = cv2.boundingRect(contour)
            
            # Determine shape type
            shape_type = self._identify_shape(contour)
            
            # Extract text within the component
            component_image = image[y:y+h, x:x+w]
            component_text = self._extract_diagram_text(component_image)
            
            components.append({
                'id': f"component_{i}",
                'type': shape_type,
                'position': {'x': int(x), 'y': int(y), 'width': int(w), 'height': int(h)},
                'text': component_text
            })
            
        return components
    
    def _extract_component_connections(self, image: np.ndarray, components: List[Dict]) -> List[Dict]:
        """
        Extract connections between diagram components (arrows, lines).
        
        Args:
            image: Image data as numpy array
            components: List of identified components
            
        Returns:
            List of dictionaries describing connections between components
        """
        connections = []
        
        # Convert to grayscale if needed
        if len(image.shape) > 2 and image.shape[2] > 1:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Create a mask excluding components to isolate lines/arrows
        mask = np.ones_like(gray) * 255
        
        for component in components:
            pos = component['position']
            x, y, w, h = pos['x'], pos['y'], pos['width'], pos['height']
            mask[y:y+h, x:x+w] = 0
            
        # Apply mask to the grayscale image
        masked_gray = cv2.bitwise_and(gray, mask)
        
        # Detect edges and lines
        edges = cv2.Canny(masked_gray, 50, 150)
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=30, minLineLength=30, maxLineGap=10)
        
        if lines is None:
            return connections
        
        # Group line segments that likely form a single connection
        grouped_lines = self._group_line_segments(lines)
        
        for i, line_group in enumerate(grouped_lines):
            # Determine start and end points
            start_point, end_point = self._get_line_endpoints(line_group)
            
            # Find components connected by this line
            start_component = self._find_closest_component(start_point, components)
            end_component = self._find_closest_component(end_point, components)
            
            if start_component and end_component and start_component != end_component:
                # Determine if it's an arrow and its direction
                is_arrow, direction = self._check_arrow_properties(line_group, gray)
                
                connections.append({
                    'id': f"connection_{i}",
                    'from_component': start_component,
                    'to_component': end_component,
                    'type': 'arrow' if is_arrow else 'line',
                    'direction': direction if is_arrow else None,
                    'path': [{'x': int(x1), 'y': int(y1), 'x2': int(x2), 'y2': int(y2)} 
                            for x1, y1, x2, y2 in line_group]
                })
        
        return connections
    
    def _get_chart_subtype(self, image: np.ndarray, visualization_type: str) -> str:
        """
        Determine the specific subtype of a chart based on visualization type.
        
        Args:
            image: Image data as numpy array
            visualization_type: Base visualization type
            
        Returns:
            String indicating chart subtype
        """
        if 'bar' in visualization_type:
            # Check for horizontal orientation
            if self._detect_horizontal_orientation(image):
                return 'horizontal_bar'
                
            # Check for stacked bars
            if self._detect_stacked_bars(image):
                return 'stacked_bar'
                
            # Check for grouped bars
            if self._detect_grouped_bars(image):
                return 'grouped_bar'
                
            return 'bar_chart'  # Default
            
        elif 'line' in visualization_type:
            # Check for multiple lines
            color_variety = self._calculate_color_variety(image)
            
            # Check for area chart
            if self._detect_filled_area(image):
                return 'area_chart'
                
            if color_variety > 3:
                return 'multi_line'
                
            return 'line_chart'  # Default
            
        elif 'pie' in visualization_type:
            # Check for donut chart
            if self._detect_donut(image):
                return 'donut_chart'
                
            return 'pie_chart'  # Default
            
        elif 'scatter' in visualization_type:
            # Check for bubble chart
            if self._detect_bubble_sizes(image):
                return 'bubble_chart'
                
            # Check for connected scatter
            if self._detect_lines(image):
                return 'connected_scatter'
                
            return 'scatter_plot'  # Default
        
        # Return base type for other visualizations
        return visualization_type
        
    def _detect_horizontal_orientation(self, image: np.ndarray) -> bool:
        """
        Detect if a bar chart has horizontal orientation.
        
        Args:
            image: Image data
            
        Returns:
            True if horizontal orientation detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply edge detection
        edges = cv2.Canny(gray, 50, 150)
        
        # Calculate horizontal and vertical projections
        h_projection = np.sum(edges, axis=1)
        v_projection = np.sum(edges, axis=0)
        
        # Analyze signal characteristics
        h_signal = np.var(h_projection)
        v_signal = np.var(v_projection)
        
        # Horizontal bars create stronger vertical edges
        return v_signal > h_signal * 1.2
        
    def _calculate_color_variety(self, image: np.ndarray) -> int:
        """
        Calculate the number of distinct colors in an image.
        
        Args:
            image: Image data
            
        Returns:
            Estimated number of distinct colors
        """
        # If grayscale, return 1
        if len(image.shape) == 2:
            return 1
            
        # Downsample image for efficiency
        small = cv2.resize(image, (100, 100))
        
        # Reshape for k-means
        pixels = small.reshape(-1, 3).astype(np.float32)
        
        # Use k-means to find clusters of colors
        k = 8  # Max number of colors to detect
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
        _, labels, centers = cv2.kmeans(pixels, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        
        # Count significant color clusters (>5% of pixels)
        unique, counts = np.unique(labels, return_counts=True)
        significant = sum(1 for count in counts if count > pixels.shape[0] * 0.05)
        
        return significant
        
    def _detect_nodes(self, image: np.ndarray) -> bool:
        """
        Detect if image contains nodes (e.g., for scatter plots, networks).
        
        Args:
            image: Image data
            
        Returns:
            True if nodes detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Apply binary threshold
        _, thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY)
        
        # Set up blob detector parameters
        params = cv2.SimpleBlobDetector_Params()
        params.filterByArea = True
        params.minArea = 10
        params.maxArea = 500
        params.filterByCircularity = True
        params.minCircularity = 0.7
        
        # Create detector
        detector = cv2.SimpleBlobDetector_create(params)
        
        # Detect blobs
        keypoints = detector.detect(thresh)
        
        # Return True if significant number of circular blobs found
        return len(keypoints) > 5
        
    def _detect_lines(self, image: np.ndarray) -> bool:
        """
        Detect if image contains significant line segments.
        
        Args:
            image: Image data
            
        Returns:
            True if lines detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply edge detection
        edges = cv2.Canny(gray, 50, 150, apertureSize=3)
        
        # Use Hough Line Transform
        lines = cv2.HoughLinesP(
            edges, 1, np.pi/180, threshold=30, 
            minLineLength=max(gray.shape) * 0.1, 
            maxLineGap=20
        )
        
        # Return True if enough line segments found
        return lines is not None and len(lines) > 5
        
    def _detect_scatter_points(self, image: np.ndarray) -> bool:
        """
        Detect if image contains scatter plot points.
        
        Args:
            image: Image data
            
        Returns:
            True if scatter points detected, False otherwise
        """
        try:
            # Convert to grayscale if needed
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
                
            # Apply Gaussian blur
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            # Apply binary threshold
            _, thresh = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY_INV)
            
            # Find contours
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Count small, roughly circular contours
            scatter_points = 0
            for contour in contours:
                area = cv2.contourArea(contour)
                if area < 200 and area > 10:  # Small but not too small
                    perimeter = cv2.arcLength(contour, True)
                    circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
                    if 0.6 < circularity < 1.4:  # Fairly circular
                        scatter_points += 1
            
            # Return True if significant number of scatter points found
            return scatter_points > 10
        except Exception as e:
            logger.error(f"Error in _detect_scatter_points: {str(e)}")
            logger.debug(traceback.format_exc())
            return False
        
    def _detect_bars(self, image: np.ndarray) -> bool:
        """
        Detect if image contains bars (for bar charts).
        
        Args:
            image: Image data
            
        Returns:
            True if bars detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply binary threshold
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Count rectangular shapes
        bar_count = 0
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < thresh.size * 0.5 and area > thresh.size * 0.001:  # Reasonable size
                x, y, w, h = cv2.boundingRect(contour)
                aspect_ratio = float(w) / h if h > 0 else 0
                # Bars typically have aspect ratio far from 1
                if aspect_ratio > 3 or aspect_ratio < 0.33:
                    # Verify the shape is rectangular
                    rect_area = w * h
                    if area / rect_area > 0.8:  # Fills at least 80% of bounding rectangle
                        bar_count += 1
        
        # Return True if significant number of bars found
        return bar_count > 3
        
    def _detect_stacked_bars(self, image: np.ndarray) -> bool:
        """
        Detect if image contains stacked bars.
        
        Args:
            image: Image data
            
        Returns:
            True if stacked bars detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply edge detection
        edges = cv2.Canny(gray, 50, 150)
        
        # Find contours
        contours, hierarchy = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        
        # Check hierarchy to identify stacked regions
        if hierarchy is None:
            return False
            
        # Count potential stacked bars
        is_horizontal = self._detect_horizontal_orientation(image)
        
        # Get image dimensions
        height, width = gray.shape
        
        # Group contours by x position for vertical bars or by y position for horizontal bars
        groups = {}
        
        for i, contour in enumerate(contours):
            x, y, w, h = cv2.boundingRect(contour)
            
            # Skip very small contours
            if cv2.contourArea(contour) < width * height * 0.001:
                continue
                
            if is_horizontal:
                # Group by y position (similar y = same bar)
                key = y // (height // 10)  # Discretize y-coordinate
                if key not in groups:
                    groups[key] = []
                groups[key].append((x, y, w, h))
            else:
                # Group by x position (similar x = same bar)
                key = x // (width // 10)  # Discretize x-coordinate
                if key not in groups:
                    groups[key] = []
                groups[key].append((x, y, w, h))
        
        # Count groups with multiple rectangles
        stacked_groups = 0
        for rects in groups.values():
            if len(rects) > 1:
                stacked_groups += 1
        
        # Return True if significant number of stacked groups found
        return stacked_groups > 2
        
    def _detect_grouped_bars(self, image: np.ndarray) -> bool:
        """
        Detect if image contains grouped bars.
        
        Args:
            image: Image data
            
        Returns:
            True if grouped bars detected, False otherwise
        """
        # Calculate color variety
        color_variety = self._calculate_color_variety(image)
        
        # Check for bars
        has_bars = self._detect_bars(image)
        
        # If we have multiple colors and bars, likely grouped
        if color_variety > 2 and has_bars:
            # Convert to grayscale if needed
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
                
            # Find contours
            _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Get image dimensions
            height, width = gray.shape
            
            # Extract rectangles for bars
            rects = []
            for contour in contours:
                if cv2.contourArea(contour) > width * height * 0.001:
                    x, y, w, h = cv2.boundingRect(contour)
                    rects.append((x, y, w, h))
            
            # Sort rectangles by x-position
            rects.sort(key=lambda r: r[0])
            
            # Check for consistent grouping pattern
            if len(rects) >= 6:  # At least 2 groups of 3 bars
                # Calculate distances between consecutive bars
                distances = [rects[i+1][0] - (rects[i][0] + rects[i][2]) for i in range(len(rects)-1)]
                
                # Check if distances show a pattern (small gap between grouped bars, larger gap between groups)
                if len(distances) >= 3:
                    distances = np.array(distances)
                    mean_dist = np.mean(distances)
                    large_gaps = np.where(distances > mean_dist * 1.5)[0]
                    
                    # If we find large gaps at regular intervals, likely grouped bars
                    if len(large_gaps) >= 1:
                        return True
        
        return False
        
    def _detect_filled_area(self, image: np.ndarray) -> bool:
        """
        Detect if image contains a filled area under a line (area chart).
        
        Args:
            image: Image data
            
        Returns:
            True if filled area detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply binary threshold
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Get image dimensions
        height, width = gray.shape
        
        # Look for large filled areas
        for contour in contours:
            # Skip small contours
            if cv2.contourArea(contour) < width * height * 0.05:
                    continue
                    
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Typical area chart has a filled region that extends to bottom of chart
            if h > height * 0.3 and y + h > height * 0.8:
                # Check if top edge is more like a line (not flat)
                contour_image = np.zeros_like(thresh)
                cv2.drawContours(contour_image, [contour], 0, 255, -1)
                
                # Extract top edge profile
                top_profile = []
                for i in range(x, x+w):
                    for j in range(y, y+h):
                        if contour_image[j, i] > 0:
                            top_profile.append(j)
                            break
                
                # Calculate variance of top profile
                if top_profile and len(top_profile) > w * 0.5:
                    variance = np.var(top_profile)
                    # If top edge has significant variation, likely an area chart
                    if variance > 100:
                        return True
        
        return False
        
    def _detect_donut(self, image: np.ndarray) -> bool:
        """
        Detect if image contains a donut chart.
        
        Args:
            image: Image data
            
        Returns:
            True if donut chart detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply binary threshold
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        
        # Look for circular hole in the middle
        potential_donut = False
        
        # Find the largest contour (likely the whole chart)
        if not contours:
            return False
            
        largest_contour = max(contours, key=cv2.contourArea)
        largest_area = cv2.contourArea(largest_contour)
        
        # Find the center of the pie chart
        M = cv2.moments(largest_contour)
        if M["m00"] == 0:
            return False
            
        center_x = int(M["m10"] / M["m00"])
        center_y = int(M["m01"] / M["m00"])
        
        # Look for a hole near the center
        for contour in contours:
            # Skip the largest contour
            if np.array_equal(contour, largest_contour):
                continue
                
            # Get contour center
            M = cv2.moments(contour)
            if M["m00"] == 0:
                continue
                
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            
            # Check if this contour is near the center
            distance = np.sqrt((cx - center_x)**2 + (cy - center_y)**2)
            
            # Check if roughly circular
            area = cv2.contourArea(contour)
            perimeter = cv2.arcLength(contour, True)
            circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
            
            # If there's a circular hole near the center, it's likely a donut chart
            if distance < largest_area**0.5 * 0.2 and circularity > 0.7:
                potential_donut = True
                break
        
        return potential_donut
        
    def _detect_bubble_sizes(self, image: np.ndarray) -> bool:
        """
        Detect if image contains bubble chart (variable-sized circles).
        
        Args:
            image: Image data
            
        Returns:
            True if bubble chart detected, False otherwise
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
            
        # Apply binary threshold
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours to find circular shapes
        areas = []
        
        for contour in contours:
            area = cv2.contourArea(contour)
            # Skip very small contours
            if area < 20:
                continue
                
            # Check if roughly circular
            perimeter = cv2.arcLength(contour, True)
            circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
            
            if 0.7 < circularity < 1.3:  # Fairly circular
                areas.append(area)
        
        # Must have enough circular shapes
        if len(areas) < 5:
            return False
            
        # Calculate size variation - bubble charts should have variable sizes
        areas = np.array(areas)
        max_area = np.max(areas)
        min_area = np.min(areas)
        
        # If there's significant size variation, likely a bubble chart
        return max_area > min_area * 3

    def _group_line_segments(self, lines):
        """
        Group line segments that might belong to the same line.
        
        Args:
            lines: Detected line segments from Hough transform
            
        Returns:
            List of line groups
        """
        if lines is None:
            return []
            
        # Extract line segments
        segments = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            segments.append(((x1, y1), (x2, y2)))
        
        # Initialize groups
        groups = []
        
        # Helper function to check if a segment is close to a group
        def is_close_to_group(segment, group, threshold=10):
            for g_segment in group:
                # Calculate minimum distance between segment endpoints and group segments
                s1, s2 = segment
                g1, g2 = g_segment
                
                # Check all endpoint combinations
                d1 = np.sqrt((s1[0] - g1[0])**2 + (s1[1] - g1[1])**2)
                d2 = np.sqrt((s1[0] - g2[0])**2 + (s1[1] - g2[1])**2)
                d3 = np.sqrt((s2[0] - g1[0])**2 + (s2[1] - g1[1])**2)
                d4 = np.sqrt((s2[0] - g2[0])**2 + (s2[1] - g2[1])**2)
                
                min_dist = min(d1, d2, d3, d4)
                
                if min_dist < threshold:
                    return True
            
            return False
        
        # Group segments
        for segment in segments:
            added_to_group = False
            
            for group in groups:
                if is_close_to_group(segment, group):
                    group.append(segment)
                    added_to_group = True
                    break
            
            if not added_to_group:
                groups.append([segment])
        
        # Convert groups back to line format for consistency
        result = []
        for group in groups:
            group_lines = []
            for segment in group:
                (x1, y1), (x2, y2) = segment
                group_lines.append(np.array([[x1, y1, x2, y2]]))
            result.append(group_lines)
        
        return result
            
    def _extract_generic_chart_data(self, binary_image: np.ndarray) -> List[Dict]:
        """
        Generic data extraction for unspecified chart types.
        
        Args:
            binary_image: Preprocessed binary image
            
        Returns:
            List of extracted data points
        """
        # Find contours
        contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Get image dimensions
        height, width = binary_image.shape
        
        data_points = []
        
        for contour in contours:
            # Skip very small contours
            if cv2.contourArea(contour) < width * height * 0.001:
                continue
                
            # Get contour center
            M = cv2.moments(contour)
            if M["m00"] == 0:
                continue
                
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            
            # Normalize coordinates
            norm_x = cx / width
            norm_y = 1.0 - (cy / height)  # Invert y-axis
            
            # Add to data points
            data_points.append({
                'x': norm_x,
                'y': norm_y,
                'contour_index': len(data_points)
            })
        
        return data_points
    
    def _extract_axes_labels(self, image: np.ndarray) -> Dict[str, str]:
        """
        Extract labels for the x and y axes from charts and graphs.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            Dictionary with x and y axis labels
        """
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Define regions where axis labels are typically found
        x_axis_region = image[int(height * 0.85):height, int(width * 0.1):int(width * 0.9)]
        y_axis_region = image[int(height * 0.1):int(height * 0.9), 0:int(width * 0.15)]
        
        # Extract text from these regions
        x_label = self._extract_diagram_text(x_axis_region).strip()
        y_label = self._extract_diagram_text(y_axis_region).strip()
        
        return {'x_axis': x_label, 'y_axis': y_label}
    
    def _extract_legend(self, image: np.ndarray) -> List[Dict]:
        """
        Extract legend items from charts and graphs.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            List of legend items with color and label
        """
        # Common places for legends are top right, bottom right, or bottom of image
        height, width = image.shape[:2]
        
        # Check top right corner
        top_right = image[0:int(height * 0.3), int(width * 0.7):width]
        # Check bottom right corner
        bottom_right = image[int(height * 0.7):height, int(width * 0.7):width]
        # Check bottom center
        bottom_center = image[int(height * 0.85):height, int(width * 0.2):int(width * 0.8)]
        
        # Try to extract legend from these regions
        legend_regions = [top_right, bottom_right, bottom_center]
        
        for region in legend_regions:
            legend_items = self._process_legend_region(region)
            if legend_items:
                return legend_items
        
        return []
    
    def _process_legend_region(self, region: np.ndarray) -> List[Dict]:
        """
        Process a potential legend region to extract legend items.
        
        Args:
            region: Image region to process
            
        Returns:
            List of legend items
        """
        legend_items = []
        
        # Convert to grayscale
        if len(region.shape) > 2 and region.shape[2] > 1:
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
        else:
            gray = region.copy()
            
        # Threshold to find boxes/markers
        _, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        for contour in contours:
            # Skip small contours
            if cv2.contourArea(contour) < 20:
                continue
                
            # Get bounding box
            x, y, w, h = cv2.boundingRect(contour)
            
            # Check if there's text next to this symbol/color
            text_region = region[max(0, y-5):min(region.shape[0], y+h+5), 
                               min(region.shape[1]-1, x+w+5):min(region.shape[1], x+w+150)]
            
            legend_text = self._extract_diagram_text(text_region).strip()
            
            if legend_text:
                # Get the color of the legend marker
                marker_region = region[y:y+h, x:x+w]
                color = self._get_dominant_color(marker_region)
                
                legend_items.append({
                    'label': legend_text,
                    'color': color,
                    'marker_type': self._identify_marker_type(marker_region)
                })
        
        return legend_items
    
    def _extract_data_points(self, image: np.ndarray, visualization_type: str) -> List[Dict]:
        """
        Extract data points from a visualization.
        
        Args:
            image: Image data as numpy array
            visualization_type: Type of visualization (e.g., 'bar_chart', 'line_chart', etc.)
            
        Returns:
            List of extracted data points
        """
        # Preprocess the image
        preprocessed = self._preprocess_image(image)
        
        # Determine the specific chart subtype
        chart_subtype = self._get_chart_subtype(image, visualization_type)
        
        # Extract data based on visualization type
        if 'bar' in visualization_type or 'bar' in chart_subtype:
            is_horizontal = 'horizontal' in chart_subtype
            is_stacked = 'stacked' in chart_subtype
            is_grouped = 'grouped' in chart_subtype
            data_points = self._extract_bar_chart_data(
                preprocessed, 
                horizontal=is_horizontal,
                stacked=is_stacked,
                grouped=is_grouped
            )
        elif 'line' in visualization_type or 'area' in chart_subtype:
            multi_line = 'multi_line' in chart_subtype
            is_area = 'area' in chart_subtype
            data_points = self._extract_line_chart_data(
                preprocessed,
                multi_line=multi_line,
                area_chart=is_area
            )
        elif 'pie' in visualization_type or 'donut' in chart_subtype:
            is_donut = 'donut' in chart_subtype
            data_points = self._extract_pie_chart_data(
                preprocessed,
                donut=is_donut
            )
        elif 'scatter' in visualization_type or 'bubble' in chart_subtype:
            is_bubble = 'bubble' in chart_subtype
            is_connected = 'connected' in chart_subtype
            data_points = self._extract_scatter_plot_data(
                preprocessed,
                bubble_chart=is_bubble,
                connected=is_connected
            )
        elif 'histogram' in visualization_type:
            data_points = self._extract_bar_chart_data(
                preprocessed,
                histogram=True
            )
        elif 'heatmap' in visualization_type:
            data_points = self._extract_heatmap_data(preprocessed)
        else:
            # Fallback to generic extraction
            data_points = self._extract_generic_chart_data(preprocessed)
            
        return data_points
    
    def _preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        Preprocess image for data extraction.
        
        Args:
            image: Original image data
            
        Returns:
            Preprocessed binary image
        """
        try:
            # Convert to grayscale if needed
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
                
            # Apply Gaussian blur to reduce noise
            blurred = cv2.GaussianBlur(
                gray, 
                Config.GAUSSIAN_KERNEL_SIZE, 
                Config.GAUSSIAN_SIGMA
            )
            
            # Apply Otsu's thresholding
            _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            
            return binary
        except Exception as e:
            logger.error(f"Error in _preprocess_image: {str(e)}")
            logger.debug(traceback.format_exc())
            # Return original image if preprocessing fails
            if len(image.shape) == 3:
                return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            return image
        
    def _extract_bar_chart_data(self, binary_image: np.ndarray, horizontal: bool = False, 
                              stacked: bool = False, grouped: bool = False, 
                              histogram: bool = False) -> List[Dict]:
        """
        Extract data from a bar chart.
        
        Args:
            binary_image: Preprocessed binary image
            horizontal: Whether bars are horizontal
            stacked: Whether bars are stacked
            grouped: Whether bars are grouped
            histogram: Whether this is a histogram (specialized bar chart)
            
        Returns:
            List of data points
        """
        # Find contours
        contours, hierarchy = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Get image dimensions for normalization
        height, width = binary_image.shape
        
        # Filter and process bar contours
        data_points = []
        
        for contour in contours:
            # Skip small contours
            if cv2.contourArea(contour) < (width * height * 0.001):
                continue
                
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Check if shape matches a bar
            if horizontal and w > h:
                # Horizontal bar
                value = w / width
                position = 1.0 - ((y + h/2) / height)  # Normalized position
                
                data_points.append({
                    'x': position,
                    'y': value,
                    'width': h / height,
                    'height': w / width
                })
            elif not horizontal and h > w:
                # Vertical bar
                value = h / height
                position = (x + w/2) / width  # Normalized position
                
                data_points.append({
                    'x': position,
                    'y': value,
                    'width': w / width,
                    'height': h / height
                })
                
        # If no bars found, try fallback method
        if not data_points:
            # For histograms, use column-wise projection
            if histogram:
                # Sum binary image columns (for vertical histograms)
                if not horizontal:
                    projection = np.sum(binary_image, axis=0)
                    for i, value in enumerate(projection):
                        if value > 0:  # Only include non-zero columns
                            norm_value = value / height
                            norm_position = i / width
                            
                            data_points.append({
                                'x': norm_position,
                                'y': norm_value,
                                'width': 1 / width,
                                'height': norm_value
                            })
                else:
                    # For horizontal histograms
                    projection = np.sum(binary_image, axis=1)
                    for i, value in enumerate(projection):
                        if value > 0:  # Only include non-zero rows
                            norm_value = value / width
                            norm_position = 1.0 - (i / height)
                            
                            data_points.append({
                                'x': norm_position,
                                'y': norm_value,
                                'width': norm_value,
                                'height': 1 / height
                            })
        else:
                # Fallback to column projection for regular charts
                projection = np.sum(binary_image, axis=0) if not horizontal else np.sum(binary_image, axis=1)
                
                # Find peaks in the projection
                from scipy.signal import find_peaks
                peaks, _ = find_peaks(projection, height=np.max(projection) * 0.1, distance=width/20)
                
                for peak in peaks:
                    if not horizontal:
                        norm_value = projection[peak] / height
                        norm_position = peak / width
                        
                        data_points.append({
                            'x': norm_position,
                            'y': norm_value,
                            'width': width/len(peaks) / width,
                            'height': norm_value
                        })
                    else:
                        norm_value = projection[peak] / width
                        norm_position = 1.0 - (peak / height)
                        
                        data_points.append({
                            'x': norm_position,
                            'y': norm_value,
                            'width': norm_value,
                            'height': height/len(peaks) / height
                        })
                        
        return data_points
        
    def _extract_line_chart_data(self, binary_image: np.ndarray, multi_line: bool = False, 
                                area_chart: bool = False) -> List[Dict]:
        """
        Extract data from a line chart.
        
        Args:
            binary_image: Preprocessed binary image
            multi_line: Whether chart contains multiple lines
            area_chart: Whether this is an area chart
            
        Returns:
            List of data points
        """
        try:
            # Get image dimensions for normalization
            height, width = binary_image.shape
            
            # Use edge detection for finding lines
            edges = cv2.Canny(
                binary_image, 
                Config.CANNY_THRESHOLD1, 
                Config.CANNY_THRESHOLD2, 
                apertureSize=3
            )
            
            # Extract line segments using Hough Line Transform
            lines = cv2.HoughLinesP(
                edges, 1, np.pi/180, 
                threshold=Config.HOUGH_THRESHOLD, 
                minLineLength=width * Config.HOUGH_MIN_LINE_LENGTH_RATIO,
                maxLineGap=Config.HOUGH_MAX_LINE_GAP
            )
            
            if lines is None:
                logger.info("No lines detected in image using Hough transform")
                return []
                
            # Group line segments that might belong to the same line
            line_groups = self._group_line_segments(lines)
            
            data_points = []
            line_index = 0
            
            for group in line_groups:
                # Skip groups with too few segments (noise)
                if len(group) < 2:
                    continue
                    
                # Sort segments by x-coordinate to connect them properly
                sorted_segments = []
                for segment in group:
                    for line in segment:
                        x1, y1, x2, y2 = line[0]
                        # Ensure points are ordered by x-coordinate
                        if x1 > x2:
                            x1, y1, x2, y2 = x2, y2, x1, y1
                        sorted_segments.append((x1, y1, x2, y2))
                        
                sorted_segments.sort(key=lambda s: s[0])  # Sort by starting x-coordinate
                
                # Sample points along the line
                points = []
                for x1, y1, x2, y2 in sorted_segments:
                    # Add starting point
                    points.append((x1, y1))
                    # Add ending point of the last segment
                    if (x1, y1, x2, y2) == sorted_segments[-1]:
                        points.append((x2, y2))
                
                # For multi-line charts, add a line identifier
                line_id = line_index if multi_line else None
                line_index += 1
                
                # Convert points to normalized data points
                for x, y in points:
                    norm_x = x / width
                    norm_y = 1.0 - (y / height)  # Invert y-axis
                    
                    data_points.append({
                        'x': norm_x,
                        'y': norm_y,
                        'line_id': line_id
                    })
                    
            # If no lines were found with Hough transform or it's an area chart, try contour method
            if not data_points or area_chart:
                logger.info("Using contour method for area chart or as fallback")
                contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                
                for contour in contours:
                    # Skip small contours
                    if cv2.contourArea(contour) < width * height * Config.MIN_CONTOUR_AREA_RATIO:
                        continue
                        
                    # For area charts, find the top edge of the filled area
                    if area_chart:
                        # Get the top-most points for each x-coordinate
                        contour_points = contour.reshape(-1, 2)
                        x_coords = {}
                        
                        for x, y in contour_points:
                            if x not in x_coords or y < x_coords[x]:
                                x_coords[x] = y
                                
                        # Convert to normalized data points
                        for x, y in sorted(x_coords.items()):
                            norm_x = x / width
                            norm_y = 1.0 - (y / height)  # Invert y-axis
                            
                            data_points.append({
                                'x': norm_x,
                                'y': norm_y,
                                'line_id': 0  # Single line for area charts
                            })
                    else:
                        # For regular lines, simplify the contour to get key points
                        epsilon = 0.01 * cv2.arcLength(contour, True)
                        approx = cv2.approxPolyDP(contour, epsilon, True)
                        
                        # Convert to normalized data points
                        for point in approx:
                            x, y = point[0]
                            norm_x = x / width
                            norm_y = 1.0 - (y / height)  # Invert y-axis
                            
                            data_points.append({
                                'x': norm_x,
                                'y': norm_y,
                                'line_id': line_index
                            })
                        line_index += 1
            
            # Sort data points by x-coordinate within each line
            if multi_line:
                # Group by line_id
                lines_dict = {}
                for point in data_points:
                    line_id = point['line_id']
                    if line_id not in lines_dict:
                        lines_dict[line_id] = []
                    lines_dict[line_id].append(point)
                    
                # Sort each line by x-coordinate
                data_points = []
                for line_id, points in lines_dict.items():
                    sorted_points = sorted(points, key=lambda p: p['x'])
                    data_points.extend(sorted_points)
            else:
                data_points = sorted(data_points, key=lambda p: p['x'])
                
            logger.info(f"Extracted {len(data_points)} data points from line chart")
            return data_points
        except Exception as e:
            logger.error(f"Error in _extract_line_chart_data: {str(e)}")
            logger.debug(traceback.format_exc())
            return []
        
    def _extract_scatter_plot_data(self, binary_image: np.ndarray, bubble_chart: bool = False,
                                 connected: bool = False) -> List[Dict]:
        """
        Extract data from a scatter plot.
        
        Args:
            binary_image: Preprocessed binary image
            bubble_chart: Whether this is a bubble chart (variable-sized points)
            connected: Whether points are connected
            
        Returns:
            List of data points
        """
        try:
            # Get image dimensions for normalization
            height, width = binary_image.shape
            
            # Find contours for the points
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            data_points = []
            
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # Skip very small or very large contours
                if area < Config.MIN_CIRCULAR_AREA or area > width * height * Config.MAX_CIRCULAR_AREA_RATIO:
                    continue
                    
                # Check if shape is roughly circular
                perimeter = cv2.arcLength(contour, True)
                circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
                
                if Config.CIRCULARITY_MIN <= circularity <= Config.CIRCULARITY_MAX:  # Fairly circular
                    # Get center and size
                    M = cv2.moments(contour)
                    if M["m00"] == 0:
                        continue
                        
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    
                    # Normalize coordinates
                    norm_x = cx / width
                    norm_y = 1.0 - (cy / height)  # Invert y-axis
                    
                    # For bubble charts, include size information
                    if bubble_chart:
                        # Calculate radius from area
                        radius = np.sqrt(area / np.pi)
                        norm_radius = radius / (min(width, height) / 2)
                        
                        data_points.append({
                            'x': norm_x,
                            'y': norm_y,
                            'size': norm_radius,
                            'area': area
                        })
                    else:
                        data_points.append({
                            'x': norm_x,
                            'y': norm_y
                        })
            
            # For connected scatter plots, add connection information
            if connected and len(data_points) > 1:
                # Sort points by x-coordinate
                data_points.sort(key=lambda p: p['x'])
                
                # Add connection information
                for i in range(len(data_points) - 1):
                    data_points[i]['next_point'] = i + 1
                    
            logger.info(f"Extracted {len(data_points)} data points from scatter plot")
            return data_points
        except Exception as e:
            logger.error(f"Error in _extract_scatter_plot_data: {str(e)}")
            logger.debug(traceback.format_exc())
            return []
        
    def _extract_pie_chart_data(self, binary_image: np.ndarray, donut: bool = False) -> List[Dict]:
        """
        Extract data from a pie chart.
        
        Args:
            binary_image: Preprocessed binary image
            donut: Whether this is a donut chart
            
        Returns:
            List of data points (pie segments)
        """
        # Get image dimensions
        height, width = binary_image.shape
        
        # Find contours
        contours, hierarchy = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        
        if not contours:
            return []
            
        # Find the largest contour (likely the outer circle of the pie chart)
        largest_contour = max(contours, key=cv2.contourArea)
        largest_area = cv2.contourArea(largest_contour)
        
        # Get the center of the pie chart
        M = cv2.moments(largest_contour)
        if M["m00"] == 0:
            return []
            
        center_x = int(M["m10"] / M["m00"])
        center_y = int(M["m01"] / M["m00"])
        
        # For donut charts, find the inner circle
        inner_circle = None
        inner_radius = 0
        
        if donut:
            for contour in contours:
                if np.array_equal(contour, largest_contour):
                    continue
                    
                # Calculate distance from center
                M = cv2.moments(contour)
                if M["m00"] == 0:
                    continue
                    
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
                
                distance = np.sqrt((cx - center_x)**2 + (cy - center_y)**2)
                
                # Check if roughly circular
                area = cv2.contourArea(contour)
                perimeter = cv2.arcLength(contour, True)
                circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
                
                # If circular and near center, it's likely the inner circle
                if distance < largest_area**0.5 * 0.2 and circularity > 0.7:
                    if inner_circle is None or area > cv2.contourArea(inner_circle):
                        inner_circle = contour
                        # Approximate radius from area
                        inner_radius = np.sqrt(area / np.pi)
        
        # Create a mask for the pie chart
        mask = np.zeros_like(binary_image)
        cv2.drawContours(mask, [largest_contour], 0, 255, -1)
        
        # If it's a donut chart, remove the inner circle
        if donut and inner_circle is not None:
            cv2.drawContours(mask, [inner_circle], 0, 0, -1)
        
        # Use watershed or other segmentation techniques to separate pie segments
        # For simplicity, we'll use color-based segmentation on the original image
        
        # Find contours in the pie mask
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        data_points = []
        total_area = cv2.contourArea(largest_contour)
        if donut and inner_circle is not None:
            total_area -= cv2.contourArea(inner_circle)
        
        # Process each segment
        for i, contour in enumerate(contours):
            # Skip small contours
            if cv2.contourArea(contour) < total_area * 0.01:
                continue
                
            # Calculate segment properties
            area = cv2.contourArea(contour)
            
            # Calculate angle range for the segment
            points = contour.reshape(-1, 2)
            angles = []
            
            for x, y in points:
                # Calculate angle relative to center
                angle = np.arctan2(y - center_y, x - center_x)
                angles.append(angle)
            
            # Find start and end angles
            min_angle = min(angles)
            max_angle = max(angles)
            
            # Convert to degrees and ensure positive values
            start_angle = (min_angle * 180 / np.pi) % 360
            end_angle = (max_angle * 180 / np.pi) % 360
            
            # Ensure proper ordering
            if end_angle < start_angle:
                end_angle += 360
                
            # Calculate percentage
            percentage = area / total_area
            
            data_points.append({
                'segment_id': i,
                'start_angle': start_angle,
                'end_angle': end_angle,
                'percentage': percentage,
                'area': area
            })
        
        return data_points
        
    def _extract_heatmap_data(self, binary_image: np.ndarray) -> List[Dict]:
        """
        Extract data from a heatmap.
        
        Args:
            binary_image: Preprocessed binary image
            
        Returns:
            List of data points (cells with intensity values)
        """
        # Get image dimensions
        height, width = binary_image.shape
        
        # For heatmaps, we need to analyze the intensity distribution
        # Convert back to grayscale if binary
        gray_image = 255 - binary_image  # Invert because binary image has dark areas as foreground
        
        # Try to detect grid structure
        # Use edge detection
        edges = cv2.Canny(gray_image, 50, 150)
        
        # Detect horizontal and vertical lines
        h_lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=width*0.3, maxLineGap=20)
        v_lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=height*0.3, maxLineGap=20)
        
        # If grid lines detected, use them to define cells
        if h_lines is not None and v_lines is not None:
            # Extract x and y coordinates of lines
            h_positions = []
            for line in h_lines:
                x1, y1, x2, y2 = line[0]
                h_positions.append(y1)
                
            v_positions = []
            for line in v_lines:
                x1, y1, x2, y2 = line[0]
                v_positions.append(x1)
                
            # Sort and remove duplicates
            h_positions = sorted(list(set([int(y) for y in h_positions])))
            v_positions = sorted(list(set([int(x) for x in v_positions])))
            
            # Create cells from grid intersections
            data_points = []
            
            for i in range(len(h_positions)-1):
                for j in range(len(v_positions)-1):
                    # Define cell boundaries
                    x1, y1 = v_positions[j], h_positions[i]
                    x2, y2 = v_positions[j+1], h_positions[i+1]
                    
                    # Skip if cell is too small
                    if x2 - x1 < 5 or y2 - y1 < 5:
                        continue
                        
                    # Calculate average intensity in the cell
                    cell_region = gray_image[y1:y2, x1:x2]
                    avg_intensity = np.mean(cell_region)
                    
                    # Normalize coordinates and intensity
                    norm_x = (x1 + (x2 - x1) / 2) / width
                    norm_y = 1.0 - ((y1 + (y2 - y1) / 2) / height)  # Invert y-axis
                    norm_intensity = avg_intensity / 255.0
                    
                    data_points.append({
                        'x': norm_x,
                        'y': norm_y,
                        'value': norm_intensity,
                        'row': i,
                        'col': j
                    })
        else:
            # If no grid structure detected, divide the image into cells
            cell_size = min(width, height) // 20  # Approximate cell size
            
            data_points = []
            
            for i in range(0, height, cell_size):
                for j in range(0, width, cell_size):
                    # Define cell boundaries
                    x1, y1 = j, i
                    x2, y2 = min(j + cell_size, width), min(i + cell_size, height)
                    
                    # Calculate average intensity in the cell
                    cell_region = gray_image[y1:y2, x1:x2]
                    if cell_region.size == 0:
                        continue
                        
                    avg_intensity = np.mean(cell_region)
                    
                    # Only include cells with significant intensity
                    if avg_intensity > 10:
                        # Normalize coordinates and intensity
                        norm_x = (x1 + (x2 - x1) / 2) / width
                        norm_y = 1.0 - ((y1 + (y2 - y1) / 2) / height)  # Invert y-axis
                        norm_intensity = avg_intensity / 255.0
                        
                        data_points.append({
                            'x': norm_x,
                            'y': norm_y,
                            'value': norm_intensity,
                            'row': i // cell_size,
                            'col': j // cell_size
                        })
        
        return data_points
        
    def _extract_chart_title(self, image: np.ndarray) -> str:
        """
        Extract the title of a chart.
        
        Args:
            image: Image data as numpy array
            
        Returns:
            String containing the extracted chart title
        """
        # Chart titles are typically at the top of the image
        height, width = image.shape[:2]
        
        # Define region for title (top 15% of the image)
        title_region = image[0:int(height * 0.15), 0:width]
        
        # Extract text from this region
        title_text = self._extract_diagram_text(title_region).strip()
        
        return title_text
        
    def visualize_extraction_result(self, extraction_result: Dict, output_path: str = None) -> np.ndarray:
        """
        Create a visualization of the extraction results.
        
        Args:
            extraction_result: Dictionary with extraction results
            output_path: Optional path to save the visualization
            
        Returns:
            Numpy array containing visualization image
        """
        try:
            # Create a copy of the first page image as background
            images = extraction_result.get('images', [])
            if not images or 'image_data' not in images[0]:
                logger.warning("No image data found for visualization, creating blank canvas")
                # Create a blank canvas if no image is available
                visualization = np.ones((800, 600, 3), dtype=np.uint8) * 255
            else:
                # Use the first image as background
                visualization = images[0]['image_data'].copy()
                
            # Resize if too large
            max_dim = Config.MAX_VISUALIZATION_DIM
            h, w = visualization.shape[:2]
            if h > max_dim or w > max_dim:
                if h > w:
                    visualization = cv2.resize(visualization, (int(w * max_dim / h), max_dim))
                else:
                    visualization = cv2.resize(visualization, (max_dim, int(h * max_dim / w)))
                logger.debug(f"Resized visualization to {visualization.shape}")
                
            # Draw bounding boxes around identified diagrams
            for diagram in extraction_result.get('diagrams', []):
                pos = diagram.get('position', {})
                if pos:
                    x, y = pos.get('x', 0), pos.get('y', 0)
                    w, h = pos.get('width', 0), pos.get('height', 0)
                    
                    # Draw rectangle
                    cv2.rectangle(visualization, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    
                    # Add label
                    label = f"Diagram: {diagram.get('type', 'unknown')}"
                    cv2.putText(visualization, label, (x, y-10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                            
            # Draw bounding boxes around identified figures
            for figure in extraction_result.get('figures', []):
                pos = figure.get('position', {})
                if pos:
                    x, y = pos.get('x', 0), pos.get('y', 0)
                    w, h = pos.get('width', 0), pos.get('height', 0)
                    
                    # Draw rectangle
                    cv2.rectangle(visualization, (x, y), (x+w, y+h), (255, 0, 0), 2)
                    
                    # Add label
                    label = f"Figure: {figure.get('subtype', figure.get('type', 'unknown'))}"
                    cv2.putText(visualization, label, (x, y-10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
                            
            # Draw lines for visual relationships
            for rel in extraction_result.get('visual_relationships', []):
                # Find the visual element
                visual_id = rel.get('visual_id')
                visual_element = None
                
                for element_list in [
                    extraction_result.get('images', []),
                    extraction_result.get('diagrams', []),
                    extraction_result.get('figures', [])
                ]:
                    for element in element_list:
                        if element.get('id') == visual_id:
                            visual_element = element
                            break
                    if visual_element:
                        break
                        
                if not visual_element:
                    continue
                    
                # Get visual position
                vis_pos = visual_element.get('position', {})
                if not vis_pos:
                    continue
                    
                vis_x = vis_pos.get('x', 0) + vis_pos.get('width', 0) // 2
                vis_y = vis_pos.get('y', 0) + vis_pos.get('height', 0) // 2
                
                # Draw connections to related text blocks
                for block in rel.get('related_text_blocks', []):
                    block_pos = block.get('position', {})
                    if not block_pos:
                        continue
                        
                    block_x = block_pos.get('x', 0) + block_pos.get('width', 0) // 2
                    block_y = block_pos.get('y', 0) + block_pos.get('height', 0) // 2
                    
                    # Draw line between visual and text
                    cv2.line(visualization, (vis_x, vis_y), (block_x, block_y), (0, 0, 255), 1)
                    
                    # Add relationship type
                    mid_x = (vis_x + block_x) // 2
                    mid_y = (vis_y + block_y) // 2
                    rel_type = rel.get('relationship_type', 'unknown')
                    cv2.putText(visualization, rel_type, (mid_x, mid_y), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
                
            # Save if output path is provided
            if output_path:
                os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
                cv2.imwrite(output_path, visualization)
                logger.info(f"Visualization saved to {output_path}")
                
            return visualization
        except Exception as e:
            logger.error(f"Error in visualize_extraction_result: {str(e)}")
            logger.debug(traceback.format_exc())
            # Return a blank image if visualization fails
            return np.ones((800, 600, 3), dtype=np.uint8) * 255