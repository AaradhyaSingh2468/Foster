"""
Resource Initialization Script
----------------------------
Downloads and sets up required NLTK resources and other dependencies.
"""

import nltk
import os
import logging

logger = logging.getLogger(__name__)

def init_nltk_resources():
    """Download required NLTK resources if not already present"""
    required_resources = [
        'punkt',
        'averaged_perceptron_tagger',
        'maxent_ne_chunker',
        'words',
        'stopwords'
    ]
    
    try:
        for resource in required_resources:
            try:
                nltk.data.find(f'tokenizers/{resource}')
                logger.info(f"NLTK resource '{resource}' already downloaded")
            except LookupError:
                logger.info(f"Downloading NLTK resource: {resource}")
                nltk.download(resource, quiet=True)
    except Exception as e:
        logger.error(f"Error initializing NLTK resources: {str(e)}")
        raise

def init_all():
    """Initialize all required resources"""
    logger.info("Initializing required resources...")
    init_nltk_resources()
    logger.info("Resource initialization complete")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    init_all() 