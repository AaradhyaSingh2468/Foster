class LiteraryWorkAnalyzer:
    """Support class for analyzing literary works including Shakespeare plays"""
    def __init__(self, work_subtype=None):
        """
        Initialize with optional work subtype specification
        
        Args:
            work_subtype: Subtype of literary work (e.g., 'play:shakespeare', 'novel', 'poem')
        """
        self.work_type = work_subtype.split(':')[0] if work_subtype and ':' in work_subtype else work_subtype
        self.work_subtype = work_subtype.split(':')[1] if work_subtype and ':' in work_subtype else None
        self.character_map = {}
        self.scene_breakdown = {}
        self.literary_devices = {
            'metaphor': [],
            'simile': [],
            'alliteration': [],
            'personification': [],
            'irony': [],
            'foreshadowing': []
        }
        
    def analyze_characters(self, text):
        """
        Identify and analyze characters in the text
        
        Args:
            text: Full text content to analyze
            
        Returns:
            Dictionary with character information
        """
        import re
        
        # First pass: identify potential character names from speech patterns
        # Look for patterns like "HAMLET:" or "ROMEO."
        character_pattern = r'([A-Z]{2,}[A-Z\s]*)[\.:]\s'
        potential_characters = set(re.findall(character_pattern, text))
        
        # Filter out stage directions often in all caps
        filtered_characters = [char for char in potential_characters 
                              if char not in ['EXIT', 'ENTER', 'EXEUNT', 'ALL']]
        
        character_data = {}
        for character in filtered_characters:
            # Count lines spoken
            line_count = len(re.findall(f"{character}[\.:]", text))
            
            # Find all speech by this character
            speech_pattern = f"{character}[\.:]\\s*(.*?)(?=([A-Z]{{2,}}[A-Z\\s]*[\\.:]|$))"
            speeches = re.findall(speech_pattern, text, re.DOTALL)
            speech_text = ' '.join([s[0] for s in speeches if s[0]])
            
            # Calculate word count and average speech length
            words = speech_text.split()
            word_count = len(words)
            avg_speech_length = word_count / max(1, line_count)
            
            character_data[character] = {
                'line_count': line_count,
                'word_count': word_count,
                'avg_speech_length': avg_speech_length,
                'sample_speech': speech_text[:200] + '...' if len(speech_text) > 200 else speech_text
            }
        
        self.character_map = character_data
        return character_data
        
    def identify_scenes(self, text):
        """
        Break down text into acts and scenes for plays
        
        Args:
            text: Full text content
            
        Returns:
            Dictionary with act/scene structure
        """
        import re
        
        acts_scenes = {}
        
        # For Shakespeare and similar structured plays
        if self.work_type == 'play':
            # Find act divisions
            act_pattern = r'ACT\s+([IVXLCDM]+|[0-9]+)(.+?)(?=ACT\s+[IVXLCDM]+|[0-9]+|$)'
            acts = re.findall(act_pattern, text, re.DOTALL)
            
            for act_num, act_content in acts:
                # Find scene divisions within this act
                scene_pattern = r'SCENE\s+([IVXLCDM]+|[0-9]+)(.+?)(?=SCENE\s+[IVXLCDM]+|[0-9]+|$)'
                scenes = re.findall(scene_pattern, act_content, re.DOTALL)
                
                act_key = f"ACT {act_num}"
                acts_scenes[act_key] = {}
                
                for scene_num, scene_content in scenes:
                    scene_key = f"SCENE {scene_num}"
                    
                    # Try to extract setting information
                    setting_match = re.search(r'\[(.*?)\]', scene_content)
                    setting = setting_match.group(1) if setting_match else "Unknown setting"
                    
                    # Get characters in scene
                    character_pattern = r'([A-Z]{2,}[A-Z\s]*)[\.:]\s'
                    scene_characters = set(re.findall(character_pattern, scene_content))
                    
                    acts_scenes[act_key][scene_key] = {
                        'setting': setting,
                        'characters': list(scene_characters),
                        'length': len(scene_content),
                        'word_count': len(scene_content.split())
                    }
        
        # For novels and other chapter-based works
        elif self.work_type == 'novel':
            # Find chapter divisions
            chapter_pattern = r'CHAPTER\s+([IVXLCDM]+|[0-9]+)(.+?)(?=CHAPTER\s+[IVXLCDM]+|[0-9]+|$)'
            chapters = re.findall(chapter_pattern, text, re.DOTALL)
            
            for chapter_num, chapter_content in chapters:
                chapter_key = f"CHAPTER {chapter_num}"
                
                # Try to extract title if available
                title_match = re.search(r'CHAPTER\s+[IVXLCDM0-9]+\.\s+(.*?)[\n\r]', chapter_content)
                title = title_match.group(1) if title_match else "Untitled"
                
                acts_scenes[chapter_key] = {
                    'title': title,
                    'length': len(chapter_content),
                    'word_count': len(chapter_content.split())
                }
        
        self.scene_breakdown = acts_scenes
        return acts_scenes
    
    def detect_literary_devices(self, text):
        """
        Identify common literary devices in the text
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with literary devices found
        """
        import re
        
        devices = {
            'metaphor': [],
            'simile': [],
            'alliteration': [],
            'personification': []
        }
        
        # Break text into sentences for analysis
        sentences = re.split(r'[.!?]', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        # Find similes (like/as comparisons)
        simile_patterns = [
            r'\b\w+\s+like\s+\w+',  # "white like snow"
            r'\b\w+\s+as\s+\w+\s+as\s+\w+'  # "cold as winter night"
        ]
        
        for sentence in sentences:
            # Check for similes
            for pattern in simile_patterns:
                matches = re.findall(pattern, sentence, re.IGNORECASE)
                if matches:
                    devices['simile'].extend(matches)
            
            # Check for alliteration (3+ words starting with same consonant)
            words = sentence.split()
            if len(words) >= 3:
                for i in range(len(words) - 2):
                    if (words[i] and words[i+1] and words[i+2] and
                        len(words[i]) > 0 and len(words[i+1]) > 0 and len(words[i+2]) > 0):
                        first_chars = [w[0].lower() for w in [words[i], words[i+1], words[i+2]]]
                        if (first_chars[0] == first_chars[1] == first_chars[2] and 
                            first_chars[0] not in 'aeiou'):
                            devices['alliteration'].append(' '.join([words[i], words[i+1], words[i+2]]))
            
            # Basic personification detection (non-human things doing human actions)
            personification_verbs = ['spoke', 'whispered', 'thought', 'laughed', 'cried', 'smiled', 'frowned']
            personification_subjects = ['sky', 'moon', 'sun', 'wind', 'tree', 'forest', 'sea', 'ocean', 'mountain']
            
            for subject in personification_subjects:
                for verb in personification_verbs:
                    if f"{subject} {verb}" in sentence.lower():
                        devices['personification'].append(f"{subject} {verb}")
        
        self.literary_devices = devices
        return devices
        
    def analyze_verse_patterns(self, text):
        """
        Analyze verse patterns in poetic works including Shakespeare
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with verse analysis
        """
        # Break text into lines
        lines = text.split('\n')
        lines = [line.strip() for line in lines if line.strip()]
        
        verse_analysis = {
            'iambic_pentameter_count': 0,
            'rhyming_couplets': 0,
            'blank_verse_sections': 0,
            'sonnets': 0,
            'average_syllables_per_line': 0
        }
        
        total_syllables = 0
        
        # Count syllables for each line
        for i, line in enumerate(lines):
            # Simple syllable counting - can be improved
            syllable_count = self._count_syllables(line)
            total_syllables += syllable_count
            
            # Check for potential iambic pentameter (10 syllables)
            if 9 <= syllable_count <= 11:
                verse_analysis['iambic_pentameter_count'] += 1
                
            # Check for potential rhyming couplets
            if i > 0 and len(lines[i-1]) > 2 and len(line) > 2:
                if lines[i-1][-2:].lower() == line[-2:].lower():
                    verse_analysis['rhyming_couplets'] += 1
        
        # Calculate average syllables per line
        if lines:
            verse_analysis['average_syllables_per_line'] = total_syllables / len(lines)
            
        return verse_analysis
    
    def _count_syllables(self, word):
        """
        Simple syllable counter for English text
        
        Args:
            word: Word to count syllables for
            
        Returns:
            Estimated syllable count
        """
        # Remove punctuation
        word = ''.join(c for c in word if c.isalpha() or c.isspace())
        
        # Split into individual words
        words = word.split()
        count = 0
        
        for w in words:
            w = w.lower()
            
            # Count vowel groups
            vowels = "aeiouy"
            on_vowel = False
            in_word = False
            syllables = 0
            
            # Count syllables in the word
            for char in w:
                if char in vowels:
                    if not on_vowel:
                        syllables += 1
                        on_vowel = True
                else:
                    on_vowel = False
                    
            # Adjust for endings
            if w.endswith('e') and not w.endswith('le'):
                syllables -= 1
                
            if syllables == 0:
                syllables = 1
                
            count += syllables
            
        return count
    
    def detect_shakespearean_themes(self, text):
        """
        Identify common Shakespearean themes in the text
        
        Args:
            text: Text to analyze
            
        Returns:
            Dictionary with theme analysis
        """
        # Define common Shakespearean themes and related keywords
        themes = {
            'power_corruption': ['crown', 'throne', 'king', 'queen', 'rule', 'power', 'tyrant', 'ambition'],
            'love_romance': ['love', 'heart', 'passion', 'desire', 'kiss', 'marry', 'marriage', 'lovers'],
            'betrayal': ['betray', 'trust', 'loyal', 'faithful', 'deceive', 'traitor', 'backstab'],
            'appearance_reality': ['seem', 'appear', 'mask', 'disguise', 'truth', 'deception', 'reality'],
            'supernatural': ['ghost', 'witch', 'fairy', 'spirit', 'magic', 'dream', 'fate', 'omen'],
            'order_chaos': ['order', 'chaos', 'balance', 'harmony', 'discord', 'peace', 'war', 'tumult'],
            'revenge': ['revenge', 'vengeance', 'avenge', 'wrong', 'justice', 'blood', 'death']
        }
        
        text_lower = text.lower()
        theme_scores = {}
        
        # Score each theme based on keyword presence
        for theme, keywords in themes.items():
            # Count occurrences of theme keywords
            score = sum(text_lower.count(' ' + keyword + ' ') for keyword in keywords)
            theme_scores[theme] = score
        
        # Normalize scores by text length (per 10,000 words)
        word_count = len(text_lower.split())
        for theme in theme_scores:
            theme_scores[theme] = (theme_scores[theme] * 10000) / max(1, word_count)
        
        # Find the dominant themes (scores above average)
        avg_score = sum(theme_scores.values()) / len(theme_scores)
        dominant_themes = {theme: score for theme, score in theme_scores.items() if score > avg_score}
        
        return {
            'all_themes': theme_scores,
            'dominant_themes': dominant_themes
        }
    