import json
import logging
import os
import re
from collections.abc import Mapping
from typing import Dict, List, Any, Optional, Union, Tuple

import nltk
import numpy as np
from jsonschema import validate, ValidationError
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer

# Importing required classes from other files in the same directory
from .ContentAnalyzer import ContentAnalyzer
from .ContentEnrichment import ContentEnrichmentProcessor
from .ContentRelationshipAnalyzer import ContentRelationshipAnalyzer
from .VisualizationElementExtractor import VisualizationElementExtractor
from ..adaptive_learning.DomainSpecificProcessor import DomainSpecificProcessor
from ..errors.WorkflowErrors import (
    ContentAnalysisError,
    DomainDetectionError,
    ContentStructuringError,
    SummarizationError
)
from pipeline.multimedia.mistralModel import OpenRouterMistralClient
from pipeline.pdf_extraction.EnhancedPDFExtractor import EnhancedPDFExtractor

# Try to download NLTK resources, handle if already exists or network unavailable
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
except Exception as e:
    pass  # Silently continue if downloads fail (might already be available)

def print_key_structure(d: dict) -> None:
    """
    Given a dictionary `d`, prints its keys and any nested subkeys
    as a JSON-formatted structure where leaf values are replaced by {}.
    """
    def extract_keys(obj):
        if isinstance(obj, Mapping):
            return {k: extract_keys(v) for k, v in obj.items()}
        else:
            # non‐dict value → leaf key
            return type(obj).__name__
    
    key_tree = extract_keys(d)
    print(json.dumps(key_tree, indent=4))
    
class ContentAnalysisSchema:
    """Defines the schema for content analysis output validation"""
    
    # Schema for the overall analysis result
    ANALYSIS_RESULT_SCHEMA = {
        "type": "object",
        "required": ["topic", "summary", "concepts", "structure", "metadata"],
        "properties": {
            "topic": {"type": "string", "minLength": 1},
            "summary": {
                "type": "object",
                "required": ["brief", "key_points"],
                "properties": {
                    "brief": {"type": "string", "minLength": 10},
                    "key_points": {
                        "type": "array",
                        "items": {"type": "string", "minLength": 5},
                        "minItems": 1
                    },
                    "difficulty_level": {"type": "string"},
                    "estimated_reading_time": {"type": "number", "minimum": 0}
                }
            },
            "concepts": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["name", "description"],
                    "properties": {
                        "name": {"type": "string", "minLength": 1},
                        "description": {"type": "string", "minLength": 10},
                        "importance": {"type": "number", "minimum": 0, "maximum": 1},
                        "related_concepts": {
                            "type": "array",
                            "items": {"type": "string"}
                        }
                    }
                },
                "minItems": 1
            },
            "structure": {
                "type": "object",
                "required": ["sections"],
                "properties": {
                    "sections": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["title", "content"],
                            "properties": {
                                "title": {"type": "string"},
                                "content": {"type": "string", "minLength": 10},
                                "level": {"type": "integer", "minimum": 1},
                                "subsections": {
                                    "type": "array",
                                    "items": {"$ref": "#/properties/structure/properties/sections/items"}
                                }
                            }
                        },
                        "minItems": 1
                    },
                    "narrative_flow": {
                        "type": "array",
                        "items": {"type": "string"}
                    }
                }
            },
            "metadata": {
                "type": "object",
                "properties": {
                    "domain": {"type": "string"},
                    "domain_confidence": {"type": "number", "minimum": 0, "maximum": 1},
                    "language": {"type": "string"},
                    "source_type": {"type": "string"},
                    "analysis_version": {"type": "string"}
                }
            },
            "quiz": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["question", "options", "correct_answer"],
                    "properties": {
                        "question": {"type": "string", "minLength": 10},
                        "options": {
                            "type": "array",
                            "items": {"type": "string", "minLength": 1},
                            "minItems": 2
                        },
                        "correct_answer": {"type": ["string", "integer"]},
                        "explanation": {"type": "string"},
                        "difficulty": {"type": "string", "enum": ["easy", "medium", "hard"]}
                    }
                }
            }
        },
        "additionalProperties": True
    }
    
    # Schema for domain-specific analysis results
    DOMAIN_SPECIFIC_SCHEMAS = {
        "mathematics": {
            "type": "object",
            "required": ["equations", "variables", "complexity_level"],
            "properties": {
                "equations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["latex", "description"],
                        "properties": {
                            "latex": {"type": "string"},
                            "description": {"type": "string"},
                            "variables": {
                                "type": "array",
                                "items": {"type": "string"}
                            }
                        }
                    }
                },
                "variables": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "description"],
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                            "units": {"type": "string"}
                        }
                    }
                },
                "complexity_level": {"type": "string"}
            }
        },
        "physics": {
            "type": "object",
            "required": ["principles", "experiments"],
            "properties": {
                "principles": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                            "equations": {
                                "type": "array",
                                "items": {"type": "string"}
                            }
                        }
                    }
                },
                "experiments": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                            "outcomes": {
                                "type": "array",
                                "items": {"type": "string"}
                            }
                        }
                    }
                }
            }
        },
        "computer_science": {
            "type": "object",
            "required": ["algorithms", "code_examples"],
            "properties": {
                "algorithms": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                            "complexity": {"type": "string"}
                        }
                    }
                },
                "code_examples": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "language": {"type": "string"},
                            "code": {"type": "string"},
                            "explanation": {"type": "string"}
                        }
                    }
                }
            }
        }
    }
    
class ContentAnalysisPipeline:
    """
    Pipeline for analyzing extracted PDF content,
    with robust schema validation and domain-specific processing
    """
    
    def __init__(self, domain: str = "general", model_path: Optional[str] = None):
        """
        Initialize the content analysis pipeline
        
        Args:
            domain: Default domain for content analysis
            model_path: Path to domain classification model
        """
        self.domain = domain
        self.model_path = model_path
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Configure processing pipeline
        self._configure_pipeline()
    
    def _configure_pipeline(self):
        """Configure the analysis pipeline components"""
        # Initialize content analyzer for text processing
        self.content_analyzer = ContentAnalyzer()
        
        # Initialize content relationship analyzer
        self.relationship_analyzer = ContentRelationshipAnalyzer()
        
        # Initialize content enrichment processor
        self.enrichment_processor = ContentEnrichmentProcessor()
        
        # Initialize visualization element extractor
        self.visualization_extractor = VisualizationElementExtractor()
        
        # Initialize LLM client for advanced analysis if available
        try:
            # The model_path parameter is used to provide the OpenRouter API key
            if self.model_path:
                # Initialize with API key if provided
                self.llm_client = OpenRouterMistralClient(api_key=self.model_path)
                self.logger.info("LLM client initialized with provided API key")
            else:
                # Initialize without API key (will need to be updated later)
                self.llm_client = OpenRouterMistralClient()
                self.logger.warning("LLM client initialized without API key. Some features may be unavailable.")
            
            self.llm_available = True
            self.logger.info("LLM client initialized successfully")
        except Exception as e:
            self.llm_available = False
            self.logger.warning(f"LLM client initialization failed: {str(e)}. Using fallback methods.")
        
        # Initialize domain processors with lazy loading
        self.domain_processors = {}
        
        # Initialize text processing tools
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # TF-IDF vectorizer for keyword extraction
        self.tfidf = TfidfVectorizer(max_features=100, stop_words='english')
        
        # Domain keywords for classification
        self.domain_keywords = {
            "mathematics": ["equation", "theorem", "formula", "calculation", "algebra", "geometry", 
                           "calculus", "function", "variable", "constant", "proof", "matrix"],
            "physics": ["force", "energy", "motion", "gravity", "particle", "wave", "quantum", 
                       "relativity", "momentum", "acceleration", "velocity", "mass", "charge"],
            "computer_science": ["algorithm", "programming", "code", "function", "data", "variable", 
                               "class", "object", "database", "network", "system", "software", "hardware"],
            "biology": ["cell", "organism", "dna", "evolution", "species", "protein", "gene", 
                       "tissue", "enzyme", "chromosome", "ecology", "metabolism"],
            "chemistry": ["element", "compound", "reaction", "molecule", "acid", "base", "bond", 
                         "solution", "atom", "electron", "periodic", "organic"]
        }
        
        self.logger.info("Content analysis pipeline configured successfully")
    
    def analyze_content(self, extracted_content: Dict[str, Any], output_dir: str,
                       domain_focus: Optional[str] = None, grade_level: str = "general",
                       detail_level: str = "standard", include_quiz: bool = False,
                       language: str = "en") -> Dict[str, Any]:
        """
        Analyze the extracted content
        
        Args:
            extracted_content: The extracted PDF content
            output_dir: Directory to store analysis output
            domain_focus: Domain to focus analysis on (e.g., "mathematics", "physics")
            grade_level: Educational grade level (e.g., "elementary", "university")
            detail_level: Level of detail for analysis
            include_quiz: Whether to generate quiz questions
            language: Content language
            
        Returns:
            Dictionary containing analyzed content
            
        Raises:
            ContentAnalysisError: If analysis fails
        """
        try:
            # Validate input content
            self._validate_input_content(extracted_content)
            
            # Detect content domain if not specified
            detected_domain, domain_confidence = self._detect_domain(extracted_content, domain_focus)
            
            # Analyze content structure
            structure = self._analyze_structure(extracted_content, grade_level, detail_level)
            
            # Extract key concepts
            concepts = self._extract_concepts(extracted_content, detected_domain, grade_level)
            
            # Generate summary
            summary = self._generate_summary(extracted_content, detected_domain, 
                                           grade_level, detail_level)
            
            # Generate domain-specific analysis
            domain_specific = self._generate_domain_specific_analysis(
                extracted_content, detected_domain, grade_level, detail_level
            )
            
            # Generate quiz if requested
            quiz = self._generate_quiz(extracted_content, concepts, grade_level) if include_quiz else []
            
            # Compile results
            result = {
                "topic": self._generate_topic(extracted_content, detected_domain),
                "summary": summary,
                "concepts": concepts,
                "structure": structure,
                "metadata": {
                    "domain": detected_domain,
                    "domain_confidence": domain_confidence,
                    "grade_level": grade_level,
                    "detail_level": detail_level,
                    "language": language,
                    "source_type": "pdf",
                    "analysis_version": "1.0"
                }
            }
            
            # Add domain-specific analysis if available
            if domain_specific:
                result["domain_specific"] = domain_specific
            
            # Add quiz if generated
            if quiz:
                result["quiz"] = quiz
            
            # Validate the output against schema
            self._validate_analysis_result(result, detected_domain)
            
            # Save results to output directory
            os.makedirs(output_dir, exist_ok=True)
            with open(os.path.join(output_dir, "analysis_result.json"), "w") as f:
                json.dump(result, f, indent=2)
            
            return result
            
        except ValidationError as e:
            # Handle schema validation errors
            schema_error = f"Schema validation error: {e.message}"
            self.logger.error(schema_error)
            raise ContentStructuringError(schema_error, details={"schema_path": e.schema_path})
            
        except Exception as e:
            # Handle other errors
            error_message = f"Content analysis failed: {str(e)}"
            self.logger.error(error_message)
            
            if isinstance(e, ContentAnalysisError):
                raise
            else:
                raise ContentAnalysisError(error_message)
    
    def _validate_input_content(self, content: Dict[str, Any]) -> None:
        """
        Validate input content structure
        
        Args:
            content: Extracted content dictionary
            
        Raises:
            ContentAnalysisError: If content is invalid
        """
        if not isinstance(content, dict):
            raise ContentAnalysisError("Extracted content must be a dictionary")
        
        # Check for required fields
        required_fields = ["content", "pages"]
        missing_fields = [field for field in required_fields if field not in content]
        
        if missing_fields:
            raise ContentAnalysisError(
                f"Extracted content missing required fields: {', '.join(missing_fields)}"
            )
        
        # Check content type and minimum length
        if not isinstance(content.get("content"), str) or len(content.get("content", "")) < 50:
            raise ContentAnalysisError(
                "Extracted content must contain text content of sufficient length"
            )
        
        # Check pages structure
        if not isinstance(content.get("pages"), list) or not content.get("pages"):
            raise ContentAnalysisError("Extracted content must contain pages data")
    
    def _validate_analysis_result(self, result: Dict[str, Any], domain: str) -> None:
        """
        Validate analysis result against schema
        
        Args:
            result: Analysis result dictionary
            domain: Detected content domain
            
        Raises:
            ValidationError: If result does not match schema
        """
        # Validate against base schema
        validate(instance=result, schema=ContentAnalysisSchema.ANALYSIS_RESULT_SCHEMA)
        
        # Validate domain-specific parts if present
        if domain in ContentAnalysisSchema.DOMAIN_SPECIFIC_SCHEMAS and "domain_specific" in result:
            domain_schema = ContentAnalysisSchema.DOMAIN_SPECIFIC_SCHEMAS[domain]
            validate(instance=result["domain_specific"], schema=domain_schema)
    
    def _detect_domain(self, content: Dict[str, Any], domain_focus: Optional[str] = None) \
            -> Tuple[str, float]:
        """
        Detect the content domain
        
        Args:
            content: Extracted content dictionary
            domain_focus: Optional domain focus
            
        Returns:
            Tuple of (detected_domain, confidence)
        """
        # If domain focus is specified, use it with high confidence
        if domain_focus and domain_focus != "auto":
            return domain_focus, 1.0
        
        try:
            # Extract text content
            text = content.get("content", "")
            
            # Tokenize and preprocess text
            tokens = word_tokenize(text.lower())
            
            # Remove stopwords and lemmatize
            filtered_tokens = [
                self.lemmatizer.lemmatize(token) 
                for token in tokens 
                if token.isalpha() and token not in self.stop_words
            ]
            
            # Count domain keywords in text
            domain_scores = {}
            for domain, keywords in self.domain_keywords.items():
                # Calculate the presence of domain keywords in filtered tokens
                keyword_count = sum(1 for token in filtered_tokens if token in keywords)
                # Weight by document length to avoid bias towards longer documents
                domain_scores[domain] = keyword_count / max(1, len(filtered_tokens)) * 100
            
            # If we have LLM access, enhance with more sophisticated analysis
            if self.llm_available and len(text) > 200:
                try:
                    # Check if API key is available
                    if hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                        # Prepare a prompt for domain classification
                        prompt = f"Classify the following text into one of these domains: {', '.join(self.domain_keywords.keys())}.\n\nText: {text[:2000]}\n\nDomain:"
                        llm_result = self.llm_client.generate(prompt, max_tokens=20)
                        llm_domain = llm_result.lower().strip()
                        
                        # If LLM returns a recognized domain, boost its score
                        for domain in self.domain_keywords:
                            if domain in llm_domain:
                                domain_scores[domain] = domain_scores.get(domain, 0) + 30
                                break
                    else:
                        self.logger.warning("LLM domain classification skipped: API key not set")
                except Exception as e:
                    self.logger.warning(f"LLM domain classification failed: {str(e)}")
            
            # Determine the most likely domain
            if domain_scores:
                best_domain = max(domain_scores.items(), key=lambda x: x[1])
                domain_name, score = best_domain
                
                # Calculate confidence (normalize score to 0.5-0.95 range)
                confidence = min(0.95, 0.5 + (score / 200))
                
                # Only return a specific domain if confidence is above threshold
                if confidence > 0.6:
                    return domain_name, confidence
            
            # Check for tables and equations as indicators of technical domains
            has_tables = len(content.get("tables", [])) > 0
            has_equations = "equations" in content or "formulas" in text.lower()
            
            if has_equations and has_tables:
                return "mathematics", 0.7
            elif has_tables and "data" in text.lower():
                return "computer_science", 0.65
            
            # Default to general with moderate confidence
            return "general", 0.6
            
        except Exception as e:
            self.logger.error(f"Domain detection failed: {str(e)}")
            # Fallback to general domain with low confidence
            return "general", 0.5
    
    def _analyze_structure(self, content: Dict[str, Any], grade_level: str, detail_level: str) \
            -> Dict[str, Any]:
        """
        Analyze content structure
        
        Args:
            content: Extracted content dictionary
            grade_level: Educational grade level
            detail_level: Level of detail
            
        Returns:
            Content structure dictionary
        """
        try:
            # Extract the pages data
            pages = content.get("pages", [])
            full_text = content.get("content", "")
            
            # Initialize structure components
            sections = []
            narrative_flow = ["introduction"]
            
            # If no pages, create a basic structure
            if not pages:
                if full_text:
                    # Try to identify sections from the full text
                    paragraphs = full_text.split('\n\n')
                    
                    if len(paragraphs) > 3:
                        intro = paragraphs[0]
                        main_content = ' '.join(paragraphs[1:-1])
                        conclusion = paragraphs[-1]
                        
                        sections = [
                            {"title": "Introduction", "content": intro, "level": 1},
                            {"title": "Main Content", "content": main_content, "level": 1},
                            {"title": "Conclusion", "content": conclusion, "level": 1}
                        ]
                        narrative_flow = ["introduction", "main_content", "conclusion"]
                    else:
                        sections = [{"title": "Content", "content": full_text, "level": 1}]
                        narrative_flow = ["content"]
                else:
                    # Return minimal structure if no content
                    return {
                        "sections": [{"title": "Empty Document", "content": "No content available", "level": 1}],
                        "narrative_flow": ["empty"]
                    }
            else:
                # Process page data to identify sections
                section_candidates = []
                current_level = 1
                
                # Analyze text for headings
                heading_pattern = re.compile(r'^(#+|\d+\.|\b(?:CHAPTER|SECTION)\b)', re.IGNORECASE)
                
                # Extract potential sections from page data
                for page in pages:
                    page_text = page.get("text", "")
                    lines = page_text.split('\n')
                    
                    for line in lines:
                        line = line.strip()
                        if not line:
                            continue
                            
                        # Check if this line looks like a heading
                        if heading_pattern.match(line) or (len(line) < 100 and line.isupper()):
                            # Determine heading level
                            level = 1
                            if line.startswith('##'):
                                level = 3 if line.startswith('###') else 2
                            elif line.startswith('#'):
                                level = 1
                            elif '.' in line and line[0].isdigit():
                                # Check for nested numbering like "1.2.3"
                                dots = line.split('.', 1)[0].count('.')
                                level = dots + 1
                            
                            # Save as section candidate
                            section_candidates.append({
                                "title": line.lstrip('#. '),
                                "content": "",
                                "level": level,
                                "index": len(section_candidates)
                            })
                        elif section_candidates:
                            # Append content to the latest section
                            section_candidates[-1]["content"] += line + " "
                
                # If we found sections, organize them into a hierarchy
                if section_candidates:
                    # Normalize section levels to ensure they start at 1
                    min_level = min(section["level"] for section in section_candidates)
                    for section in section_candidates:
                        section["level"] = max(1, section["level"] - min_level + 1)
                    
                    # Organize sections into a nested structure
                    sections = self._organize_sections(section_candidates)
                    
                    # Define the narrative flow based on sections
                    narrative_flow = ["introduction"]
                    if len(sections) > 2:
                        narrative_flow.extend(["development"] * (len(sections) - 2))
                    if len(sections) > 1:
                        narrative_flow.append("conclusion")
                else:
                    # If no section candidates, create generic sections based on pages
                    if len(pages) > 3:
                        # First page as intro, last as conclusion
                        sections = [
                            {"title": "Introduction", "content": pages[0].get("text", ""), "level": 1},
                            {"title": "Main Content", "content": " ".join(p.get("text", "") for p in pages[1:-1]), "level": 1},
                            {"title": "Conclusion", "content": pages[-1].get("text", ""), "level": 1}
                        ]
                        narrative_flow = ["introduction", "main_content", "conclusion"]
                    else:
                        # For short documents, just use all content
                        sections = [{"title": "Content", "content": " ".join(p.get("text", "") for p in pages), "level": 1}]
                        narrative_flow = ["content"]
            
            # Adjust level of detail based on parameter
            if detail_level == "minimal":
                # Keep only top-level sections
                sections = [s for s in sections if s["level"] == 1]
            elif detail_level == "detailed":
                # Keep all sections, already handled above
                pass
            else:  # "standard" detail level
                # Keep up to level 3
                sections = self._filter_sections_by_max_level(sections, 3)
            
            # Adjust for grade level
            if grade_level == "elementary":
                # Simplify content for younger students
                for section in sections:
                    if len(section["content"]) > 300:
                        section["content"] = section["content"][:300] + "..."
            
            return {
                "sections": sections,
                "narrative_flow": narrative_flow
            }
            
        except Exception as e:
            self.logger.error(f"Structure analysis failed: {str(e)}")
            # Return a basic structure as fallback
            return {
                "sections": [{"title": "Content", "content": content.get("content", "")[:1000], "level": 1}],
                "narrative_flow": ["content"]
            }
    
    def _organize_sections(self, section_candidates: List[Dict]) -> List[Dict]:
        """Helper to organize sections into a properly nested structure"""
        if not section_candidates:
            return []
            
        # Sort by original index to maintain order
        sorted_sections = sorted(section_candidates, key=lambda x: x["index"])
        
        # Create a new list without the index field
        clean_sections = []
        for section in sorted_sections:
            new_section = {
                "title": section["title"],
                "content": section["content"].strip(),
                "level": section["level"]
            }
            
            # Add empty subsections list if it might have children
            if any(s["level"] > section["level"] for s in sorted_sections):
                new_section["subsections"] = []
                
            clean_sections.append(new_section)
        
        # Build the hierarchy (only for top-level sections)
        result = []
        i = 0
        while i < len(clean_sections):
            if clean_sections[i]["level"] == 1:
                # Start with a top-level section
                current_section = clean_sections[i]
                i += 1
                
                # Process subsections
                self._add_subsections(current_section, clean_sections, i)
                
                # Add to result
                result.append(current_section)
            else:
                # Skip non-top-level sections as they'll be handled by _add_subsections
                i += 1
                
        return result
    
    def _add_subsections(self, parent: Dict, all_sections: List[Dict], start_idx: int) -> int:
        """Recursively add subsections to a parent section"""
        parent_level = parent["level"]
        i = start_idx
        
        # Make sure parent has subsections field
        if "subsections" not in parent:
            parent["subsections"] = []
            
        while i < len(all_sections):
            current = all_sections[i]
            
            if current["level"] <= parent_level:
                # If same or higher level, we're done with this parent
                return i
            
            if current["level"] == parent_level + 1:
                # Direct child of parent
                parent["subsections"].append(current)
                i += 1
                
                # Process children of this child
                i = self._add_subsections(current, all_sections, i)
            else:
                # Skip sections that are too deeply nested
                i += 1
                
        return i
    
    def _filter_sections_by_max_level(self, sections: List[Dict], max_level: int) -> List[Dict]:
        """Filter sections to keep only up to a certain level"""
        result = []
        
        for section in sections:
            new_section = {
                "title": section["title"],
                "content": section["content"],
                "level": section["level"]
            }
            
            # Handle subsections
            if "subsections" in section and section["level"] < max_level:
                new_section["subsections"] = self._filter_sections_by_max_level(
                    section["subsections"], max_level)
                
            result.append(new_section)
            
        return result
    
    def _extract_concepts(self, content: Dict[str, Any], domain: str, grade_level: str) \
            -> List[Dict[str, Any]]:
        """
        Extract key concepts from content
        
        Args:
            content: Extracted content dictionary
            domain: Content domain
            grade_level: Educational grade level
            
        Returns:
            List of concept dictionaries
        """
        try:
            # Get text content
            text = content.get("content", "")
            if not text:
                return [{"name": "Unknown", "description": "No content available for concept extraction.", 
                        "importance": 0.5, "related_concepts": []}]
            
            # Extract domain-specific concepts first if available
            domain_concepts = []
            
            # Check if we need to load a domain processor
            if domain != "general" and domain not in self.domain_processors:
                try:
                    # Lazy-load domain processor
                    processor_class = DomainSpecificProcessor.get_processor_for_domain(domain)
                    if processor_class:
                        self.domain_processors[domain] = processor_class()
                except Exception as e:
                    self.logger.warning(f"Failed to load domain processor for {domain}: {str(e)}")
            
            # Use domain processor if available
            if domain in self.domain_processors:
                domain_concepts = self.domain_processors[domain].extract_concepts(content, grade_level)
            
            # If domain-specific concepts were found, return them
            if domain_concepts:
                return domain_concepts
                
            # Otherwise, use general NLP approach
            # Tokenize content and remove stopwords
            tokens = word_tokenize(text.lower())
            filtered_tokens = [self.lemmatizer.lemmatize(token) for token in tokens 
                              if token.isalpha() and token not in self.stop_words]
            
            # Create corpus for TF-IDF
            sentences = sent_tokenize(text)
            
            if not sentences:
                return [{"name": "Unknown", "description": "Content could not be processed for concepts.", 
                        "importance": 0.5, "related_concepts": []}]
            
            # Process sentences for TF-IDF
            try:
                # Fit TF-IDF vectorizer
                self.tfidf.fit(sentences)
                
                # Get feature names
                feature_names = self.tfidf.get_feature_names_out()
                
                # Transform the corpus
                tfidf_matrix = self.tfidf.transform(sentences)
                
                # Get top terms by TF-IDF score
                max_val = tfidf_matrix.max(axis=0).toarray().ravel()
                sorted_indices = max_val.argsort()[::-1][:15]  # Get top 15 terms
                
                # Get the actual terms
                top_terms = [feature_names[i] for i in sorted_indices if max_val[i] > 0]
                
                # If we have too few terms, add more based on frequency
                if len(top_terms) < 5:
                    # Count word frequencies
                    word_freq = {}
                    for token in filtered_tokens:
                        word_freq[token] = word_freq.get(token, 0) + 1
                        
                    # Add most frequent words not already in top_terms
                    freq_terms = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
                    for term, freq in freq_terms:
                        if term not in top_terms and len(term) > 3:  # Skip very short words
                            top_terms.append(term)
                            if len(top_terms) >= 10:
                                break
            except Exception as e:
                self.logger.warning(f"TF-IDF processing failed: {str(e)}. Using fallback method.")
                # Fallback: Use simple frequency
                word_freq = {}
                for token in filtered_tokens:
                    word_freq[token] = word_freq.get(token, 0) + 1
                
                # Get top terms by frequency
                top_terms = [term for term, freq in sorted(word_freq.items(), 
                                                         key=lambda x: x[1], 
                                                         reverse=True)[:15]
                            if len(term) > 3]  # Skip very short words
            
            # Use LLM to enhance concept descriptions if available
            concepts = []
            for term in top_terms[:10]:  # Limit to top 10
                # Find relevant sentences
                relevant_sentences = [s for s in sentences if term.lower() in s.lower()]
                context = " ".join(relevant_sentences[:3])  # Use up to 3 sentences
                
                if self.llm_available and hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                    try:
                        # Ask LLM to generate concept description
                        prompt = f"Based on the following context, provide a concise description (max 50 words) of the concept '{term}'.\n\nContext: {context}\n\nDescription:"
                        description = self.llm_client.generate(prompt, max_tokens=100)
                        
                        # Also get related concepts
                        related_prompt = f"List 3 concepts related to '{term}' based on this context: {context}\n\nRelated concepts (comma-separated):"
                        related_concepts_text = self.llm_client.generate(related_prompt, max_tokens=50)
                        related_concepts = [c.strip() for c in related_concepts_text.split(',')]
                    except Exception as e:
                        self.logger.warning(f"LLM concept enhancement failed: {str(e)}. Using fallback.")
                        description = f"A key concept related to {term}."
                        related_concepts = []
                else:
                    # Fallback without LLM or when API key not set
                    description = context[:200] + "..." if len(context) > 200 else context
                    related_concepts = []
                
                # Calculate importance based on position in top_terms
                importance = 1.0 - (top_terms.index(term) / len(top_terms))
                
                concepts.append({
                    "name": term.capitalize(),
                    "description": description,
                    "importance": round(importance, 2),
                    "related_concepts": related_concepts[:3]  # Limit to 3 related concepts
                })
            
            return concepts
            
        except Exception as e:
            self.logger.error(f"Concept extraction failed: {str(e)}")
            # Return a minimal placeholder in case of errors
            return [
                {
                    "name": "Main Topic",
                    "description": "The central topic of the document.",
                    "importance": 1.0,
                    "related_concepts": []
                }
            ]
    
    def _generate_summary(self, content: Dict[str, Any], domain: str, 
                        grade_level: str, detail_level: str) -> Dict[str, Any]:
        """
        Generate content summary
        
        Args:
            content: Extracted content dictionary
            domain: Content domain
            grade_level: Educational grade level
            detail_level: Level of detail
            
        Returns:
            Summary dictionary
        """
        try:
            # Get the text content
            text = content.get("content", "")
            if not text:
                return {
                    "brief": "No content available to summarize.",
                    "key_points": ["Content unavailable"],
                    "difficulty_level": grade_level,
                    "estimated_reading_time": 0
                }
            
            # Calculate estimated reading time (avg adult reads ~250 words per minute)
            word_count = len(text.split())
            reading_time = word_count / 250  # In minutes
            
            # Adjust reading time based on grade level
            if grade_level == "elementary":
                # Younger readers take longer
                reading_time *= 1.5
            elif grade_level == "university":
                # Advanced readers may be faster
                reading_time *= 0.9
            
            # Determine difficulty level based on content
            difficulty = self._estimate_difficulty(text, grade_level)
            
            # Generate summary based on detail level
            summary_length = {
                "minimal": 100,    # Very short summary
                "standard": 200,   # Medium length summary
                "detailed": 400    # Longer summary
            }.get(detail_level, 200)
            
            # Use LLM for abstractive summarization if available
            brief_summary = ""
            if self.llm_available and hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                try:
                    # Truncate text if too long for prompt
                    truncated_text = text[:4000] if len(text) > 4000 else text
                    
                    # Prompt for general summary
                    prompt = f"Summarize the following text in about {summary_length} words. Focus on the main ideas and key concepts. Make the summary coherent and readable.\n\nText: {truncated_text}\n\nSummary:"
                    brief_summary = self.llm_client.generate(prompt, max_tokens=summary_length * 2)
                    
                    # Prompt for key points
                    points_prompt = f"Extract the 5 most important points from this text as a numbered list:\n\nText: {truncated_text}\n\nKey Points:"
                    key_points_text = self.llm_client.generate(points_prompt, max_tokens=300)
                    
                    # Parse key points into a list
                    key_points = []
                    for line in key_points_text.strip().split('\n'):
                        # Remove numbering and strip whitespace
                        clean_line = re.sub(r'^\d+\.?\s*', '', line).strip()
                        if clean_line:
                            key_points.append(clean_line)
                    
                    # If we didn't get enough key points, add generic ones
                    while len(key_points) < 3:
                        key_points.append(f"Additional important information from the {domain} content")
                    
                except Exception as e:
                    self.logger.warning(f"LLM summarization failed: {str(e)}. Using fallback method.")
                    brief_summary = ""  # Reset to use fallback
            
            # Fallback to extractive summarization if LLM failed or not available
            if not brief_summary:
                # Split text into sentences
                sentences = sent_tokenize(text)
                
                if not sentences:
                    return {
                        "brief": "Unable to process content for summarization.",
                        "key_points": ["Content could not be processed"],
                        "difficulty_level": difficulty,
                        "estimated_reading_time": reading_time
                    }
                
                # Calculate sentence scores
                scores = {}
                for sentence in sentences:
                    # Skip very short sentences
                    if len(sentence.split()) < 4:
                        continue

                    # Simple scoring based on sentence position and keywords
                    score = 0
                    
                    # First and last sentences often contain important information
                    if sentence == sentences[0]:
                        score += 0.3
                    elif sentence == sentences[-1]:
                        score += 0.2
                    
                    # Check for domain keywords
                    if domain in self.domain_keywords:
                        for keyword in self.domain_keywords[domain]:
                            if keyword in sentence.lower():
                                score += 0.1
                                break
                    
                    # Check for informative phrases
                    info_phrases = ["important", "significant", "key", "main", "essential", "fundamental"]
                    for phrase in info_phrases:
                        if phrase in sentence.lower():
                            score += 0.05
                            break
                    
                    scores[sentence] = score
                
                # Sort sentences by score
                sorted_sentences = sorted(scores.items(), key=lambda x: x[1], reverse=True)
                
                # Select top sentences
                top_sentence_count = max(3, int(len(sentences) * 0.2))  # At least 3 sentences or 20%
                if detail_level == "minimal":
                    top_sentence_count = min(3, top_sentence_count)
                elif detail_level == "detailed":
                    top_sentence_count = max(5, top_sentence_count)
                
                # Get top sentences and sort them by original order
                top_sentences = [s[0] for s in sorted_sentences[:top_sentence_count]]
                ordered_sentences = [s for s in sentences if s in top_sentences]
                
                # Create brief summary
                brief_summary = " ".join(ordered_sentences)
                
                # Truncate if too long
                if len(brief_summary) > summary_length * 5:  # Average word ~5 chars
                    brief_summary = brief_summary[:summary_length * 5] + "..."
                
                # Extract key points
                key_points = []
                for sentence in ordered_sentences[:5]:
                    # Simplify long sentences
                    if len(sentence.split()) > 15:
                        key_points.append(" ".join(sentence.split()[:15]) + "...")
                else:
                    key_points.append(sentence)
                
                # Ensure we have at least 3 key points
                while len(key_points) < 3:
                    key_points.append(f"Additional information from the {domain} content")
            
            return {
                "brief": brief_summary,
                "key_points": key_points[:5],  # Limit to 5 key points
                "difficulty_level": difficulty,
                "estimated_reading_time": round(reading_time, 1)
            }
            
        except Exception as e:
            self.logger.error(f"Summary generation failed: {str(e)}")
            # Return a default summary in case of errors
            return {
                "brief": "Summary unavailable due to processing error.",
                "key_points": ["Content available in full document"],
                "difficulty_level": grade_level,
                "estimated_reading_time": 5.0
            }
    
    def _estimate_difficulty(self, text: str, grade_level: str) -> str:
        """Estimate the difficulty level of the text"""
        # Simple implementation to estimate reading difficulty
        sentences = sent_tokenize(text)
        if not sentences:
            return grade_level
        
        # Get average sentence length
        avg_sentence_length = sum(len(s.split()) for s in sentences) / len(sentences)
        
        # Get percentage of complex words (rough approximation)
        words = [w.lower() for s in sentences for w in word_tokenize(s)]
        complex_word_count = sum(1 for w in words if len(w) > 8)
        complex_word_pct = complex_word_count / max(1, len(words))
        
        # Calculate a complexity score
        complexity_score = (avg_sentence_length * 0.6) + (complex_word_pct * 100 * 0.4)
        
        # Adjust based on input grade level
        if grade_level == "elementary":
            complexity_score -= 5
        elif grade_level == "university":
            complexity_score += 5
        
        # Map score to difficulty level
        if complexity_score < 10:
            return "beginner"
        elif complexity_score < 15:
            return "intermediate"
        elif complexity_score < 20:
            return "advanced"
        else:
            return "expert"
    
    def _generate_domain_specific_analysis(self, content: Dict[str, Any], domain: str,
                                         grade_level: str, detail_level: str) \
            -> Optional[Dict[str, Any]]:
        """
        Generate domain-specific analysis
        
        Args:
            content: Extracted content dictionary
            domain: Content domain
            grade_level: Educational grade level
            detail_level: Level of detail
            
        Returns:
            Domain-specific analysis or None
        """
        try:
            # Only generate for supported domains
            if domain not in ContentAnalysisSchema.DOMAIN_SPECIFIC_SCHEMAS:
                return None
            
            # Extract text content
            text = content.get("content", "")
            if not text:
                return None
            
            # Use LLM for domain-specific analysis if available
            if self.llm_available and hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                try:
                    # Truncate text if too long
                    truncated_text = text[:3000] if len(text) > 3000 else text
                    
                    # Create domain-specific prompts
                    if domain == "mathematics":
                        prompt = f"""
                        Extract mathematical equations and variables from this text:
                        {truncated_text}
                        
                        Format as JSON:
                        {{
                            "equations": [
                                {{"latex": "equation1", "description": "what it represents"}}
                            ],
                            "variables": [
                                {{"name": "variable name", "description": "what it represents", "units": "units of measurement"}}
                            ],
                            "complexity_level": "beginner/intermediate/advanced"
                        }}
                        """
                    elif domain == "physics":
                        prompt = f"""
                        Extract physics principles and experiments from this text:
                        {truncated_text}
                        
                        Format as JSON:
                        {{
                            "principles": [
                                {{"name": "principle name", "description": "what it states"}}
                            ],
                            "experiments": [
                                {{"name": "experiment name", "description": "what it demonstrates"}}
                            ]
                        }}
                        """
                    elif domain == "computer_science":
                        prompt = f"""
                        Extract algorithms and code examples from this text:
                        {truncated_text}
                        
                        Format as JSON:
                        {{
                            "algorithms": [
                                {{"name": "algorithm name", "description": "what it does", "complexity": "time complexity"}}
                            ],
                            "code_examples": [
                                {{"language": "programming language", "code": "code snippet", "explanation": "what it does"}}
                            ]
                        }}
                        """
                    else:
                        return None
                    
                    # Generate LLM response
                    llm_response = self.llm_client.generate(prompt, max_tokens=500)
                    
                    # Try to parse JSON response
                    try:
                        # Extract JSON object from response
                        json_str = re.search(r'({.*})', llm_response, re.DOTALL)
                        if json_str:
                            domain_analysis = json.loads(json_str.group(1))
                            return domain_analysis
                    except Exception as e:
                        self.logger.warning(f"Failed to parse LLM domain analysis: {str(e)}")
                
                except Exception as e:
                    self.logger.warning(f"LLM domain analysis failed: {str(e)}")
            
            # Fallback to basic templates if LLM unavailable or failed
            if domain == "mathematics":
                return {
                    "equations": [{"latex": "E = mc^2", "description": "Energy-mass equivalence"}],
                    "variables": [{"name": "E", "description": "Energy", "units": "joules"}],
                    "complexity_level": "intermediate"
                }
            elif domain == "physics":
                return {
                    "principles": [{"name": "Conservation of Energy", "description": "Energy cannot be created or destroyed"}],
                    "experiments": [{"name": "Double Slit", "description": "Demonstrates wave-particle duality"}]
                }
            elif domain == "computer_science":
                return {
                    "algorithms": [{"name": "Quicksort", "description": "Sorting algorithm", "complexity": "O(n log n)"}],
                    "code_examples": [{"language": "Python", "code": "print('Hello world')", "explanation": "Basic output"}]
                }
            
            return None
            
        except Exception as e:
            self.logger.error(f"Domain-specific analysis failed: {str(e)}")
            return None
    
    def _generate_quiz(self, content: Dict[str, Any], concepts: List[Dict[str, Any]],
                     grade_level: str) -> List[Dict[str, Any]]:
        """
        Generate quiz questions based on content
        
        Args:
            content: Extracted content dictionary
            concepts: Extracted concepts
            grade_level: Educational grade level
            
        Returns:
            List of quiz questions
        """
        try:
            # If no concepts available, return a simple default quiz
            if not concepts:
                return [{
                    "question": "What is the main topic discussed in this content?",
                    "options": ["Topic A", "Topic B", "Topic C", "Topic D"],
                    "correct_answer": 0,
                    "explanation": "The content primarily discusses Topic A.",
                    "difficulty": "medium"
                }]
            
            # Extract text content
            text = content.get("content", "")
            if not text:
                return []
                
            quiz_questions = []
            
            # Generate questions based on top concepts
            if self.llm_available and hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                try:
                    # Process top concepts (maximum 5)
                    for i, concept in enumerate(concepts[:5]):
                        concept_name = concept["name"]
                        concept_desc = concept["description"]
                        
                        # Find relevant sentences for context
                        sentences = sent_tokenize(text)
                        relevant_sentences = [s for s in sentences if concept_name.lower() in s.lower()]
                        context = " ".join(relevant_sentences[:3]) if relevant_sentences else text[:500]
                        
                        # Generate a question about this concept
                        question_prompt = f"""
                        Create a multiple-choice question about the concept '{concept_name}' based on this context:
                        {context}
                        
                        Format:
                        Question: (the question)
                        Option A: (first option)
                        Option B: (second option)
                        Option C: (third option)
                        Option D: (fourth option)
                        Correct: (A, B, C, or D)
                        Explanation: (why this answer is correct)
                        Difficulty: (easy, medium, or hard)
                        """
                        
                        question_response = self.llm_client.generate(question_prompt, max_tokens=300)
                        
                        # Parse the response
                        try:
                            lines = question_response.strip().split('\n')
                            question_text = next((line.split(':', 1)[1].strip() 
                                              for line in lines if line.startswith('Question:')), 
                                             f"What best describes {concept_name}?")
                            
                            options = []
                            for letter in ['A', 'B', 'C', 'D']:
                                option = next((line.split(':', 1)[1].strip() 
                                           for line in lines if line.startswith(f'Option {letter}:')), 
                                          f"Option about {concept_name}")
                                options.append(option)
                            
                            correct_letter = next((line.split(':', 1)[1].strip() 
                                              for line in lines if line.startswith('Correct:')), 'A')
                            correct_index = ord(correct_letter[0]) - ord('A')  # Convert letter to index
                            
                            explanation = next((line.split(':', 1)[1].strip() 
                                            for line in lines if line.startswith('Explanation:')), 
                                           f"Related to the concept of {concept_name}")
                            
                            difficulty = next((line.split(':', 1)[1].strip() 
                                           for line in lines if line.startswith('Difficulty:')), 'medium')
                            
                            # Validate difficulty
                            if difficulty not in ['easy', 'medium', 'hard']:
                                difficulty = 'medium'
                                
                            # Validate correct index
                            if correct_index < 0 or correct_index >= len(options):
                                correct_index = 0
                            
                            quiz_questions.append({
                                "question": question_text,
                                "options": options,
                                "correct_answer": correct_index,
                                "explanation": explanation,
                                "difficulty": difficulty
                            })
                            
                        except Exception as e:
                            self.logger.warning(f"Failed to parse LLM quiz question: {str(e)}")
                            # Add a fallback question
                            quiz_questions.append({
                                "question": f"Which statement best describes {concept_name}?",
                                "options": [
                                    concept_desc[:100],
                                    f"The opposite of {concept_name}",
                                    f"A concept unrelated to {concept_name}",
                                    f"None of the above"
                                ],
                                "correct_answer": 0,
                                "explanation": f"The first option correctly describes {concept_name}.",
                                "difficulty": "medium"
                            })
                            
                except Exception as e:
                    self.logger.warning(f"LLM quiz generation failed: {str(e)}. Using fallback method.")
                    # Will use fallback below
            
            # If we didn't generate any questions with LLM (or it failed), use fallback
            if not quiz_questions:
                # Generate simple questions based on concepts
                for i, concept in enumerate(concepts[:5]):
                    concept_name = concept["name"]
                    concept_desc = concept["description"]
                    
                    # Create basic question
                    quiz_questions.append({
                        "question": f"Which of the following best describes {concept_name}?",
                        "options": [
                            concept_desc[:100] + "..." if len(concept_desc) > 100 else concept_desc,
                            f"The opposite of {concept_name}",
                            f"A process unrelated to {concept_name}",
                            f"None of the above"
                        ],
                        "correct_answer": 0,
                        "explanation": f"The description matches the concept of {concept_name}.",
                        "difficulty": "medium"
                    })
            
            # Adjust quiz difficulty based on grade level
            for question in quiz_questions:
                if grade_level == "elementary":
                    question["difficulty"] = "easy"
                elif grade_level == "university":
                    if question["difficulty"] == "easy":
                        question["difficulty"] = "medium"
            
            return quiz_questions
            
        except Exception as e:
            self.logger.error(f"Quiz generation failed: {str(e)}")
            # Return a simple fallback quiz
            return [{
                "question": "What is the main topic of this content?",
                "options": ["Topic A", "Topic B", "Topic C", "Topic D"],
                "correct_answer": 0,
                "explanation": "The content primarily discusses Topic A.",
                "difficulty": "medium"
            }]
    
    def _generate_topic(self, content: Dict[str, Any], domain: str) -> str:
        """
        Generate a topic title for the content
        
        Args:
            content: Extracted content dictionary
            domain: Content domain
            
        Returns:
            Topic title string
        """
        try:
            # Extract text content
            text = content.get("content", "")
            
            if not text:
                return "Untitled Document"
                
            # Try to find title in metadata if available
            if "title" in content:
                return content["title"]
                
            # Try to extract from first page
            if "pages" in content and content["pages"]:
                first_page = content["pages"][0]
                if "title" in first_page:
                    return first_page["title"]
                    
                # Try to find a title-like line in the first page text
                if "text" in first_page:
                    lines = first_page["text"].split("\n")
                    # Look for short lines at the beginning that might be titles
                    for line in lines[:5]:
                        if 3 <= len(line.split()) <= 10 and any(c.isupper() for c in line):
                            return line.strip()
            
            # Use LLM to generate title if available
            if self.llm_available and hasattr(self.llm_client, 'api_key') and self.llm_client.api_key:
                try:
                    # Truncate text if too long
                    truncated_text = text[:3000] if len(text) > 3000 else text
                    
                    # Prompt for title generation
                    prompt = f"Based on the following text, generate a concise, descriptive title (maximum 10 words):\n\n{truncated_text}\n\nTitle:"
                    title = self.llm_client.generate(prompt, max_tokens=50).strip()
                    
                    # Check if we got a reasonable title
                    if title and len(title.split()) <= 12:
                        return title
                except Exception as e:
                    self.logger.warning(f"LLM title generation failed: {str(e)}. Using fallback method.")
            
            # Fallback: Extract key phrases for title
            sentences = sent_tokenize(text)
            if sentences:
                # Use first sentence for keywords
                first_sentence = sentences[0]
                
                # Remove stop words and extract nouns/important words
                words = word_tokenize(first_sentence.lower())
                filtered_words = [w for w in words if w.isalpha() and w not in self.stop_words]
                
                # Take the first few important words
                if filtered_words:
                    title_words = filtered_words[:4]
                    title = " ".join(w.capitalize() for w in title_words)
                    return f"{title} ({domain.capitalize()})"
            
            # Default title with domain
            return f"{domain.capitalize()} Content"
            
        except Exception as e:
            self.logger.error(f"Topic generation failed: {str(e)}")
            # Return generic title
            return f"Educational Content ({domain.capitalize()})"
    
    def set_api_key(self, api_key: str) -> bool:
        """
        Set or update the API key for the LLM client
        
        Args:
            api_key: OpenRouter API key (starts with sk-...)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if self.llm_available and hasattr(self.llm_client, 'update_api_key'):
                success = self.llm_client.update_api_key(api_key)
                self.model_path = api_key  # Update the stored model_path as well
                self.logger.info("API key updated successfully")
                return success
            else:
                self.logger.warning("Cannot update API key: LLM client not available or doesn't support key updates")
                return False
        except Exception as e:
            self.logger.error(f"Failed to update API key: {str(e)}")
            return False
    
    def process_document(self, pdf_path: str, output_dir: str,
                      extract_images: bool = True,
                      extract_tables: bool = True,
                      respect_heading_hierarchy: bool = True,
                      domain_focus: Optional[str] = None,
                      grade_level: str = "general",
                      detail_level: str = "standard",
                      include_quiz: bool = False,
                      language: str = "en") -> Dict[str, Any]:
        """
        Process a PDF document through the content analysis pipeline.
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store output files
            extract_images: Whether to extract images from the PDF
            extract_tables: Whether to extract tables from the PDF
            respect_heading_hierarchy: Whether to maintain heading hierarchy in extraction
            domain_focus: Optional domain to focus analysis on
            grade_level: Target grade level for content analysis
            detail_level: Level of detail for analysis
            include_quiz: Whether to generate quiz questions
            language: Language of the content
            
        Returns:
            Dictionary containing the analysis results
        """
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize PDF extractor with default parameters
        pdf_extractor = EnhancedPDFExtractor()
        
        try:
            # Extract content from PDF with the extraction parameters
            extracted_content = pdf_extractor.extract_content(
                pdf_path=pdf_path, 
                output_dir=output_dir,
                extract_images=extract_images,
                extract_tables=extract_tables,
                respect_heading_hierarchy=respect_heading_hierarchy
            )
            
            # Analyze the extracted content
            analysis_result = self.analyze_content(
                extracted_content=extracted_content,
                output_dir=output_dir,
                domain_focus=domain_focus,
                grade_level=grade_level,
                detail_level=detail_level,
                include_quiz=include_quiz,
                language=language
            )
            
            return analysis_result
            
        except Exception as e:
            logging.error(f"Error processing document {pdf_path}: {str(e)}")
            raise ContentAnalysisError(f"Failed to process document: {str(e)}")
    