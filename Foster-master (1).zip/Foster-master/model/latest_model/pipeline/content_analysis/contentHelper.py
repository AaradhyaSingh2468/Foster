import re

class TextProcessor:
    """Provides text manipulation and preprocessing utilities"""
    
    def __init__(self):
        self.stop_words = {'the', 'and', 'of', 'to', 'a', 'in', 'for', 'is', 'on', 'that', 
                     'by', 'this', 'with', 'i', 'you', 'it', 'not', 'or', 'be', 'are', 
                     'from', 'at', 'as', 'your', 'have', 'has', 'had', 'was', 'were', 
                     'they', 'their', 'them', 'we', 'our', 'us', 'he', 'she', 'his', 
                     'her', 'him', 'an', 'can', 'will', 'just', 'do', 'does', 'did',
                     'but', 'if', 'so', 'what', 'when', 'where', 'how', 'all', 'any',
                     'both', 'each', 'few', 'more', 'most', 'some', 'such', 'no', 'nor',
                     'too', 'very', 'one', 'every', 'least', 'less', 'many', 'now',
                     'ever', 'never', 'say', 'says', 'said', 'also', 'like', 'time'}
    
    def segment_text_block(self, text):
        """Break a block of text into logical segments."""
        segments = []
        paragraphs = text.split('\n\n')
        
        for paragraph in paragraphs:
            if not paragraph.strip():
                continue
                
            segments.append({
                'type': 'paragraph',  # Default type
                'content': paragraph.strip()
            })
            
        return segments
    
    def find_term_positions(self, text, term):
        """Find all positions of a term in text."""
        positions = []
        pattern = r'\b' + re.escape(term) + r'\b'

        for match in re.finditer(pattern, text, re.IGNORECASE):
            positions.append(match.start())

        return positions
    
    def detect_poetic_structure(self, text):
        """Detect if text has poetic structure based on line length patterns"""
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not lines:
            return False
        
        # Count lines with similar length (potential verse structure)
        line_lengths = [len(line) for line in lines]
        
        # Get average line length
        avg_length = sum(line_lengths) / len(line_lengths)
        
        # Count lines within 50% of average length (consistent structure)
        consistent_lines = sum(1 for length in line_lengths if 0.5*avg_length <= length <= 1.5*avg_length)
        
        # If at least 60% of lines have consistent length, likely poetry
        return (consistent_lines / len(line_lengths)) > 0.6

    def find_term_locations(self, text, term):
        """
        Find locations of a term in the text.

        Args:
            text (str): The text to search in
            term (str): The term to locate

        Returns:
            List of positions (character indices) where the term appears
        """
        import re

        locations = []
        pattern = r'\b' + re.escape(term) + r'\b'

        for match in re.finditer(pattern, text, re.IGNORECASE):
            locations.append(match.start())

        return locations

    def count_term_occurrences(self, text, term):
        """
        Count occurrences of a term in text.

        Args:
            text (str): The text to search in
            term (str): The term to count

        Returns:
            Number of occurrences
        """
        import re
        # Use word boundaries to ensure we match whole words
        pattern = r'\b' + re.escape(term) + r'\b'
        return len(re.findall(pattern, text, re.IGNORECASE))

    def get_context_around_term(self, text, term, context_size=100):
        """
        Get text context around a term.

        Args:
            text (str): The text to search in
            term (str): The term to find context for
            context_size (int): Number of characters around the term

        Returns:
            String with context
        """
        import re

        # Find all occurrences of the term
        matches = list(re.finditer(r'\b' + re.escape(term) + r'\b', text, re.IGNORECASE))

        if not matches:
            return ""

        # Use the first occurrence
        match = matches[0]
        start_pos = max(0, match.start() - context_size)
        end_pos = min(len(text), match.end() + context_size)

        # Extract context
        context = text[start_pos:end_pos]

        # Add ellipsis if needed
        if start_pos > 0:
            context = "..." + context
        if end_pos < len(text):
            context = context + "..."

        return context

    def extract_noun_phrases(self, text):
        """
        Extract noun phrases from text.

        Args:
            text (str): Text to extract noun phrases from

        Returns:
            List of noun phrases
        """
        # Simple implementation using basic patterns
        import re

        # Pattern for simple noun phrases
        noun_phrase_pattern = re.compile(r'(?:[A-Z][a-z]+\s)?(?:[A-Z][a-z]+\s)?[A-Z]?[a-z]+')
        matches = noun_phrase_pattern.findall(text)

        # Filter short phrases and common words
        stop_words = {'the', 'and', 'of', 'to', 'a', 'in', 'for', 'is', 'on', 'that', 'by', 'this', 'with'}
        phrases = [match for match in matches if len(match) > 4 and match.lower() not in stop_words]

        return phrases


class SemanticAnalyzer:
    """Handles semantic analysis of text content"""
    
    def __init__(self, domain_rules=None):
        self.domain_rules = domain_rules or {}
    
    def identify_segment_type(self, text):
        """Identify the type of a text segment."""
        text = text.strip().lower()
        
        # Check if it's a definition
        if text.startswith('definition') or ': is defined as' in text or 'refers to' in text:
            return 'definition'
            
        # Check if it's an example
        if text.startswith('example') or text.startswith('for example') or 'for instance' in text:
            return 'example'
            
        # Check if it's a theorem/proposition
        if text.startswith('theorem') or text.startswith('proposition') or text.startswith('lemma'):
            return 'theorem'
            
        # Check if it's a proof
        if text.startswith('proof') or text.endswith('q.e.d.') or text.endswith('□'):
            return 'proof'
            
        # Check domain-specific section types
        if 'section_types' in self.domain_rules:
            for section_type in self.domain_rules['section_types']:
                if section_type.lower() in text[:20]:
                    return section_type
        
        # Default to paragraph
        return 'paragraph'
    
    def generate_semantic_tags(self, text):
        """Generate semantic tags for a piece of text."""
        tags = []
        
        # Check for domain-specific terminology
        if 'terminologies' in self.domain_rules:
            for term in self.domain_rules['terminologies']:
                if term.lower() in text.lower():
                    tags.append(term)
        
        # Check if text contains numerical data
        if any(char.isdigit() for char in text):
            tags.append('numerical_data')
            
        # Check if text contains questions
        if '?' in text:
            tags.append('question')
            
        # Check if text contains lists
        if any(line.strip().startswith(('-', '•', '*')) for line in text.split('\n')):
            tags.append('list')
            
        return tags


class KeywordExtractor:
    """Extracts keywords and concepts from text"""
    
    def __init__(self, stop_words=None, domain_rules=None):
        self.stop_words = stop_words or set()
        self.domain_rules = domain_rules or {}
    
    def extract_keywords_and_concepts(self, text, domain=None, max_terms=20, min_word_length=3):
        """Extract key terms and concepts from text, optionally customized by domain."""
        # Split text into words and clean them
        if not text:
            return {'keywords': [], 'concepts': []}

        words = text.lower().split()
        words = [word.strip('.,;:()[]{}"\'-') for word in words if word.strip('.,;:()[]{}"\'-')]

        # Remove stop words and short words
        filtered_words = [word for word in words if word not in self.stop_words and len(word) > min_word_length]

        # Count word frequencies
        word_freq = {}
        for word in filtered_words:
            word_freq[word] = word_freq.get(word, 0) + 1

        # Get top keywords by frequency
        keywords = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:max_terms]

        # Extract multi-word concepts (bigrams)
        bigrams = []
        for i in range(len(filtered_words) - 1):
            if filtered_words[i] and filtered_words[i+1]:
                bigram = filtered_words[i] + ' ' + filtered_words[i+1]
                bigrams.append(bigram)

        bigram_counts = {}
        for bigram in bigrams:
            bigram_counts[bigram] = bigram_counts.get(bigram, 0) + 1

        # Get top bigrams
        top_bigrams = sorted(bigram_counts.items(), key=lambda x: x[1], reverse=True)[:max_terms//2]

        # Extract domain-specific concepts if available
        domain_concepts = []
        if domain and self.domain_rules:
            if 'entity_patterns' in self.domain_rules:
                for pattern in self.domain_rules['entity_patterns']:
                    matches = re.findall(pattern, text)
                    domain_concepts.extend(matches)

        return {
            'keywords': [keyword for keyword, _ in keywords],
            'bigrams': [bigram for bigram, _ in top_bigrams],
            'domain_concepts': domain_concepts,
            'word_frequencies': word_freq,
            'raw_keywords': keywords,  # Include frequency information
            'raw_bigrams': top_bigrams  # Include frequency information
        }
    
    def extract_keywords_with_positions(self, text, domain=None, max_terms=20, min_word_length=3):
        """Extract keywords with their positions in the text."""
        # Get base extraction results
        base_results = self.extract_keywords_and_concepts(text, domain, max_terms, min_word_length)

        # Add position information
        terms_with_positions = {}
        text_processor = TextProcessor()

        # Find positions for keywords
        for keyword in base_results['keywords']:
            positions = text_processor.find_term_positions(text, keyword)
            if positions:
                terms_with_positions[keyword] = positions

        # Find positions for bigrams
        for bigram in base_results['bigrams']:
            positions = text_processor.find_term_positions(text, bigram)
            if positions:
                terms_with_positions[bigram] = positions

        # Find positions for domain concepts
        for concept in base_results['domain_concepts']:
            positions = text_processor.find_term_positions(text, concept)
            if positions:
                terms_with_positions[concept] = positions

        # Add position information to results
        base_results['term_positions'] = terms_with_positions

        return base_results
    
    def extract_key_terms_with_importance(self, text, domain_rules=None, max_terms=20, min_word_length=3):
        """Extract key terms with importance scores."""
        result = self.extract_keywords_and_concepts(text, domain_rules, max_terms*2, min_word_length)
        term_importance = {}
        
        # Add single words with their importance
        for term, count in result['raw_keywords']:
            # Calculate importance using frequency
            term_importance[term] = count / max(1, len(text.split())) * 0.8  # Single words get slightly lower weight
        
        # Add bigrams with higher weight
        for bigram, count in result['raw_bigrams']:
            if count > 1:  # Only include bigrams that occur more than once
                term_importance[bigram] = count / max(1, len(result.get('bigrams', []))) * 1.2  # Bigrams get higher weight
        
        # Add domain-specific concepts with highest weight
        for concept in result.get('domain_concepts', []):
            # Domain concepts get highest weight
            term_importance[concept] = 1.5
        
        # Sort by importance and return top terms
        sorted_terms = sorted(term_importance.items(), key=lambda x: x[1], reverse=True)
        
        return sorted_terms[:max_terms]

    def count_bigram_frequency(self, text, bigram):
        """Count frequency of a bigram in text"""
        words = text.lower().split()
        count = 0
        bigram_parts = bigram.lower().split()
        
        if len(bigram_parts) != 2:
            return 0
            
        for i in range(len(words) - 1):
            if words[i] == bigram_parts[0] and words[i+1] == bigram_parts[1]:
                count += 1
        
        return count
    
    def get_ngrams(self, text, n=3):
        """Generate n-grams from text"""
        return [text[i:i+n] for i in range(len(text)-n+1)]
    
    def calculate_term_similarity(self, term_a, term_b):
        """
        Calculate similarity between two terms using n-grams.
        
        Args:
            term_a (str): First term
            term_b (str): Second term
            
        Returns:
            Similarity score between 0 and 1
        """
        # Convert to lower case
        term_a = term_a.lower()
        term_b = term_b.lower()
        
        # Generate character 3-grams
        ngrams_a = set(self.get_ngrams(term_a))
        ngrams_b = set(self.get_ngrams(term_b))
        
        # Calculate Jaccard similarity
        if not ngrams_a or not ngrams_b:
            return 0
        
        intersection = len(ngrams_a.intersection(ngrams_b))
        union = len(ngrams_a.union(ngrams_b))
        
        return intersection / union if union > 0 else 0

class SentimentAnalyzer:
    """Analyzes sentiment and tone in text"""
    
    def perform_sentiment_analysis(self, text):
        """Analyze tone and sentiment of content sections using industry-standard NLP libraries."""
        try:
            # Using NLTK's VADER (Valence Aware Dictionary and sEntiment Reasoner)
            # VADER is specifically attuned to sentiments expressed in social media and works well on texts
            from nltk.sentiment.vader import SentimentIntensityAnalyzer
            import nltk
            from textblob import TextBlob
            
            # Ensure NLTK resources are downloaded
            try:
                nltk.data.find('vader_lexicon')
            except LookupError:
                nltk.download('vader_lexicon', quiet=True)
            
            # Initialize VADER
            sid = SentimentIntensityAnalyzer()
            
            # Get sentiment scores from VADER
            vader_scores = sid.polarity_scores(text)
            
            # Use TextBlob as a second opinion (combines pattern analyzer and NaiveBayesAnalyzer)
            blob = TextBlob(text)
            textblob_polarity = blob.sentiment.polarity  # Range: -1.0 to 1.0
            
            # Combine scores (weight VADER more as it's specifically designed for this)
            compound_score = vader_scores['compound']  # Range: -1.0 to 1.0
            
            # Weighted average (70% VADER, 30% TextBlob)
            weighted_score = (0.7 * compound_score) + (0.3 * textblob_polarity)
            
            # Determine overall sentiment
            if weighted_score >= 0.05:
                sentiment = 'positive'
            elif weighted_score <= -0.05:
                sentiment = 'negative'
            else:
                sentiment = 'neutral'
            
            # Check for academic/formal language
            academic_markers = ['therefore', 'thus', 'consequently', 'furthermore', 'moreover', 
                               'subsequently', 'hence', 'accordingly', 'evidently', 'demonstrably']
            academic_count = sum(text.lower().count(' ' + marker + ' ') for marker in academic_markers)
            
            # More sophisticated approach to detect academic tone
            # Higher ratio of long words often indicates academic writing
            words = text.split()
            long_words = [word for word in words if len(word) > 8]
            long_word_ratio = len(long_words) / max(len(words), 1)
            
            # Use both markers and vocabulary complexity as indicators
            is_academic = (academic_count > len(words) / 200) or (long_word_ratio > 0.15)
            
            return {
                'overall_sentiment': sentiment,
                'compound_score': round(weighted_score, 3),
                'vader_scores': {
                    'negative': round(vader_scores['neg'], 3),
                    'neutral': round(vader_scores['neu'], 3),
                    'positive': round(vader_scores['pos'], 3),
                    'compound': round(vader_scores['compound'], 3)
                },
                'textblob_polarity': round(textblob_polarity, 3),
                'is_academic_tone': is_academic,
                'long_word_ratio': round(long_word_ratio, 3)
            }
        
        except Exception as e:
            # Fallback to a simpler method if libraries aren't available
            print(f"Sentiment analysis error: {str(e)}. Using fallback method.")
            
            # Basic fallback implementation
            positive_words = ['good', 'excellent', 'positive', 'beneficial', 'advantage', 
                             'effective', 'success', 'improve', 'best', 'important']
            negative_words = ['bad', 'poor', 'negative', 'problem', 'disadvantage', 
                             'ineffective', 'failure', 'worse', 'worst', 'difficult']
            
            # Count occurrences of positive and negative words
            text_lower = text.lower()
            positive_count = sum(text_lower.count(' ' + word + ' ') for word in positive_words)
            negative_count = sum(text_lower.count(' ' + word + ' ') for word in negative_words)
            
            # Determine overall sentiment
            if positive_count > negative_count * 1.5:
                sentiment = 'positive'
            elif negative_count > positive_count * 1.5:
                sentiment = 'negative'
            else:
                sentiment = 'neutral'
            
            # Check for academic/formal language
            academic_markers = ['therefore', 'thus', 'consequently', 'furthermore', 'moreover']
            academic_count = sum(text_lower.count(' ' + marker + ' ') for marker in academic_markers)
            is_academic = academic_count > len(text.split()) / 200
            
            return {
                'overall_sentiment': sentiment,
                'positive_count': positive_count,
                'negative_count': negative_count,
                'is_academic_tone': is_academic,
                'fallback_method': True
            }


class TextSummarizer:
    """Generates summaries of text content"""
    
    def __init__(self, keyword_extractor=None):
        self.keyword_extractor = keyword_extractor or KeywordExtractor()
    
    def generate_summaries(self, sections, max_length=200):
        """Create concise summaries of complex sections."""
        # Simple extractive summarization implementation
        
        if isinstance(sections, str):
            text = sections
        else:
            # If sections is a dictionary or list, concatenate all text
            text = ' '.join([section if isinstance(section, str) else section.get('text', '')
                             for section in sections])
        
        # Split into sentences
        sentences = text.replace('!', '.').replace('?', '.').split('.')
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if not sentences:
            return ""
        
        # Simple scoring: prefer sentences with keywords and at the beginning/end
        keywords = self.keyword_extractor.extract_keywords_and_concepts(text)['keywords'][:10]
        
        scored_sentences = []
        for i, sentence in enumerate(sentences):
            # Score based on position (beginning and end sentences are important)
            position_score = 1.0
            if i < len(sentences) / 10:  # First 10%
                position_score = 2.0
            elif i > len(sentences) * 0.9:  # Last 10%
                position_score = 1.5
                
            # Score based on keyword presence
            keyword_score = sum(1.0 for keyword in keywords if keyword in sentence.lower())
            
            # Score based on sentence length (not too short, not too long)
            length = len(sentence.split())
            length_score = 1.0
            if 5 <= length <= 20:
                length_score = 1.5
                
            # Combine scores
            total_score = position_score + keyword_score + length_score
            scored_sentences.append((sentence, total_score))
        
        # Sort by score and select top sentences
        scored_sentences.sort(key=lambda x: x[1], reverse=True)
        
        # Select top sentences up to max_length
        summary = ""
        for sentence, _ in scored_sentences:
            if len(summary) + len(sentence) <= max_length:
                summary += sentence + ". "
            else:
                break
                
        return summary.strip()
