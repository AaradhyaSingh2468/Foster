from contentHelper import *
from pipeline.adaptive_learning.DomainRulesManager import DomainRulesManager

class ContentAnalyzer:
    def __init__(self, language_model=None, domain=None, extractor=None):
        """
        Initialize with optional connection to an extractor
        
        Args:
            language_model: Optional pre-trained language model
            domain: Optional domain specification
            extractor: Optional PDFContentExtractor to use for segmentation
        """
        self.language_model = language_model
        self.domain = domain
        self.domain_specific_rules = self._load_domain_rules(domain)
        self.extractor = extractor
        
        # Create helper objects
        self.text_processor = TextProcessor()
        self.semantic_analyzer = SemanticAnalyzer(self.domain_specific_rules)
        self.keyword_extractor = KeywordExtractor(self.text_processor.stop_words, self.domain_specific_rules)
        self.sentiment_analyzer = SentimentAnalyzer()
        self.text_summarizer = TextSummarizer(self.keyword_extractor)
    
    def _load_domain_rules(self, domain):
        """
        Load domain-specific rules and patterns for content analysis.

        Args:
            domain: The domain to load rules for

        Returns:
            Dictionary of rules and patterns specific to the domain
        """
        return DomainRulesManager.get_domain_rules(domain)
    
    def analyze_content(self, extraction_result):
        """
        Main method to analyze extracted content from a PDF.
        
        Args:
            extraction_result: Dictionary containing the extracted content from PDFContentExtractor
            
        Returns:
            Dictionary containing the original content enriched with semantic annotations
        """
        analyzed_result = extraction_result.copy()
        if self.language_model is not None:
            return self._analyze_with_language_model(extraction_result)
        
        # Add semantic analysis to the content
        if 'content_blocks' in analyzed_result:
            analyzed_result['content_blocks'] = self.tag_content_blocks(analyzed_result['content_blocks'])
        
        # Extract keywords and concepts
        if 'text_content' in analyzed_result:
            analyzed_result['keywords_and_concepts'] = self.keyword_extractor.extract_keywords_and_concepts(
                analyzed_result['text_content'], self.domain
            )
        
        # Generate summaries for sections
        if 'sections' in analyzed_result:
            analyzed_result['section_summaries'] = {
                section_id: self.text_summarizer.generate_summaries(section_content)
                for section_id, section_content in analyzed_result['sections'].items()
            }
        
        # Segment content into logical units
        analyzed_result['content_segments'] = self.segment_content(extraction_result)
        
        # Add sentiment analysis if text is available
        if 'text_content' in analyzed_result:
            analyzed_result['sentiment_analysis'] = self.sentiment_analyzer.perform_sentiment_analysis(
                analyzed_result['text_content']
            )
        
        if self.domain == 'literature':
            try:
                # Extract full text content
                text_content = extraction_result.get('text_content', '')
                work_subtype = self._determine_literary_work_subtype(text_content)
    
                if work_subtype:
                    # Add literary analysis (without causing recursion)
                    analyzed_result['literary_analysis'] = self.analyze_literary_work(
                        extraction_result, work_subtype
                    )
            except Exception as e:
                # Fail gracefully if the literary analysis can't be performed
                analyzed_result['literary_analysis_error'] = str(e)
    
        return analyzed_result
    
    def segment_content(self, extraction_result):
        """
        Divides content into logical segments using extractor if available,
        otherwise uses built-in segmentation
        
        Args:
            extraction_result: Dictionary with extracted content
            
        Returns:
            List of content segments with semantic annotations
        """
        segments = []
        
        # Use extractor for segmentation if available
        if self.extractor and hasattr(self.extractor, 'segment_text'):
            # If we have structured content already
            if 'pages' in extraction_result:
                for page in extraction_result['pages']:
                    for block in page.get('blocks', []):
                        # Get base segmentation from extractor
                        if 'text' in block:
                            text_segments = self.extractor.segment_text(block['text'])
                            for text in text_segments:
                                # Add semantic annotation 
                                segment_type = self.semantic_analyzer.identify_segment_type(text)
                                segments.append({
                                    'type': segment_type,
                                    'content': text,
                                    'semantic_tags': self.semantic_analyzer.generate_semantic_tags(text)
                                })
            # If we only have raw text
            elif 'text_content' in extraction_result:
                text_segments = self.extractor.segment_text(extraction_result['text_content'])
                for text in text_segments:
                    segment_type = self.semantic_analyzer.identify_segment_type(text)
                    segments.append({
                        'type': segment_type,
                        'content': text,
                        'semantic_tags': self.semantic_analyzer.generate_semantic_tags(text)
                    })
        else:
            # Fall back to built-in segmentation
            if 'document_structure' in extraction_result:
                structure = extraction_result['document_structure']
                for section in structure:
                    # Create a segment for the heading
                    if 'heading' in section:
                        segments.append({
                            'type': 'heading',
                            'level': section.get('level', 1),
                            'content': section['heading'],
                            'semantic_tags': self.semantic_analyzer.generate_semantic_tags(section['heading'])
                        })
                    
                    # Process the content under this heading
                    if 'content' in section:
                        content_segments = self.text_processor.segment_text_block(section['content'])
                        segments.extend(content_segments)
            
            # If no structure is available, segment the raw text
            elif 'text_content' in extraction_result:
                segments = self.text_processor.segment_text_block(extraction_result['text_content'])
        
        return segments
    
    def tag_content_blocks(self, blocks):
        """
        Classify content blocks into specific types.
        
        Args:
            blocks: List of content blocks from the extraction result
            
        Returns:
            List of content blocks with type classification added
        """
        tagged_blocks = []
        
        for block in blocks:
            block_copy = block.copy()
            
            # Determine the block type based on content and structure
            if 'text' in block:
                block_copy['block_type'] = self.semantic_analyzer.identify_segment_type(block['text'])
                
                # Add additional semantic tags if possible
                block_copy['semantic_tags'] = self.semantic_analyzer.generate_semantic_tags(block['text'])
            
            tagged_blocks.append(block_copy)
            
        return tagged_blocks
    
    def analyze_literary_work(self, extraction_result, work_type='novel'):
        """
        Special method for analyzing literary works like Shakespeare plays

        Args:
            extraction_result: Dictionary containing the extracted content
            work_type: Type of literary work ('play', 'novel', 'poem')

        Returns:
            Dictionary with literary analysis results
        """
        # Create literary work analyzer
        literary_analyzer = LiteraryWorkAnalyzer(work_type)

        # Extract full text content
        text_content = extraction_result.get('text_content', '')

        # Initialize result dictionary
        literary_analysis = {
            'characters': literary_analyzer.analyze_characters(text_content),
            'structure': literary_analyzer.identify_scenes(text_content),
            'literary_devices': literary_analyzer.detect_literary_devices(text_content)
        }

        # For plays and poetry, add verse analysis
        if work_type in ['play', 'poem']:
            literary_analysis['verse_patterns'] = literary_analyzer.analyze_verse_patterns(text_content)

        # For Shakespeare works, add theme analysis
        if work_type == 'play:shakespeare':
            literary_analysis['themes'] = literary_analyzer.detect_shakespearean_themes(text_content)

        return literary_analysis

    # Delegate methods to appropriate classes for interface compatibility
    def extract_keywords_and_concepts(self, text, domain=None, max_terms=20, min_word_length=3):
        return self.keyword_extractor.extract_keywords_and_concepts(text, domain, max_terms, min_word_length)
    
    def extract_keywords_with_positions(self, text, domain=None, max_terms=20, min_word_length=3):
        return self.keyword_extractor.extract_keywords_with_positions(text, domain, max_terms, min_word_length)
    
    def extract_key_terms_with_importance(self, text, max_terms=20, min_word_length=3):
        return self.keyword_extractor.extract_key_terms_with_importance(text, self.domain_specific_rules, max_terms, min_word_length)
    
    def generate_summaries(self, sections, max_length=200):
        return self.text_summarizer.generate_summaries(sections, max_length)
    
    def perform_sentiment_analysis(self, text):
        return self.sentiment_analyzer.perform_sentiment_analysis(text)
    
    def _determine_literary_work_subtype(self, text_content):
        """
        Determine the subtype of literary work based on content analysis.

        Args:
            text_content: The raw text content

        Returns:
            String indicating work subtype or None
        """
        # Check for play-like structure (character names followed by dialogue)
        dialogue_patterns = re.findall(r'([A-Z]{2,}[A-Z\s]*)[\.:]\s', text_content)

        if len(dialogue_patterns) > 10:
            # This looks like a play
            work_subtype = 'play'

            # Check for Shakespeare-specific markers
            shakespeare_markers = ['thee', 'thou', 'thy', 'hath', 'doth', 'prithee', 'forsooth', 'anon']
            shakespeare_count = sum(text_content.lower().count(' ' + marker + ' ') for marker in shakespeare_markers)

            if shakespeare_count > 5:
                work_subtype += ':shakespeare'
        elif re.search(r'Chapter [IVXLCDM]+|Chapter \d+', text_content):
            work_subtype = 'novel'
        elif self.text_processor.detect_poetic_structure(text_content):
            work_subtype = 'poem'
        else:
            work_subtype = 'general'

        return work_subtype
    
    def _find_term_locations(self, text, term):
        return self.text_processor.find_term_locations(text, term)

    def _analyze_with_language_model(self, extraction_result):
        """
        Use the provided language model to perform content analysis.

        Args:
            extraction_result: Dictionary containing the extracted content

        Returns:
            Dictionary with enhanced analysis from the language model
        """
        analyzed_result = extraction_result.copy()
        text_content = extraction_result.get('text_content', '')

        if not text_content:
            # Fallback to original method if no text content is available
            return self.analyze_content(extraction_result)

        # Get comprehensive analysis from language model
        model_analysis = {
            'keywords_and_concepts': self.language_model.extract_keywords(text_content, self.domain),
            'sentiment_analysis': self.language_model.analyze_sentiment(text_content),
            'content_segments': self.language_model.segment_content(text_content),
            'semantic_tags': self.language_model.generate_semantic_tags(text_content, self.domain)
        }

        # Add section summaries if sections exist
        if 'sections' in extraction_result:
            model_analysis['section_summaries'] = {}
            for section_id, section_content in extraction_result['sections'].items():
                model_analysis['section_summaries'][section_id] = self.language_model.summarize_text(
                    section_content, max_length=200
                )

        # Add domain-specific analysis
        if self.domain == 'literature':
            try:
                work_subtype = self._determine_literary_work_subtype(text_content)
                if work_subtype:
                    model_analysis['literary_analysis'] = self.language_model.analyze_literary_work(
                        text_content, work_subtype
                    )
            except Exception as e:
                model_analysis['literary_analysis_error'] = str(e)

        # Merge the language model analysis with the extraction result
        analyzed_result.update(model_analysis)

        return analyzed_result