"""
Utility functions for the visualization element extraction pipeline.

This module contains helper functions, error handling, and logging utilities
to support the main extraction functionality.
"""

import os
import time
import json
import logging
import functools
import traceback
from typing import Any, Callable, Dict, List, Optional, Tuple, TypeVar, Union, cast

import cv2
import numpy as np

from .config import Config

# Set up logger
logger = logging.getLogger(__name__)
Config.setup_logging()

# Type variables for function decorators
F = TypeVar('F', bound=Callable[..., Any])


class ExtractionError(Exception):
    """Base exception class for extraction errors."""
    pass


class PreprocessingError(ExtractionError):
    """Exception raised when image preprocessing fails."""
    pass


class ExtractionFailedError(ExtractionError):
    """Exception raised when data extraction fails."""
    pass


class ValidationError(ExtractionError):
    """Exception raised when data validation fails."""
    pass


def log_execution_time(func: F) -> F:
    """
    Decorator to log the execution time of a function.
    
    Args:
        func: The function to be decorated.
        
    Returns:
        The wrapped function.
    """
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug(f"Function {func.__name__} executed in {execution_time:.4f} seconds")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Function {func.__name__} failed after {execution_time:.4f} seconds: {str(e)}")
            raise
    
    return cast(F, wrapper)


def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0, 
           exceptions: Tuple[Exception, ...] = (Exception,)) -> Callable[[F], F]:
    """
    Retry decorator with exponential backoff.
    
    Args:
        max_attempts: Maximum number of attempts to retry the function.
        delay: Initial delay between retries in seconds.
        backoff: Factor by which the delay increases after each retry.
        exceptions: Exceptions to catch and retry on.
        
    Returns:
        Decorator function.
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            mtries, mdelay = max_attempts, delay
            while mtries > 1:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    logger.warning(f"Retrying {func.__name__} after error: {str(e)}. "
                                 f"Attempts remaining: {mtries-1}")
                    time.sleep(mdelay)
                    mtries -= 1
                    mdelay *= backoff
            return func(*args, **kwargs)
        return cast(F, wrapper)
    return decorator


def safe_execute(default_return: Any = None) -> Callable[[F], F]:
    """
    Decorator to safely execute a function and return a default value on exception.
    
    Args:
        default_return: The default value to return in case of exception.
        
    Returns:
        Decorator function.
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in {func.__name__}: {str(e)}")
                logger.debug(f"Traceback: {traceback.format_exc()}")
                return default_return
        return cast(F, wrapper)
    return decorator


def validate_image(image: np.ndarray) -> bool:
    """
    Validate that an image is properly loaded and usable.
    
    Args:
        image: The image to validate.
        
    Returns:
        True if the image is valid, False otherwise.
    
    Raises:
        ValidationError: If the image is invalid.
    """
    if image is None or image.size == 0:
        raise ValidationError("Image is empty or None")
    
    if len(image.shape) < 2:
        raise ValidationError(f"Invalid image dimensions: {image.shape}")
    
    if not isinstance(image, np.ndarray):
        raise ValidationError(f"Image is not a numpy array, got {type(image)}")
    
    return True


def ensure_directory_exists(directory_path: str) -> None:
    """
    Ensure that the specified directory exists, creating it if necessary.
    
    Args:
        directory_path: Path to the directory.
    """
    if not os.path.exists(directory_path):
        try:
            os.makedirs(directory_path, exist_ok=True)
            logger.debug(f"Created directory: {directory_path}")
        except OSError as e:
            logger.error(f"Failed to create directory {directory_path}: {str(e)}")
            raise


def save_extraction_results(results: Dict[str, Any], output_path: str, 
                            format: str = Config.OUTPUT_FORMAT) -> str:
    """
    Save extraction results to a file.
    
    Args:
        results: Dictionary containing extraction results.
        output_path: Path where the results should be saved.
        format: Output format (json, csv, xml).
        
    Returns:
        Path to the saved file.
    """
    ensure_directory_exists(os.path.dirname(output_path))
    
    try:
        if format.lower() == 'json':
            with open(output_path, 'w') as f:
                json.dump(results, f, indent=2)
        elif format.lower() == 'csv':
            # Implement CSV export logic if needed
            pass
        elif format.lower() == 'xml':
            # Implement XML export logic if needed
            pass
        else:
            logger.warning(f"Unsupported format: {format}, defaulting to JSON")
            with open(output_path, 'w') as f:
                json.dump(results, f, indent=2)
                
        logger.info(f"Saved extraction results to {output_path}")
        return output_path
    
    except Exception as e:
        logger.error(f"Failed to save results to {output_path}: {str(e)}")
        raise


def load_image(image_path: str) -> np.ndarray:
    """
    Safely load an image from a file path.
    
    Args:
        image_path: Path to the image file.
        
    Returns:
        Loaded image as numpy array.
        
    Raises:
        FileNotFoundError: If the image file doesn't exist.
        PreprocessingError: If the image couldn't be loaded.
    """
    if not os.path.exists(image_path):
        logger.error(f"Image file not found: {image_path}")
        raise FileNotFoundError(f"Image file not found: {image_path}")
    
    try:
        image = cv2.imread(image_path)
        if image is None:
            raise PreprocessingError(f"Failed to load image: {image_path}")
        
        validate_image(image)
        logger.debug(f"Successfully loaded image: {image_path}")
        return image
    
    except Exception as e:
        logger.error(f"Error loading image {image_path}: {str(e)}")
        raise PreprocessingError(f"Error loading image {image_path}: {str(e)}") 