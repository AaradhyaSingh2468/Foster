"""
Example script for AI-powered animation generation
--------------------------------------------------
This script demonstrates how to use the enhanced AnimationGenerator with
Stable Diffusion integration to generate actual visuals for educational content.
"""

import os
import json
import time
import logging
import argparse
from typing import Dict, Any

from pipeline.multimedia.MultimediaPipeline import MultimediaGenerationPipeline
from pipeline.multimedia.AnimationGenerator import AnimationGenerator
from pipeline.multimedia.ScriptGenerator import ScriptGenerator

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ExampleAIAnimation")

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Generate AI animations with diffusion models')
    parser.add_argument('--scheduler', type=str, choices=['ddim', 'lms'], default='ddim',
                        help='Scheduler type: DDIM (default) or LMS')
    parser.add_argument('--style', type=str, choices=['modern', 'minimalist', 'playful'], default='modern',
                        help='Visual style of animations')
    args = parser.parse_args()
    
    # Create output directory
    output_dir = f"output/ai_animation_demo_{args.scheduler}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Sample script data (normally this would come from ScriptGenerator)
    script_data = create_sample_script_data()
    
    # Initialize AnimationGenerator with AI enabled
    logger.info(f"Initializing AI-powered AnimationGenerator with {args.scheduler.upper()} scheduler")
    animator = AnimationGenerator(
        style=args.style,
        color_scheme="educational",
        animation_level="standard",
        include_transitions=True,
        use_ai=True,  # Enable AI generation
        model_id="stabilityai/stable-diffusion-2-1-base",
        scheduler_type=args.scheduler,  # Use the specified scheduler
        output_dir=output_dir
    )
    
    # Generate animations with AI visuals
    logger.info("Generating animations with AI visuals")
    start_time = time.time()
    animation_data = animator.generate_animations(script_data)
    
    # Save the animation data
    animation_path = os.path.join(output_dir, "animations.json")
    with open(animation_path, "w", encoding="utf-8") as f:
        json.dump(animation_data, f, indent=2)
    
    # Report results
    total_time = time.time() - start_time
    scene_count = len(animation_data.get("scenes", []))
    logger.info(f"Animation generation completed in {total_time:.2f} seconds")
    logger.info(f"Generated {scene_count} animated scenes using {args.scheduler.upper()} scheduler")
    logger.info(f"Animation data saved to {animation_path}")
    
    # List any generated visual files
    visuals_count = count_generated_visuals(animation_data)
    logger.info(f"Generated {visuals_count} visual files in {output_dir}")
    
    logger.info(f"Completed AI animation example")

def create_sample_script_data() -> Dict[str, Any]:
    """Create a sample script data object for demonstration"""
    return {
        "script": "Sample educational content about photosynthesis",
        "sections": [
            {
                "title": "Introduction",
                "content": "Photosynthesis is the process by which plants convert light energy into chemical energy.",
                "duration": 30,
                "markers": []
            },
            {
                "title": "The Process of Photosynthesis",
                "content": "Photosynthesis takes place in the chloroplasts of plant cells, specifically using the chlorophyll pigments.",
                "duration": 45,
                "markers": []
            },
            {
                "title": "Light and Dark Reactions",
                "content": "The process consists of light-dependent reactions and light-independent (dark) reactions.",
                "duration": 40,
                "markers": []
            },
            {
                "title": "Conclusion",
                "content": "Photosynthesis is essential for life on Earth, producing oxygen and forming the base of most food chains.",
                "duration": 25,
                "markers": []
            }
        ],
        "scenes": [
            {
                "scene_id": "scene_1",
                "title": "Introduction to Photosynthesis",
                "narration": "Welcome to this educational video about photosynthesis. In this video, we'll explore how plants convert sunlight into energy.",
                "duration_estimate": 15,
                "visual_elements": [
                    {
                        "type": "title_slide",
                        "title": "Photosynthesis: Nature's Energy Process",
                        "subtitle": "How plants convert light into chemical energy"
                    }
                ]
            },
            {
                "scene_id": "scene_2",
                "title": "The Process Overview",
                "narration": "Photosynthesis takes place in the chloroplasts of plant cells, using chlorophyll to capture light energy.",
                "duration_estimate": 20,
                "visual_elements": [
                    {
                        "type": "diagram",
                        "title": "Plant Cell Structure",
                        "content": {
                            "type": "cellular",
                            "title": "Chloroplast Structure",
                            "components": ["Outer membrane", "Inner membrane", "Thylakoid", "Stroma"]
                        }
                    },
                    {
                        "type": "bullet_points",
                        "title": "Key Components",
                        "points": [
                            "Chloroplasts: The site of photosynthesis",
                            "Chlorophyll: The primary pigment",
                            "Sunlight: Energy source",
                            "Water and CO2: Raw materials"
                        ]
                    }
                ]
            },
            {
                "scene_id": "scene_3",
                "title": "Light and Dark Reactions",
                "narration": "Photosynthesis consists of two main stages: light-dependent reactions that occur in the thylakoid membrane, and light-independent reactions that take place in the stroma.",
                "duration_estimate": 25,
                "visual_elements": [
                    {
                        "type": "whiteboard",
                        "title": "Two Stages of Photosynthesis",
                        "content": "Drawing showing the flow of electrons in light reactions and the Calvin cycle in dark reactions."
                    }
                ]
            },
            {
                "scene_id": "scene_4",
                "title": "Importance of Photosynthesis",
                "narration": "Photosynthesis is essential for life on Earth. It produces oxygen, which most organisms need for respiration, and it forms the base of most food chains through the production of glucose.",
                "duration_estimate": 15,
                "visual_elements": [
                    {
                        "type": "concept_graph",
                        "content": {
                            "nodes": ["Oxygen Production", "Food Chain Base", "Carbon Cycle", "Plant Growth"],
                            "edges": [
                                ["Photosynthesis", "Oxygen Production"],
                                ["Photosynthesis", "Food Chain Base"],
                                ["Photosynthesis", "Carbon Cycle"],
                                ["Photosynthesis", "Plant Growth"]
                            ]
                        }
                    }
                ]
            },
            {
                "scene_id": "scene_5",
                "title": "Conclusion",
                "narration": "In conclusion, photosynthesis is a remarkable process that harnesses light energy to sustain life on our planet.",
                "duration_estimate": 10,
                "visual_elements": [
                    {
                        "type": "summary_slide",
                        "title": "Key Takeaways",
                        "points": [
                            "Photosynthesis converts light energy to chemical energy",
                            "Occurs in chloroplasts using chlorophyll",
                            "Has light-dependent and light-independent reactions",
                            "Essential for oxygen production and the food chain"
                        ]
                    }
                ]
            }
        ],
        "metadata": {
            "topic": "Photosynthesis",
            "subject": "Biology",
            "grade_level": "High School",
            "difficulty": "Intermediate",
            "style": {
                "tone": "educational",
                "verbosity": "moderate"
            }
        }
    }

def count_generated_visuals(animation_data: Dict[str, Any]) -> int:
    """Count the number of visual files generated in the animation data"""
    count = 0
    for scene in animation_data.get("scenes", []):
        animation_spec = scene.get("animation_spec", {})
        visuals = animation_spec.get("visuals", {})
        for visual_type, visual_list in visuals.items():
            count += len(visual_list)
    return count

if __name__ == "__main__":
    main() 