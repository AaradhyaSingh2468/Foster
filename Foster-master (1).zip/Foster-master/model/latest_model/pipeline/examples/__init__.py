"""
Example Scripts and Tests
-----------------------
Example usage and test scripts for the Foster pipeline.
""" 