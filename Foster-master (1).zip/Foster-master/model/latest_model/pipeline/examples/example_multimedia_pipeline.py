"""
Example Multimedia Pipeline Usage
--------------------------------
This script demonstrates how to use the MultimediaGenerationPipeline to create educational videos
based on content analysis data.
"""

import os
import json
from pathlib import Path

from pipeline.multimedia.MultimediaPipeline import MultimediaGenerationPipeline

def load_sample_content_analysis(file_path):
    """Load sample content analysis data from a JSON file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def main():
    # Create output directory if it doesn't exist
    output_dir = "output/multimedia"
    os.makedirs(output_dir, exist_ok=True)
    
    print("Initializing multimedia generation pipeline...")
    pipeline = MultimediaGenerationPipeline(
        api_key="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",
        output_dir=output_dir,
        video_format="mp4",
        video_quality="high"
    )
    
    # Load sample content analysis data
    # In a real application, this would come from the ContentAnalysisPipeline
    sample_content_path = "samples/sample_content_analysis.json"
    
    # For demo purposes, create sample data if it doesn't exist
    if not os.path.exists(sample_content_path):
        os.makedirs(os.path.dirname(sample_content_path), exist_ok=True)
        create_sample_content_analysis(sample_content_path)
    
    print(f"Loading content analysis from {sample_content_path}...")
    content_analysis = load_sample_content_analysis(sample_content_path)
    
    # Define customization options
    script_style = {
        "tone": "friendly",
        "verbosity": "moderate",
        "target_audience": "high_school",
        "language": "en-US"
    }
    
    animation_style = {
        "style": "modern",
        "color_scheme": "vibrant",
        "animation_level": "dynamic"
    }
    
    voice_options = {
        "voice_id": "en-US-Neural2-F",
        "speed": 1.0,
        "pitch": 0,
        "language_code": "en-US"
    }
    
    # Generate the video
    print("Generating educational video...")
    result = pipeline.generate_video(
        content_analysis=content_analysis,
        output_name="physics_lesson",
        script_style=script_style,
        animation_style=animation_style,
        voice_options=voice_options
    )
    
    # Print results
    print("\n=== Video Generation Results ===")
    print(f"Video file: {result['video_file']}")
    print(f"Duration: {result['duration']} seconds")
    print(f"Resolution: {result['resolution']}")
    print(f"Format: {result['format']}")
    print(f"Processing time: {result['processing_time']:.1f} seconds")
    print(f"Number of scenes: {result['scene_count']}")
    
    # Generate a preview
    print("\nGenerating 15-second preview...")
    preview_path = pipeline.generate_preview(duration=15)
    print(f"Preview generated: {preview_path}")
    
    # Add background music
    print("\nAdding background music...")
    music_path = "samples/background_music.mp3"
    # Create dummy music file for demonstration
    if not os.path.exists(music_path):
        os.makedirs(os.path.dirname(music_path), exist_ok=True)
        with open(music_path, 'w') as f:
            f.write("This is a placeholder for a music file")
            
    video_with_music = pipeline.add_background_music(music_path, volume=0.15)
    print(f"Video with music: {video_with_music}")
    
    # Export to multiple formats
    print("\nExporting to multiple formats...")
    formats = [
        {"format": "webm", "resolution": "720p"},
        {"format": "mp4", "resolution": "480p", "quality": "medium"}
    ]
    exported_files = pipeline.export_multiple_formats(formats)
    print(f"Exported formats: {', '.join(exported_files)}")
    
    print("\nMultimedia generation pipeline demonstration completed successfully!")

def create_sample_content_analysis(file_path):
    """Create a sample content analysis JSON file for demonstration"""
    sample_data = {
        "topic": "Newton's Laws of Motion",
        "subject": "Physics",
        "grade_level": "high_school",
        "difficulty": "intermediate",
        "learning_objectives": [
            "Understand Newton's three laws of motion",
            "Apply Newton's laws to real-world scenarios",
            "Calculate force, mass and acceleration using F=ma"
        ],
        "key_concepts": [
            {
                "name": "First Law (Inertia)",
                "description": "An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force.",
                "importance": "high"
            },
            {
                "name": "Second Law (F=ma)",
                "description": "The acceleration of an object is directly proportional to the force applied and inversely proportional to its mass.",
                "importance": "high"
            },
            {
                "name": "Third Law (Action-Reaction)",
                "description": "For every action, there is an equal and opposite reaction.",
                "importance": "high"
            }
        ],
        "examples": [
            {
                "title": "Car Braking",
                "description": "When a car brakes suddenly, passengers continue moving forward due to inertia (First Law).",
                "visual_elements": ["car", "passengers", "motion vectors"]
            },
            {
                "title": "Rocket Launch",
                "description": "Rockets expel gas downward (action) and experience an upward force (reaction) according to the Third Law.",
                "visual_elements": ["rocket", "exhaust", "force vectors"]
            }
        ],
        "suggested_structure": [
            {
                "section": "Introduction",
                "duration": 30,
                "description": "Brief overview of Newton's contributions to physics"
            },
            {
                "section": "First Law",
                "duration": 60,
                "description": "Explanation and examples of the Law of Inertia"
            },
            {
                "section": "Second Law",
                "duration": 90,
                "description": "Explanation of F=ma with calculations and examples"
            },
            {
                "section": "Third Law",
                "duration": 60,
                "description": "Explanation and examples of action-reaction pairs"
            },
            {
                "section": "Real-world Applications",
                "duration": 45,
                "description": "How Newton's laws explain everyday phenomena"
            },
            {
                "section": "Summary",
                "duration": 30,
                "description": "Review of the three laws and their significance"
            }
        ],
        "recommended_visuals": [
            "force diagrams",
            "interactive simulations",
            "slow-motion examples",
            "comparative animations"
        ],
        "difficulty_assessment": {
            "conceptual_complexity": "medium",
            "mathematical_complexity": "medium",
            "prerequisite_knowledge": ["basic mechanics", "vector concepts"]
        }
    }
    
    # Save to file
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(sample_data, f, indent=2, ensure_ascii=False)
    
    print(f"Created sample content analysis file: {file_path}")

if __name__ == "__main__":
    main() 