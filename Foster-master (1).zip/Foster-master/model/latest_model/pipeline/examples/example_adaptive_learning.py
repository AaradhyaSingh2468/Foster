"""
Example: Adaptive Learning Usage
-------------------------------
Demonstrates how to use the Adaptive Learning components
to create personalized learning experiences from PDF content.
"""

import os
from pipeline.adaptive_learning.AdaptiveLearningManager import AdaptiveLearningManager
from pipeline.adaptive_learning.StudentProfileManager import StudentProfileManager
from pipeline.multimedia.mistralModel import OpenRouterMistralClient

def main():
    # Initialize components
    profile_manager = StudentProfileManager(storage_dir="example_profiles")
    
    # Create a language model client (assuming you have API keys set up)
    # lm_client = OpenRouterMistralClient()
    
    # Initialize the adaptive learning manager
    manager = AdaptiveLearningManager(
        domain="math",  # Specify domain of content (if known)
        storage_dir="example_adaptive_learning",
        profile_manager=profile_manager
    )
    
    # Create a student profile
    student_id = "student123"
    profile = profile_manager.create_profile(
        student_id=student_id,
        name="Alex Student",
        email="alex@example.com",
        academic_level="intermediate",
        learning_pace="standard"
    )
    
    # Set learning style preferences
    profile_manager.update_profile(
        student_id=student_id,
        learning_style={
            "visual": 0.7,  # Prefers visual learning
            "textual": 0.4,
            "interactive": 0.6
        }
    )
    
    # Add some prior knowledge
    profile = profile_manager.get_profile(student_id)
    profile.update_knowledge_area("math", "algebra", 0.8)  # Strong in algebra
    profile.update_knowledge_area("math", "calculus", 0.3)  # Needs work in calculus
    profile_manager.save_profile(profile)
    
    # Process a PDF document
    pdf_path = "sample_math_textbook.pdf"  # Replace with actual PDF path
    
    if os.path.exists(pdf_path):
        print(f"Processing document: {pdf_path}")
        document_id = manager.process_document(pdf_path)
        
        # Create personalized learning pathway
        # Focus on specific concepts (optional)
        target_concepts = ["derivatives", "integrals"]
        
        print(f"Creating personalized learning pathway for student {student_id}")
        print(f"Document: {document_id}")
        print(f"Target concepts: {target_concepts}")
        
        session_id = manager.create_personalized_pathway(
            student_id=student_id,
            document_id=document_id,
            target_concepts=target_concepts
        )
        
        print(f"Learning session created: {session_id}")
        
        # Begin the learning session
        print("\nLearning Session:")
        session_completed = False
        
        while not session_completed:
            # Get next recommended content
            next_content = manager.get_next_content(session_id)
            
            if "completed" in next_content and next_content["completed"]:
                print("\nLearning pathway completed!")
                print(f"Overall progress: {next_content['progress']}%")
                session_completed = True
                break
                
            print(f"\nNext content: {next_content['title']}")
            print(f"Type: {next_content['content_type']}")
            print(f"Difficulty: {next_content['difficulty']}")
            print(f"Estimated time: {next_content['estimated_time']} minutes")
            
            if next_content['alternatives']:
                print("Alternative versions available:")
                for alt in next_content['alternatives']:
                    print(f"  - {alt['title']} ({alt['content_type']})")
            
            # Simulate student completing the content
            performance = 0.8  # 80% mastery (would be based on actual assessment)
            
            # Mark content as completed
            status = manager.complete_content(
                session_id=session_id,
                node_id=next_content['node_id'],
                performance=performance
            )
            
            print(f"Completed node {next_content['node_id']}")
            print(f"Progress: {status['progress_percentage']}%")
            print(f"Completed {status['completed_nodes']}/{status['total_nodes']} nodes")
            
            # For demonstration, break after a few iterations
            if status['completed_nodes'] >= 3:
                print("\nDemo: Showing first 3 nodes only")
                break
        
        # Get overall session status
        final_status = manager.get_session_status(session_id)
        print("\nSession Summary:")
        print(f"Duration: {final_status['duration_minutes']} minutes")
        print(f"Progress: {final_status['progress_percentage']}%")
        print(f"Completed: {final_status['completed_nodes']}/{final_status['total_nodes']} nodes")
        
        # Get updated student profile
        updated_profile = profile_manager.get_profile(student_id)
        print("\nUpdated Student Profile:")
        print(f"Strengths: {len(updated_profile.strengths)} areas")
        for strength in updated_profile.strengths[:3]:  # Show top 3
            print(f"  - {strength['domain']}: {strength['topic']} ({strength['proficiency']:.2f})")
            
        print(f"Areas needing improvement: {len(updated_profile.weaknesses)} areas")
        for weakness in updated_profile.weaknesses[:3]:  # Show top 3
            print(f"  - {weakness['domain']}: {weakness['topic']} ({weakness['proficiency']:.2f})")
    else:
        print(f"Error: PDF file not found: {pdf_path}")
        print("Please replace with an actual PDF path or create a sample PDF for testing")

if __name__ == "__main__":
    main() 