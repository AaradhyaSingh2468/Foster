import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
import logging
import traceback
import argparse
from pathlib import Path
from VisualizationElementExtractor import VisualizationElementExtractor, Config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("visualization_test.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("VisualizationTest")

# Test configuration
class TestConfig:
    """Configuration for visualization tests"""
    # Output directory for test results
    OUTPUT_DIR = "output"
    
    # Test image dimensions
    IMAGE_WIDTH = 640
    IMAGE_HEIGHT = 480
    
    # Chart parameters
    BAR_WIDTH = 40
    BAR_SPACE = 30
    BAR_VALUES = [150, 250, 180, 300, 220]
    BAR_COLORS = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (0, 255, 255)]
    
    # Pie chart parameters
    PIE_SEGMENTS = [30, 60, 75, 120, 75]  # Angles in degrees
    
    # Number of scatter points to generate
    SCATTER_POINTS = 30
    
    # Random seed for reproducibility
    RANDOM_SEED = 42


def test_visualization_extractor(chart_types=None, output_dir=None):
    """
    Test the VisualizationElementExtractor with sample visualizations.
    
    Args:
        chart_types: List of chart types to test, or None for all
        output_dir: Directory to save output files
    """
    try:
        # Initialize the extractor
        logger.info("Initializing VisualizationElementExtractor")
        extractor = VisualizationElementExtractor()
        
        # Set output directory
        if output_dir:
            output_path = Path(output_dir)
        else:
            output_path = Path(TestConfig.OUTPUT_DIR)
            
        # Create output directory if it doesn't exist
        output_path.mkdir(exist_ok=True, parents=True)
        logger.info(f"Test results will be saved to {output_path.absolute()}")
        
        # Define chart types to test
        if chart_types is None:
            chart_types = ["bar_chart", "line_chart", "scatter_plot", "pie_chart"]
        
        # Create a sample extraction result with different visualization types
        test_results = {}
        
        # Process each chart type
        for chart_type in chart_types:
            try:
                logger.info(f"Creating and processing {chart_type}")
                
                # Create the chart image
                if chart_type == "bar_chart":
                    image = create_sample_bar_chart()
                elif chart_type == "line_chart":
                    image = create_sample_line_chart()
                elif chart_type == "scatter_plot":
                    image = create_sample_scatter_plot()
                elif chart_type == "pie_chart":
                    image = create_sample_pie_chart()
                else:
                    logger.warning(f"Unknown chart type: {chart_type}, skipping...")
                    continue
                
                # Process the image
                result = process_image(extractor, image, chart_type)
                test_results[chart_type] = result
                
                # Save the original image for reference
                original_path = output_path / f"{chart_type}_original.png"
                cv2.imwrite(str(original_path), image)
                logger.debug(f"Saved original {chart_type} to {original_path}")
                
            except Exception as e:
                logger.error(f"Error processing {chart_type}: {str(e)}")
                logger.debug(traceback.format_exc())
        
        # Visualize and save results
        success_count = 0
        for chart_type, result in test_results.items():
            try:
                output_file = output_path / f"{chart_type}_result.png"
                visualization = extractor.visualize_extraction_result(result, str(output_file))
                
                if 'figures' in result and result['figures']:
                    data_points_count = len(result.get('figures', [])[0].get('data_points', []))
                    logger.info(f"Processed {chart_type}, extracted {data_points_count} data points")
                    success_count += 1
                else:
                    logger.warning(f"No figures detected in {chart_type}")
            except Exception as e:
                logger.error(f"Error visualizing {chart_type} result: {str(e)}")
                logger.debug(traceback.format_exc())
                
        logger.info(f"Testing complete! Successfully processed {success_count}/{len(chart_types)} chart types")
        return test_results
        
    except Exception as e:
        logger.error(f"Test failed with error: {str(e)}")
        logger.debug(traceback.format_exc())
        return {}
    
def process_image(extractor, image, chart_type):
    """
    Process an image with the VisualizationElementExtractor.
    
    Args:
        extractor: VisualizationElementExtractor instance
        image: Image data as numpy array
        chart_type: Type of chart for labeling
        
    Returns:
        Dictionary with extraction results
    """
    try:
        logger.debug(f"Processing {chart_type} image of shape {image.shape}")
        
        # Create a mock extraction result with the image
        extraction_result = {
            'images': [
                {
                    'image_data': image,
                    'page_num': 1,
                    'position': {'x': 0, 'y': 0, 'width': image.shape[1], 'height': image.shape[0]}
                }
            ],
            'text_blocks': []
        }
        
        # Extract figures from the image
        extraction_result = extractor.analyze_figures(extraction_result)
        
        return extraction_result
    except Exception as e:
        logger.error(f"Error in process_image for {chart_type}: {str(e)}")
        logger.debug(traceback.format_exc())
        return {'error': str(e), 'images': [{'image_data': image}]}

def create_sample_bar_chart(width=None, height=None):
    """
    Create a sample bar chart for testing.
    
    Args:
        width: Image width (defaults to TestConfig.IMAGE_WIDTH)
        height: Image height (defaults to TestConfig.IMAGE_HEIGHT)
        
    Returns:
        Numpy array containing the bar chart image
    """
    width = width or TestConfig.IMAGE_WIDTH
    height = height or TestConfig.IMAGE_HEIGHT
    
    # Create blank image
    image = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Draw x and y axes
    cv2.line(image, (50, height-50), (width-50, height-50), (0, 0, 0), 2)  # x-axis
    cv2.line(image, (50, 50), (50, height-50), (0, 0, 0), 2)  # y-axis
    
    # Draw bars
    bar_width = TestConfig.BAR_WIDTH
    space = TestConfig.BAR_SPACE
    x_positions = [100, 200, 300, 400, 500]
    values = TestConfig.BAR_VALUES
    colors = TestConfig.BAR_COLORS
    
    for i, (x, val, color) in enumerate(zip(x_positions, values, colors)):
        bar_height = val
        cv2.rectangle(image, (x, height - 50 - bar_height), (x + bar_width, height - 50), color, -1)
        
        # Add value text
        cv2.putText(image, str(val), (x + 10, height - 60 - bar_height), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        # Add x-label
        cv2.putText(image, f"Item {i+1}", (x, height - 30), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    # Add chart title
    cv2.putText(image, "Sample Bar Chart", (width // 3, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    return image

def create_sample_line_chart(width=None, height=None):
    """
    Create a sample line chart for testing.
    
    Args:
        width: Image width (defaults to TestConfig.IMAGE_WIDTH)
        height: Image height (defaults to TestConfig.IMAGE_HEIGHT)
        
    Returns:
        Numpy array containing the line chart image
    """
    width = width or TestConfig.IMAGE_WIDTH
    height = height or TestConfig.IMAGE_HEIGHT
    
    # Create blank image
    image = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Draw x and y axes
    cv2.line(image, (50, height-50), (width-50, height-50), (0, 0, 0), 2)  # x-axis
    cv2.line(image, (50, 50), (50, height-50), (0, 0, 0), 2)  # y-axis
    
    # Draw grid lines
    for y in range(100, height-50, 50):
        cv2.line(image, (50, y), (width-50, y), (200, 200, 200), 1)
    
    # Draw two lines
    x_points = np.linspace(50, width-50, 10).astype(int)
    y_points1 = np.array([250, 200, 300, 270, 350, 330, 280, 320, 270, 390])
    y_points2 = np.array([150, 180, 100, 200, 250, 220, 180, 150, 200, 170])
    
    # Line 1
    for i in range(len(x_points)-1):
        cv2.line(image, (x_points[i], y_points1[i]), (x_points[i+1], y_points1[i+1]), (255, 0, 0), 2)
        if i % 2 == 0:  # Add sample points
            cv2.circle(image, (x_points[i], y_points1[i]), 5, (255, 0, 0), -1)
    
    # Line 2
    for i in range(len(x_points)-1):
        cv2.line(image, (x_points[i], y_points2[i]), (x_points[i+1], y_points2[i+1]), (0, 0, 255), 2)
        if i % 2 == 0:  # Add sample points
            cv2.circle(image, (x_points[i], y_points2[i]), 5, (0, 0, 255), -1)
    
    # Add legend
    cv2.rectangle(image, (width-150, 70), (width-50, 120), (255, 255, 255), -1)
    cv2.rectangle(image, (width-150, 70), (width-50, 120), (0, 0, 0), 1)
    cv2.line(image, (width-140, 85), (width-110, 85), (255, 0, 0), 2)
    cv2.line(image, (width-140, 105), (width-110, 105), (0, 0, 255), 2)
    cv2.putText(image, "Series 1", (width-105, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    cv2.putText(image, "Series 2", (width-105, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    # Add chart title
    cv2.putText(image, "Sample Line Chart", (width // 3, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    return image

def create_sample_scatter_plot(width=None, height=None):
    """
    Create a sample scatter plot for testing.
    
    Args:
        width: Image width (defaults to TestConfig.IMAGE_WIDTH)
        height: Image height (defaults to TestConfig.IMAGE_HEIGHT)
        
    Returns:
        Numpy array containing the scatter plot image
    """
    width = width or TestConfig.IMAGE_WIDTH
    height = height or TestConfig.IMAGE_HEIGHT
    
    # Create blank image
    image = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Draw x and y axes
    cv2.line(image, (50, height-50), (width-50, height-50), (0, 0, 0), 2)  # x-axis
    cv2.line(image, (50, 50), (50, height-50), (0, 0, 0), 2)  # y-axis
    
    # Generate random points
    np.random.seed(TestConfig.RANDOM_SEED)  # For reproducibility
    x_coords = np.random.randint(70, width-70, TestConfig.SCATTER_POINTS)
    y_coords = np.random.randint(70, height-70, TestConfig.SCATTER_POINTS)
    
    # Draw scatter points
    for x, y in zip(x_coords, y_coords):
        cv2.circle(image, (x, y), 5, (0, 0, 255), -1)
    
    # Add chart title
    cv2.putText(image, "Sample Scatter Plot", (width // 3, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    return image

def create_sample_pie_chart(width=None, height=None):
    """
    Create a sample pie chart for testing.
    
    Args:
        width: Image width (defaults to TestConfig.IMAGE_WIDTH)
        height: Image height (defaults to TestConfig.IMAGE_HEIGHT)
        
    Returns:
        Numpy array containing the pie chart image
    """
    width = width or TestConfig.IMAGE_WIDTH
    height = height or TestConfig.IMAGE_HEIGHT
    
    # Create blank image
    image = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Define center and radius
    center = (width // 2, height // 2)
    radius = min(width, height) // 3
    
    # Define segments and colors
    segments = TestConfig.PIE_SEGMENTS
    colors = TestConfig.BAR_COLORS
    
    # Draw pie segments
    start_angle = 0
    for angle, color in zip(segments, colors):
        end_angle = start_angle + angle
        
        # Convert angles to radians for cv2.ellipse
        start_rad = start_angle * np.pi / 180
        end_rad = end_angle * np.pi / 180
        
        # Draw the pie segment
        cv2.ellipse(image, center, (radius, radius), 0, start_angle, end_angle, color, -1)
        
        # Add a line from center to the segment edge
        end_x = int(center[0] + radius * np.cos(start_rad))
        end_y = int(center[1] + radius * np.sin(start_rad))
        cv2.line(image, center, (end_x, end_y), (0, 0, 0), 1)
        
        # Calculate label position
        mid_angle = (start_angle + end_angle) / 2
        mid_rad = mid_angle * np.pi / 180
        label_x = int(center[0] + (radius + 30) * np.cos(mid_rad))
        label_y = int(center[1] + (radius + 30) * np.sin(mid_rad))
        
        # Add percentage text
        percentage = angle / 360 * 100
        cv2.putText(image, f"{percentage:.1f}%", (label_x-20, label_y), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        
        start_angle = end_angle
    
    # Add chart title
    cv2.putText(image, "Sample Pie Chart", (width // 3, 30), 
               cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    return image

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Test VisualizationElementExtractor')
    parser.add_argument('--charts', type=str, nargs='+', 
                        choices=['bar_chart', 'line_chart', 'scatter_plot', 'pie_chart'],
                        help='Chart types to test')
    parser.add_argument('--output', type=str, help='Output directory')
    parser.add_argument('--log-level', type=str, default='INFO',
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help='Logging level')
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_arguments()
    
    # Set log level
    logging.getLogger().setLevel(getattr(logging, args.log_level))
    
    # Run tests
    test_visualization_extractor(args.charts, args.output) 