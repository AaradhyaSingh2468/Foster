"""
Simple test script for the TextToSpeech module.
This script creates audio files using the TextToSpeechGenerator without dependencies on other modules.
"""

import os
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("TTSSimpleTest")

# Import the TextToSpeech module
from pipeline.multimedia.TextToSpeech import TextToSpeechGenerator

def main():
    print("Simple Text-to-Speech Generator Test")
    
    # Create output directory
    os.makedirs("output/audio", exist_ok=True)
    
    # Initialize the TTS generator
    tts_generator = TextToSpeechGenerator(
        voice_id="professional",
        language_code="en-US",
        voice_speed=1.0,
        pitch=0,
        use_ssml=False
    )
    
    # Sample script data
    script_data = {
        "scenes": [
            {
                "scene_id": "scene_1",
                "title": "Test Scene",
                "narration": "This is a test of the TextToSpeech generator module. It should generate an MP3 file with this narration."
            }
        ]
    }
    
    # Generate speech
    result = tts_generator.generate_speech(script_data)
    
    # Display results
    print("\nSpeech generation complete!")
    print(f"Total duration: {result['metadata']['total_duration']:.2f} seconds")
    print(f"Number of scenes: {len(result['scenes'])}")
    
    # Print details for each scene
    for i, scene in enumerate(result['scenes']):
        print(f"\nScene {i+1}: {scene['title']}")
        audio_spec = scene['audio_spec']
        if audio_spec.get('audio_file'):
            print(f"Audio file: {audio_spec['audio_file']}")
            print(f"Duration: {audio_spec['duration']:.2f} seconds")
        else:
            print(f"No audio generated: {audio_spec.get('error', 'Unknown error')}")

    # Save result to JSON for inspection
    with open("output/audio/simple_tts_result.json", "w") as f:
        json.dump(result, f, indent=2)
    
    print("\nTest complete. Results saved to output/audio/simple_tts_result.json")

if __name__ == "__main__":
    main() 