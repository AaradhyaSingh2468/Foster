"""
Example script for text-to-speech generation
--------------------------------------------------
This script demonstrates how to use the TextToSpeechGenerator with
Google TTS integration to generate actual speech audio for educational content.
"""

import os
import json
import time
import logging
from typing import Dict, Any

from pipeline.multimedia.TextToSpeech import TextToSpeechGenerator

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ExampleTTS")

def main():
    # Create output directory
    output_dir = "output/tts_demo"
    os.makedirs(output_dir, exist_ok=True)
    
    # Sample script data
    script_data = create_sample_script_data()
    
    # Initialize TextToSpeechGenerator
    logger.info("Initializing Text-to-Speech Generator")
    tts_generator = TextToSpeechGenerator(
        voice_id="professional",     # Use professional voice
        language_code="en-US",       # English (US)
        voice_speed=1.0,             # Normal speed
        pitch=0,                     # Default pitch
        use_ssml=False               # Don't use SSML (not supported by gTTS)
    )
    
    # Generate speech
    logger.info("Generating speech audio")
    start_time = time.time()
    audio_data = tts_generator.generate_speech(script_data)
    
    # Save the audio data
    audio_metadata_path = os.path.join(output_dir, "audio_metadata.json")
    with open(audio_metadata_path, "w", encoding="utf-8") as f:
        # Create a serializable version (can't serialize audio file objects)
        serializable_data = {
            "scenes": [{
                "scene_id": scene["scene_id"],
                "title": scene["title"],
                "audio_spec": {
                    "audio_file": scene["audio_spec"]["audio_file"],
                    "duration": scene["audio_spec"]["duration"],
                    "format": scene["audio_spec"]["format"],
                    "sample_rate": scene["audio_spec"]["sample_rate"],
                    "bit_rate": scene["audio_spec"]["bit_rate"]
                }
            } for scene in audio_data["scenes"]],
            "metadata": audio_data["metadata"]
        }
        json.dump(serializable_data, f, indent=2)
    
    # Report results
    total_time = time.time() - start_time
    scene_count = len(audio_data.get("scenes", []))
    logger.info(f"Speech generation completed in {total_time:.2f} seconds")
    logger.info(f"Generated {scene_count} audio segments")
    logger.info(f"Audio metadata saved to {audio_metadata_path}")
    
    # List generated audio files
    audio_files = [scene["audio_spec"]["audio_file"] for scene in audio_data["scenes"] 
                if scene["audio_spec"].get("audio_file")]
    
    logger.info(f"Generated {len(audio_files)} audio files")
    for i, audio_file in enumerate(audio_files):
        logger.info(f"  {i+1}. {os.path.basename(audio_file)}")
    
    # Try merging audio files
    if len(audio_files) > 1:
        logger.info("Merging audio files...")
        audio_specs = [scene["audio_spec"] for scene in audio_data["scenes"]]
        merged_file = tts_generator.merge_audio_files(audio_specs)
        
        if merged_file:
            logger.info(f"Merged audio saved to: {merged_file}")
        else:
            logger.warning("Could not merge audio files")
    
    logger.info("Completed TTS example")
    
    # Demonstrate different voices
    demonstrate_voices(tts_generator, output_dir)

def create_sample_script_data() -> Dict[str, Any]:
    """Create a sample script data object for demonstration"""
    return {
        "scenes": [
            {
                "scene_id": "scene_1",
                "title": "Introduction to Machine Learning",
                "narration": "Welcome to this introduction to machine learning. In this video, we will explore the fundamental concepts of machine learning and its applications in today's world."
            },
            {
                "scene_id": "scene_2",
                "title": "Supervised Learning",
                "narration": "Supervised learning is a type of machine learning where the model is trained on labeled data. The algorithm learns to map inputs to outputs based on example input-output pairs."
            },
            {
                "scene_id": "scene_3",
                "title": "Unsupervised Learning",
                "narration": "In unsupervised learning, the model works with unlabeled data. It identifies patterns and relationships without explicit guidance, making it useful for clustering and dimensionality reduction."
            },
            {
                "scene_id": "scene_4",
                "title": "Real-world Applications",
                "narration": "Machine learning has numerous real-world applications, from recommendation systems and fraud detection to natural language processing and computer vision."
            },
            {
                "scene_id": "scene_5",
                "title": "Conclusion",
                "narration": "Understanding the basics of machine learning is crucial in today's data-driven world. As we've seen, different approaches can be applied to solve a wide range of problems."
            }
        ]
    }

def demonstrate_voices(tts_generator: TextToSpeechGenerator, output_dir: str):
    """Demonstrate different voice profiles"""
    logger.info("Demonstrating different voice profiles...")
    
    # Sample text to demonstrate voices
    demo_text = "This is a demonstration of different voice profiles available in the Text-to-Speech Generator."
    
    # Get available voices
    voices = tts_generator.get_available_voices()
    
    for voice in voices:
        voice_id = voice["id"]
        logger.info(f"Generating sample for voice: {voice_id}")
        
        # Update voice
        tts_generator.customize_voice(voice_id=voice_id)
        
        # Create a simple scene for demonstration
        demo_scene = {
            "scene_id": f"voice_demo_{voice_id}",
            "title": f"Voice Demo: {voice_id}",
            "narration": demo_text
        }
        
        # Generate speech for this scene
        processed_text = tts_generator._process_narration_text(demo_text)
        audio_spec = tts_generator._generate_scene_audio(
            processed_text, 
            f"voice_demo_{voice_id}", 
            f"Voice Demo: {voice_id}"
        )
        
        if audio_spec.get("audio_file"):
            logger.info(f"  Generated sample for {voice_id}: {os.path.basename(audio_spec['audio_file'])}")
        else:
            logger.warning(f"  Failed to generate sample for {voice_id}")

if __name__ == "__main__":
    main() 