"""
Test script for the TextToSpeech module.
This script creates a simple audio file using the TextToSpeechGenerator.
"""

import os
import json
from pipeline.multimedia.TextToSpeech import TextToSpeechGenerator

def main():
    print("Testing Text-to-Speech Generator")
    
    # Create output directory
    os.makedirs("output/audio", exist_ok=True)
    
    # Initialize the TTS generator
    tts_generator = TextToSpeechGenerator(
        voice_id="professional",
        language_code="en-US",
        voice_speed=1.0,
        pitch=0,
        use_ssml=False
    )
    
    # Sample script data
    script_data = {
        "scenes": [
            {
                "scene_id": "scene_1",
                "title": "Introduction",
                "narration": "Welcome to our educational video about artificial intelligence. In this video, we will explore the basic concepts of machine learning and neural networks."
            },
            {
                "scene_id": "scene_2",
                "title": "Machine Learning Basics",
                "narration": "Machine learning is a subset of artificial intelligence that focuses on the development of algorithms that can learn from and make predictions on data."
            }
        ]
    }
    
    # Generate speech
    result = tts_generator.generate_speech(script_data)
    
    # Display results
    print("\nSpeech generation complete!")
    print(f"Total duration: {result['metadata']['total_duration']:.2f} seconds")
    print(f"Number of scenes: {len(result['scenes'])}")
    
    # Print details for each scene
    for i, scene in enumerate(result['scenes']):
        print(f"\nScene {i+1}: {scene['title']}")
        audio_spec = scene['audio_spec']
        if audio_spec.get('audio_file'):
            print(f"Audio file: {audio_spec['audio_file']}")
            print(f"Duration: {audio_spec['duration']:.2f} seconds")
        else:
            print(f"No audio generated: {audio_spec.get('error', 'Unknown error')}")

    # Save result to JSON for inspection
    with open("output/audio/tts_result.json", "w") as f:
        json.dump(result, f, indent=2)
    
    print("\nTest complete. Results saved to output/audio/tts_result.json")

if __name__ == "__main__":
    main() 