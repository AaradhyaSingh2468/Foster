"""
Combined example for AI-powered animation and text-to-speech
--------------------------------------------------
This script demonstrates how to use both the enhanced AnimationGenerator with
Stable Diffusion integration and TextToSpeechGenerator with Google TTS
to create a complete multimedia package.
"""

import os
import json
import time
import logging
import argparse
from typing import Dict, Any
import uuid

from pipeline.multimedia.MultimediaPipeline import MultimediaGenerationPipeline
from pipeline.multimedia.AnimationGenerator import AnimationGenerator
from pipeline.multimedia.TextToSpeech import TextToSpeechGenerator
from pipeline.multimedia.VideoCompiler import VideoCompiler

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("CombinedExample")

def main():
    # Set up command-line arguments
    parser = argparse.ArgumentParser(description='Generate educational content with TTS and animations')
    parser.add_argument('--scheduler', type=str, choices=['ddim', 'lms'], default='ddim',
                        help='Scheduler type for Stable Diffusion: DDIM (default) or LMS')
    parser.add_argument('--style', type=str, choices=['modern', 'minimalist', 'playful'], default='modern',
                        help='Visual style of animations')
    args = parser.parse_args()
    
    # Create output directory with a unique ID
    run_id = uuid.uuid4().hex[:6]
    output_dir = f"output/combined_demo_{run_id}"
    os.makedirs(output_dir, exist_ok=True)
    
    # Sample script data
    script_data = create_sample_script_data()
    
    logger.info(f"Starting combined AI animation and TTS example (run ID: {run_id})")
    logger.info(f"Output directory: {output_dir}")
    
    # Save script data
    script_path = os.path.join(output_dir, "script_data.json")
    with open(script_path, "w", encoding="utf-8") as f:
        json.dump(script_data, f, indent=2)
    
    # Step 1: Generate speech audio
    logger.info("Step 1: Generating speech audio with Google TTS")
    tts_generator = TextToSpeechGenerator(
        voice_id="professional",
        language_code="en-US",
        voice_speed=1.0,
        pitch=0,
        use_ssml=False
    )
    
    start_time = time.time()
    audio_data = tts_generator.generate_speech(script_data)
    tts_time = time.time() - start_time
    
    # Save speech metadata
    audio_metadata_path = os.path.join(output_dir, "audio_metadata.json")
    with open(audio_metadata_path, "w", encoding="utf-8") as f:
        json.dump(audio_data, f, indent=2, default=str)
    
    logger.info(f"Speech generation completed in {tts_time:.2f} seconds")
    
    # Step 2: Generate animations
    logger.info(f"Step 2: Generating animations with Stable Diffusion using {args.scheduler.upper()} scheduler")
    animator = AnimationGenerator(
        style=args.style,
        color_scheme="educational",
        animation_level="standard",
        include_transitions=True,
        use_ai=True,
        model_id="stabilityai/stable-diffusion-2-1-base",
        scheduler_type=args.scheduler,
        output_dir=os.path.join(output_dir, "animations")
    )
    
    start_time = time.time()
    animation_data = animator.generate_animations(script_data)
    animation_time = time.time() - start_time
    
    # Save animation metadata
    animation_metadata_path = os.path.join(output_dir, "animation_metadata.json")
    with open(animation_metadata_path, "w", encoding="utf-8") as f:
        json.dump(animation_data, f, indent=2, default=str)
    
    logger.info(f"Animation generation completed in {animation_time:.2f} seconds using {args.scheduler.upper()} scheduler")
    
    # Step 3: Compile video (if both audio and animation are available)
    logger.info("Step 3: Compiling video")
    video_compiler = VideoCompiler(output_format="mp4", quality="high")
    
    # Check if both animations and audio were generated
    has_animations = animation_data and len(animation_data.get("scenes", [])) > 0
    has_audio = audio_data and len(audio_data.get("scenes", [])) > 0
    
    if has_animations and has_audio:
        logger.info("Both animations and audio are available, compiling video...")
        
        # Prepare output path
        video_path = os.path.join(output_dir, f"combined_video_{run_id}.mp4")
        
        # Compile video
        start_time = time.time()
        video_result = video_compiler.compile_video(
            animation_data, 
            audio_data, 
            video_path
        )
        video_time = time.time() - start_time
        
        # Save video metadata
        video_metadata_path = os.path.join(output_dir, "video_metadata.json")
        with open(video_metadata_path, "w", encoding="utf-8") as f:
            json.dump(video_result, f, indent=2, default=str)
        
        logger.info(f"Video compilation completed in {video_time:.2f} seconds")
        logger.info(f"Output video: {video_path}")
    else:
        if not has_animations:
            logger.warning("No animations were generated, skipping video compilation")
        if not has_audio:
            logger.warning("No audio was generated, skipping video compilation")
    
    # Summary
    total_time = tts_time + animation_time
    logger.info(f"Combined example completed in {total_time:.2f} seconds")
    logger.info(f"- Speech generation: {tts_time:.2f} seconds")
    logger.info(f"- Animation generation: {animation_time:.2f} seconds")
    if has_animations and has_audio:
        logger.info(f"- Video compilation: {video_time:.2f} seconds")
    
    logger.info(f"All output saved to: {output_dir}")

def create_sample_script_data() -> Dict[str, Any]:
    """Create a sample script data object for demonstration"""
    return {
        "script": "Sample educational content about renewable energy",
        "sections": [
            {
                "title": "Introduction",
                "content": "Renewable energy sources are sustainable alternatives to fossil fuels.",
                "duration": 30,
                "markers": []
            },
            {
                "title": "Solar Energy",
                "content": "Solar energy harnesses power from the sun using photovoltaic cells.",
                "duration": 45,
                "markers": []
            },
            {
                "title": "Wind Energy",
                "content": "Wind turbines convert kinetic energy from wind into electrical power.",
                "duration": 40,
                "markers": []
            },
            {
                "title": "Conclusion",
                "content": "Transitioning to renewable energy is crucial for a sustainable future.",
                "duration": 25,
                "markers": []
            }
        ],
        "scenes": [
            {
                "scene_id": "scene_1",
                "title": "Introduction to Renewable Energy",
                "narration": "Welcome to this educational video about renewable energy. We'll explore sustainable alternatives to fossil fuels that can help address climate change.",
                "duration_estimate": 15,
                "visual_elements": [
                    {
                        "type": "title_slide",
                        "title": "Renewable Energy: Powering a Sustainable Future",
                        "subtitle": "Clean alternatives to fossil fuels"
                    }
                ]
            },
            {
                "scene_id": "scene_2",
                "title": "Solar Energy",
                "narration": "Solar energy harnesses the power of the sun using photovoltaic cells, which convert sunlight directly into electricity. This technology is becoming increasingly affordable and efficient.",
                "duration_estimate": 20,
                "visual_elements": [
                    {
                        "type": "diagram",
                        "title": "How Solar Panels Work",
                        "content": {
                            "type": "process",
                            "title": "Photovoltaic Process",
                            "components": ["Sunlight", "Solar Cells", "Inverter", "Electrical Grid"]
                        }
                    },
                    {
                        "type": "bullet_points",
                        "title": "Benefits of Solar Energy",
                        "points": [
                            "Renewable and abundant resource",
                            "Zero emissions during operation",
                            "Decreasing installation costs",
                            "Suitable for residential and utility-scale"
                        ]
                    }
                ]
            },
            {
                "scene_id": "scene_3",
                "title": "Wind Energy",
                "narration": "Wind energy captures the natural power of the wind using turbines. As wind flows across the blades, it causes them to rotate, driving a generator that produces electricity.",
                "duration_estimate": 25,
                "visual_elements": [
                    {
                        "type": "whiteboard",
                        "title": "Wind Turbine Components",
                        "content": "Drawing showing the main parts of a wind turbine including blades, rotor, nacelle, generator, and tower."
                    }
                ]
            },
            {
                "scene_id": "scene_4",
                "title": "Comparison of Energy Sources",
                "narration": "When we compare renewable energy sources like solar and wind to fossil fuels, we see significant environmental benefits. Renewables produce little to no greenhouse gas emissions during operation.",
                "duration_estimate": 15,
                "visual_elements": [
                    {
                        "type": "concept_graph",
                        "content": {
                            "nodes": ["Renewable Energy", "Fossil Fuels", "Carbon Emissions", "Sustainability", "Cost"],
                            "edges": [
                                ["Renewable Energy", "Low Carbon Emissions"],
                                ["Renewable Energy", "High Sustainability"],
                                ["Fossil Fuels", "High Carbon Emissions"],
                                ["Fossil Fuels", "Low Sustainability"]
                            ]
                        }
                    }
                ]
            },
            {
                "scene_id": "scene_5",
                "title": "Conclusion",
                "narration": "Transitioning to renewable energy sources is essential for addressing climate change and creating a sustainable future. As technology improves and costs decrease, renewable energy will continue to play an increasingly important role in our global energy mix.",
                "duration_estimate": 10,
                "visual_elements": [
                    {
                        "type": "summary_slide",
                        "title": "Key Takeaways",
                        "points": [
                            "Renewable energy offers sustainable alternatives to fossil fuels",
                            "Solar and wind are increasingly cost-competitive",
                            "Transitioning to renewables reduces carbon emissions",
                            "Technology continues to improve efficiency and reliability"
                        ]
                    }
                ]
            }
        ],
        "metadata": {
            "topic": "Renewable Energy",
            "subject": "Environmental Science",
            "grade_level": "High School",
            "difficulty": "Intermediate",
            "style": {
                "tone": "educational",
                "verbosity": "moderate"
            }
        }
    }

if __name__ == "__main__":
    main() 