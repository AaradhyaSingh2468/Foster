"""
Example Workflow Script
----------------------
Demonstrates the educational content workflow from PDF upload to video delivery.
"""

import os
import sys
import time
from pathlib import Path
import shutil

# Add parent directory to path to allow imports
try:
    # For script execution
    current_dir = Path(__file__).parent
except NameError:
    # For notebook execution
    current_dir = Path.cwd()

# Add the parent directory to Python path
parent_dir = current_dir.parent
if str(parent_dir) not in sys.path:
    sys.path.append(str(parent_dir))

from WorkflowCoordinator import WorkflowCoordinator
from pdf_extraction.PDFContentExtractor import PDFContentExtractor
from content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
from multimedia.MultimediaPipeline import MultimediaGenerationPipeline
from ..adaptive_learning.AdaptiveLearningManager import AdaptiveLearningManager
from ..adaptive_learning.StudentProfileManager import StudentProfileManager
from content_analysis.init_resources import init_all

# Initialize required resources
init_all()

def get_processing_options():
    """Get the processing options for the workflow"""
    return {
        "extraction_options": {
            "extract_images": True,
            "extract_tables": True,
            "extract_equations": True,
            "ocr_quality": "standard",
            "ocr_language": "eng"
        },
        "analysis_options": {
            "domain": "auto",
            "depth_level": "standard",
            "use_domain_specific": True,
            "context_preservation": True,
            "semantic_enrichment": True,
            "apply_iterative_refinement": True
        },
        "multimedia_options": {
            "script_style": {
                "tone": "friendly",
                "verbosity": "moderate",
                "target_audience": "high_school",
                "language": "en-US"
            },
            "animation_style": {
                "style": "modern",
                "color_scheme": "vibrant",
                "animation_level": "standard",
                "scheduler_type": "ddim"  # Hardcoded scheduler type
            },
            "voice_options": {
                "voice_id": "friendly",
                "speed": 1.0,
                "pitch": 0,
                "language_code": "en-US"
            },
            "huggingface_api_key": os.environ.get("HUGGINGFACE_API_KEY", ""),
            "mistral_api_key": os.environ.get("MISTRAL_API_KEY", "")
        },
        "adaptive_options": {
            "difficulty_adjustment": True,
            "personalization_level": "high",
            "focus_areas": ["visual_representations", "interactive_elements"]
        }
    }

def print_workflow_results(result):
    """Print the results of a workflow"""
    print("\nWorkflow output:")
    
    if "extraction_summary" in result:
        extraction = result["extraction_summary"]
        print(f"- Content extraction: {extraction.get('page_count', 0)} pages")
        
        if "extraction_quality" in extraction:
            quality = extraction["extraction_quality"]
            print(f"  Quality score: {quality.get('quality_score', 0):.2f}")
            if "issues" in quality and quality["issues"]:
                print(f"  Issues: {', '.join(quality['issues'])}")
    
    if "analysis_summary" in result:
        analysis = result["analysis_summary"]
        print(f"- Content analysis: {analysis.get('topic', 'Unknown')} ({analysis.get('subject', 'General')})")
        print(f"  Domain: {analysis.get('domain', 'general')}")
        print(f"  Key concepts: {analysis.get('key_concepts_count', 0)}")
        
        if "analysis_quality" in analysis:
            print(f"  Analysis quality: {analysis.get('analysis_quality', 0):.2f}")
    
    if "video_path" in result and result["video_path"]:
        print(f"- Generated video: {result['video_path']}")
    
    if "performance_metrics" in result:
        metrics = result["performance_metrics"]
        print("\nPerformance metrics (seconds):")
        for metric, value in metrics.items():
            if "time" in metric:
                print(f"- {metric}: {value:.1f}")

def simulate_feedback(coordinator, student_id, result):
    """Simulate student feedback and process it"""
    print("\n=== Simulating Student Feedback ===")
    
    feedback_data = {
        "student_id": student_id,
        "video_id": os.path.basename(result.get('video_path', 'unknown')),
        "timestamp": time.time(),
        "interactions": {
            "watch_time": 350,  # seconds
            "completion_rate": 0.85,  # 85% watched
            "pauses": [45, 120, 122, 123, 210],  # timestamps where student paused
            "replays": [
                {"segment": "Second Law", "count": 3},
                {"segment": "Applications", "count": 1}
            ],
            "skips": [
                {"segment": "Introduction", "timestamp": 20}
            ],
            "quiz_results": [
                {"question_id": "q1", "correct": True, "time_taken": 12},
                {"question_id": "q2", "correct": False, "time_taken": 25},
                {"question_id": "q3", "correct": True, "time_taken": 9},
                {"question_id": "q4", "correct": True, "time_taken": 15},
                {"question_id": "q5", "correct": False, "time_taken": 30}
            ]
        },
        "explicit_feedback": {
            "rating": 4,  # out of 5
            "difficulty": "challenging",
            "comments": "I found the Second Law explanation confusing at first, but after replaying it I understood."
        }
    }
    
    print("Processing student feedback...")
    feedback_start = time.time()
    feedback_result = coordinator.process_student_feedback(feedback_data)
    feedback_time = time.time() - feedback_start
    
    print(f"Feedback processed in {feedback_time:.1f} seconds")
    print(f"Status: {feedback_result['status']}")
    
    if feedback_result['status'] == 'success':
        if "comprehension_assessment" in feedback_result:
            comp = feedback_result["comprehension_assessment"]
            print("\nComprehension assessment:")
            print(f"- Overall level: {comp.get('overall_level', 'unknown')}")
            print(f"- Confidence: {comp.get('confidence', 0):.2f}")
            
            if "difficulty_areas" in comp and comp["difficulty_areas"]:
                print("- Difficulty areas:")
                for area in comp["difficulty_areas"][:2]:
                    if "segment" in area:
                        print(f"  * {area['segment']} (confidence: {area.get('confidence', 0):.2f})")
        
        if "interventions" in feedback_result and feedback_result["interventions"]:
            print("\nRecommended interventions:")
            for i, intervention in enumerate(feedback_result["interventions"][:2]):
                print(f"- {intervention.get('type', 'unknown')}: {intervention.get('description', '')}")

def save_video(video_path, output_dir="output/videos"):
    """Save the generated video to the specified output directory"""
    try:
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Get the video filename
        video_filename = os.path.basename(video_path)
        destination_path = os.path.join(output_dir, video_filename)
        
        # Copy the video file to the output directory
        shutil.copy2(video_path, destination_path)
        
        # Verify the file was copied successfully
        if os.path.exists(destination_path):
            file_size = os.path.getsize(destination_path)
            print(f"\nVideo saved successfully:")
            print(f"- Location: {destination_path}")
            print(f"- Size: {file_size / (1024*1024):.2f} MB")
            return True
        else:
            print("\nError: Video file was not saved properly")
            return False
            
    except Exception as e:
        print(f"\nError saving video: {str(e)}")
        return False

def main():
    """Run the example workflow"""
    print("=== Foster Educational Content Workflow Demo ===")
    
    # Initialize the workflow coordinator with hardcoded configuration
    coordinator = WorkflowCoordinator(
        output_dir="output",
        config_dict={
            "huggingface_api_key": os.environ.get("HUGGINGFACE_API_KEY", "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"),
            "mistral_api_key": os.environ.get("MISTRAL_API_KEY", ""),
            "video_format": "mp4",
            "video_quality": "high",
            "async_processing": False,
            "use_distributed": False,
            "use_ai": True,
            "scheduler_type": "ddim",  # Hardcoded scheduler type
            "auto_scaling": {
                "enabled": True,
                "cpu_threshold": 0.8,
                "memory_threshold": 0.8,
                "time_threshold": 300
            },
            "distributed": {
                "type": "local",
                "config": {}
            },
            "extraction_options": {
                "tesseract_path": None,
                "extract_equations": True,
                "extract_images": True,
                "extract_tables": True,
                "ocr_quality": "standard",
                "ocr_language": "eng"
            },
            "analysis_options": {
                "domain": "auto",
                "depth_level": "standard",
                "use_domain_specific": True,
                "context_preservation": True,
                "semantic_enrichment": True,
                "apply_iterative_refinement": True
            },
            "multimedia_options": {
                "script_style": {
                    "tone": "friendly",
                    "verbosity": "moderate",
                    "target_audience": "high_school",
                    "language": "en-US"
                },
                "animation_style": {
                    "style": "modern",
                    "color_scheme": "vibrant",
                    "animation_level": "standard",
                    "scheduler_type": "ddim"
                },
                "voice_options": {
                    "voice_id": "friendly",
                    "speed": 1.0,
                    "pitch": 0,
                    "language_code": "en-US"
                },
                "video_format": "mp4",
                "video_quality": "high",
                "huggingface_api_key": os.environ.get("HUGGINGFACE_API_KEY", ""),
                "mistral_api_key": os.environ.get("MISTRAL_API_KEY", "")
            },
            "adaptive_options": {
                "difficulty_adjustment": True,
                "personalization_level": "high",
                "focus_areas": ["visual_representations", "interactive_elements"]
            }
        }
    )
    
    # Set up input PDF and student ID
    pdf_path = "input.pdf"
    student_id = "student_123"
    
    print(f"\n=== Processing PDF ===")
    print(f"PDF path: {pdf_path}")
    
    # Start workflow timer
    start_time = time.time()
    
    # Run the workflow with hardcoded options
    result = coordinator.process_pdf(
        pdf_path=pdf_path,
        student_id=student_id,
        custom_options=get_processing_options()
    )
    
    # Display results
    process_time = time.time() - start_time
    print(f"Workflow completed in {process_time:.1f} seconds")
    print(f"Status: {result['status']}")
    
    if result['status'] == 'completed':
        print_workflow_results(result)
        
        # Save the generated video
        if "video_path" in result and result["video_path"]:
            video_saved = save_video(result["video_path"])
            if not video_saved:
                print("Warning: Video saving failed, but workflow completed successfully")
        
        simulate_feedback(coordinator, student_id, result)
        
        # Display performance statistics from the result
        print("\n=== Performance Statistics ===")
        if "duration" in result:
            print(f"Total processing time: {result['duration']:.1f} seconds")
        
        if "extraction" in result:
            print("\nExtraction statistics:")
            print(f"- Pages processed: {result['extraction']['pages']}")
            print(f"- Images extracted: {result['extraction']['images']}")
            print(f"- Tables extracted: {result['extraction']['tables']}")
        
        if "video" in result:
            print("\nVideo statistics:")
            print(f"- Video length: {result['video']['length']:.1f} seconds")
            print(f"- Output file: {result['video']['video_file']}")
    else:
        print(f"Error: {result.get('error_message', 'Unknown error')}")
    
    print("\nWorkflow demonstration completed!")

if __name__ == "__main__":
    main() 