"""
Event System
-----------
Implements a simple event system for communication between workflow components.
Enables loose coupling between components and better error handling.
"""

import logging
import uuid
from typing import Dict, Any, List, Callable, Optional, Set
from dataclasses import dataclass, field
from enum import Enum, auto
import time
import threading


class EventType(Enum):
    """Defines the standard workflow event types"""
    # Workflow lifecycle events
    WORKFLOW_STARTED = auto()
    WORKFLOW_COMPLETED = auto()
    WORKFLOW_FAILED = auto()
    
    # Step lifecycle events
    EXTRACTION_STARTED = auto()
    EXTRACTION_COMPLETED = auto()
    EXTRACTION_FAILED = auto()
    
    ANALYSIS_STARTED = auto()
    ANALYSIS_COMPLETED = auto()
    ANALYSIS_FAILED = auto()
    
    VIDEO_GENERATION_STARTED = auto()
    VIDEO_GENERATION_COMPLETED = auto()
    VIDEO_GENERATION_FAILED = auto()
    
    ADAPTIVE_LEARNING_STARTED = auto()
    ADAPTIVE_LEARNING_COMPLETED = auto()
    ADAPTIVE_LEARNING_FAILED = auto()
    
    # Performance and monitoring events
    PERFORMANCE_METRICS_UPDATED = auto()
    AUTO_SCALING_TRIGGERED = auto()
    RESOURCE_WARNING = auto()


@dataclass
class Event:
    """Represents a workflow event with payload data"""
    event_type: EventType
    workflow_id: str
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    payload: Dict[str, Any] = field(default_factory=dict)


# Type definition for event handlers
EventHandler = Callable[[Event], None]


class EventBus:
    """
    Central event bus that manages publishing and subscribing to events.
    Implements the observer pattern for workflow components.
    """
    
    def __init__(self):
        """Initialize the event bus"""
        self.logger = logging.getLogger(__name__)
        self._handlers: Dict[EventType, Set[EventHandler]] = {}
        self._global_handlers: Set[EventHandler] = set()
        self._lock = threading.RLock()  # For thread safety
    
    def subscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """
        Subscribe to a specific event type.
        
        Args:
            event_type: The event type to subscribe to
            handler: Function that will be called when the event occurs
        """
        with self._lock:
            if event_type not in self._handlers:
                self._handlers[event_type] = set()
            
            self._handlers[event_type].add(handler)
            self.logger.debug(f"Subscribed handler to {event_type.name}")
    
    def subscribe_to_all(self, handler: EventHandler) -> None:
        """
        Subscribe to all events.
        
        Args:
            handler: Function that will be called for all events
        """
        with self._lock:
            self._global_handlers.add(handler)
            self.logger.debug("Subscribed handler to all events")
    
    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """
        Unsubscribe from a specific event type.
        
        Args:
            event_type: The event type to unsubscribe from
            handler: The handler to remove
        """
        with self._lock:
            if event_type in self._handlers:
                if handler in self._handlers[event_type]:
                    self._handlers[event_type].remove(handler)
                    self.logger.debug(f"Unsubscribed handler from {event_type.name}")
    
    def unsubscribe_from_all(self, handler: EventHandler) -> None:
        """
        Unsubscribe from all events.
        
        Args:
            handler: The handler to remove
        """
        with self._lock:
            # Remove from global handlers
            if handler in self._global_handlers:
                self._global_handlers.remove(handler)
            
            # Remove from specific event handlers
            for event_type in self._handlers:
                if handler in self._handlers[event_type]:
                    self._handlers[event_type].remove(handler)
            
            self.logger.debug("Unsubscribed handler from all events")
    
    def publish(self, event: Event) -> None:
        """
        Publish an event to all subscribers.
        
        Args:
            event: The event to publish
        """
        with self._lock:
            # Get relevant handlers
            handlers = set()
            
            # Add specific handlers for this event type
            if event.event_type in self._handlers:
                handlers.update(self._handlers[event.event_type])
            
            # Add global handlers
            handlers.update(self._global_handlers)
        
        # Release lock before calling handlers to avoid deadlocks
        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                self.logger.error(f"Error in event handler: {e}")
    
    def publish_for_workflow(self, 
                           workflow_id: str, 
                           event_type: EventType, 
                           payload: Optional[Dict[str, Any]] = None) -> Event:
        """
        Convenience method to create and publish an event for a specific workflow.
        
        Args:
            workflow_id: The workflow ID
            event_type: The event type
            payload: Optional event payload
            
        Returns:
            The published event
        """
        event = Event(
            event_type=event_type,
            workflow_id=workflow_id,
            payload=payload or {}
        )
        
        self.publish(event)
        return event


# Singleton instance for application-wide event bus
_event_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """
    Get the global event bus instance.
    
    Returns:
        The global event bus
    """
    global _event_bus
    if _event_bus is None:
        _event_bus = EventBus()
    return _event_bus


class EventMonitor:
    """
    Monitors and records events for debugging and analysis.
    """
    
    def __init__(self, max_events: int = 1000):
        """
        Initialize the event monitor.
        
        Args:
            max_events: Maximum number of events to keep in memory
        """
        self.max_events = max_events
        self.events: List[Event] = []
        self.logger = logging.getLogger(__name__)
        
        # Subscribe to all events
        get_event_bus().subscribe_to_all(self._on_event)
    
    def _on_event(self, event: Event) -> None:
        """Event handler that records events"""
        self.events.append(event)
        
        # Trim events if exceeding max limit
        if len(self.events) > self.max_events:
            self.events = self.events[-self.max_events:]
    
    def get_events_for_workflow(self, workflow_id: str) -> List[Event]:
        """
        Get all events for a specific workflow.
        
        Args:
            workflow_id: The workflow ID
            
        Returns:
            List of events for the workflow
        """
        return [event for event in self.events if event.workflow_id == workflow_id]
    
    def get_events_by_type(self, event_type: EventType) -> List[Event]:
        """
        Get all events of a specific type.
        
        Args:
            event_type: The event type
            
        Returns:
            List of events of the specified type
        """
        return [event for event in self.events if event.event_type == event_type]
    
    def clear(self) -> None:
        """Clear all recorded events"""
        self.events = []
    
    def shutdown(self) -> None:
        """Unsubscribe from the event bus"""
        get_event_bus().unsubscribe_from_all(self._on_event) 