"""
Dependency Injection Container
-----------------------------
Manages component creation, configuration, and lifecycle.
Provides a central point for component dependencies and service location.
"""

import logging
from typing import Dict, Any, Type, Optional, Callable, TypeVar
import os

# Import component configurations
from pipeline.config.ComponentConfig import WorkflowConfig

# Type variable for generic component types
T = TypeVar('T')

class DependencyContainer:
    """
    A simple dependency injection container that manages component creation and lifecycle.
    """
    
    def __init__(self, config: WorkflowConfig):
        """
        Initialize the container with a configuration.
        
        Args:
            config: The typed configuration for all components
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Validate the configuration
        try:
            self.config.validate()
        except ValueError as e:
            self.logger.error(f"Configuration validation failed: {e}")
            raise
        
        # Component registry - stores factories for creating components
        self._component_factories: Dict[str, Callable[[], Any]] = {}
        
        # Component instances - lazily instantiated components
        self._component_instances: Dict[str, Any] = {}
        
        # Initialize the built-in components
        self._initialize_default_components()
    
    def _initialize_default_components(self) -> None:
        """Initialize the default component factories"""
        # These will be initialized on first use
        from pipeline.pdf_extraction.EnhancedPDFExtractor import EnhancedPDFExtractor
        from pipeline.content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
        from pipeline.multimedia.MultimediaPipeline import MultimediaGenerationPipeline
        from pipeline.adaptive_learning.AdaptiveLearningManager import AdaptiveLearningManager
        from pipeline.adaptive_learning.StudentProfileManager import StudentProfileManager
        
        # Register PDF extractor factory
        self.register_component(
            "pdf_extractor",
            lambda: EnhancedPDFExtractor(
                tesseract_path=self.config.extraction_options.tesseract_path,
                math_recognition=self.config.extraction_options.extract_equations,
                chem_recognition=True
            )
        )
        
        # Register content analysis pipeline factory
        self.register_component(
            "content_pipeline", 
            lambda: ContentAnalysisPipeline(
                domain=self.config.analysis_options.domain
            )
        )
        
        # Register multimedia pipeline factory
        self.register_component(
            "multimedia_pipeline",
            lambda: MultimediaGenerationPipeline(
                huggingface_api_key=self.config.multimedia_options.huggingface_api_key,
                mistral_api_key=self.config.multimedia_options.mistral_api_key,
                output_dir=os.path.join(self.config.output_dir, "multimedia"),
                video_format=self.config.multimedia_options.video_format,
                video_quality=self.config.multimedia_options.video_quality
            )
        )
        
        # Register adaptive learning components
        self.register_component(
            "learning_manager",
            lambda: AdaptiveLearningManager()
        )
        
        self.register_component(
            "student_manager",
            lambda: StudentProfileManager()
        )
    
    def register_component(self, name: str, factory: Callable[[], Any]) -> None:
        """
        Register a component factory.
        
        Args:
            name: Component name
            factory: Factory function that creates the component
        """
        self._component_factories[name] = factory
        # Remove any cached instance if re-registering
        if name in self._component_instances:
            del self._component_instances[name]
            
    def get_component(self, name: str) -> Any:
        """
        Get a component by name, creating it if necessary.
        
        Args:
            name: The component name
            
        Returns:
            The component instance
            
        Raises:
            KeyError: If the component is not registered
        """
        # Return cached instance if available
        if name in self._component_instances:
            return self._component_instances[name]
        
        # Check if factory exists
        if name not in self._component_factories:
            raise KeyError(f"Component not registered: {name}")
        
        # Create and cache the component
        try:
            instance = self._component_factories[name]()
            self._component_instances[name] = instance
            return instance
        except Exception as e:
            self.logger.error(f"Error creating component '{name}': {e}")
            raise
    
    def get_component_typed(self, name: str, component_type: Type[T]) -> T:
        """
        Get a component by name and validate its type.
        
        Args:
            name: The component name
            component_type: Expected component type
            
        Returns:
            The component instance cast to the expected type
            
        Raises:
            KeyError: If the component is not registered
            TypeError: If the component is not of the expected type
        """
        component = self.get_component(name)
        
        if not isinstance(component, component_type):
            raise TypeError(
                f"Component '{name}' is of type {type(component).__name__}, "
                f"expected {component_type.__name__}"
            )
        
        return component
    
    def has_component(self, name: str) -> bool:
        """
        Check if a component is registered.
        
        Args:
            name: The component name
            
        Returns:
            True if the component is registered, False otherwise
        """
        return name in self._component_factories
    
    def remove_component(self, name: str) -> None:
        """
        Remove a component from the registry.
        
        Args:
            name: The component name
        """
        if name in self._component_factories:
            del self._component_factories[name]
        
        if name in self._component_instances:
            del self._component_instances[name]
    
    def reset(self) -> None:
        """Reset all component instances but keep factories"""
        self._component_instances = {}
        
    def shutdown(self) -> None:
        """Shutdown the container and all components"""
        for name, instance in self._component_instances.items():
            try:
                # Call shutdown method if available
                if hasattr(instance, "shutdown") and callable(getattr(instance, "shutdown")):
                    instance.shutdown()
                # Close method is also common
                elif hasattr(instance, "close") and callable(getattr(instance, "close")):
                    instance.close()
            except Exception as e:
                self.logger.error(f"Error shutting down component '{name}': {e}")
        
        # Clear all instances and factories
        self._component_instances = {}
        self._component_factories = {} 