"""
Foster Educational Content Generation Pipeline
-------------------------------------------
A comprehensive pipeline for generating educational content from PDFs.
"""

from pipeline.WorkflowCoordinator import WorkflowCoordinator

__version__ = "1.0.0" 