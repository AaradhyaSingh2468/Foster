"""
Test suite for WorkflowCoordinator
----------------------------------
Tests the end-to-end workflow orchestration with mocked dependencies.
"""

import os
import unittest
from unittest.mock import MagicMock, patch, ANY
import tempfile
import json
import shutil
from typing import Dict, Any

# Import the workflow coordinator and related components
from pipeline.WorkflowCoordinator import WorkflowCoordinator
from pipeline.config.ComponentConfig import WorkflowConfig
from pipeline.di.DependencyContainer import DependencyContainer
from pipeline.events.EventSystem import get_event_bus, EventType, reset_event_bus
from pipeline.errors.WorkflowErrors import (
    WorkflowError, PDFExtractionError, ContentAnalysisError,
    MultimediaGenerationError, AdaptiveLearningError
)


class TestWorkflowCoordinator(unittest.TestCase):
    """Test cases for WorkflowCoordinator"""

    def setUp(self):
        """Set up test environment before each test case"""
        # Create temporary directory for outputs
        self.temp_dir = tempfile.mkdtemp(prefix="test_workflow_")
        
        # Create test PDF path (doesn't need to be a real file for mock tests)
        self.test_pdf = os.path.join(self.temp_dir, "test_document.pdf")
        
        # Reset event bus
        reset_event_bus()
        
        # Create test config
        self.test_config = {
            "extraction_options": {
                "extract_images": True,
                "extract_tables": True,
                "extract_equations": True,
                "ocr_quality": "high",
                "ocr_language": "eng"
            },
            "analysis_options": {
                "domain_focus": "science",
                "grade_level": "university",
                "detail_level": "comprehensive"
            },
            "multimedia_options": {
                "script_style": {
                    "tone": "professional",
                    "pacing": "moderate"
                },
                "animation_style": {
                    "style": "modern",
                    "transitions": "smooth"
                },
                "voice_options": {
                    "voice_id": "en-US-neural-1",
                    "speed": 1.0
                }
            },
            "adaptive_options": {
                "create_pathway": True,
                "question_count": 10
            },
            "output_dir": self.temp_dir,
            "async_processing": False
        }
        
        # Create mocks for each dependency
        self.mock_pdf_extractor = MagicMock()
        self.mock_content_analyzer = MagicMock()
        self.mock_multimedia_generator = MagicMock()
        self.mock_adaptive_learning = MagicMock()
        self.mock_student_profile = MagicMock()
        
        # Set up return values for the mocks
        self.mock_pdf_extractor.is_scanned_document.return_value = False
        self.mock_pdf_extractor.extract_content.return_value = {
            "content": "Test content",
            "summary": {"pages": 5, "word_count": 2500},
            "pages": [{"number": 1, "text": "Test page 1"}],
            "images": [{"id": "img1", "caption": "Test image"}],
            "tables": [{"id": "tbl1", "caption": "Test table"}]
        }
        
        self.mock_content_analyzer.analyze_content.return_value = {
            "topic": "Test Topic",
            "summary": {"key_points": ["Point 1", "Point 2"]},
            "concepts": [{"name": "Concept 1", "description": "Description 1"}],
            "structure": {"sections": [{"title": "Section 1", "content": "Content 1"}]}
        }
        
        self.mock_multimedia_generator.generate_video.return_value = {
            "video_file": "test_video.mp4",
            "script_file": "test_script.txt",
            "duration": 120,
            "timeline": [{"time": 0, "action": "intro"}, {"time": 60, "action": "conclusion"}]
        }
        
        self.mock_adaptive_learning.create_learning_pathway.return_value = {
            "learning_path": "test_path_id",
            "questions": [{"id": "q1", "text": "Question 1?"}],
            "concepts": ["concept1", "concept2"]
        }
        
        # Create patch for the DependencyContainer
        self.container_patcher = patch('pipeline.di.DependencyContainer.DependencyContainer')
        self.mock_container_class = self.container_patcher.start()
        self.mock_container = MagicMock()
        self.mock_container_class.return_value = self.mock_container
        
        # Configure container to return our mocks
        self.mock_container.get_component_typed.side_effect = self._mock_get_component

    def _mock_get_component(self, component_name: str, component_type):
        """Return appropriate mock based on requested component type"""
        from pipeline.pdf_extraction.PDFContentExtractor import PDFContentExtractor
        from pipeline.content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
        from pipeline.multimedia.MultimediaPipeline import MultimediaGenerationPipeline
        from pipeline.adaptive_learning.AdaptiveLearningManager import AdaptiveLearningManager
        from pipeline.adaptive_learning.StudentProfileManager import StudentProfileManager
        
        # Return the appropriate mock based on the component type
        if component_type == PDFContentExtractor:
            return self.mock_pdf_extractor
        elif component_type == ContentAnalysisPipeline:
            return self.mock_content_analyzer
        elif component_type == MultimediaGenerationPipeline:
            return self.mock_multimedia_generator
        elif component_type == AdaptiveLearningManager:
            return self.mock_adaptive_learning
        elif component_type == StudentProfileManager:
            return self.mock_student_profile
        else:
            return MagicMock()
    
    def tearDown(self):
        """Clean up after each test"""
        # Stop patchers
        self.container_patcher.stop()
        
        # Remove temp directory
        shutil.rmtree(self.temp_dir, ignore_errors=True)
        
        # Reset event bus
        reset_event_bus()
    
    def test_init(self):
        """Test coordinator initialization"""
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        self.assertIsNotNone(coord.config)
        self.assertEqual(coord.config.output_dir, self.temp_dir)
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, "extracted")))
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, "analysis")))
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, "multimedia")))
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, "feedback")))
        self.assertTrue(os.path.exists(os.path.join(self.temp_dir, "metrics")))
    
    def test_process_pdf_synchronous(self):
        """Test synchronous PDF processing workflow"""
        # Create coordinator with test config
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        
        # Process PDF
        result = coord.process_pdf(pdf_path=self.test_pdf)
        
        # Verify the workflow was executed
        self.mock_pdf_extractor.is_scanned_document.assert_called_once_with(self.test_pdf)
        self.mock_pdf_extractor.extract_content.assert_called_once()
        self.mock_content_analyzer.analyze_content.assert_called_once()
        self.mock_multimedia_generator.generate_video.assert_called_once()
        
        # Verify results
        self.assertEqual(result["status"], "completed")
        self.assertIn("workflow_id", result)
        self.assertIn("performance_metrics", result)
        self.assertIn("extraction", result["performance_metrics"])
        self.assertIn("analysis", result["performance_metrics"])
        self.assertIn("video_generation", result["performance_metrics"])
    
    def test_extraction_error_handling(self):
        """Test error handling during extraction phase"""
        # Set up extraction to fail
        self.mock_pdf_extractor.extract_content.side_effect = PDFExtractionError(
            "Test extraction error", workflow_id=None, details={"test": True}
        )
        
        # Create coordinator with test config
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        
        # Process PDF and expect error
        result = coord.process_pdf(pdf_path=self.test_pdf)
        
        # Verify error status
        self.assertEqual(result["status"], "error")
        self.assertIn("workflow_id", result)
        self.assertIn("error_message", result)
        self.assertIn("extraction error", result["error_message"])
        
        # Verify subsequent steps weren't called
        self.mock_content_analyzer.analyze_content.assert_not_called()
        self.mock_multimedia_generator.generate_video.assert_not_called()
    
    def test_custom_options(self):
        """Test processing with custom options"""
        # Create custom options that override some defaults
        custom_options = {
            "extraction_options": {
                "extract_images": False,
                "ocr_quality": "medium"
            },
            "multimedia_options": {
                "script_style": {
                    "tone": "casual"
                }
            }
        }
        
        # Create coordinator with test config
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        
        # Process PDF with custom options
        result = coord.process_pdf(pdf_path=self.test_pdf, custom_options=custom_options)
        
        # Verify extraction was called with updated options
        call_args = self.mock_pdf_extractor.extract_content.call_args[1]
        self.assertFalse(call_args["extract_images"])
        self.assertEqual(call_args["ocr_quality"], "medium")
        self.assertTrue(call_args["extract_tables"])  # Should still have original value
    
    def test_event_publishing(self):
        """Test that events are published during workflow"""
        # Create event listener
        events = []
        
        def event_listener(event_type, payload):
            events.append((event_type, payload))
        
        # Register listener for all event types
        bus = get_event_bus()
        for event_type in EventType:
            bus.subscribe(event_type, event_listener)
        
        # Create coordinator with test config
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        
        # Process PDF
        result = coord.process_pdf(pdf_path=self.test_pdf)
        
        # Verify events were published
        event_types = [e[0] for e in events]
        self.assertIn(EventType.WORKFLOW_STARTED, event_types)
        self.assertIn(EventType.EXTRACTION_STARTED, event_types)
        self.assertIn(EventType.EXTRACTION_COMPLETED, event_types)
        self.assertIn(EventType.ANALYSIS_STARTED, event_types)
        self.assertIn(EventType.ANALYSIS_COMPLETED, event_types)
        self.assertIn(EventType.VIDEO_GENERATION_STARTED, event_types)
        self.assertIn(EventType.VIDEO_GENERATION_COMPLETED, event_types)
        self.assertIn(EventType.WORKFLOW_COMPLETED, event_types)
    
    def test_student_adaptive_integration(self):
        """Test workflow with student ID for adaptive learning"""
        # Create coordinator with test config
        coord = WorkflowCoordinator(config_dict=self.test_config, output_dir=self.temp_dir)
        
        # Process PDF with student ID
        result = coord.process_pdf(
            pdf_path=self.test_pdf,
            student_id="test_student_123"
        )
        
        # Verify adaptive learning was called with student ID
        self.mock_adaptive_learning.create_learning_pathway.assert_called_once()
        call_args = self.mock_adaptive_learning.create_learning_pathway.call_args[1]
        self.assertEqual(call_args["student_id"], "test_student_123")
        
        # Verify results include adaptive learning
        self.assertIn("adaptive_learning", result)
        self.assertEqual(result["adaptive_learning"]["learning_path"], "test_path_id")


if __name__ == "__main__":
    unittest.main() 