"""
Animation Generator Module
-----------------------
Converts script scenes into detailed animation and visualization instructions.
Generates specifications for animations, diagrams, and visual elements.
Integrates Stable Diffusion for AI-powered visual generation.
"""

import re
import json
import random
import os
import io
import logging
import numpy as np
from typing import Dict, List, Any, Optional, Union, Tuple
from PIL import Image
import requests
import base64
from pathlib import Path

# Stable Diffusion requirements
try:
    from diffusers import StableDiffusionPipeline, DiffusionPipeline
    from diffusers.schedulers import DDIMScheduler, LMSDiscreteScheduler
    import torch
    from torch import autocast
    STABLE_DIFFUSION_AVAILABLE = True
except ImportError:
    STABLE_DIFFUSION_AVAILABLE = False

class AnimationGenerator:
    """Generates animation instructions and visuals from script data using AI"""
    
    def __init__(self, style="modern", color_scheme="educational", 
                animation_level="standard", include_transitions=True,
                use_ai=True, model_id="stabilityai/stable-diffusion-2-1-base",
                scheduler_type="ddim", output_dir="output/animations"):
        """
        Initialize the animation generator with style preferences and AI model
        
        Args:
            style: Visual style of animations (modern, minimalist, playful)
            color_scheme: Color palette (educational, vibrant, monochrome)
            animation_level: Level of animation complexity (simple, standard, complex)
            include_transitions: Whether to include transitions between scenes
            use_ai: Whether to use AI for generating visuals (requires GPU)
            model_id: HuggingFace model ID for Stable Diffusion
            scheduler_type: Type of scheduler to use (ddim, lms)
            output_dir: Directory to save generated animations
        """
        self.style = style
        self.color_scheme = color_scheme
        self.animation_level = animation_level
        self.include_transitions = include_transitions
        self.use_ai = use_ai and STABLE_DIFFUSION_AVAILABLE
        self.model_id = model_id
        self.scheduler_type = scheduler_type.lower()
        self.output_dir = output_dir
        self.device = "cuda" if torch.cuda.is_available() and self.use_ai else "cpu"
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger("AnimationGenerator")
        
        # Initialize AI model if available
        if self.use_ai and STABLE_DIFFUSION_AVAILABLE:
            self._initialize_ai_model()
        elif self.use_ai and not STABLE_DIFFUSION_AVAILABLE:
            self.logger.warning("Stable Diffusion not available. Install with: pip install diffusers transformers torch")
            self.use_ai = False
        
        # Define color palettes for different schemes
        self.color_palettes = {
            "educational": {
                "primary": "#4285F4",  # Google Blue
                "secondary": "#34A853",  # Google Green
                "tertiary": "#FBBC05",  # Google Yellow
                "accent": "#EA4335",  # Google Red
                "background": "#FFFFFF",
                "text": "#202124"
            },
            "vibrant": {
                "primary": "#FF5252",  # Bright Red
                "secondary": "#42A5F5",  # Bright Blue
                "tertiary": "#FFCA28",  # Bright Yellow
                "accent": "#66BB6A",  # Bright Green
                "background": "#FAFAFA",
                "text": "#212121"
            },
            "monochrome": {
                "primary": "#455A64",  # Blue Grey
                "secondary": "#607D8B",  # Lighter Blue Grey
                "tertiary": "#90A4AE",  # Even Lighter Blue Grey
                "accent": "#263238",  # Dark Blue Grey
                "background": "#ECEFF1",
                "text": "#263238"
            }
        }
        
        # Animation templates for different visual types
        self.animation_templates = {
            "title_slide": {
                "simple": {
                    "animation_type": "fade_in",
                    "duration": 3,
                    "elements": ["title", "subtitle"]
                },
                "standard": {
                    "animation_type": "sequential_fade",
                    "duration": 5,
                    "elements": ["title", "subtitle", "background_element"]
                },
                "complex": {
                    "animation_type": "parallax_zoom",
                    "duration": 7,
                    "elements": ["background", "title_animated", "subtitle_animated", "decorative_elements"]
                }
            },
            "text_slide": {
                "simple": {
                    "animation_type": "simple_text_appear",
                    "duration": 2,
                    "elements": ["title", "content"]
                },
                "standard": {
                    "animation_type": "text_build",
                    "duration": 4,
                    "elements": ["title", "content_sequential"]
                },
                "complex": {
                    "animation_type": "dynamic_text_display",
                    "duration": 6,
                    "elements": ["animated_title", "animated_content", "highlight_effects"]
                }
            },
            "bullet_points": {
                "simple": {
                    "animation_type": "sequential_bullets",
                    "duration": 2,
                    "elements": ["title", "bullets"]
                },
                "standard": {
                    "animation_type": "bullet_build_with_icons",
                    "duration": 4,
                    "elements": ["title", "bullets_with_icons", "highlight"]
                },
                "complex": {
                    "animation_type": "dynamic_bullet_reveal",
                    "duration": 6,
                    "elements": ["animated_title", "interactive_bullets", "bullet_connections"]
                }
            },
            "diagram": {
                "simple": {
                    "animation_type": "diagram_display",
                    "duration": 5,
                    "elements": ["title", "diagram"]
                },
                "standard": {
                    "animation_type": "diagram_build",
                    "duration": 8,
                    "elements": ["title", "diagram_sequential", "labels"]
                },
                "complex": {
                    "animation_type": "interactive_diagram",
                    "duration": 12,
                    "elements": ["title", "diagram_parts", "animated_connections", "highlight_sequence"]
                }
            },
            "figure": {
                "simple": {
                    "animation_type": "figure_display",
                    "duration": 4,
                    "elements": ["figure", "caption"]
                },
                "standard": {
                    "animation_type": "figure_zoom",
                    "duration": 6,
                    "elements": ["figure", "caption", "highlight_areas"]
                },
                "complex": {
                    "animation_type": "figure_analysis",
                    "duration": 10,
                    "elements": ["figure", "callouts", "animated_explanations", "zoom_sequence"]
                }
            },
            "whiteboard": {
                "simple": {
                    "animation_type": "basic_whiteboard",
                    "duration": 8,
                    "elements": ["hand_drawn_elements", "simple_text"]
                },
                "standard": {
                    "animation_type": "sequential_whiteboard",
                    "duration": 12,
                    "elements": ["hand_drawn_sequential", "appearing_text", "basic_highlights"]
                },
                "complex": {
                    "animation_type": "dynamic_whiteboard",
                    "duration": 18,
                    "elements": ["complex_drawings", "animated_text", "color_highlights", "transitions"]
                }
            },
            "concept_graph": {
                "simple": {
                    "animation_type": "graph_display",
                    "duration": 5,
                    "elements": ["nodes", "edges"]
                },
                "standard": {
                    "animation_type": "graph_build",
                    "duration": 10,
                    "elements": ["nodes_sequential", "edges_sequential", "labels"]
                },
                "complex": {
                    "animation_type": "interactive_graph",
                    "duration": 15,
                    "elements": ["nodes_animated", "edges_animated", "highlights", "zoom_areas"]
                }
            },
            "summary_slide": {
                "simple": {
                    "animation_type": "summary_fade",
                    "duration": 5,
                    "elements": ["title", "summary_points"]
                },
                "standard": {
                    "animation_type": "summary_build",
                    "duration": 8,
                    "elements": ["title_animated", "summary_points_sequential", "conclusion_element"]
                },
                "complex": {
                    "animation_type": "dynamic_summary",
                    "duration": 12,
                    "elements": ["title_animated", "summary_points_interactive", "recap_visuals", "call_to_action"]
                }
            }
        }
        
        # Transition templates
        self.transition_templates = {
            "simple": [
                {"type": "fade", "duration": 0.5},
                {"type": "cut", "duration": 0},
                {"type": "dissolve", "duration": 1}
            ],
            "standard": [
                {"type": "wipe_right", "duration": 0.8},
                {"type": "fade_through_black", "duration": 1.2},
                {"type": "zoom_out_in", "duration": 1.5},
                {"type": "push_left", "duration": 1}
            ],
            "complex": [
                {"type": "page_turn", "duration": 1.5},
                {"type": "morph", "duration": 2},
                {"type": "3d_rotation", "duration": 2.2},
                {"type": "particle_transition", "duration": 2.5},
                {"type": "parallax_transition", "duration": 2}
            ]
        }
    
    def _initialize_ai_model(self):
        """Initialize the Stable Diffusion model"""
        try:
            # Use CUDA if available for faster generation
            self.logger.info(f"Initializing Stable Diffusion model {self.model_id}")
            self.logger.info(f"Using device: {self.device}")
            
            # For local model usage
            if self.device == "cuda":
                # Choose scheduler based on scheduler_type
                if self.scheduler_type == "lms":
                    self.logger.info("Using LMSDiscreteScheduler")
                    scheduler = LMSDiscreteScheduler.from_pretrained(self.model_id, subfolder="scheduler")
                else:
                    # Default to DDIM
                    self.logger.info("Using DDIMScheduler")
                scheduler = DDIMScheduler.from_pretrained(self.model_id, subfolder="scheduler")
                
                # Initialize Stable Diffusion pipeline
                self.pipe = StableDiffusionPipeline.from_pretrained(
                    self.model_id,
                    scheduler=scheduler,
                    torch_dtype=torch.float16
                ).to(self.device)
                self.pipe.enable_attention_slicing()  # Reduce memory usage
                
                # Also initialize a DiffusionPipeline for text-to-image for special cases
                if self.model_id in ["stabilityai/stable-diffusion-2-1-base", "stabilityai/stable-diffusion-2"]:
                    self.logger.info("Also initializing DiffusionPipeline for special cases")
                    try:
                        self.diffusion_pipe = DiffusionPipeline.from_pretrained(
                            self.model_id,
                            torch_dtype=torch.float16,
                        ).to(self.device)
                    except Exception as e:
                        self.logger.warning(f"Could not initialize DiffusionPipeline: {str(e)}")
                        self.diffusion_pipe = None
                else:
                    self.diffusion_pipe = None
            else:
                # For CPU fallback, use API-based generation
                self.pipe = None
                self.diffusion_pipe = None
                self.logger.warning("GPU not available. Using API-based generation which may be slower.")
        except Exception as e:
            self.logger.error(f"Error initializing Stable Diffusion: {str(e)}")
            self.use_ai = False
            self.pipe = None
            self.diffusion_pipe = None
    
    def generate_animations(self, script_data: Dict) -> Dict[str, Any]:
        """
        Generate animation instructions and visuals from script data
        
        Args:
            script_data: The script data generated by ScriptGenerator
            
        Returns:
            Dictionary with animation specifications and paths to generated visuals
        """
        self.logger.info("Generating animation instructions")
        
        scenes = script_data.get("scenes", [])
        if not scenes:
            self.logger.warning("No scenes found in script data")
            return {"scenes": [], "metadata": {}}
        
        # Generate animation instructions for each scene
        animated_scenes = []
        
        for i, scene in enumerate(scenes):
            # Generate animation spec for this scene
            animation_spec = self._generate_scene_animation(scene)
            
            # Generate actual visuals if AI is enabled
            if self.use_ai:
                self.logger.info(f"Generating visuals for scene {i+1}/{len(scenes)}")
                visuals = self._generate_scene_visuals(scene, animation_spec)
                animation_spec["visuals"] = visuals
            
            # Add transition to next scene (except for the last scene)
            if i < len(scenes) - 1 and self.include_transitions:
                animation_spec["transition_to_next"] = self._generate_transition()
            
            animated_scenes.append({
                "scene_id": scene.get("scene_id", f"scene_{i+1}"),
                "title": scene.get("title", f"Scene {i+1}"),
                "narration": scene.get("narration", ""),
                "duration_estimate": scene.get("duration_estimate", 10),
                "animation_spec": animation_spec
            })
        
        # Calculate total animation time
        total_animation_time = sum(scene["animation_spec"]["total_duration"] 
                                 for scene in animated_scenes)
        
        # Add metadata
        result = {
            "scenes": animated_scenes,
            "metadata": {
                "style": self.style,
                "color_scheme": self.color_scheme,
                "color_palette": self.color_palettes[self.color_scheme],
                "animation_level": self.animation_level,
                "total_frames": int(total_animation_time * 30),  # Assuming 30fps
                "total_duration": total_animation_time,
                "ai_generated": self.use_ai,
                "scheduler_type": self.scheduler_type
            }
        }
        
        self.logger.info(f"Animation generation complete: {len(animated_scenes)} scenes, {total_animation_time:.1f} seconds")
        return result
    
    def _generate_scene_visuals(self, scene: Dict, animation_spec: Dict) -> Dict[str, Any]:
        """Generate visual elements for a scene using Stable Diffusion"""
        visuals = {}
        scene_title = scene.get("title", "Scene")
        scene_id = scene.get("scene_id", "scene_1")
        
        # Create a folder for this scene
        scene_folder = os.path.join(self.output_dir, f"{scene_id}")
        os.makedirs(scene_folder, exist_ok=True)
        
        # Generate visuals for each animation element
        for i, element in enumerate(animation_spec.get("elements", [])):
            element_type = element.get("type", "text_slide")
            element_content = element.get("content", {})
            
            # Generate a prompt based on the element type and content
            prompt = self._create_visual_prompt(element_type, element_content, scene)
            
            # Generate the image
            try:
                if self.device == "cuda" and self.pipe is not None:
                    # Local generation on GPU
                    image = self._generate_image_local(prompt, element_type)
                else:
                    # API-based generation (fallback)
                    image = self._generate_image_api(prompt, element_type)
                
                if image:
                    # Save the image
                    image_path = os.path.join(scene_folder, f"{element_type}_{i+1}.png")
                    image.save(image_path)
                    
                    # Add to visuals dictionary
                    if element_type not in visuals:
                        visuals[element_type] = []
                    
                    visuals[element_type].append({
                        "path": image_path,
                        "prompt": prompt,
                        "element_index": i
                    })
                    
                    self.logger.info(f"Generated {element_type} visual for {scene_title}")
                
            except Exception as e:
                self.logger.error(f"Error generating visual: {str(e)}")
        
        return visuals
    
    def _create_visual_prompt(self, element_type: str, content: Dict, scene: Dict) -> str:
        """Create a prompt for image generation based on element type and content"""
        style_words = {
            "modern": "clean, modern, minimal design, professional, sharp lines",
            "minimalist": "minimalist, simple, clean, uncluttered, essential elements only",
            "playful": "playful, vibrant, fun, colorful, engaging, dynamic"
        }
        
        # Handle both string and dictionary style configurations
        style_key = self.style.get('style', self.style) if isinstance(self.style, dict) else self.style
        style_prompt = style_words.get(style_key, "modern")
        
        # Base prompts by element type
        if element_type == "title_slide":
            title = content.get("title", scene.get("title", "Educational Content"))
            subtitle = content.get("subtitle", "")
            prompt = f"A {style_key} educational title slide with title '{title}'"
            if subtitle:
                prompt += f" and subtitle '{subtitle}'"
            prompt += f". {style_prompt}, educational presentation slide"
            
        elif element_type == "text_slide":
            title = content.get("title", "")
            text = content.get("text", "")
            prompt = f"A {style_key} educational slide with title '{title}' and text content. {style_prompt}, educational presentation"
            
        elif element_type == "bullet_points":
            title = content.get("title", "Key Points")
            points = content.get("points", [])
            points_text = ", ".join(points[:3])  # Include first few points
            prompt = f"A {style_key} slide with bullet points titled '{title}' including points about: {points_text}. {style_prompt}, educational presentation"
            
        elif element_type == "diagram":
            diagram_type = content.get("diagram_type", "generic")
            title = content.get("title", "Diagram")
            prompt = f"A {diagram_type} diagram titled '{title}' in {style_key} style. {style_prompt}, educational, clear diagram"
            
        elif element_type == "figure":
            caption = content.get("caption", "")
            prompt = f"An educational figure with caption '{caption}'. {style_prompt}, clear illustration, educational"
            
        elif element_type == "whiteboard":
            title = content.get("title", scene.get("title", ""))
            content_text = content.get("content", "")
            prompt = f"A whiteboard drawing explaining '{title}'. {style_prompt}, hand-drawn, educational whiteboard"
            
        elif element_type == "concept_graph":
            prompt = f"A concept graph or mind map in {style_key} style. {style_prompt}, nodes and connections, educational diagram"
            
        elif element_type == "summary_slide":
            title = content.get("title", "Summary")
            prompt = f"A summary slide titled '{title}' in {style_key} style. {style_prompt}, educational, conclusion slide"
            
        else:
            # Generic fallback
            prompt = f"Educational content slide in {style_key} style. {style_prompt}, educational presentation"
        
        # Add color scheme information
        prompt += f". Color scheme: {self.color_scheme}"
        
        return prompt
    
    def _generate_image_local(self, prompt: str, element_type: str) -> Optional[Image.Image]:
        """Generate an image using local Stable Diffusion model"""
        if not self.pipe:
            return None
            
        try:
            # Use specialized diffusion pipeline for diagrams and concept graphs if available
            if element_type in ["diagram", "concept_graph"] and self.diffusion_pipe is not None:
                try:
                    self.logger.info(f"Using DiffusionPipeline for {element_type}")
                    with autocast("cuda"):
                        image = self.diffusion_pipe(
                            prompt=prompt,
                            num_inference_steps=30,
                            guidance_scale=7.5,
                        ).images[0]
                    return image
                except Exception as e:
                    self.logger.warning(f"Error with DiffusionPipeline, falling back to standard: {str(e)}")
                    # Fall back to standard pipeline
            
            # Use standard StableDiffusionPipeline
            with autocast("cuda"):
                image = self.pipe(
                    prompt=prompt,
                    num_inference_steps=30,
                    guidance_scale=7.5,
                ).images[0]
                
            return image
            
        except Exception as e:
            self.logger.error(f"Error generating image locally: {str(e)}")
            return None
    
    def _generate_image_api(self, prompt: str, element_type: str) -> Optional[Image.Image]:
        """Generate an image using HuggingFace Inference API (fallback method)"""
        try:
            # Use HuggingFace Inference API
            API_URL = f"https://api-inference.huggingface.co/models/{self.model_id}"
            
            # Get API token from environment variable
            api_token = os.environ.get("HUGGINGFACE_API_TOKEN", "")
            if not api_token:
                self.logger.warning("No Hugging Face API token found. Set HUGGINGFACE_API_TOKEN environment variable.")
                # Generate a placeholder image
                return self._generate_placeholder_image(prompt, element_type)
            
            headers = {
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "inputs": prompt,
                "parameters": {
                    "num_inference_steps": 30,
                    "guidance_scale": 7.5,
                }
            }
            
            response = requests.post(API_URL, headers=headers, json=payload)
            if response.status_code == 200:
                # Convert to PIL Image
                image = Image.open(io.BytesIO(response.content))
                return image
            else:
                self.logger.error(f"API Error: {response.status_code}, {response.text}")
                # Generate a placeholder image as fallback
                return self._generate_placeholder_image(prompt, element_type)
        
        except Exception as e:
            self.logger.error(f"Error generating image via API: {str(e)}")
            # Generate a placeholder image as fallback
            return self._generate_placeholder_image(prompt, element_type)
    
    def _generate_placeholder_image(self, prompt: str, element_type: str) -> Image.Image:
        """Generate a placeholder image with text when AI generation fails"""
        # Create a simple colored background with text
        width, height = 512, 512
        background_color = self.color_palettes[self.color_scheme]["background"]
        text_color = self.color_palettes[self.color_scheme]["text"]
        
        # Convert hex colors to RGB
        def hex_to_rgb(hex_color):
            hex_color = hex_color.lstrip('#')
            return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        bg_color = hex_to_rgb(background_color)
        
        # Create image
        image = Image.new('RGB', (width, height), bg_color)
        
        # Return the placeholder image
        return image

    def _generate_scene_animation(self, scene: Dict) -> Dict:
        """Generate animation specification for a single scene"""
        visual_elements = scene.get("visual_elements", [])
        narration_duration = scene.get("duration_estimate", 10)
        
        # Initialize animation elements for this scene
        animation_elements = []
        total_duration = 0
        
        # Process each visual element
        for visual in visual_elements:
            visual_type = visual.get("type", "text_slide")
            
            # Get animation template for this type of visual
            templates = self.animation_templates.get(visual_type, self.animation_templates["text_slide"])
            template = templates.get(self.animation_level, templates["standard"])
            
            # Generate animation element based on the template
            animation_element = {
                "type": visual_type,
                "animation_type": template["animation_type"],
                "duration": template["duration"],
                "start_time": total_duration,
                "elements": []
            }
            
            # Add visual content
            if visual_type == "title_slide":
                animation_element["content"] = {
                    "title": visual.get("title", scene["title"]),
                    "subtitle": visual.get("subtitle", ""),
                    "background_color": self.color_palettes[self.color_scheme]["background"],
                    "text_color": self.color_palettes[self.color_scheme]["text"],
                    "accent_color": self.color_palettes[self.color_scheme]["accent"]
                }
            
            elif visual_type == "text_slide":
                animation_element["content"] = {
                    "title": visual.get("title", ""),
                    "text": visual.get("content", ""),
                    "background_color": self.color_palettes[self.color_scheme]["background"],
                    "text_color": self.color_palettes[self.color_scheme]["text"],
                    "highlight_color": self.color_palettes[self.color_scheme]["accent"]
                }
            
            elif visual_type == "bullet_points":
                animation_element["content"] = {
                    "title": visual.get("title", "Key Points"),
                    "points": visual.get("points", []),
                    "background_color": self.color_palettes[self.color_scheme]["background"],
                    "text_color": self.color_palettes[self.color_scheme]["text"],
                    "bullet_color": self.color_palettes[self.color_scheme]["primary"]
                }
            
            elif visual_type == "diagram":
                # Get diagram content from the visual element
                diagram_content = visual.get("content", {})
                animation_element["content"] = {
                    "diagram_type": diagram_content.get("type", "generic"),
                    "title": diagram_content.get("title", "Diagram"),
                    "svg_content": diagram_content.get("svg", ""),
                    "components": diagram_content.get("components", []),
                    "background_color": self.color_palettes[self.color_scheme]["background"],
                    "primary_color": self.color_palettes[self.color_scheme]["primary"],
                    "secondary_color": self.color_palettes[self.color_scheme]["secondary"]
                }
            
            elif visual_type == "figure":
                # Get figure content from the visual element
                figure_content = visual.get("content", {})
                animation_element["content"] = {
                    "image_path": figure_content.get("path", ""),
                    "caption": figure_content.get("caption", ""),
                    "alt_text": figure_content.get("alt_text", ""),
                    "highlight_areas": figure_content.get("highlights", [])
                }
            
            elif visual_type == "whiteboard":
                animation_element["content"] = {
                    "title": visual.get("title", scene["title"]),
                    "content": visual.get("content", ""),
                    "drawing_style": self.style,
                    "background_color": "#FFFFFF",  # Always white for whiteboard
                    "ink_color": "#333333"  # Dark gray ink
                }
            
            elif visual_type == "concept_graph":
                # Get graph content from the visual element
                graph_content = visual.get("content", {})
                animation_element["content"] = {
                    "nodes": graph_content.get("nodes", []),
                    "edges": graph_content.get("edges", []),
                    "node_color": self.color_palettes[self.color_scheme]["primary"],
                    "edge_color": self.color_palettes[self.color_scheme]["tertiary"],
                    "highlight_color": self.color_palettes[self.color_scheme]["accent"],
                    "background_color": self.color_palettes[self.color_scheme]["background"]
                }
            
            elif visual_type == "summary_slide":
                animation_element["content"] = {
                    "title": visual.get("title", "Summary"),
                    "points": visual.get("points", []),
                    "background_color": self.color_palettes[self.color_scheme]["background"],
                    "text_color": self.color_palettes[self.color_scheme]["text"],
                    "accent_color": self.color_palettes[self.color_scheme]["accent"]
                }
            
            # Add animation-specific properties
            animation_element["timing"] = {
                "start_time": total_duration,
                "duration": template["duration"],
                "end_time": total_duration + template["duration"]
            }
            
            # Apply style customizations
            self._apply_style_customizations(animation_element)
            
            # Add to scene elements and update total duration
            animation_elements.append(animation_element)
            total_duration += template["duration"]
        
        # If narration is longer than animations, extend the last animation
        if total_duration < narration_duration and animation_elements:
            last_element = animation_elements[-1]
            duration_extension = narration_duration - total_duration
            last_element["timing"]["duration"] += duration_extension
            last_element["timing"]["end_time"] += duration_extension
            total_duration = narration_duration
        
        # Create the final animation specification
        animation_spec = {
            "elements": animation_elements,
            "total_duration": total_duration,
            "style": self.style,
            "color_scheme": self.color_scheme,
            "animation_level": self.animation_level
        }
        
        return animation_spec
    
    def _apply_style_customizations(self, animation_element: Dict):
        """Apply style-specific customizations to animation elements"""
        element_type = animation_element["type"]
        
        # Get style key from either string or dictionary configuration
        style_key = self.style.get('style', self.style) if isinstance(self.style, dict) else self.style
        
        # Apply modern style customizations
        if style_key == "modern":
            # Add drop shadows to text elements
            if element_type in ["title_slide", "text_slide", "bullet_points", "summary_slide"]:
                animation_element["style_effects"] = {
                    "text_shadow": {"enabled": True, "blur": 4, "color": "rgba(0,0,0,0.2)"},
                    "use_sans_serif": True,
                    "rounded_corners": True,
                    "border_radius": 8
                }
            
            # Clean, minimal diagrams with thin lines
            elif element_type in ["diagram", "concept_graph"]:
                animation_element["style_effects"] = {
                    "line_thickness": "thin",
                    "use_gradients": True,
                    "shadow": {"enabled": True, "blur": 10, "opacity": 0.2},
                    "rounded_corners": True
                }
        
        # Apply minimalist style customizations
        elif style_key == "minimalist":
            # Simple, clean text without decorations
            if element_type in ["title_slide", "text_slide", "bullet_points", "summary_slide"]:
                animation_element["style_effects"] = {
                    "text_shadow": {"enabled": False},
                    "use_sans_serif": True,
                    "use_thin_font": True,
                    "uppercase_headings": True
                }
            
            # Simple diagrams with monochrome colors
            elif element_type in ["diagram", "concept_graph"]:
                animation_element["style_effects"] = {
                    "line_thickness": "thin",
                    "use_gradients": False,
                    "monochromatic": True,
                    "shadow": {"enabled": False}
                }
        
        # Apply playful style customizations
        elif style_key == "playful":
            # Playful text with rounded fonts and bright colors
            if element_type in ["title_slide", "text_slide", "bullet_points", "summary_slide"]:
                animation_element["style_effects"] = {
                    "text_shadow": {"enabled": True, "blur": 0, "offset_y": 2, "color": "rgba(0,0,0,0.3)"},
                    "use_rounded_font": True,
                    "use_bright_colors": True,
                    "add_decorative_elements": True
                }
            
            # Colorful diagrams with fun elements
            elif element_type in ["diagram", "concept_graph"]:
                animation_element["style_effects"] = {
                    "line_thickness": "medium",
                    "use_gradients": True,
                    "use_bright_colors": True,
                    "add_decorative_elements": True,
                    "rounded_corners": True,
                    "playful_icons": True
                }
        
        # Additional customizations based on animation level
        animation_level = self.animation_level
        if isinstance(self.style, dict):
            animation_level = self.style.get('animation_level', animation_level)
            
        if animation_level == "complex":
            animation_element["advanced_effects"] = {
                "use_parallax": True,
                "use_3d_elements": element_type in ["diagram", "concept_graph"],
                "use_particle_effects": True,
                "dynamic_backgrounds": True
            }
    
    def _generate_transition(self) -> Dict:
        """Generate a transition specification between scenes"""
        # Select transition type based on animation level
        transitions = self.transition_templates.get(self.animation_level, self.transition_templates["standard"])
        transition = random.choice(transitions)
        
        # Apply style-specific customizations
        if self.style == "minimalist":
            # Prefer simple transitions for minimalist style
            transition = random.choice(self.transition_templates["simple"])
        
        return transition
    
    def customize_animation_style(self, animation_data: Dict, style=None, 
                               color_scheme=None, animation_level=None) -> Dict:
        """
        Customize the style of existing animation data
        
        Args:
            animation_data: Existing animation data
            style: New style to apply (string or dict)
            color_scheme: New color scheme
            animation_level: New animation complexity level
            
        Returns:
            Updated animation data
        """
        # Update style parameters
        if style:
            self.style = style
            if isinstance(style, dict):
                if 'color_scheme' in style:
                    self.color_scheme = style['color_scheme']
                if 'animation_level' in style:
                    self.animation_level = style['animation_level']
        if color_scheme:
            self.color_scheme = color_scheme
        if animation_level:
            self.animation_level = animation_level
        
        # Update metadata
        style_key = self.style.get('style', self.style) if isinstance(self.style, dict) else self.style
        animation_data["metadata"].update({
            "style": style_key,
            "color_scheme": self.color_scheme,
            "color_palette": self.color_palettes[self.color_scheme],
            "animation_level": self.animation_level
        })
        
        # Mark for regeneration
        animation_data["needs_regeneration"] = True
        
        return animation_data 