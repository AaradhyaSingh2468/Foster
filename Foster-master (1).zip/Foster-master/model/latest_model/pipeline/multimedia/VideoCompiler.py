"""
Video Compiler Module
------------------
Combines animations and audio into complete educational videos.
Handles synchronization, editing, transitions, and final video production.
"""

import os
import time
import json
import logging
import subprocess
import tempfile
import shutil
from typing import Dict, List, Any, Optional, Union

class VideoCompiler:
    """Compiles animations and audio into complete videos"""
    
    def __init__(self, output_format="mp4", resolution=(1920, 1080), 
                fps=30, quality="high", add_subtitles=True):
        """
        Initialize the video compiler with output preferences
        
        Args:
            output_format: Video format (mp4, webm, mov)
            resolution: Video resolution as (width, height) tuple
            fps: Frames per second
            quality: Output quality (low, medium, high)
            add_subtitles: Whether to add subtitles/captions
        """
        self.output_format = output_format
        self.resolution = resolution
        self.fps = fps
        self.quality = quality
        self.add_subtitles = add_subtitles
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger("VideoCompiler")
        
        # Quality presets
        self.quality_presets = {
            "low": {
                "bitrate": "1M",
                "preset": "veryfast",
                "audio_bitrate": "96k"
            },
            "medium": {
                "bitrate": "4M",
                "preset": "medium",
                "audio_bitrate": "128k"
            },
            "high": {
                "bitrate": "8M",
                "preset": "slow",
                "audio_bitrate": "192k"
            }
        }
        
        # Check if FFmpeg is installed
        try:
            subprocess.run(["ffmpeg", "-version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            self.ffmpeg_available = True
            self.logger.info("FFmpeg is available for video processing")
        except (subprocess.SubprocessError, FileNotFoundError):
            self.ffmpeg_available = False
            self.logger.warning("FFmpeg not found. Falling back to simulation mode.")
    
    def compile_video(self, animation_data: Dict, audio_data: Dict, 
                    output_path: str = None) -> Dict[str, Any]:
        """
        Compile animations and audio into a complete video
        
        Args:
            animation_data: Animation data from AnimationGenerator
            audio_data: Audio data from TextToSpeechGenerator
            output_path: Path for the output video file
            
        Returns:
            Dictionary with video compilation results
        """
        self.logger.info("Starting video compilation")
        
        # Get animation and audio scenes
        animation_scenes = animation_data.get("scenes", [])
        audio_scenes = audio_data.get("scenes", [])
        
        # Check if we have matching scenes
        if len(animation_scenes) != len(audio_scenes):
            self.logger.warning(f"Scene count mismatch: {len(animation_scenes)} animation scenes, {len(audio_scenes)} audio scenes")
        
        # Create output directory if needed
        if output_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        else:
            # Generate default output path
            temp_dir = tempfile.gettempdir()
            output_path = os.path.join(temp_dir, f"educational_video.{self.output_format}")
        
        # Generate overall video specifications
        video_specs = self._generate_video_specs(animation_data, audio_data)
        
        # Compile individual scenes
        scene_results = []
        for i in range(min(len(animation_scenes), len(audio_scenes))):
            animation_scene = animation_scenes[i]
            audio_scene = audio_scenes[i]
            
            # Compile this scene
            scene_result = self._compile_scene(animation_scene, audio_scene, i)
            scene_results.append(scene_result)
        
        # Combine scenes into final video
        video_result = self._combine_scenes(scene_results, video_specs, output_path)
        
        # Generate subtitles if requested
        if self.add_subtitles:
            subtitle_path = self._generate_subtitles(audio_data, output_path)
            video_result["subtitle_file"] = subtitle_path
        
        self.logger.info(f"Video compilation complete: {output_path}")
        return video_result
    
    def _generate_video_specs(self, animation_data: Dict, audio_data: Dict) -> Dict:
        """Generate video specifications based on input data"""
        # Calculate total duration (use the longer of animation or audio)
        animation_duration = animation_data.get("metadata", {}).get("total_duration", 0)
        audio_duration = audio_data.get("metadata", {}).get("total_duration", 0)
        total_duration = max(animation_duration, audio_duration)
        
        # Get quality settings
        quality_preset = self.quality_presets.get(self.quality, self.quality_presets["medium"])
        
        video_specs = {
            "format": self.output_format,
            "width": self.resolution[0],
            "height": self.resolution[1],
            "fps": self.fps,
            "duration": total_duration,
            "total_frames": int(total_duration * self.fps),
            "quality_settings": quality_preset
        }
        
        return video_specs
    
    def _compile_scene(self, animation_scene: Dict, audio_scene: Dict, scene_index: int) -> Dict:
        """
        Compile a single scene combining animation and audio
        
        Args:
            animation_scene: Animation data for the scene
            audio_scene: Audio data for the scene
            scene_index: Index of the scene
            
        Returns:
            Scene compilation result
        """
        scene_id = animation_scene.get("scene_id", f"scene_{scene_index}")
        title = animation_scene.get("title", f"Scene {scene_index}")
        
        # Get animation specification
        animation_spec = animation_scene.get("animation_spec", {})
        animation_duration = animation_spec.get("total_duration", 0)
        
        # Get audio specification
        audio_spec = audio_scene.get("audio_spec", {})
        audio_duration = audio_spec.get("duration", 0)
        audio_file = audio_spec.get("audio_file", "")
        
        # Determine scene duration (use the longer of animation or audio)
        scene_duration = max(animation_duration, audio_duration)
        
        # Generate temporary output file for this scene
        temp_dir = tempfile.gettempdir()
        scene_output = os.path.join(temp_dir, f"{scene_id}.{self.output_format}")
        
        # Real implementation using FFmpeg to render the animation and combine with audio
        if self.ffmpeg_available and os.path.exists(audio_file):
            try:
                # Get animation frames (assuming they're available as image sequence or video)
                animation_frames = animation_spec.get("animation_frames", "")
                animation_video = animation_spec.get("animation_video", "")
                
                # If we have animation frames (as image sequence)
                if animation_frames and os.path.exists(animation_frames):
                    # Create video from image sequence
                    frame_pattern = os.path.join(animation_frames, "frame_%04d.png")
                    cmd = [
                        "ffmpeg", "-y",
                        "-framerate", str(self.fps),
                        "-i", frame_pattern,
                        "-i", audio_file,
                        "-c:v", "libx264",
                        "-preset", self.quality_presets[self.quality]["preset"],
                        "-b:v", self.quality_presets[self.quality]["bitrate"],
                        "-c:a", "aac",
                        "-b:a", self.quality_presets[self.quality]["audio_bitrate"],
                        "-pix_fmt", "yuv420p",
                        "-shortest",
                        scene_output
                    ]
                    subprocess.run(cmd, check=True)
                
                # If we have animation as video
                elif animation_video and os.path.exists(animation_video):
                    # Combine animation video with audio
                    cmd = [
                        "ffmpeg", "-y",
                        "-i", animation_video,
                        "-i", audio_file,
                        "-c:v", "libx264",
                        "-preset", self.quality_presets[self.quality]["preset"],
                        "-b:v", self.quality_presets[self.quality]["bitrate"],
                        "-c:a", "aac",
                        "-b:a", self.quality_presets[self.quality]["audio_bitrate"],
                        "-shortest",
                        scene_output
                    ]
                    subprocess.run(cmd, check=True)
                
                # If we don't have animation, create a video from a color
                else:
                    # Create a simple color background video with audio
                    cmd = [
                        "ffmpeg", "-y",
                        "-f", "lavfi",
                        "-i", f"color=c=blue:s={self.resolution[0]}x{self.resolution[1]}:r={self.fps}:d={scene_duration}",
                        "-i", audio_file,
                        "-c:v", "libx264",
                        "-preset", self.quality_presets[self.quality]["preset"],
                        "-b:v", self.quality_presets[self.quality]["bitrate"],
                        "-c:a", "aac",
                        "-b:a", self.quality_presets[self.quality]["audio_bitrate"],
                        "-shortest",
                        scene_output
                    ]
                    subprocess.run(cmd, check=True)
                
                self.logger.info(f"Compiled scene with FFmpeg: {title} ({scene_duration:.1f} seconds)")
            
            except subprocess.SubprocessError as e:
                self.logger.error(f"FFmpeg scene compilation failed: {str(e)}")
                # Fallback to simulation
                self._simulate_render_time(scene_duration)
        else:
            # Fallback to simulation if FFmpeg not available or audio file missing
            self._simulate_render_time(scene_duration)
            self.logger.info(f"Simulated scene compilation: {title} ({scene_duration:.1f} seconds)")
        
        scene_result = {
            "scene_id": scene_id,
            "title": title,
            "output_file": scene_output,
            "duration": scene_duration,
            "frames": int(scene_duration * self.fps)
        }
        
        return scene_result
    
    def _combine_scenes(self, scene_results: List[Dict], video_specs: Dict, output_path: str) -> Dict:
        """
        Combine individual scenes into the final video
        
        Args:
            scene_results: List of scene compilation results
            video_specs: Overall video specifications
            output_path: Path for the output video file
            
        Returns:
            Video compilation result
        """
        # Real implementation to concatenate scene videos with FFmpeg
        if self.ffmpeg_available and scene_results:
            try:
                # Create a temporary file listing all input videos
                temp_dir = tempfile.gettempdir()
                concat_file = os.path.join(temp_dir, "concat_list.txt")
                
                with open(concat_file, 'w') as f:
                    for scene in scene_results:
                        if os.path.exists(scene["output_file"]):
                            f.write(f"file '{scene['output_file']}'\n")
                
                # Use FFmpeg's concat demuxer to join the videos
                cmd = [
                    "ffmpeg", "-y",
                    "-f", "concat",
                    "-safe", "0",
                    "-i", concat_file,
                    "-c", "copy",
                    output_path
                ]
                subprocess.run(cmd, check=True)
                
                # Calculate total duration
                total_duration = sum(scene.get("duration", 0) for scene in scene_results)
                
                self.logger.info(f"Combined {len(scene_results)} scenes with FFmpeg: {output_path}")
                
            except (subprocess.SubprocessError, IOError) as e:
                self.logger.error(f"FFmpeg scene combination failed: {str(e)}")
                # Fallback to simulation
                total_duration = sum(scene.get("duration", 0) for scene in scene_results)
                self._simulate_render_time(total_duration * 0.2)
        else:
            # Fallback to simulation if FFmpeg not available
            total_duration = sum(scene.get("duration", 0) for scene in scene_results)
            self._simulate_render_time(total_duration * 0.2)
            self.logger.info(f"Simulated scene combination: {output_path}")
        
        # Generate metadata
        video_result = {
            "output_file": output_path,
            "format": video_specs["format"],
            "resolution": f"{video_specs['width']}x{video_specs['height']}",
            "fps": video_specs["fps"],
            "duration": total_duration,
            "frames": int(total_duration * self.fps),
            "scenes": [scene["scene_id"] for scene in scene_results],
            "quality": self.quality
        }
        
        return video_result
    
    def _generate_subtitles(self, audio_data: Dict, video_path: str) -> str:
        """
        Generate subtitles/captions for the video
        
        Args:
            audio_data: Audio data with word timings
            video_path: Path to the video file
            
        Returns:
            Path to the subtitle file
        """
        # Create subtitle file path based on video path
        subtitle_path = os.path.splitext(video_path)[0] + ".srt"
        
        # Extract word timings from all scenes
        all_word_timings = []
        current_time_offset = 0
        
        for scene in audio_data.get("scenes", []):
            audio_spec = scene.get("audio_spec", {})
            word_timings = audio_spec.get("word_timings", [])
            scene_duration = audio_spec.get("duration", 0)
            
            # Adjust timings with current offset
            adjusted_timings = []
            for timing in word_timings:
                adjusted_timing = timing.copy()
                adjusted_timing["start_time"] += current_time_offset
                adjusted_timing["end_time"] += current_time_offset
                adjusted_timings.append(adjusted_timing)
            
            all_word_timings.extend(adjusted_timings)
            current_time_offset += scene_duration
        
        # Group words into sentences for better subtitle chunking
        sentences = []
        current_sentence = []
        sentence_start_time = 0
        
        for i, timing in enumerate(all_word_timings):
            word = timing["word"]
            
            if not current_sentence:
                sentence_start_time = timing["start_time"]
                
            current_sentence.append(word)
            
            # End the sentence if the word ends with punctuation or it's the last word
            if (word.endswith('.') or word.endswith('!') or word.endswith('?') or 
                i == len(all_word_timings) - 1):
                sentence_text = " ".join(current_sentence)
                sentence_end_time = timing["end_time"]
                
                sentences.append({
                    "text": sentence_text,
                    "start_time": sentence_start_time,
                    "end_time": sentence_end_time
                })
                
                current_sentence = []
        
        # Break sentences into subtitle lines (about 42 chars per line max)
        subtitle_lines = []
        MAX_CHARS_PER_LINE = 42
        
        for i, sentence in enumerate(sentences):
            text = sentence["text"]
            words = text.split()
            
            # If sentence is short enough, use it as is
            if len(text) <= MAX_CHARS_PER_LINE:
                subtitle_lines.append({
                    "index": len(subtitle_lines) + 1,
                    "start_time": sentence["start_time"],
                    "end_time": sentence["end_time"],
                    "text": text
                })
            else:
                # Split into multiple lines
                current_line = []
                current_line_length = 0
                line_start_time = sentence["start_time"]
                
                for j, word in enumerate(words):
                    # If adding this word would exceed the max length, finish the line
                    if current_line_length + len(word) + 1 > MAX_CHARS_PER_LINE and current_line:
                        line_text = " ".join(current_line)
                        # Calculate approximate end time based on position in sentence
                        progress = j / len(words)
                        line_end_time = line_start_time + progress * (sentence["end_time"] - sentence["start_time"])
                        
                        subtitle_lines.append({
                            "index": len(subtitle_lines) + 1,
                            "start_time": line_start_time,
                            "end_time": line_end_time,
                            "text": line_text
                        })
                        
                        current_line = [word]
                        current_line_length = len(word)
                        line_start_time = line_end_time
                    else:
                        current_line.append(word)
                        current_line_length += len(word) + 1  # +1 for space
                
                # Add the last line if there's anything left
                if current_line:
                    line_text = " ".join(current_line)
                    subtitle_lines.append({
                        "index": len(subtitle_lines) + 1,
                        "start_time": line_start_time,
                        "end_time": sentence["end_time"],
                        "text": line_text
                    })
        
        # Write the SRT file in proper format
        with open(subtitle_path, 'w', encoding='utf-8') as f:
            for line in subtitle_lines:
                # Convert time to SRT format (HH:MM:SS,mmm)
                start_h = int(line["start_time"] // 3600)
                start_m = int((line["start_time"] % 3600) // 60)
                start_s = int(line["start_time"] % 60)
                start_ms = int((line["start_time"] * 1000) % 1000)
                
                end_h = int(line["end_time"] // 3600)
                end_m = int((line["end_time"] % 3600) // 60)
                end_s = int(line["end_time"] % 60)
                end_ms = int((line["end_time"] * 1000) % 1000)
                
                # Write SRT entry
                f.write(f"{line['index']}\n")
                f.write(f"{start_h:02d}:{start_m:02d}:{start_s:02d},{start_ms:03d} --> ")
                f.write(f"{end_h:02d}:{end_m:02d}:{end_s:02d},{end_ms:03d}\n")
                f.write(f"{line['text']}\n\n")
        
        self.logger.info(f"Generated SRT subtitles: {subtitle_path} ({len(subtitle_lines)} lines)")
        
        return subtitle_path
    
    def _simulate_render_time(self, duration: float):
        """Simulate rendering time for the given duration"""
        # Simple simulation: 10% of real-time duration
        time.sleep(min(5, duration * 0.1))  # Cap at 5 seconds for demo purposes
    
    def add_background_music(self, video_path: str, music_path: str, volume=0.2) -> str:
        """
        Add background music to a video
        
        Args:
            video_path: Path to the video file
            music_path: Path to the music file
            volume: Volume level for the music (0.0-1.0)
            
        Returns:
            Path to the new video file with music
        """
        # Generate output path
        output_path = os.path.splitext(video_path)[0] + "_with_music" + os.path.splitext(video_path)[1]
        
        # Real implementation using FFmpeg to mix audio tracks
        if self.ffmpeg_available and os.path.exists(video_path) and os.path.exists(music_path):
            try:
                # Get video duration
                cmd = [
                    "ffprobe", 
                    "-v", "error", 
                    "-show_entries", "format=duration", 
                    "-of", "default=noprint_wrappers=1:nokey=1", 
                    video_path
                ]
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
                video_duration = float(result.stdout.strip())
                
                # Use FFmpeg to mix the audio tracks
                cmd = [
                    "ffmpeg", "-y",
                    "-i", video_path,
                    "-i", music_path,
                    "-filter_complex", f"[1:a]volume={volume},aloop=loop=-1:size=2e+09[a1];[0:a][a1]amix=inputs=2:duration=first[a]",
                    "-map", "0:v",
                    "-map", "[a]",
                    "-c:v", "copy",
                    "-c:a", "aac",
                    "-b:a", self.quality_presets[self.quality]["audio_bitrate"],
                    "-shortest",
                    output_path
                ]
                subprocess.run(cmd, check=True)
                
                self.logger.info(f"Added background music with FFmpeg: {output_path} (music volume: {volume:.1f})")
                
            except (subprocess.SubprocessError, FileNotFoundError) as e:
                self.logger.error(f"FFmpeg background music addition failed: {str(e)}")
                # Fallback to simulation
                time.sleep(2)
                # Copy the original video as fallback
                if os.path.exists(video_path):
                    shutil.copy2(video_path, output_path)
        else:
            # Simulate processing time
            time.sleep(2)
            self.logger.info(f"Simulated adding background music: {output_path} (music volume: {volume:.1f})")
            # Copy the original video as fallback
            if os.path.exists(video_path):
                shutil.copy2(video_path, output_path)
        
        return output_path
    
    def generate_preview(self, video_path: str, preview_duration=30) -> str:
        """
        Generate a short preview of the video
        
        Args:
            video_path: Path to the video file
            preview_duration: Duration of the preview in seconds
            
        Returns:
            Path to the preview video file
        """
        # Generate output path
        output_path = os.path.splitext(video_path)[0] + "_preview" + os.path.splitext(video_path)[1]
        
        # Real implementation using FFmpeg to extract segment and add watermark
        if self.ffmpeg_available and os.path.exists(video_path):
            try:
                # Create a temporary watermark image with "PREVIEW" text
                watermark_path = os.path.join(tempfile.gettempdir(), "preview_watermark.png")
                
                # Extract segment and add watermark
                cmd = [
                    "ffmpeg", "-y",
                    "-i", video_path,
                    "-t", str(preview_duration),
                    "-vf", f"drawtext=text='PREVIEW':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=h-th-10:box=1:boxcolor=black@0.5:boxborderw=5",
                    "-c:v", "libx264",
                    "-preset", self.quality_presets[self.quality]["preset"],
                    "-c:a", "aac",
                    output_path
                ]
                subprocess.run(cmd, check=True)
                
                self.logger.info(f"Generated video preview with FFmpeg: {output_path} ({preview_duration} seconds)")
                
            except subprocess.SubprocessError as e:
                self.logger.error(f"FFmpeg preview generation failed: {str(e)}")
                # Fallback to simulation
                time.sleep(1)
                # Copy a portion of the original video as fallback
                if os.path.exists(video_path):
                    try:
                        cmd = [
                            "ffmpeg", "-y",
                            "-i", video_path,
                            "-t", str(preview_duration),
                            "-c", "copy",
                            output_path
                        ]
                        subprocess.run(cmd, check=True)
                    except:
                        # Last resort: just copy the file
                        shutil.copy2(video_path, output_path)
        else:
            # Simulate processing time
            time.sleep(1)
            self.logger.info(f"Simulated video preview generation: {output_path} ({preview_duration} seconds)")
            # Copy the original video as fallback if possible
            if os.path.exists(video_path):
                shutil.copy2(video_path, output_path)
        
        return output_path
    
    def set_output_format(self, format="mp4", resolution=(1920, 1080), fps=30, quality="high"):
        """
        Set output format and quality options
        
        Args:
            format: Video format (mp4, webm, mov)
            resolution: Video resolution as (width, height) tuple
            fps: Frames per second
            quality: Output quality (low, medium, high)
        """
        self.output_format = format
        self.resolution = resolution
        self.fps = fps
        self.quality = quality
        
        self.logger.info(f"Output format set: {format}, {resolution[0]}x{resolution[1]}, {fps} fps, {quality} quality")
    
    def export_multiple_formats(self, video_path: str, formats=None) -> List[str]:
        """
        Export the video to multiple formats
        
        Args:
            video_path: Path to the original video file
            formats: List of format specifications
            
        Returns:
            List of paths to the exported video files
        """
        if formats is None:
            formats = [
                {"format": "mp4", "resolution": (1920, 1080), "quality": "high"},
                {"format": "mp4", "resolution": (1280, 720), "quality": "medium"},
                {"format": "webm", "resolution": (1280, 720), "quality": "medium"}
            ]
        
        output_paths = []
        
        # Real implementation using FFmpeg for transcoding
        if self.ffmpeg_available and os.path.exists(video_path):
            for format_spec in formats:
                # Generate output path
                base_name = os.path.splitext(video_path)[0]
                resolution = format_spec.get("resolution", (1920, 1080))
                quality = format_spec.get("quality", "medium")
                format_ext = format_spec.get("format", "mp4")
                quality_preset = self.quality_presets.get(quality, self.quality_presets["medium"])
                
                output_name = f"{base_name}_{resolution[0]}x{resolution[1]}_{quality}.{format_ext}"
                
                try:
                    # Set the video codec based on format
                    if format_ext == "webm":
                        vcodec = "libvpx-vp9"
                        acodec = "libopus"
                    elif format_ext == "mp4":
                        vcodec = "libx264"
                        acodec = "aac"
                    else:
                        vcodec = "libx264"
                        acodec = "aac"
                    
                    # Transcode with FFmpeg
                    cmd = [
                        "ffmpeg", "-y",
                        "-i", video_path,
                        "-c:v", vcodec,
                        "-b:v", quality_preset["bitrate"],
                        "-c:a", acodec,
                        "-b:a", quality_preset["audio_bitrate"],
                        "-s", f"{resolution[0]}x{resolution[1]}",
                        output_name
                    ]
                    
                    subprocess.run(cmd, check=True)
                    output_paths.append(output_name)
                    self.logger.info(f"Exported video format with FFmpeg: {output_name}")
                    
                except subprocess.SubprocessError as e:
                    self.logger.error(f"FFmpeg format conversion failed for {output_name}: {str(e)}")
                    # Skip this format on error
        else:
            # Fallback to simulation if FFmpeg not available
            for format_spec in formats:
                # Generate output path
                base_name = os.path.splitext(video_path)[0]
                resolution = format_spec.get("resolution", (1920, 1080))
                quality = format_spec.get("quality", "medium")
                format_ext = format_spec.get("format", "mp4")
                
                output_name = f"{base_name}_{resolution[0]}x{resolution[1]}_{quality}.{format_ext}"
                
                # Simulate processing time
                time.sleep(1)
                
                # Try a simple copy if the original file exists
                if os.path.exists(video_path):
                    try:
                        shutil.copy2(video_path, output_name)
                        output_paths.append(output_name)
                        self.logger.info(f"Simulated video format export: {output_name}")
                    except:
                        pass
        
        return output_paths 