import requests
import json

class OpenRouterMistralClient:
    CHAR_LIMIT = 30000  # approximate character limit to avoid context overflow

    def __init__(self, api_key: str = None,
                 model: str = "mistralai/mistral-7b-instruct-v0.2"):
        """
        LM client for Mistral‑7B‑Instruct via OpenRouter's free API.

        Args:
            api_key: Your OpenRouter API key (starts with sk-…)
            model:   The model identifier on OpenRouter
        """
        self.url = "https://openrouter.ai/api/v1/chat/completions"
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {api_key}" if api_key else "",
            "Content-Type": "application/json"
        }
        self.model = model

    def _chunk_text(self, text: str) -> list[str]:
        """
        Split text into chunks under CHAR_LIMIT characters.
        """
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + self.CHAR_LIMIT, len(text))
            # try to split at last newline within limit for cleaner chunks
            if end < len(text):
                nl = text.rfind("\n", start, end)
                if nl > start:
                    end = nl
            chunks.append(text[start:end])
            start = end
        return chunks

    def update_api_key(self, api_key: str):
        """
        Update the API key after initialization
        
        Args:
            api_key: OpenRouter API key (starts with sk-...)
        """
        self.api_key = api_key
        self.headers["Authorization"] = f"Bearer {api_key}"
        return True

    def generate(self, prompt: str, max_tokens: int = 256) -> str:
        """
        Generate text completion for a prompt.
        
        Args:
            prompt: The full text prompt to complete
            max_tokens: Maximum number of tokens to generate
            
        Returns:
            Generated text completion
        """
        if not self.api_key:
            raise ValueError("API key is required. Set it in constructor or call update_api_key()")
        
        return self._generate(prompt_template="{text}", text=prompt, max_tokens=max_tokens)

    def _generate(self, prompt_template: str, text: str, max_tokens: int = 256) -> str:
        """
        Core chat‑completion call to OpenRouter, with input chunking.

        Args:
            prompt_template: a format string expecting placeholders subbed
            text:            the raw text to insert into the prompt
            max_tokens:      model's max new tokens

        Returns:
            Combined responses across all text chunks.
        """
        if not self.api_key:
            raise ValueError("API key is required. Set it in constructor or call update_api_key()")
            
        responses = []
        for chunk in self._chunk_text(text):
            prompt = prompt_template.replace("{text}", chunk)
            payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens
            }
            resp = requests.post(self.url, headers=self.headers, json=payload)
            if not resp.ok:
                raise RuntimeError(
                    f"OpenRouter API error {resp.status_code}: {resp.text}"
                )
            data = resp.json()
            if "choices" not in data:
                raise KeyError(f"OpenRouter response missing 'choices': {json.dumps(data)}")
            content = data["choices"][0]["message"]["content"]
            responses.append(content)
        # Join chunk responses naturally
        return "\n".join(responses)

    def extract_keywords(self, text: str, domain: str = None):
        """Extract key terms and concepts from text."""
        template = (
            "Extract the key terms and concepts from the following {domain} text. "
            "Return a JSON with fields 'keywords' and 'concepts':\n\n{text}"
        )
        return self._generate(template.replace("{domain}", domain or 'general'), text)

    def analyze_sentiment(self, text: str):
        """Analyze sentiment of text."""
        template = (
            "Provide a sentiment analysis of the following text. "
            "Return a JSON with fields 'sentiment' and 'score':\n\n{text}"
        )
        return self._generate(template, text)

    def segment_content(self, text: str):
        """Split text into logical segments."""
        template = (
            "Split the following into logical content segments. "
            "Return a JSON array of segments:\n\n{text}"
        )
        result = self._generate(template, text, max_tokens=512)
        try:
            # Try to parse as JSON
            segments = json.loads(result)
            return segments if isinstance(segments, list) else [result]
        except json.JSONDecodeError:
            # Fall back to line splitting if not valid JSON
            return [seg.strip() for seg in result.split("\n") if seg.strip()]

    def generate_semantic_tags(self, text: str, domain: str = None):
        """Generate semantic tags for text."""
        template = (
            "Generate a list of semantic tags relevant to {domain} domain for this text. "
            "Return a JSON array of tags:\n\n{text}"
        )
        result = self._generate(template.replace("{domain}", domain or 'general'), text)
        try:
            # Try to parse as JSON
            tags = json.loads(result)
            return tags if isinstance(tags, list) else result.split(",")
        except json.JSONDecodeError:
            # Fall back to comma splitting if not valid JSON
            return [tag.strip() for tag in result.split(",")]

    def summarize_text(self, text: str, max_length: int = 200):
        """Summarize text within max length."""
        template = (
            "Summarize the following text in no more than {max} words:\n\n{text}"
        )
        return self._generate(template.replace("{max}", str(max_length)), text, max_tokens=max_length)

    def analyze_literary_work(self, text: str, subtype: str):
        """Analyze literary work by subtype."""
        template = (
            "As a literary critic analyzing a {subtype}, provide a JSON with fields "
            "'characters', 'structure', 'literary_devices', and 'themes':\n\n{text}"
        )
        return self._generate(template.replace("{subtype}", subtype), text, max_tokens=512)
    
    # New domain-specific analysis methods
    
    def analyze_scientific_content(self, text: str):
        """Analyze scientific content."""
        template = (
            "Analyze this scientific text and provide a JSON with fields "
            "'terminology', 'methods', 'findings', and 'conclusions':\n\n{text}"
        )
        return self._generate(template, text, max_tokens=512)
    
    def analyze_mathematical_content(self, text: str):
        """Analyze mathematical content."""
        template = (
            "Analyze this mathematical text and provide a JSON with fields "
            "'theorems', 'proofs', 'equations', 'definitions', and 'problem_types':\n\n{text}"
        )
        return self._generate(template, text, max_tokens=512)
    
    def analyze_chemical_content(self, text: str):
        """Analyze chemical content."""
        template = (
            "Analyze this chemistry text and provide a JSON with fields "
            "'compounds', 'reactions', and 'reaction_conditions':\n\n{text}"
        )
        return self._generate(template, text, max_tokens=512)
    
    def analyze_biological_content(self, text: str):
        """Analyze biological content."""
        template = (
            "Analyze this biology text and provide a JSON with fields "
            "'species', 'genes', and 'biological_pathways':\n\n{text}"
        )
        return self._generate(template, text, max_tokens=512)
    
    def analyze_physics_content(self, text: str):
        """Analyze physics content."""
        template = (
            "Analyze this physics text and provide a JSON with fields "
            "'physical_laws', 'physical_quantities', and 'physics_equations':\n\n{text}"
        )
        return self._generate(template, text, max_tokens=512)
    
    def analyze_section(self, text: str, domain: str = None):
        """Analyze a specific section with domain context."""
        template = (
            "Analyze this {domain} section and provide a JSON with fields "
            "'summary', 'key_points', and 'relevant_entities':\n\n{text}"
        )
        return self._generate(template.replace("{domain}", domain or 'general'), text, max_tokens=384)

class MistralSmallClient:
    """
    Client for interacting with Mistral Small model for script generation and other tasks.
    
    This class is optimized for educational script generation using Mistral Small 3.1,
    which is well-suited for knowledge-intensive tasks like educational content creation.
    """
    
    CHAR_LIMIT = 32000  # Higher context limit for Mistral Small
    
    def __init__(self, api_key: str = None, 
                 model: str = "mistralai/mistral-small-latest"):
        """
        Initialize the Mistral Small client.
        
        Args:
            api_key: Your Mistral API key
            model: The model identifier (defaults to Mistral Small)
        """
        self.api_key = api_key
        self.model = model
        self.url = "https://api.mistral.ai/v1/chat/completions"
        self.headers = {
            "Authorization": f"Bearer {api_key}" if api_key else "",
            "Content-Type": "application/json"
        }
    
    def _chunk_text(self, text: str) -> list[str]:
        """
        Split text into chunks under CHAR_LIMIT characters.
        """
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + self.CHAR_LIMIT, len(text))
            # try to split at last newline within limit for cleaner chunks
            if end < len(text):
                nl = text.rfind("\n", start, end)
                if nl > start:
                    end = nl
            chunks.append(text[start:end])
            start = end
        return chunks
    
    def update_api_key(self, api_key: str):
        """
        Update the API key after initialization
        
        Args:
            api_key: Mistral API key
        """
        self.api_key = api_key
        self.headers["Authorization"] = f"Bearer {api_key}"
        return True
    
    def generate(self, prompt: str, max_tokens: int = 1024, 
                temperature: float = 0.7, system_prompt: str = None) -> str:
        """
        Generate text using Mistral Small model.
        
        Args:
            prompt: The text prompt to complete
            max_tokens: Maximum number of tokens to generate
            temperature: Controls randomness (0.0-1.0)
            system_prompt: Optional system prompt for context
            
        Returns:
            Generated text
        """
        if not self.api_key:
            raise ValueError("API key is required. Set it in constructor or call update_api_key()")
        
        messages = []
        
        # Add system prompt if provided
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
            
        # Add user prompt
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        resp = requests.post(self.url, headers=self.headers, json=payload)
        if not resp.ok:
            raise RuntimeError(
                f"Mistral API error {resp.status_code}: {resp.text}"
            )
        
        data = resp.json()
        if "choices" not in data:
            raise KeyError(f"Mistral response missing 'choices': {json.dumps(data)}")
        
        return data["choices"][0]["message"]["content"]
    
    def _generate_with_messages(self, messages: list, max_tokens: int = 1024,
                               temperature: float = 0.7) -> str:
        """
        Generate response using a list of message objects.
        
        Args:
            messages: List of message objects (role, content)
            max_tokens: Maximum tokens to generate
            temperature: Controls randomness
            
        Returns:
            Generated text
        """
        if not self.api_key:
            raise ValueError("API key is required. Set it in constructor or call update_api_key()")
        
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        resp = requests.post(self.url, headers=self.headers, json=payload)
        if not resp.ok:
            raise RuntimeError(
                f"Mistral API error {resp.status_code}: {resp.text}"
            )
        
        data = resp.json()
        if "choices" not in data:
            raise KeyError(f"Mistral response missing 'choices': {json.dumps(data)}")
        
        return data["choices"][0]["message"]["content"]
    
    def generate_educational_script(self, topic: str, key_concepts: list, 
                                  audience: str = "general", tone: str = "neutral",
                                  max_length: int = 2000) -> str:
        """
        Generate an educational script focused on explaining a topic.
        
        Args:
            topic: The main topic of the script
            key_concepts: List of key concepts to cover
            audience: Target audience (elementary, secondary, university, general)
            tone: Desired tone (neutral, conversational, formal)
            max_length: Maximum length of the script in tokens
            
        Returns:
            Generated educational script
        """
        system_prompt = (
            "You are an expert educational script writer. Your task is to create "
            "clear, engaging, and accurate educational scripts for videos. "
            "Incorporate proper transitions between topics and use language "
            "appropriate for the target audience."
        )
        
        # Format key concepts as a comma-separated list
        concepts_text = ", ".join(key_concepts) if isinstance(key_concepts, list) else key_concepts
        
        user_prompt = f"""
        Create an educational script about {topic} for a {audience} audience.
        
        Key concepts to cover:
        {concepts_text}
        
        The script should:
        - Use a {tone} tone
        - Include a clear introduction and conclusion
        - Explain each concept in a way appropriate for the {audience} audience
        - Include appropriate transition phrases between sections
        - Mark places where a visual should be displayed with [VISUAL: description]
        
        Format the script with clear section headers and concise content.
        """
        
        return self.generate(user_prompt, max_tokens=max_length, 
                           temperature=0.7, system_prompt=system_prompt)
    
    def generate_section_content(self, section_title: str, description: str, 
                               key_concepts: list, audience: str = "general",
                               tone: str = "neutral", max_length: int = 500) -> str:
        """
        Generate content for a specific section of an educational script.
        
        Args:
            section_title: Title of the section
            description: Brief description of the section
            key_concepts: Key concepts to cover in this section
            audience: Target audience
            tone: Desired tone
            max_length: Maximum length of the section content
            
        Returns:
            Generated section content
        """
        system_prompt = (
            "You are writing a section for an educational script. Your writing should be "
            "clear, accurate, and engaging. Structure your response to flow naturally "
            "in a spoken format, with appropriate transitions and language for the target audience."
        )
        
        # Format key concepts
        concepts_text = ", ".join(key_concepts) if isinstance(key_concepts, list) else key_concepts
        
        user_prompt = f"""
        Write the content for the "{section_title}" section of an educational script.
        
        Section description: {description}
        
        Key concepts to address: {concepts_text}
        
        Requirements:
        - Use a {tone} tone appropriate for a {audience} audience
        - Keep the content focused and concise
        - Include appropriate transitions for a spoken script
        - Mark visual cues with [VISUAL: description]
        - Limit to approximately {max_length//5} words
        
        The content should be ready to be performed as part of a video script.
        """
        
        return self.generate(user_prompt, max_tokens=max_length, 
                           temperature=0.7, system_prompt=system_prompt)
    
    def generate_introduction(self, topic: str, key_concepts: list, 
                            audience: str = "general", tone: str = "neutral") -> str:
        """
        Generate an engaging introduction for an educational script.
        
        Args:
            topic: The main topic
            key_concepts: Key concepts to mention
            audience: Target audience 
            tone: Desired tone
            
        Returns:
            Generated introduction
        """
        # Format key concepts
        concepts_text = ", ".join(key_concepts) if isinstance(key_concepts, list) else key_concepts
        
        system_prompt = "You are writing an engaging introduction for an educational video script."
        
        user_prompt = f"""
        Create an engaging introduction for an educational video about {topic}.
        
        The introduction should:
        - Use a {tone} tone appropriate for a {audience} audience
        - Briefly mention that we'll cover these key concepts: {concepts_text}
        - Hook the viewer's interest with a compelling opening
        - Be approximately 100-150 words
        - Include a visual cue if appropriate with [VISUAL: description]
        
        The introduction should naturally lead into the main content of the video.
        """
        
        return self.generate(user_prompt, max_tokens=350, 
                           temperature=0.7, system_prompt=system_prompt)
    
    def generate_conclusion(self, topic: str, key_concepts: list, 
                          audience: str = "general", tone: str = "neutral") -> str:
        """
        Generate a conclusion for an educational script.
        
        Args:
            topic: The main topic
            key_concepts: Key concepts to summarize
            audience: Target audience 
            tone: Desired tone
            
        Returns:
            Generated conclusion
        """
        # Format key concepts
        concepts_text = ", ".join(key_concepts) if isinstance(key_concepts, list) else key_concepts
        
        system_prompt = "You are writing a concise, effective conclusion for an educational video script."
        
        user_prompt = f"""
        Create a strong conclusion for an educational video about {topic}.
        
        The conclusion should:
        - Use a {tone} tone appropriate for a {audience} audience
        - Briefly summarize the key concepts we covered: {concepts_text}
        - Emphasize why this topic matters or how it connects to broader contexts
        - Include a call to action or thought-provoking final statement
        - Be approximately 80-120 words
        
        The conclusion should provide a sense of closure while reinforcing the main takeaways.
        """
        
        return self.generate(user_prompt, max_tokens=300, 
                           temperature=0.7, system_prompt=system_prompt)
    
    def analyze_content_for_script(self, content: str, domain: str = None) -> dict:
        """
        Analyze content to extract key elements for script generation.
        
        Args:
            content: The content to analyze
            domain: Optional domain context
            
        Returns:
            Dictionary with extracted script elements
        """
        system_prompt = (
            "You are an expert content analyst for educational video production. "
            "Your task is to extract key elements from content that will be useful "
            "for creating an educational script."
        )
        
        domain_context = f"in the {domain} domain" if domain else ""
        
        user_prompt = f"""
        Analyze the following content {domain_context} and extract elements for an educational script.
        
        Content:
        {content[:4000]}
        
        Extract and return a JSON object with the following structure:
        {{
            "topic": "The main topic of the content",
            "key_concepts": ["List of 5-8 key concepts"],
            "suggested_structure": [
                {{"section": "Introduction", "description": "Brief intro to topic"}},
                {{"section": "Concept 1", "description": "Explanation of first key concept"}},
                // Additional sections
                {{"section": "Conclusion", "description": "Summary and key takeaways"}}
            ],
            "visual_elements": [
                {{"type": "diagram/chart/image", "description": "What should be shown"}}
            ],
            "target_audience": "Suggested target audience based on content complexity",
            "estimated_duration": "Estimated video length in minutes"
        }}
        
        Ensure the suggested structure follows a logical flow and covers all key concepts.
        """
        
        response = self.generate(user_prompt, max_tokens=1500, 
                               temperature=0.3, system_prompt=system_prompt)
        
        # Try to extract JSON from the response
        try:
            # Find JSON object in response
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            if json_start >= 0 and json_end > json_start:
                json_str = response[json_start:json_end]
                return json.loads(json_str)
            else:
                return {"error": "Could not extract JSON from response", "raw_response": response}
        except json.JSONDecodeError:
            return {"error": "Failed to parse JSON", "raw_response": response}