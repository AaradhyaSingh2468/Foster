"""
Script Generator Module
----------------------
This module provides functionality for generating educational scripts from content analysis data.
It works with the MultimediaGenerationPipeline to create structured scripts for educational videos.
"""

import os
import json
import time
import logging
import requests
from typing import Dict, Any, List, Optional, Tuple, Union
from datetime import datetime

from content_analysis.AnalysisResult import AnalysisResult
from mistralModel import OpenRouterMistralClient, MistralSmallClient

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ScriptGenerator:
    """
    Generates educational scripts from content analysis data.
    
    This class takes content analysis data and transforms it into a structured script
    that can be used for educational video creation. It supports various customization
    options for tone, verbosity, and target audience.
    """
    
    def __init__(self, mistral_client: Optional[OpenRouterMistralClient] = None,
                 mistral_small_client: Optional[MistralSmallClient] = None):
        """
        Initialize the ScriptGenerator with the specified Mistral clients.
        
        Args:
            mistral_client: Optional Mistral client for text generation via OpenRouter
            mistral_small_client: Optional Mistral Small client for improved script generation
        """
        self.mistral_client = mistral_client
        self.mistral_small_client = mistral_small_client
        self.script_structure = {
            "introduction": "Introduction to the topic",
            "main_concepts": "Explanation of main concepts",
            "examples": "Illustrative examples",
            "practical_applications": "Real-world applications",
            "conclusion": "Summary and takeaways"
        }
        
        logger.info("Initialized ScriptGenerator with Mistral clients")
    
    def generate_script(self, analysis_result: Union[AnalysisResult, Dict[str, Any]], 
                      structure: Optional[Dict[str, Dict]] = None) -> Dict[str, Any]:
        """
        Generate an educational script from analysis results.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            structure: Optional custom script structure
            
        Returns:
            Dictionary containing the complete script
        """
        # Extract key elements from analysis result
        topic = self._extract_topic(analysis_result)
        subject = self._extract_subject(analysis_result)
        key_concepts = self._extract_key_concepts(analysis_result)
        
        # Use provided structure or create default
        if not structure:
            structure = self._create_default_structure(topic, subject, key_concepts)
        
        # Determine audience and tone
        audience = self._determine_audience(analysis_result)
        tone = self._determine_tone(analysis_result)
        
        # Initialize script output
        script = {
            "title": topic,
            "subject": subject,
            "audience": audience,
            "tone": tone,
            "generated_date": datetime.now().isoformat(),
            "sections": {}
        }
        
        # Check if we have a Mistral client
        if not self.mistral_client:
            # Generate simple placeholder content for each section
            for section_id, section_info in structure.items():
                script["sections"][section_id] = {
                    "title": section_info["title"],
                    "content": f"Content for {section_info['title']} section about {section_info['description']}."
                }
        else:
            # Use Mistral client to generate content for each section
            for section_id, section_info in structure.items():
                prompt = f"Write content for a {section_id} section of an educational script about {topic}. "
                prompt += f"This section should cover {section_info['description']}. "
                prompt += f"Use a {tone} tone appropriate for a {audience} audience."
                
                # Generate content with Mistral
                content = self.mistral_client.generate(prompt, max_tokens=400)
                
                # Add to script
                script["sections"][section_id] = {
                    "title": section_info["title"],
                    "content": content
                }
        
        return script
    
    def generate_script_with_mistral_small(self, analysis_result: AnalysisResult, 
                                         structure: Optional[Dict[str, Dict]] = None) -> Dict[str, Any]:
        """
        Generate an enhanced educational script using Mistral Small.
        
        This method uses the more advanced Mistral Small model for higher quality script generation,
        with specialized prompts for educational content creation.
        
        Args:
            analysis_result: Content analysis results object
            structure: Optional custom script structure
            
        Returns:
            Dictionary containing the complete script with sections
        """
        # Check if we have a Mistral Small client
        if not self.mistral_small_client:
            # Fall back to standard generation
            return self.generate_script(analysis_result, structure)
        
        # Extract key elements from analysis result
        topic = self._extract_topic(analysis_result)
        subject = self._extract_subject(analysis_result)
        key_concepts = self._extract_key_concepts(analysis_result)
        
        # Determine audience and tone
        audience = self._determine_audience(analysis_result)
        tone = self._determine_tone(analysis_result)
        
        # Initialize script output
        script = {
            "title": topic,
                "subject": subject,
            "audience": audience,
            "tone": tone,
            "generated_date": datetime.now().isoformat(),
            "sections": {}
        }
        
        # Option 1: Generate entire script at once
        if not structure:
            # Generate full script in one call
            full_script = self.mistral_small_client.generate_educational_script(
                topic=topic,
                key_concepts=key_concepts,
                audience=audience,
                tone=tone,
                max_length=2500
            )
            
            # Parse the generated script into sections
            sections = self._parse_generated_script(full_script)
            script["full_text"] = full_script
            script["sections"] = sections
            
            return script
        
        # Option 2: Generate section by section with custom structure
        # Generate introduction
        intro_content = self.mistral_small_client.generate_introduction(
            topic=topic,
            key_concepts=key_concepts,
            audience=audience,
            tone=tone
        )
        
        script["sections"]["introduction"] = {
            "title": "Introduction",
            "content": intro_content
        }
        
        # Generate body sections
        for section_id, section_info in structure.items():
            # Skip introduction and conclusion which are handled separately
            if section_id in ["introduction", "conclusion"]:
                continue
                
            section_content = self.mistral_small_client.generate_section_content(
                section_title=section_info["title"],
                description=section_info["description"],
                key_concepts=section_info.get("concepts", key_concepts),
                audience=audience,
                tone=tone,
                max_length=600
            )
            
            script["sections"][section_id] = {
                "title": section_info["title"],
                "content": section_content
            }
        
        # Generate conclusion
        conclusion_content = self.mistral_small_client.generate_conclusion(
            topic=topic,
            key_concepts=key_concepts,
            audience=audience,
            tone=tone
        )
        
        script["sections"]["conclusion"] = {
            "title": "Conclusion",
            "content": conclusion_content
        }
        
        return script
    
    def _extract_topic(self, analysis_result: Union[AnalysisResult, Dict[str, Any]]) -> str:
        """
        Extract the primary topic from analysis results.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            
        Returns:
            Topic string
        """
        # Handle dictionary input
        if isinstance(analysis_result, dict):
            # Try to get topic from metadata
            if 'metadata' in analysis_result and isinstance(analysis_result['metadata'], dict):
                if 'title' in analysis_result['metadata']:
                    return analysis_result['metadata']['title']
            
            # Try to get topic directly
            if 'topic' in analysis_result:
                return analysis_result['topic']
            
            # Fallback to concepts
            if 'concepts' in analysis_result and analysis_result['concepts']:
                if isinstance(analysis_result['concepts'], list):
                    if analysis_result['concepts'] and isinstance(analysis_result['concepts'][0], dict):
                        return analysis_result['concepts'][0].get('name', 'Educational Content')
                    return str(analysis_result['concepts'][0])
            
            return "Educational Content"
        
        # Handle AnalysisResult object
        if hasattr(analysis_result, 'metadata') and analysis_result.metadata:
            if 'title' in analysis_result.metadata:
                return analysis_result.metadata['title']
        
        if hasattr(analysis_result, 'key_concepts') and analysis_result.key_concepts:
            return analysis_result.key_concepts[0]
        
        return "Educational Content"
    
    def _extract_subject(self, analysis_result: Union[AnalysisResult, Dict[str, Any]]) -> str:
        """
        Extract the subject area from analysis results.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            
        Returns:
            Subject string
        """
        # Handle dictionary input
        if isinstance(analysis_result, dict):
            # Try to get from metadata
            if 'metadata' in analysis_result and isinstance(analysis_result['metadata'], dict):
                if 'domain' in analysis_result['metadata']:
                    return analysis_result['metadata']['domain']
            
            # Try to get domain directly
            if 'domain' in analysis_result:
                return analysis_result['domain']
            
            # Try domain_specific
            if 'domain_specific' in analysis_result:
                return analysis_result['domain_specific'].get('domain', 'general')
            
            return 'general'
        
        # Handle AnalysisResult object
        if hasattr(analysis_result, 'domain'):
            return analysis_result.domain
        
        return 'general'
    
    def _extract_key_concepts(self, analysis_result: Union[AnalysisResult, Dict[str, Any]]) -> List[str]:
        """
        Extract key concepts from analysis results.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            
        Returns:
            List of key concept strings
        """
        concepts = []
        
        # Handle dictionary input
        if isinstance(analysis_result, dict):
            # Add concepts from the concepts list
            if 'concepts' in analysis_result:
                if isinstance(analysis_result['concepts'], list):
                    for concept in analysis_result['concepts']:
                        if isinstance(concept, dict):
                            if 'name' in concept:
                                concepts.append(concept['name'])
                        else:
                            concepts.append(str(concept))
            
            # Add important entities if available
            if 'entities' in analysis_result:
                for entity in analysis_result['entities']:
                    if isinstance(entity, dict):
                        if entity.get('importance', 0) > 0.7 and entity.get('name'):
                            concepts.append(entity['name'])
            
            return list(set(concepts)) if concepts else ["Main Topic"]
        
        # Handle AnalysisResult object
        # Add explicit key concepts
        if hasattr(analysis_result, 'key_concepts') and analysis_result.key_concepts:
            concepts.extend(analysis_result.key_concepts)
        
        # Add important entities
        if hasattr(analysis_result, 'entities') and analysis_result.entities:
            for entity in analysis_result.entities:
                if entity.get('importance', 0) > 0.7 and entity.get('name'):
                    concepts.append(entity['name'])
        
        return list(set(concepts)) if concepts else ["Main Topic"]
    
    def _create_default_structure(self, topic: str, subject: str, key_concepts: List[str]) -> Dict[str, Dict]:
        """
        Create a default script structure.
        
        Args:
            topic: The main topic
            subject: The subject area
            key_concepts: List of key concepts
            
        Returns:
            Dictionary of script sections
        """
        structure = {}
        
        # Introduction section
        structure["introduction"] = {
            "title": "Introduction",
            "description": f"Introduction to {topic}",
            "concepts": key_concepts[:2] if len(key_concepts) > 2 else key_concepts
        }
        
        # Main concepts
        if len(key_concepts) > 0:
            for i, concept in enumerate(key_concepts[:3]):  # Limit to 3 main concepts
                section_id = f"concept_{i+1}"
                structure[section_id] = {
                    "title": concept,
                    "description": f"Explanation of {concept}",
                    "concepts": [concept]
                }
        
        # Examples section
        structure["examples"] = {
            "title": "Examples",
            "description": f"Examples relating to {topic}",
            "concepts": key_concepts
        }
        
        # Conclusion
        structure["conclusion"] = {
            "title": "Conclusion",
            "description": f"Summary and key takeaways about {topic}",
            "concepts": key_concepts
        }
        
        return structure
    
    def _determine_audience(self, analysis_result: Union[AnalysisResult, Dict[str, Any]]) -> str:
        """
        Determine the appropriate audience based on content complexity.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            
        Returns:
            Audience string (elementary, secondary, university, general)
        """
        # Handle dictionary input
        if isinstance(analysis_result, dict):
            # Try to get from metadata
            if 'metadata' in analysis_result and isinstance(analysis_result['metadata'], dict):
                if 'audience' in analysis_result['metadata']:
                    return analysis_result['metadata']['audience']
                if 'grade_level' in analysis_result['metadata']:
                    return analysis_result['metadata']['grade_level']
            
            # Try to get directly
            if 'audience' in analysis_result:
                return analysis_result['audience']
            
            return "general"
        
        # Handle AnalysisResult object
        if hasattr(analysis_result, 'metadata') and analysis_result.metadata:
            if 'audience' in analysis_result.metadata:
                return analysis_result.metadata['audience']
        
        return "general"
    
    def _determine_tone(self, analysis_result: Union[AnalysisResult, Dict[str, Any]]) -> str:
        """
        Determine the appropriate tone based on content and domain.
        
        Args:
            analysis_result: Content analysis results (either object or dictionary)
            
        Returns:
            Tone string (conversational, formal, neutral)
        """
        # Handle dictionary input
        if isinstance(analysis_result, dict):
            # Try to get from metadata
            if 'metadata' in analysis_result and isinstance(analysis_result['metadata'], dict):
                if 'tone' in analysis_result['metadata']:
                    return analysis_result['metadata']['tone']
            
            # Try to get directly
            if 'tone' in analysis_result:
                return analysis_result['tone']
            
            # Based on domain
            domain = None
            if 'metadata' in analysis_result and isinstance(analysis_result['metadata'], dict):
                domain = analysis_result['metadata'].get('domain')
            if not domain and 'domain' in analysis_result:
                domain = analysis_result['domain']
            
            if domain:
                if domain == "elementary_education":
                    return "conversational"
                elif domain in ["scientific", "academic", "medical"]:
                    return "formal"
            
            return "neutral"
        
        # Handle AnalysisResult object
        if hasattr(analysis_result, 'metadata') and analysis_result.metadata:
            if 'tone' in analysis_result.metadata:
                return analysis_result.metadata['tone']
        
        # Based on domain
        if hasattr(analysis_result, 'domain'):
            domain = analysis_result.domain
            if domain == "elementary_education":
                return "conversational"
            elif domain in ["scientific", "academic", "medical"]:
                return "formal"
        
        return "neutral"
    
    def _parse_generated_script(self, script_text: str) -> Dict[str, Dict[str, str]]:
        """
        Parse a full generated script into structured sections.
        
        Args:
            script_text: The full text of the generated script
            
        Returns:
            Dictionary of sections with title and content
        """
        sections = {}
        current_section = None
        current_content = []
        
        # Split the script by lines
        lines = script_text.split('\n')
        
        for line in lines:
            # Check if this line is a section header
            # Section headers are typically capitalized or have # or == markers
            if (line.strip().isupper() or 
                line.strip().startswith('#') or 
                line.strip().startswith('==') or
                (line.strip() and line.strip() == line.strip().title() and len(line.strip()) < 50)):
                
                # Save previous section if there was one
                if current_section:
                    sections[current_section.lower().replace(' ', '_')] = {
                        "title": current_section,
                        "content": '\n'.join(current_content)
                    }
                
                # Start new section
                current_section = line.strip().replace('#', '').replace('=', '').strip()
                current_content = []
            else:
                # Add line to current section content
                if current_section:
                    current_content.append(line)
        
        # Add the last section
        if current_section:
            sections[current_section.lower().replace(' ', '_')] = {
                "title": current_section,
                "content": '\n'.join(current_content)
            }
        
        # If no sections were found, create a single section
        if not sections:
            sections["main_content"] = {
                "title": "Main Content",
                "content": script_text
            }
        
        return sections
    
    def save_script(self, script: Dict[str, Any], output_dir: str, filename: Optional[str] = None) -> str:
        """
        Save the generated script to a file.
        
        Args:
            script: The script dictionary
            output_dir: Directory to save the script
            filename: Optional filename (default: based on title)
            
        Returns:
            Path to the saved script file
        """
        # Create directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate filename if not provided
        if not filename:
            # Create filename from title
            title_slug = script["title"].lower().replace(' ', '_')
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{title_slug}_{timestamp}.json"
        
        # Ensure filename has .json extension
        if not filename.endswith('.json'):
            filename += '.json'
        
        # Full path
        file_path = os.path.join(output_dir, filename)
        
        # Save script to file
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(script, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved script to {file_path}")
        return file_path 