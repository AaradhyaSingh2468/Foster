"""
Multimedia Generation Pipeline
----------------------------
Main pipeline for generating educational videos from structured content.
Integrates script generation, animation, text-to-speech, and video compilation.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional, Union
import time
import threading
import psutil
import uuid
from concurrent.futures import ThreadPoolExecutor
from enum import Enum
from queue import PriorityQueue
from datetime import datetime

from .ScriptGenerator import ScriptGenerator
from .AnimationGenerator import AnimationGenerator
from .TextToSpeech import TextToSpeechGenerator
from .VideoCompiler import VideoCompiler
from ..config.ComponentConfig import VideoQuality
from errors.WorkflowErrors import (
    MultimediaGenerationError, ScriptGenerationError, 
    AnimationError, AudioGenerationError, VideoRenderingError,
    ResourceLimitError, TimeoutError
)

try:
    # Import Mistral models using absolute import
    from pipeline.multimedia.mistralModel import OpenRouterMistralClient, MistralSmallClient
except ImportError:
    # Fallback to relative import if absolute fails
    from multimedia.mistralModel import OpenRouterMistralClient, MistralSmallClient

class RenderQuality(Enum):
    """Video rendering quality levels with resource requirements"""
    LOW = {
        "name": "low",
        "resolution": "720p",
        "fps": 24,
        "bitrate": "1M",
        "cpu_usage": 0.3,
        "memory_usage": 1024,  # MB
        "disk_usage": 50,  # MB per minute
        "rendering_factor": 0.5,  # Relative time factor
    }
    MEDIUM = {
        "name": "medium",
        "resolution": "1080p",
        "fps": 30,
        "bitrate": "3M",
        "cpu_usage": 0.5,
        "memory_usage": 2048,  # MB
        "disk_usage": 150,  # MB per minute
        "rendering_factor": 1.0,  # Relative time factor
    }
    HIGH = {
        "name": "high",
        "resolution": "1440p",
        "fps": 30,
        "bitrate": "8M",
        "cpu_usage": 0.7,
        "memory_usage": 4096,  # MB
        "disk_usage": 300,  # MB per minute
        "rendering_factor": 2.0,  # Relative time factor
    }
    ULTRA = {
        "name": "ultra",
        "resolution": "2160p",
        "fps": 60,
        "bitrate": "15M",
        "cpu_usage": 0.9,
        "memory_usage": 8192,  # MB
        "disk_usage": 600,  # MB per minute
        "rendering_factor": 4.0,  # Relative time factor
    }
    
    @classmethod
    def from_string(cls, quality_name: str) -> 'RenderQuality':
        """Get quality enum from string name"""
        for quality in cls:
            if quality.value["name"] == quality_name.lower():
                return quality
        return cls.MEDIUM  # Default

class RenderPriority:
    """Priority levels for rendering jobs"""
    LOW = 3
    NORMAL = 2
    HIGH = 1
    CRITICAL = 0

class RenderJob:
    """Represents a video rendering job in the queue"""
    def __init__(self, job_id: str, workflow_id: str, script_path: str, analysis_result: Dict[str, Any], output_path: str, quality: RenderQuality, priority: RenderPriority, submitted_time: float, parameters: Dict[str, Any]):
        self.job_id = job_id
        self.workflow_id = workflow_id
        self.script_path = script_path
        self.analysis_result = analysis_result
        self.output_path = output_path
        self.quality = quality
        self.priority = priority
        self.submitted_time = submitted_time
        self.parameters = parameters
        self.status = "queued"
        self.progress = 0.0
        self.result = None
        self.error = None

    def __lt__(self, other: 'RenderJob') -> bool:
        """Compare jobs for priority queue ordering"""
        # First compare by priority level
        if self.priority.value != other.priority.value:
            return self.priority.value < other.priority.value
        
        # Then by submission time (FIFO)
        return self.submitted_time < other.submitted_time

class ResourceMonitor:
    """Monitors system resources and adapts rendering settings"""
    
    def __init__(self, poll_interval: int = 5, 
                cpu_threshold: float = 0.8, 
                memory_threshold: float = 0.8):
        """
        Initialize resource monitor
        
        Args:
            poll_interval: Seconds between resource checks
            cpu_threshold: CPU usage threshold (0.0-1.0)
            memory_threshold: Memory usage threshold (0.0-1.0)
        """
        self.poll_interval = poll_interval
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Resource metrics
        self.metrics = {
            "cpu_usage": 0.0,
            "memory_usage": 0.0,
            "memory_available": 0,
            "disk_usage": 0.0,
            "disk_available": 0,
            "last_updated": 0
        }
        
        # Start monitoring thread
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
    
    def _monitor_loop(self) -> None:
        """Background thread that monitors system resources"""
        while self.running:
            try:
                # Update resource metrics
                self.metrics["cpu_usage"] = psutil.cpu_percent(interval=1) / 100.0
                
                memory = psutil.virtual_memory()
                self.metrics["memory_usage"] = memory.percent / 100.0
                self.metrics["memory_available"] = memory.available / (1024 * 1024)  # MB
                
                disk = psutil.disk_usage(os.path.abspath(os.sep))
                self.metrics["disk_usage"] = disk.percent / 100.0
                self.metrics["disk_available"] = disk.free / (1024 * 1024)  # MB
                
                self.metrics["last_updated"] = time.time()
                
                # Log if resources are constrained
                if self.metrics["cpu_usage"] > self.cpu_threshold:
                    self.logger.warning(f"CPU usage high: {self.metrics['cpu_usage']:.2f}")
                
                if self.metrics["memory_usage"] > self.memory_threshold:
                    self.logger.warning(f"Memory usage high: {self.metrics['memory_usage']:.2f}")
                
            except Exception as e:
                self.logger.error(f"Error monitoring resources: {str(e)}")
            
            time.sleep(self.poll_interval)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current resource metrics"""
        return self.metrics.copy()
    
    def can_handle_quality(self, quality: RenderQuality) -> bool:
        """
        Check if system can handle a specific render quality
        
        Args:
            quality: The desired render quality
            
        Returns:
            True if system has sufficient resources
        """
        # Check if metrics are recent
        if time.time() - self.metrics["last_updated"] > self.poll_interval * 2:
            # Force an update
            self._update_metrics()
        
        # Check CPU availability (consider current usage + required usage)
        if self.metrics["cpu_usage"] + quality.value["cpu_usage"] > 0.95:
            return False
        
        # Check memory availability
        if self.metrics["memory_available"] < quality.value["memory_usage"] * 1.2:
            return False
        
        # Check disk availability (ensure at least 10GB or 10x expected usage)
        min_disk_required = max(10 * 1024, quality.value["disk_usage"] * 10)
        if self.metrics["disk_available"] < min_disk_required:
            return False
        
        return True
    
    def recommend_quality(self, requested_quality: RenderQuality) -> RenderQuality:
        """
        Recommend a quality level based on available resources
        
        Args:
            requested_quality: The desired quality
            
        Returns:
            Recommended quality level
        """
        # If we can handle the requested quality, return it
        if self.can_handle_quality(requested_quality):
            return requested_quality
        
        # Otherwise, try to find a lower quality that will work
        qualities = list(RenderQuality)
        requested_index = qualities.index(requested_quality)
        
        for i in range(requested_index - 1, -1, -1):
            if self.can_handle_quality(qualities[i]):
                return qualities[i]
        
        # If even the lowest quality won't work, return it anyway
        # but log a warning
        self.logger.warning("System resources may be insufficient even for low quality rendering")
        return RenderQuality.LOW
    
    def _update_metrics(self) -> None:
        """Force an immediate update of resource metrics"""
        # Update CPU usage
        self.metrics["cpu_usage"] = psutil.cpu_percent(interval=0.5) / 100.0
        
        # Update memory usage
        memory = psutil.virtual_memory()
        self.metrics["memory_usage"] = memory.percent / 100.0
        self.metrics["memory_available"] = memory.available / (1024 * 1024)  # MB
        
        # Update disk usage
        disk = psutil.disk_usage(os.path.abspath(os.sep))
        self.metrics["disk_usage"] = disk.percent / 100.0
        self.metrics["disk_available"] = disk.free / (1024 * 1024)  # MB
        
        self.metrics["last_updated"] = time.time()
    
    def shutdown(self) -> None:
        """Stop the resource monitoring thread"""
        self.running = False
        if self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2)

class MultimediaGenerationPipeline:
    """
    Pipeline for generating multimedia content from analysis results
    with resource-aware rendering and job prioritization
    """
    
    def __init__(self, huggingface_api_key: Optional[str] = None, 
                mistral_api_key: Optional[str] = None,
                output_dir: str = "output",
                video_format: str = "mp4", 
                video_quality: Union[str, VideoQuality] = "high",
                max_concurrent_renders: int = 2, 
                scheduler_type: str = "ddim"):
        """
        Initialize the multimedia generation pipeline
        
        Args:
            huggingface_api_key: Hugging Face API key for image generation
            mistral_api_key: Mistral API key for script generation
            output_dir: Output directory for generated content
            video_format: Output video format
            video_quality: Default video quality
            max_concurrent_renders: Maximum concurrent rendering jobs
            scheduler_type: Diffusion scheduler type
        """
        self.huggingface_api_key = huggingface_api_key
        self.mistral_api_key = mistral_api_key
        self.output_dir = output_dir
        self.video_format = video_format
        # Convert string or VideoQuality enum to RenderQuality
        if isinstance(video_quality, VideoQuality):
            video_quality = video_quality.value
        self.default_quality = RenderQuality.from_string(video_quality)
        self.max_concurrent_renders = max_concurrent_renders
        self.scheduler_type = scheduler_type
        
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize resource monitor
        self.resource_monitor = ResourceMonitor()
        
        # Job queue and tracking
        self.job_queue = PriorityQueue()
        self.active_jobs: Dict[str, RenderJob] = {}
        self.completed_jobs: Dict[str, RenderJob] = {}
        self.job_lock = threading.RLock()
        
        # Start worker thread pool
        self.workers = ThreadPoolExecutor(max_workers=max_concurrent_renders)
        
        # Start scheduler thread
        self.running = True
        self.scheduler_thread = threading.Thread(target=self._scheduler_loop, daemon=True)
        self.scheduler_thread.start()
        
        self.logger.info(f"Multimedia pipeline initialized with {max_concurrent_renders} "
                      f"render workers and {video_quality} default quality")
    
    def generate_video(self, analysis_result: Dict[str, Any], extracted_content: Dict[str, Any],
                     output_dir: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        """
        Generate a video from analysis results
        
        Args:
            analysis_result: Content analysis result
            extracted_content: Extracted PDF content
            output_dir: Output directory (overrides default)
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with video generation results
            
        Raises:
            MultimediaGenerationError: If video generation fails
        """
        # Validate inputs
        if not analysis_result or not isinstance(analysis_result, dict):
            raise MultimediaGenerationError("Invalid analysis result")
        
        if not extracted_content or not isinstance(extracted_content, dict):
            raise MultimediaGenerationError("Invalid extracted content")
        
        try:
            # Get parameters from kwargs
            parameters = kwargs.get('parameters', {})
            
            # Generate script
            script_result = self._generate_script(analysis_result, extracted_content, **parameters)
            
            # Get target directory
            target_dir = output_dir or self.output_dir
            os.makedirs(target_dir, exist_ok=True)
        
            # Determine quality based on resource availability
            requested_quality = parameters.get("video_quality", self.default_quality)
            # Handle different quality input types
            if isinstance(requested_quality, str):
                requested_quality = RenderQuality.from_string(requested_quality)
            elif isinstance(requested_quality, VideoQuality):
                requested_quality = RenderQuality.from_string(requested_quality.value)
            elif not isinstance(requested_quality, RenderQuality):
                requested_quality = self.default_quality
            
            recommended_quality = self.resource_monitor.recommend_quality(requested_quality)
            
            if recommended_quality != requested_quality:
                self.logger.warning(f"Adjusted render quality from {requested_quality.value['name']} "
                                 f"to {recommended_quality.value['name']} due to resource constraints")
        
            # Check if we need to render synchronously or asynchronously
            if parameters.get("async_render", False):
                # Submit as job and return job ID
                job_id = self._submit_render_job(
                    workflow_id=parameters.get("workflow_id", "unknown"),
                    script_path=script_result["script_file"],
                    analysis_result=analysis_result,
                    output_path=target_dir,
                    quality=recommended_quality,
                    priority=RenderPriority.NORMAL,
                    parameters=parameters
                )
                
                return {
                    "job_id": job_id,
                    "script_file": script_result["script_file"],
                    "status": "rendering_queued",
                    "estimated_completion": self._estimate_completion_time(job_id),
                    "quality": recommended_quality.value["name"]
                }
            else:
                # Render synchronously
                render_result = self._render_video(
                    script_result["script_file"],
                    analysis_result,
                    target_dir,
                    recommended_quality,
                    parameters
                )
                
                # Combine script and render results
                result = {
                    **script_result,
                    **render_result,
                    "quality": recommended_quality.value["name"]
                }
                
                return result

        except Exception as e:
            error_msg = f"Video generation failed: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            
            if isinstance(e, MultimediaGenerationError):
                raise
            else:
                raise MultimediaGenerationError(error_msg)
    
    def _generate_script(self, analysis_result: Dict[str, Any], 
                       extracted_content: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Generate a video script from analysis results
        
        Args:
            analysis_result: Content analysis result
            extracted_content: Extracted PDF content
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with script generation results
            
        Raises:
            ScriptGenerationError: If script generation fails
        """
        try:
            # Create script generator instance with Mistral clients
            script_generator = ScriptGenerator(
                mistral_client=OpenRouterMistralClient(api_key=self.mistral_api_key) if self.mistral_api_key else None,
                mistral_small_client=MistralSmallClient(api_key=self.mistral_api_key) if self.mistral_api_key else None
            )
            
            # Generate the script using Mistral Small if available
            if script_generator.mistral_small_client:
                script_result = script_generator.generate_script_with_mistral_small(analysis_result)
            else:
                script_result = script_generator.generate_script(analysis_result)
            
            # Get target directory
            target_dir = kwargs.get("output_dir", self.output_dir)
            os.makedirs(target_dir, exist_ok=True)
            
            # Save the script to a file
            script_file = script_generator.save_script(script_result, target_dir)
            
            # Return the results
            return {
                "script_file": script_file,
                "scenes": len(script_result["sections"]),
                "duration_estimate": len(script_result["sections"]) * 40,  # Rough estimate of 40 seconds per section
                "tone": script_result["tone"]
            }
            
        except Exception as e:
            error_msg = f"Script generation failed: {str(e)}"
            self.logger.error(error_msg)
            raise ScriptGenerationError(error_msg)
    
    def _transform_sections_to_scenes(self, script_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform script sections into scenes for animation and TTS generation.
        
        Args:
            script_data: Script data with sections
            
        Returns:
            Script data with sections transformed into scenes
        """
        scenes = []
        transition_duration = 1.5  # seconds for transitions
        
        # Helper function to estimate narration duration
        def estimate_narration_duration(text: str) -> float:
            # Average speaking rate is ~150 words per minute
            words = len(text.split())
            return (words / 150) * 60  # duration in seconds

        # Helper function to extract key points
        def extract_key_points(content: str) -> List[str]:
            # Split by common bullet point markers and newlines
            points = []
            for line in content.split('\n'):
                line = line.strip()
                # Remove common bullet point markers
                line = line.lstrip('•-*').strip()
                if line and len(line) > 10:  # Minimum length for a key point
                    points.append(line)
            return points

        # Process each section
        for section_idx, (section_id, section) in enumerate(script_data.get("sections", {}).items()):
            title = section["title"]
            content = section["content"]
            
            # Extract media elements if present
            images = section.get("images", [])
            equations = section.get("equations", [])
            diagrams = section.get("diagrams", [])
            tables = section.get("tables", [])
            
            # Calculate base duration from narration
            narration_duration = estimate_narration_duration(content)
            
            # Extract key points for visual emphasis
            key_points = extract_key_points(content)
            
            # Create scenes for this section
            section_scenes = []
            
            # 1. Title introduction scene
            title_scene = {
                "scene_id": f"scene_{len(scenes) + 1}",
                "type": "title",
                "title": title,
                "narration": f"Let's explore {title}.",
                "duration": 3.0,
                "transition": {
                    "type": "fade",
                    "duration": transition_duration
                },
                "visual_elements": [
                    {
                        "type": "animated_title",
                        "content": title,
                        "style": "dynamic",
                        "animation": "fade_and_scale"
                    }
                ]
            }
            section_scenes.append(title_scene)
            
            # 2. Main content scene
            main_scene = {
                "scene_id": f"scene_{len(scenes) + 2}",
                "type": "content",
                "title": title,
                "narration": content,
                "duration": narration_duration,
                "transition": {
                    "type": "slide",
                    "duration": transition_duration
                },
                "visual_elements": [
                    {
                        "type": "dynamic_text",
                        "content": content,
                        "style": "clean",
                        "animation": "typewriter"
                    }
                ]
            }
            
            # Add media elements if present
            if images:
                main_scene["visual_elements"].extend([
                    {
                        "type": "image",
                        "source": img["path"],
                        "caption": img.get("caption", ""),
                        "animation": "fade_in",
                        "timing": f"{idx * 5}s"  # Stagger image appearances
                    } for idx, img in enumerate(images)
                ])
            
            if equations:
                main_scene["visual_elements"].extend([
                    {
                        "type": "equation",
                        "content": eq["latex"],
                        "animation": "write",
                        "timing": f"{idx * 3}s"
                    } for idx, eq in enumerate(equations)
                ])
            
            if diagrams:
                main_scene["visual_elements"].extend([
                    {
                        "type": "diagram",
                        "source": diag["path"],
                        "animation": "draw",
                        "timing": f"{idx * 4}s"
                    } for idx, diag in enumerate(diagrams)
                ])
            
            if tables:
                main_scene["visual_elements"].extend([
                    {
                        "type": "table",
                        "data": table["data"],
                        "animation": "cell_by_cell",
                        "timing": f"{idx * 4}s"
                    } for idx, table in enumerate(tables)
                ])
            
            section_scenes.append(main_scene)
            
            # 3. Key points scene (if there are key points)
            if key_points:
                points_scene = {
                    "scene_id": f"scene_{len(scenes) + 3}",
                    "type": "summary",
                    "title": "Key Points",
                    "narration": "Let's summarize the key points.",
                    "duration": len(key_points) * 3.0,  # 3 seconds per point
                    "transition": {
                        "type": "slide",
                        "duration": transition_duration
                    },
                    "visual_elements": [
                        {
                            "type": "bullet_points",
                            "points": key_points,
                            "animation": "cascade",
                            "timing": "sequential"
                        }
                    ]
                }
                section_scenes.append(points_scene)
            
            # Add section scenes to main scenes list
            scenes.extend(section_scenes)
            
            # Add section transition if not the last section
            if section_idx < len(script_data["sections"]) - 1:
                transition_scene = {
                    "scene_id": f"scene_{len(scenes) + 1}",
                    "type": "transition",
                    "title": "Transition",
                    "narration": "",  # Empty string instead of missing field
                    "duration": transition_duration,
                    "transition": {
                        "type": "fade",
                        "duration": transition_duration
                    },
                    "visual_elements": [
                        {
                            "type": "transition_effect",
                            "style": "modern",
                            "animation": "geometric"
                        }
                    ]
                }
                scenes.append(transition_scene)
        
        # Create transformed script with metadata
        transformed_script = {
            "title": script_data.get("title", "Educational Video"),
            "subject": script_data.get("subject", "general"),
            "audience": script_data.get("audience", "general"),
            "tone": script_data.get("tone", "neutral"),
            "language": script_data.get("language", "en-US"),
            "generated_date": script_data.get("generated_date", datetime.now().isoformat()),
            "metadata": {
                "total_scenes": len(scenes),
                "estimated_duration": sum(scene.get("duration", 0) for scene in scenes),
                "has_media": bool(any(section.get("images") or section.get("equations") or 
                                   section.get("diagrams") or section.get("tables") 
                                   for section in script_data.get("sections", {}).values())),
                "complexity_level": script_data.get("complexity_level", "medium")
            },
            "scenes": scenes,
            "style_guide": {
                "color_scheme": script_data.get("color_scheme", "educational"),
                "font_family": script_data.get("font_family", "modern"),
                "animation_style": script_data.get("animation_style", "smooth"),
                "transition_style": "modern"
            }
        }
        
        return transformed_script

    def _render_video(self, script_path: str, analysis_result: Dict[str, Any],
                    output_path: str, quality: RenderQuality, 
                    parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Render a video from a script
        
        Args:
            script_path: Path to script file
            analysis_result: Content analysis result
            output_path: Output directory
            quality: Render quality
            parameters: Additional parameters
            
        Returns:
            Dictionary with render results
            
        Raises:
            VideoRenderingError: If rendering fails
        """
        try:
            # Load script data
            with open(script_path, 'r') as f:
                script_data = json.load(f)
            
            # Transform sections into scenes
            script_data = self._transform_sections_to_scenes(script_data)
            
            # Initialize components with quality-appropriate settings
            animation_generator = AnimationGenerator(
                style=parameters.get("animation_style", "modern"),
                color_scheme=parameters.get("color_scheme", "educational"),
                animation_level=quality.value["name"],
                output_dir=os.path.join(output_path, "animations")
            )
            
            tts_generator = TextToSpeechGenerator(
                voice_id=parameters.get("voice_id", "professional"),
                language_code=parameters.get("language_code", "en-US"),
                voice_speed=parameters.get("voice_speed", 1.0),
                pitch=parameters.get("pitch", 0)
            )
            
            video_compiler = VideoCompiler(
                output_format=self.video_format,
                resolution=quality.value["resolution"],
                fps=quality.value["fps"],
                quality=quality.value["name"],
                add_subtitles=parameters.get("add_subtitles", True)
            )
            
            # Generate animations
            self.logger.info("Generating animations...")
            animation_data = animation_generator.generate_animations(script_data)
            
            # Generate speech audio
            self.logger.info("Generating speech audio...")
            audio_data = tts_generator.generate_speech(script_data)
            
            # Compile final video
            self.logger.info("Compiling final video...")
            video_file = os.path.join(output_path, f"educational_video.{self.video_format}")
            video_result = video_compiler.compile_video(
                animation_data=animation_data,
                audio_data=audio_data,
                output_path=video_file
            )
            
            # Return combined results
            return {
                "video_file": video_file,
                "video_length": video_result.get("duration", 0),
                "resolution": quality.value["resolution"],
                "fps": quality.value["fps"],
                "format": self.video_format,
                "render_time": time.time() - video_result.get("start_time", time.time()),
                "subtitle_file": video_result.get("subtitle_file"),
                "animation_data": animation_data.get("metadata"),
                "audio_data": audio_data.get("metadata")
            }
            
        except Exception as e:
            error_msg = f"Video rendering failed: {str(e)}"
            self.logger.error(error_msg)
            raise VideoRenderingError(error_msg)
    
    def _submit_render_job(self, workflow_id: str, script_path: str, 
                         analysis_result: Dict[str, Any], output_path: str,
                         quality: RenderQuality, priority: RenderPriority,
                         parameters: Dict[str, Any]) -> str:
        """
        Submit a rendering job to the queue
        
        Args:
            workflow_id: ID of the associated workflow
            script_path: Path to script file
            analysis_result: Content analysis result
            output_path: Output directory
            quality: Render quality
            priority: Job priority
            parameters: Additional parameters
            
        Returns:
            Job ID
        """
        job_id = str(uuid.uuid4())
        
        job = RenderJob(
            job_id=job_id,
            workflow_id=workflow_id,
            script_path=script_path,
            analysis_result=analysis_result,
            output_path=output_path,
            quality=quality,
            priority=priority,
            submitted_time=time.time(),
            parameters=parameters
        )
        
        with self.job_lock:
            # Add to queue
            self.job_queue.put(job)
            
            # Store in active jobs
            self.active_jobs[job_id] = job
        
        self.logger.info(f"Submitted render job {job_id} with {priority.name} priority "
                      f"and {quality.value['name']} quality")
        
        return job_id
    
    def _scheduler_loop(self) -> None:
        """Background thread that schedules render jobs"""
        while self.running:
            try:
                # Check how many active renders we have
                active_renders = sum(1 for job in self.active_jobs.values() 
                                  if job.status == "rendering")
                
                # Process jobs if we have capacity
                if active_renders < self.max_concurrent_renders and not self.job_queue.empty():
                    # Get next job
                    job = self.job_queue.get(block=False)
                    
                    # Update job status
                    with self.job_lock:
                        job.status = "rendering"
                        self.active_jobs[job.job_id] = job
                    
                    # Submit to worker pool
                    self.workers.submit(self._process_render_job, job)
                    
                    self.logger.info(f"Started rendering job {job.job_id} with "
                                  f"{job.quality.value['name']} quality")
            
            except Exception as e:
                if not isinstance(e, queue.Empty):
                    self.logger.error(f"Error in scheduler loop: {str(e)}")
            
            # Sleep briefly
            time.sleep(0.5)
    
    def _process_render_job(self, job: RenderJob) -> None:
        """
        Process a render job
        
        Args:
            job: Render job to process
        """
        try:
            # Render the video
            render_result = self._render_video(
                job.script_path,
                job.analysis_result,
                job.output_path,
                job.quality,
                job.parameters
            )
            
            # Update job with result
            with self.job_lock:
                job.status = "completed"
                job.progress = 1.0
                job.result = render_result
                
                # Move from active to completed
                if job.job_id in self.active_jobs:
                    del self.active_jobs[job.job_id]
                self.completed_jobs[job.job_id] = job
            
            self.logger.info(f"Completed render job {job.job_id}")
            
        except Exception as e:
            # Update job with error
            with self.job_lock:
                job.status = "failed"
                job.error = str(e)
                
                # Move from active to completed
                if job.job_id in self.active_jobs:
                    del self.active_jobs[job.job_id]
                self.completed_jobs[job.job_id] = job
            
            self.logger.error(f"Render job {job.job_id} failed: {str(e)}")
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get the status of a render job
        
        Args:
            job_id: Job ID
            
        Returns:
            Job status dictionary
            
        Raises:
            KeyError: If job not found
        """
        with self.job_lock:
            if job_id in self.active_jobs:
                job = self.active_jobs[job_id]
            elif job_id in self.completed_jobs:
                job = self.completed_jobs[job_id]
            else:
                raise KeyError(f"Job {job_id} not found")
            
            status = {
                "job_id": job.job_id,
                "status": job.status,
                "progress": job.progress,
                "quality": job.quality.value["name"],
                "submitted_time": job.submitted_time,
                "elapsed_time": time.time() - job.submitted_time
            }
            
            if job.status == "completed" and job.result:
                status["result"] = job.result
            elif job.status == "failed" and job.error:
                status["error"] = job.error
            elif job.status == "queued" or job.status == "rendering":
                status["estimated_completion"] = self._estimate_completion_time(job_id)
        
            return status
    
    def cancel_job(self, job_id: str) -> bool:
        """
        Cancel a render job
        
        Args:
            job_id: Job ID
            
        Returns:
            True if job was cancelled, False otherwise
        """
        with self.job_lock:
            if job_id in self.active_jobs:
                job = self.active_jobs[job_id]
                
                # Can only cancel queued jobs
                if job.status == "queued":
                    # Mark as cancelled
                    job.status = "cancelled"
                    
                    # Move from active to completed
                    del self.active_jobs[job_id]
                    self.completed_jobs[job_id] = job
                    
                    self.logger.info(f"Cancelled render job {job_id}")
                    return True
            
            return False
    
    def _estimate_completion_time(self, job_id: str) -> float:
        """
        Estimate when a job will complete
        
        Args:
            job_id: Job ID
            
        Returns:
            Estimated completion time timestamp
        """
        with self.job_lock:
            if job_id not in self.active_jobs:
                return 0
            
            job = self.active_jobs[job_id]
            
            # If job is rendering, estimate based on progress
            if job.status == "rendering":
                if job.progress > 0:
                    # Estimate from current progress
                    elapsed = time.time() - job.submitted_time
                    total_estimated = elapsed / job.progress
                    remaining = total_estimated - elapsed
                    return time.time() + remaining
                else:
                    # Fall back to quality-based estimate
                    return time.time() + (120 * job.quality.value["rendering_factor"])
            
            # If job is queued, estimate based on queue position and active jobs
            elif job.status == "queued":
                # Count jobs ahead in queue
                queue_position = 0
                for q_job in list(self.active_jobs.values()):
                    if q_job.status == "queued" and q_job.priority.value <= job.priority.value:
                        if q_job.submitted_time < job.submitted_time:
                            queue_position += 1
                
                # Estimate wait time based on queue position and active jobs
                wait_time = queue_position * (120 * job.quality.value["rendering_factor"])
                return time.time() + wait_time
            
            return 0
    
    def shutdown(self) -> None:
        """Shutdown the pipeline and release resources"""
        self.logger.info("Shutting down multimedia pipeline")
        
        # Stop scheduler
        self.running = False
        if self.scheduler_thread.is_alive():
            self.scheduler_thread.join(timeout=2)
        
        # Shutdown workers
        self.workers.shutdown(wait=True)
        
        # Shutdown resource monitor
        self.resource_monitor.shutdown()
        
        self.logger.info("Multimedia pipeline shutdown complete") 