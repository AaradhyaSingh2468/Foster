"""
Educational Content Workflow Coordinator
---------------------------------------
Orchestrates the end-to-end workflow from PDF upload to video delivery and adaptive learning.
Connects all system components in a seamless pipeline.
"""

# Standard library imports
import os
import time
import logging
import json
import multiprocessing
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from typing import Dict, List, Any, Optional, Union, Tuple

# Third-party imports
import psutil

# Pipeline imports
from .config.ComponentConfig import WorkflowConfig
from .di.DependencyContainer import DependencyContainer
from .events.EventSystem import get_event_bus, EventType, EventMonitor
from .errors.WorkflowErrors import (
    WorkflowError, PDFExtractionError, ContentAnalysisError, 
    MultimediaGenerationError, AdaptiveLearningError,
    ResourceLimitError, TimeoutError
)
from .pdf_extraction.PDFContentExtractor import PDFContentExtractor
from .content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
from .multimedia.MultimediaPipeline import MultimediaGenerationPipeline
from .adaptive_learning.AdaptiveLearningManager import AdaptiveLearningManager
from .adaptive_learning.StudentProfileManager import StudentProfileManager

# Optional distributed processing imports
try:
    import ray
    RAY_AVAILABLE = True
except ImportError:
    RAY_AVAILABLE = False

class WorkflowCoordinator:
    """
    Coordinates the complete educational content workflow.
    Manages the process from PDF upload through content extraction, analysis, 
    video generation, to adaptive learning feedback.
    """
    
    def __init__(self, config_dict: Optional[Dict[str, Any]] = None, output_dir: str = "output"):
        """
        Initialize the workflow coordinator
        
        Args:
            config_dict: Dictionary of configuration options (will be converted to typed config)
            output_dir: Base directory for all output
        """
        # Create typed configuration from dictionary
        self.config = WorkflowConfig.from_dict(config_dict or {})
        
        # Override output directory if specified
        if output_dir:
            self.config.output_dir = output_dir
        
        # Ensure output directories exist
        self.extracted_dir = os.path.join(self.config.output_dir, "extracted")
        self.analysis_dir = os.path.join(self.config.output_dir, "analysis")
        self.multimedia_dir = os.path.join(self.config.output_dir, "multimedia")
        self.feedback_dir = os.path.join(self.config.output_dir, "feedback")
        self.metrics_dir = os.path.join(self.config.output_dir, "metrics")
        
        for directory in [self.extracted_dir, self.analysis_dir, self.multimedia_dir, 
                          self.feedback_dir, self.metrics_dir]:
            os.makedirs(directory, exist_ok=True)
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger("WorkflowCoordinator")
        
        # Create dependency container with typed configuration
        self.container = DependencyContainer(self.config)
        
        # Initialize event monitoring
        self.event_monitor = EventMonitor()
        
        # Configure thread/process pools for parallel processing
        self._configure_parallel_processing()
        
        # Workflow state (thread-safe for concurrent operations)
        self.workflow_states = {}
        self.workflow_lock = threading.RLock()
        
        self.logger.info("WorkflowCoordinator initialized successfully")
    
    def _configure_parallel_processing(self):
        """Configure parallel processing capabilities based on system resources"""
        # Determine available resources
        cpu_count = multiprocessing.cpu_count()
        
        # Set thread and process pool sizes based on available CPUs
        # Use fewer processes for heavier tasks to avoid resource contention
        self.analysis_pool_size = max(1, min(cpu_count - 1, 4))
        self.extraction_pool_size = max(1, min(cpu_count - 1, 4))
        self.video_pool_size = max(1, min(cpu_count // 2, 2))
        
        # Create thread pool for lightweight tasks
        self.thread_pool = ThreadPoolExecutor(max_workers=cpu_count * 2)
        
        # Create process pools for CPU-intensive tasks
        self.extraction_pool = ProcessPoolExecutor(max_workers=self.extraction_pool_size)
        self.analysis_pool = ProcessPoolExecutor(max_workers=self.analysis_pool_size)
        self.video_pool = ProcessPoolExecutor(max_workers=self.video_pool_size)
        
        self.logger.info(f"Configured parallel processing: {cpu_count} CPUs, " +
                       f"{self.extraction_pool_size} extraction workers, " +
                       f"{self.analysis_pool_size} analysis workers, " +
                       f"{self.video_pool_size} video workers")
        
        # Determine if we should use distributed processing
        self.use_distributed = self.config.use_distributed
        if self.use_distributed:
            self._configure_distributed_processing()
    
    def _configure_distributed_processing(self):
        """Configure distributed processing if enabled"""
        if not RAY_AVAILABLE:
            self.logger.warning("Ray is not available. Distributed processing will be disabled.")
            self.use_distributed = False
            return

        try:
            # Initialize Ray with system resources
            if not ray.is_initialized():
                # Get system resources
                cpu_count = multiprocessing.cpu_count()
                memory_gb = psutil.virtual_memory().total / (1024 * 1024 * 1024)
                
                # Configure Ray with available resources
                ray.init(
                    num_cpus=max(1, cpu_count - 1),  # Leave one CPU for system
                    memory=memory_gb * 0.8,  # Use 80% of available memory
                    ignore_reinit_error=True,
                    logging_level=logging.INFO
                )
                
                self.logger.info(f"Ray initialized with {cpu_count-1} CPUs and {memory_gb*0.8:.1f}GB memory")
            
            # Configure distributed processing settings
            self.distributed_config = {
                "num_workers": max(1, multiprocessing.cpu_count() - 1),
                "memory_limit": psutil.virtual_memory().total * 0.8,  # 80% of system memory
                "object_store_memory": psutil.virtual_memory().total * 0.4,  # 40% for object store
                "redis_max_memory": psutil.virtual_memory().total * 0.1,  # 10% for Redis
                "temp_dir": os.path.join(self.config.output_dir, "ray_temp")
            }
            
            # Create temp directory for Ray
            os.makedirs(self.distributed_config["temp_dir"], exist_ok=True)
            
            # Configure Ray runtime environment
            ray.runtime_env.working_dir = os.getcwd()
            ray.runtime_env.pip = ["psutil", "numpy", "pandas"]  # Add required packages
            
            self.logger.info("Distributed processing configured successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to configure distributed processing: {str(e)}")
            self.use_distributed = False
            raise WorkflowError(
                "Failed to configure distributed processing",
                details={"error": str(e)}
            )
    
    def process_pdf(self, pdf_path: str, student_id: Optional[str] = None, 
                   custom_options: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Process a PDF through the complete workflow
        
        Args:
            pdf_path: Path to the uploaded PDF file
            student_id: Identifier for the student (for adaptive learning)
            custom_options: Custom processing options
            
        Returns:
            Dictionary with results from the complete workflow
        """
        # Generate workflow ID
        workflow_id = f"wf_{int(time.time())}"
        
        # Merge custom options with config
        if custom_options:
            # Create a copy of the configuration to avoid modifying the original
            workflow_config = self._merge_custom_options(custom_options)
        else:
            workflow_config = self.config
        
        # Initialize workflow state with thread safety
        with self.workflow_lock:
            self.workflow_states[workflow_id] = {
                "id": workflow_id,
                "pdf_path": pdf_path,
                "student_id": student_id,
                "status": "initializing",
                "start_time": time.time(),
                "extracted_content": None,
                "content_analysis": None,
                "video_results": None,
                "adaptive_result": None,
                "steps_completed": [],
                "error": None
            }
        
        # Publish workflow started event
        get_event_bus().publish_for_workflow(
            workflow_id, 
            EventType.WORKFLOW_STARTED,
            {
                "pdf_path": pdf_path, 
                "student_id": student_id,
                "config": {k: v for k, v in workflow_config.__dict__.items() 
                          if not k.startswith("_")}
            }
        )
        
        self.logger.info(f"Starting workflow {workflow_id} for PDF: {pdf_path}")
        
        # Check whether to process synchronously or asynchronously
        if self.config.async_processing:
            # Submit for asynchronous processing
            self.thread_pool.submit(self._run_workflow, workflow_id, pdf_path, 
                                   student_id, custom_options)
            
            # Return immediately with workflow ID
            return {
                "workflow_id": workflow_id,
                "status": "submitted",
                "message": "Workflow submitted for processing"
            }
        else:
            # Run synchronously and return complete results
            try:
                return self._run_workflow(workflow_id, pdf_path, student_id, custom_options)
            except Exception as e:
                self.logger.error(f"Workflow error: {e}")
                
                # Publish workflow failed event
                get_event_bus().publish_for_workflow(
                    workflow_id, 
                    EventType.WORKFLOW_FAILED,
                    {"error": str(e)}
                )
                
                # Update workflow state with error
                with self.workflow_lock:
                    self.workflow_states[workflow_id]["status"] = "error"
                    self.workflow_states[workflow_id]["error"] = str(e)
                
                return {
                    "workflow_id": workflow_id,
                    "pdf_path": pdf_path,
                    "status": "error",
                    "error_message": str(e)
                }
    
    def _merge_custom_options(self, custom_options: Dict[str, Any]) -> WorkflowConfig:
        """
        Merge custom options with the default configuration
        
        Args:
            custom_options: Custom options for this workflow
            
        Returns:
            Updated configuration with custom options
        """
        # Create a new config based on the current one
        config_dict = {
            "extraction_options": vars(self.config.extraction_options),
            "analysis_options": vars(self.config.analysis_options),
            "multimedia_options": {
                "script_style": vars(self.config.multimedia_options.script_style),
                "animation_style": vars(self.config.multimedia_options.animation_style),
                "voice_options": vars(self.config.multimedia_options.voice_options),
                "video_format": self.config.multimedia_options.video_format,
                "video_quality": self.config.multimedia_options.video_quality.value,
                "huggingface_api_key": self.config.multimedia_options.huggingface_api_key,
                "mistral_api_key": self.config.multimedia_options.mistral_api_key
            },
            "adaptive_options": vars(self.config.adaptive_options),
            "output_dir": self.config.output_dir,
            "async_processing": self.config.async_processing,
            "use_distributed": self.config.use_distributed,
            "auto_scaling": self.config.auto_scaling,
            "components": {
                "pdf_extractor": {
                    "type": "PDFContentExtractor",
                    "config": {
                        "tesseract_path": None,
                        "math_recognition": True,
                        "chem_recognition": True
                    }
                },
                "content_analyzer": {
                    "type": "ContentAnalysisPipeline"
                },
                "multimedia_generator": {
                    "type": "MultimediaGenerationPipeline"
                },
                "adaptive_manager": {
                    "type": "AdaptiveLearningManager"
                },
                "student_profile_manager": {
                    "type": "StudentProfileManager"
                }
            }
        }
        
        # Update with custom options
        self._deep_update(config_dict, custom_options)
        
        # Create a new typed configuration
        return WorkflowConfig.from_dict(config_dict)
    
    def _deep_update(self, base_dict: Dict[str, Any], update_dict: Dict[str, Any]) -> None:
        """
        Recursively update a dictionary with another dictionary
        
        Args:
            base_dict: The base dictionary to update
            update_dict: Dictionary with updates to apply
        """
        for key, value in update_dict.items():
            if key in base_dict and isinstance(base_dict[key], dict) and isinstance(value, dict):
                self._deep_update(base_dict[key], value)
            else:
                base_dict[key] = value

    def _run_workflow(self, workflow_id: str, pdf_path: str, student_id: Optional[str] = None, 
                     custom_options: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Execute the full workflow process
        
        Args:
            workflow_id: Unique identifier for this workflow
            pdf_path: Path to the uploaded PDF file
            student_id: Identifier for the student (for adaptive learning)
            custom_options: Custom processing options
            
        Returns:
            Dictionary with results from the complete workflow
            
        Raises:
            Various WorkflowError subclasses for specific failure scenarios
        """
        # Get workflow configuration (with custom options if provided)
        workflow_config = self._merge_custom_options(custom_options) if custom_options else self.config
        
        # Initialize timing metrics
        step_timing = {}
        start_time = time.time()
        extraction_result = None
        analysis_result = None
        video_result = None
        adaptive_result = None
        
        try:
            # Update workflow state
            self._update_workflow_status(workflow_id, "pdf_extraction")
            
            # Log and publish event
            self.logger.info(f"Workflow {workflow_id}: Starting PDF extraction for {pdf_path}")
            get_event_bus().publish_for_workflow(
                workflow_id,
                EventType.EXTRACTION_STARTED,
                {"pdf_path": pdf_path}
            )
            
            # Get PDF extractor from container
            pdf_extractor = self.container.get_component_typed("pdf_extractor", PDFContentExtractor)
            
            # Create output directory for extraction
            workflow_extracted_dir = os.path.join(self.extracted_dir, workflow_id)
            os.makedirs(workflow_extracted_dir, exist_ok=True)
            
            # Extract PDF content with error handling
            extraction_start = time.time()
            try:
                # Check if it's a scanned document
                is_scanned = pdf_extractor.is_scanned_document(pdf_path)
                
                # Extract content with appropriate options
                extraction_result = pdf_extractor.extract_content(
                    pdf_path=pdf_path,
                    output_dir=workflow_extracted_dir,
                    extract_images=workflow_config.extraction_options.extract_images,
                    extract_tables=workflow_config.extraction_options.extract_tables,
                    extract_equations=workflow_config.extraction_options.extract_equations,
                    ocr_quality=workflow_config.extraction_options.ocr_quality,
                    ocr_language=workflow_config.extraction_options.ocr_language,
                    process_scanned=workflow_config.extraction_options.process_scanned,
                    deskew_pages=workflow_config.extraction_options.deskew_pages,
                    denoise_images=workflow_config.extraction_options.denoise_images,
                    is_scanned=is_scanned
                )
                
                # Check for required fields
                if not extraction_result or not extraction_result.get("content"):
                    raise PDFExtractionError(
                        "PDF extraction failed to produce valid content",
                        workflow_id=workflow_id,
                        details={"pdf_path": pdf_path}
                    )
                
                # Save extraction output for persistence
                with open(os.path.join(workflow_extracted_dir, "extraction_result.json"), "w") as f:
                    json.dump(extraction_result, f, indent=2)
                
                # Log and publish success event
                self.logger.info(f"Workflow {workflow_id}: PDF extraction completed successfully")
                step_timing["extraction"] = time.time() - extraction_start
                
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.EXTRACTION_COMPLETED,
                    {"pages": len(extraction_result.get("pages", [])),
                     "images": len(extraction_result.get("images", [])),
                     "tables": len(extraction_result.get("tables", [])),
                     "duration": step_timing["extraction"]}
                )
                
                # Update workflow state with extraction results
                with self.workflow_lock:
                    self.workflow_states[workflow_id]["extracted_content"] = extraction_result
                    self.workflow_states[workflow_id]["steps_completed"].append("extraction")
                
            except Exception as e:
                # Capture specific extraction errors
                error_msg = f"PDF extraction failed: {str(e)}"
                self.logger.error(f"Workflow {workflow_id}: {error_msg}", exc_info=True)
                
                # Publish extraction failed event
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.EXTRACTION_FAILED,
                    {"error": str(e)}
                )
                
                # Wrap the exception in our error type if needed
                if not isinstance(e, PDFExtractionError):
                    raise PDFExtractionError(
                        error_msg, 
                        workflow_id=workflow_id,
                        details={"pdf_path": pdf_path}
                    ) from e
                raise
            
            # Update workflow state
            self._update_workflow_status(workflow_id, "content_analysis")
            
            # Log and publish event
            self.logger.info(f"Workflow {workflow_id}: Starting content analysis")
            get_event_bus().publish_for_workflow(
                workflow_id,
                EventType.ANALYSIS_STARTED,
                {"extraction_result_summary": extraction_result.get("summary", {})}
            )
            
            # Get content analyzer from container
            content_analyzer = self.container.get_component_typed("content_pipeline", ContentAnalysisPipeline)
            
            # Create output directory for analysis
            workflow_analysis_dir = os.path.join(self.analysis_dir, workflow_id)
            os.makedirs(workflow_analysis_dir, exist_ok=True)
            
            # Analyze content with error handling
            analysis_start = time.time()
            try:
                # Run content analysis pipeline
                analysis_result = content_analyzer.analyze_content(
                    extracted_content=extraction_result,
                    output_dir=workflow_analysis_dir,
                    domain_focus=workflow_config.analysis_options.domain_focus,
                    grade_level=workflow_config.analysis_options.grade_level,
                    detail_level=workflow_config.analysis_options.detail_level,
                    include_quiz=workflow_config.analysis_options.include_quiz,
                    language=workflow_config.analysis_options.language
                )
                
                # Check for required fields
                if not analysis_result or not analysis_result.get("topic"):
                    raise ContentAnalysisError(
                        "Content analysis failed to identify topic",
                        workflow_id=workflow_id
                    )
                
                # Save analysis output for persistence
                with open(os.path.join(workflow_analysis_dir, "analysis_result.json"), "w") as f:
                    json.dump(analysis_result, f, indent=2)
                
                # Log and publish success event
                self.logger.info(f"Workflow {workflow_id}: Content analysis completed successfully")
                step_timing["analysis"] = time.time() - analysis_start
                
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.ANALYSIS_COMPLETED,
                    {"topic": analysis_result.get("topic", ""),
                     "concepts": len(analysis_result.get("concepts", [])),
                     "duration": step_timing["analysis"]}
                )
                
                # Update workflow state with analysis results
                with self.workflow_lock:
                    self.workflow_states[workflow_id]["content_analysis"] = analysis_result
                    self.workflow_states[workflow_id]["steps_completed"].append("analysis")
                
            except Exception as e:
                # Capture specific analysis errors
                error_msg = f"Content analysis failed: {str(e)}"
                self.logger.error(f"Workflow {workflow_id}: {error_msg}", exc_info=True)
                
                # Publish analysis failed event
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.ANALYSIS_FAILED,
                    {"error": str(e)}
                )
                
                # Wrap the exception in our error type if needed
                if not isinstance(e, ContentAnalysisError):
                    raise ContentAnalysisError(
                        error_msg, 
                        workflow_id=workflow_id
                    ) from e
                raise
            
            # Update workflow state
            self._update_workflow_status(workflow_id, "video_generation")
            
            # Log and publish event
            self.logger.info(f"Workflow {workflow_id}: Starting multimedia generation")
            get_event_bus().publish_for_workflow(
                workflow_id,
                EventType.VIDEO_GENERATION_STARTED,
                {"analysis_summary": analysis_result.get("summary", {})}
            )
            
            # Get multimedia generator from container
            multimedia_generator = self.container.get_component_typed("multimedia_pipeline", MultimediaGenerationPipeline)
            
            # Create output directory for multimedia
            workflow_multimedia_dir = os.path.join(self.multimedia_dir, workflow_id)
            os.makedirs(workflow_multimedia_dir, exist_ok=True)
            
            # Generate multimedia with error handling
            video_start = time.time()
            try:
                # Initialize multimedia components with proper settings
                multimedia_generator = MultimediaGenerationPipeline(
                    huggingface_api_key=workflow_config.multimedia_options.huggingface_api_key,
                    mistral_api_key=workflow_config.multimedia_options.mistral_api_key,
                    output_dir=workflow_multimedia_dir,
                    video_format=workflow_config.multimedia_options.video_format,
                    video_quality=workflow_config.multimedia_options.video_quality
                )

                # Generate multimedia content
                video_result = multimedia_generator.generate_video(
                    analysis_result=analysis_result,
                    extracted_content=extraction_result,
                    output_dir=workflow_multimedia_dir,
                    parameters={
                        "script_style": vars(workflow_config.multimedia_options.script_style),
                        "animation_style": vars(workflow_config.multimedia_options.animation_style),
                        "voice_options": vars(workflow_config.multimedia_options.voice_options),
                        "video_format": workflow_config.multimedia_options.video_format,
                        "video_quality": workflow_config.multimedia_options.video_quality.value,
                        "add_subtitles": True,
                        "animation_level": "standard",
                        "color_scheme": "educational",
                        "voice_id": "professional",
                        "language_code": "en-US",
                        "voice_speed": 1.0,
                        "pitch": 0
                    }
                )
                
                # Check for required fields
                if not video_result or not video_result.get("video_file"):
                    raise MultimediaGenerationError(
                        "Video generation failed to produce video file",
                        workflow_id=workflow_id
                    )
                
                # Save video metadata for persistence
                with open(os.path.join(workflow_multimedia_dir, "video_metadata.json"), "w") as f:
                    json.dump(video_result, f, indent=2)
                
                # Log and publish success event
                self.logger.info(f"Workflow {workflow_id}: Multimedia generation completed successfully")
                step_timing["video"] = time.time() - video_start
                
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.VIDEO_GENERATION_COMPLETED,
                    {"video_file": video_result.get("video_file", ""),
                     "duration": step_timing["video"],
                     "video_length": video_result.get("video_length", 0)}
                )
                
                # Update workflow state with video results
                with self.workflow_lock:
                    self.workflow_states[workflow_id]["video_results"] = video_result
                    self.workflow_states[workflow_id]["steps_completed"].append("video")
                    
            except Exception as e:
                # Capture specific video generation errors
                error_msg = f"Multimedia generation failed: {str(e)}"
                self.logger.error(f"Workflow {workflow_id}: {error_msg}", exc_info=True)
                
                # Publish multimedia failed event
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.VIDEO_GENERATION_FAILED,
                    {"error": str(e)}
                )
                
                # Wrap the exception in our error type if needed
                if not isinstance(e, MultimediaGenerationError):
                    raise MultimediaGenerationError(
                        error_msg, 
                        workflow_id=workflow_id
                    ) from e
                raise
            
            # If student ID is provided, perform adaptive learning setup
            if student_id:
                # Update workflow state
                self._update_workflow_status(workflow_id, "adaptive_learning")
                
                # Log and publish event
                self.logger.info(f"Workflow {workflow_id}: Starting adaptive learning for student {student_id}")
                get_event_bus().publish_for_workflow(
                    workflow_id,
                    EventType.ADAPTIVE_LEARNING_STARTED,
                    {"student_id": student_id}
                )
                
                # Get adaptive learning manager and student profile manager
                adaptive_manager = self.container.get_component_typed("learning_manager", AdaptiveLearningManager)
                student_profile_manager = self.container.get_component_typed("student_manager", StudentProfileManager)
                
                # Create output directory for adaptive learning
                workflow_adaptive_dir = os.path.join(self.feedback_dir, workflow_id)
                os.makedirs(workflow_adaptive_dir, exist_ok=True)
                
                # Set up adaptive learning with error handling
                adaptive_start = time.time()
                try:
                    # Get or create student profile
                    student_profile = student_profile_manager.get_student_profile(student_id)
                    
                    # Process the document for adaptive learning first
                    document_id = adaptive_manager.process_document(
                        pdf_path=pdf_path,
                        output_dir=workflow_adaptive_dir
                    )
                    
                    # Create adaptive learning path
                    adaptive_result = adaptive_manager.create_personalized_pathway(
                        student_id=student_id,
                        document_id=document_id,  # Use the processed document ID
                        target_concepts=analysis_result.get("concepts", [])
                    )
                    
                    # Check for required fields
                    if not adaptive_result:
                        raise AdaptiveLearningError(
                            "Adaptive learning setup failed to create learning path",
                            workflow_id=workflow_id,
                            details={"student_id": student_id}
                        )
                    
                    # Save adaptive learning output for persistence
                    with open(os.path.join(workflow_adaptive_dir, "adaptive_result.json"), "w") as f:
                        json.dump(adaptive_result, f, indent=2)
                    
                    # Log and publish success event
                    self.logger.info(f"Workflow {workflow_id}: Adaptive learning setup completed")
                    step_timing["adaptive"] = time.time() - adaptive_start
                    
                    get_event_bus().publish_for_workflow(
                        workflow_id,
                        EventType.ADAPTIVE_LEARNING_COMPLETED,
                        {"session_id": adaptive_result,
                         "duration": step_timing["adaptive"]}
                    )
                    
                    # Update workflow state with adaptive results
                    with self.workflow_lock:
                        self.workflow_states[workflow_id]["adaptive_result"] = {
                            "session_id": adaptive_result,
                            "student_id": student_id
                        }
                        self.workflow_states[workflow_id]["steps_completed"].append("adaptive")
                    
                except Exception as e:
                    # Capture specific adaptive learning errors
                    error_msg = f"Adaptive learning setup failed: {str(e)}"
                    self.logger.error(f"Workflow {workflow_id}: {error_msg}", exc_info=True)
                    
                    # Publish adaptive learning failed event
                    get_event_bus().publish_for_workflow(
                        workflow_id,
                        EventType.ADAPTIVE_LEARNING_FAILED,
                        {"error": str(e), "student_id": student_id}
                    )
                    
                    # Wrap the exception in our error type if needed
                    if not isinstance(e, AdaptiveLearningError):
                        raise AdaptiveLearningError(
                            error_msg, 
                            workflow_id=workflow_id,
                            details={"student_id": student_id}
                        ) from e
                    raise
            
            # Calculate total workflow duration
            total_duration = time.time() - start_time
            
            # Compile performance metrics
            performance_metrics = {
                "workflow_id": workflow_id,
                "total_duration": total_duration,
                "step_timing": step_timing,
                "pdf_size": os.path.getsize(pdf_path) if os.path.exists(pdf_path) else 0,
                "pages_processed": len(extraction_result.get("pages", [])) if extraction_result else 0,
                "images_extracted": len(extraction_result.get("images", [])) if extraction_result else 0,
                "tables_extracted": len(extraction_result.get("tables", [])) if extraction_result else 0,
                "video_length": video_result.get("video_length", 0) if video_result else 0,
                "is_scanned_document": extraction_result.get("is_scanned", False) if extraction_result else False,
                "timestamp": time.time()
            }
            
            # Save performance metrics
            metrics_file = os.path.join(self.metrics_dir, f"{workflow_id}_metrics.json")
            with open(metrics_file, "w") as f:
                json.dump(performance_metrics, f, indent=2)
            
            # Update workflow state
            self._update_workflow_status(workflow_id, "completed")
            
            # Log and publish workflow completed event
            self.logger.info(f"Workflow {workflow_id}: Completed successfully in {total_duration:.2f} seconds")
            get_event_bus().publish_for_workflow(
                workflow_id,
                EventType.WORKFLOW_COMPLETED,
                {"total_duration": total_duration,
                 "steps_completed": self.workflow_states[workflow_id]["steps_completed"]}
            )
            
            # Check if auto-scaling is enabled
            if workflow_config.auto_scaling:
                self._check_scaling_needs(performance_metrics)
            
            # Compile final results
            result = {
                "workflow_id": workflow_id,
                "pdf_path": pdf_path,
                "status": "completed",
                "duration": total_duration,
                "extraction": {
                    "pages": len(extraction_result.get("pages", [])),
                    "images": len(extraction_result.get("images", [])),
                    "tables": len(extraction_result.get("tables", []))
                },
                "analysis": {
                    "topic": analysis_result.get("topic", ""),
                    "concepts": analysis_result.get("concepts", []),
                    "summary": analysis_result.get("summary", {})
                },
                "video": {
                    "video_file": video_result.get("video_file", ""),
                    "script_file": video_result.get("script_file", ""),
                    "length": video_result.get("video_length", 0)
                }
            }
            
            # Add adaptive learning results if applicable
            if student_id and adaptive_result:
                result["adaptive"] = {
                    "student_id": student_id,
                    "session_id": adaptive_result
                }
            
            return result
            
        except Exception as e:
            # Calculate total workflow duration even on error
            error_duration = time.time() - start_time
            
            # Determine error type
            if isinstance(e, WorkflowError):
                error_message = str(e)
                error_type = e.__class__.__name__
                error_details = e.details if hasattr(e, "details") else {}
            else:
                error_message = f"Unexpected error: {str(e)}"
                error_type = "UnexpectedError"
                error_details = {"original_type": type(e).__name__}
            
            # Log the error
            self.logger.error(
                f"Workflow {workflow_id}: Failed with {error_type}: {error_message}",
                exc_info=True
            )
            
            # Update workflow state
            with self.workflow_lock:
                self.workflow_states[workflow_id]["status"] = "error"
                self.workflow_states[workflow_id]["end_time"] = time.time()
                self.workflow_states[workflow_id]["error"] = {
                    "type": error_type,
                    "message": error_message,
                    "details": error_details
                }
            
            # Publish workflow failed event
            get_event_bus().publish_for_workflow(
                workflow_id,
                EventType.WORKFLOW_FAILED,
                {"error_type": error_type,
                 "error_message": error_message,
                 "duration": error_duration}
            )
            
            # Compile error result
            error_result = {
                "workflow_id": workflow_id,
                "pdf_path": pdf_path,
                "status": "error",
                "error": {
                    "type": error_type,
                    "message": error_message,
                    "details": error_details
                },
                "duration": error_duration,
                "steps_completed": self.workflow_states[workflow_id]["steps_completed"]
            }
            
            # Add partial results if they exist
            if extraction_result:
                error_result["partial_extraction"] = {
                    "pages": len(extraction_result.get("pages", [])),
                    "images": len(extraction_result.get("images", [])),
                    "tables": len(extraction_result.get("tables", []))
                }
            
            if analysis_result:
                error_result["partial_analysis"] = {
                    "topic": analysis_result.get("topic", ""),
                    "summary": analysis_result.get("summary", {})
                }
            
            if video_result:
                error_result["partial_video"] = {
                    "video_file": video_result.get("video_file", ""),
                    "script_file": video_result.get("script_file", "")
                }
            
            return error_result
    
    def _update_workflow_status(self, workflow_id: str, status: str) -> None:
        """
        Update the status of a workflow
        
        Args:
            workflow_id: Unique identifier for the workflow
            status: New status string
        """
        with self.workflow_lock:
            if workflow_id in self.workflow_states:
                self.workflow_states[workflow_id]["status"] = status
                self.workflow_states[workflow_id]["last_updated"] = time.time()
                
                # If status is "completed" or "error", set end time
                if status in ["completed", "error"]:
                    self.workflow_states[workflow_id]["end_time"] = time.time()
                
                # Log status change
                self.logger.info(f"Workflow {workflow_id}: Status changed to '{status}'")
    
    def _check_scaling_needs(self, performance_metrics: Dict[str, Any]) -> None:
        """
        Check if system needs to scale based on performance metrics
        
        Args:
            performance_metrics: Dictionary of performance metrics
        """
        try:
            # Get current system metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory_percent = psutil.virtual_memory().percent
            disk_usage = psutil.disk_usage('/').percent
            
            # Get workflow metrics
            total_duration = performance_metrics.get("total_duration", 0)
            step_timing = performance_metrics.get("step_timing", {})
            
            # Calculate average step duration
            avg_step_duration = sum(step_timing.values()) / len(step_timing) if step_timing else 0
            
            # Define scaling thresholds
            SCALING_THRESHOLDS = {
                "cpu_percent": 80,  # Scale if CPU usage > 80%
                "memory_percent": 85,  # Scale if memory usage > 85%
                "disk_usage": 90,  # Scale if disk usage > 90%
                "avg_step_duration": 30,  # Scale if average step takes > 30 seconds
                "total_duration": 300  # Scale if total workflow takes > 5 minutes
            }
            
            # Check if scaling is needed
            scaling_needed = False
            scaling_reasons = []
            
            if cpu_percent > SCALING_THRESHOLDS["cpu_percent"]:
                scaling_needed = True
                scaling_reasons.append(f"High CPU usage: {cpu_percent}%")
            
            if memory_percent > SCALING_THRESHOLDS["memory_percent"]:
                scaling_needed = True
                scaling_reasons.append(f"High memory usage: {memory_percent}%")
            
            if disk_usage > SCALING_THRESHOLDS["disk_usage"]:
                scaling_needed = True
                scaling_reasons.append(f"High disk usage: {disk_usage}%")
            
            if avg_step_duration > SCALING_THRESHOLDS["avg_step_duration"]:
                scaling_needed = True
                scaling_reasons.append(f"Slow step execution: {avg_step_duration:.1f}s average")
            
            if total_duration > SCALING_THRESHOLDS["total_duration"]:
                scaling_needed = True
                scaling_reasons.append(f"Long workflow duration: {total_duration:.1f}s")
            
            # If scaling is needed, trigger scaling action
            if scaling_needed:
                self.logger.warning(f"Scaling needed: {', '.join(scaling_reasons)}")
                
                # Publish scaling event
                get_event_bus().publish_for_workflow(
                    performance_metrics["workflow_id"],
                    EventType.SCALING_NEEDED,
                    {
                        "reasons": scaling_reasons,
                        "metrics": {
                            "cpu_percent": cpu_percent,
                            "memory_percent": memory_percent,
                            "disk_usage": disk_usage,
                            "avg_step_duration": avg_step_duration,
                            "total_duration": total_duration
                        }
                    }
                )
                
                # If using distributed processing, scale Ray cluster
                if self.use_distributed and RAY_AVAILABLE:
                    try:
                        # Get current Ray cluster resources
                        cluster_resources = ray.cluster_resources()
                        available_resources = ray.available_resources()
                        
                        # Calculate scaling factor based on resource usage
                        cpu_scale_factor = cpu_percent / 100
                        memory_scale_factor = memory_percent / 100
                        
                        # Determine new resource requirements
                        new_cpus = max(1, int(cluster_resources.get("CPU", 1) * (1 + cpu_scale_factor)))
                        new_memory = int(cluster_resources.get("memory", 0) * (1 + memory_scale_factor))
                        
                        # Scale Ray cluster
                        ray.autoscale(
                            min_workers=1,
                            max_workers=new_cpus,
                            target_utilization=0.7
                        )
                        
                        self.logger.info(f"Ray cluster scaled to {new_cpus} CPUs and {new_memory/1024/1024/1024:.1f}GB memory")
                        
                    except Exception as e:
                        self.logger.error(f"Failed to scale Ray cluster: {str(e)}")
            
        except Exception as e:
            self.logger.error(f"Error checking scaling needs: {str(e)}")
            # Don't raise the error as this is a non-critical operation

    def process_student_feedback(self, feedback_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process student feedback and update adaptive learning pathway
        
        Args:
            feedback_data: Dictionary containing student feedback and interaction data
                Required fields:
                - student_id: Identifier for the student
                - video_id: Identifier for the video
                - timestamp: Timestamp of feedback
                - interactions: Dictionary of student interactions
                - explicit_feedback: Dictionary of explicit feedback
                
        Returns:
            Dictionary containing feedback processing results
        """
        try:
            # Extract required data
            student_id = feedback_data.get("student_id")
            video_id = feedback_data.get("video_id")
            
            if not student_id or not video_id:
                raise ValueError("Missing required fields: student_id and video_id")
            
            # Get adaptive learning manager
            adaptive_manager = self.container.get_component_typed("learning_manager", AdaptiveLearningManager)
            
            # Get student profile manager
            profile_manager = self.container.get_component_typed("student_manager", StudentProfileManager)
            
            # Get student profile
            profile = profile_manager.get_student_profile(student_id)
            
            if not profile:
                self.logger.warning(f"No profile found for student {student_id}, creating new profile")
                profile = profile_manager.create_student_profile(student_id)
            
            # Analyze interactions
            interactions = feedback_data.get("interactions", {})
            watch_time = interactions.get("watch_time", 0)
            completion_rate = interactions.get("completion_rate", 0)
            pauses = interactions.get("pauses", [])
            replays = interactions.get("replays", [])
            skips = interactions.get("skips", [])
            quiz_results = interactions.get("quiz_results", [])
            
            # Calculate comprehension metrics
            correct_answers = sum(1 for q in quiz_results if q.get("correct", False))
            total_questions = len(quiz_results)
            quiz_score = correct_answers / total_questions if total_questions > 0 else 0
            
            # Identify difficult areas based on pauses and replays
            difficulty_areas = []
            
            # Add segments with multiple replays
            for replay in replays:
                if replay.get("count", 0) > 1:
                    difficulty_areas.append({
                        "segment": replay["segment"],
                        "confidence": 0.8,
                        "evidence": f"Replayed {replay['count']} times"
                    })
            
            # Add segments with clustered pauses
            pause_clusters = self._identify_pause_clusters(pauses)
            for cluster in pause_clusters:
                difficulty_areas.append({
                    "segment": f"Time {cluster['start']}-{cluster['end']}",
                    "confidence": 0.6,
                    "evidence": f"Multiple pauses in segment"
                })
            
            # Calculate overall comprehension level
            comprehension_factors = {
                "quiz_score": quiz_score * 0.4,
                "completion_rate": completion_rate * 0.3,
                "replay_factor": min(1.0, len(replays) * 0.1) * 0.2,
                "explicit_rating": feedback_data.get("explicit_feedback", {}).get("rating", 3) / 5 * 0.1
            }
            
            overall_comprehension = sum(comprehension_factors.values())
            
            # Determine comprehension level
            if overall_comprehension >= 0.8:
                comprehension_level = "high"
            elif overall_comprehension >= 0.6:
                comprehension_level = "medium"
            else:
                comprehension_level = "low"
            
            # Generate recommended interventions
            interventions = self._generate_interventions(
                comprehension_level=comprehension_level,
                difficulty_areas=difficulty_areas,
                quiz_results=quiz_results
            )
            
            # Compile feedback result
            feedback_result = {
                "status": "success",
                "student_id": student_id,
                "video_id": video_id,
                "timestamp": feedback_data["timestamp"],
                "comprehension_assessment": {
                    "overall_level": comprehension_level,
                    "confidence": overall_comprehension,
                    "quiz_performance": quiz_score,
                    "completion_rate": completion_rate,
                    "difficulty_areas": difficulty_areas
                },
                "interventions": interventions
            }
            
            # Save feedback results
            feedback_dir = os.path.join(self.feedback_dir, student_id)
            os.makedirs(feedback_dir, exist_ok=True)
            
            feedback_file = os.path.join(feedback_dir, f"{video_id}_feedback.json")
            with open(feedback_file, "w") as f:
                json.dump(feedback_result, f, indent=2)
            
            return feedback_result
            
        except Exception as e:
            self.logger.error(f"Error processing student feedback: {str(e)}")
            return {
                "status": "error",
                "error_message": str(e)
            }

    def _identify_pause_clusters(self, pauses: List[float], cluster_threshold: float = 10.0) -> List[Dict[str, Any]]:
        """
        Identify clusters of pauses that may indicate difficult content
        
        Args:
            pauses: List of timestamps where student paused
            cluster_threshold: Maximum time difference to consider pauses as clustered
            
        Returns:
            List of pause clusters with start and end times
        """
        if not pauses:
            return []
        
        # Sort pauses
        sorted_pauses = sorted(pauses)
        
        # Find clusters
        clusters = []
        current_cluster = {"start": sorted_pauses[0], "pauses": [sorted_pauses[0]]}
        
        for pause in sorted_pauses[1:]:
            if pause - current_cluster["pauses"][-1] <= cluster_threshold:
                # Add to current cluster
                current_cluster["pauses"].append(pause)
            else:
                # Finish current cluster and start new one
                current_cluster["end"] = current_cluster["pauses"][-1]
                clusters.append(current_cluster)
                current_cluster = {"start": pause, "pauses": [pause]}
        
        # Add last cluster
        current_cluster["end"] = current_cluster["pauses"][-1]
        clusters.append(current_cluster)
        
        return clusters

    def _generate_interventions(self, comprehension_level: str, 
                             difficulty_areas: List[Dict[str, Any]],
                             quiz_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Generate recommended interventions based on feedback analysis
        
        Args:
            comprehension_level: Overall comprehension level
            difficulty_areas: List of identified difficult areas
            quiz_results: List of quiz results
            
        Returns:
            List of recommended interventions
        """
        interventions = []
        
        # Add interventions based on comprehension level
        if comprehension_level == "low":
            interventions.append({
                "type": "review",
                "priority": "high",
                "description": "Complete review of core concepts recommended"
            })
            interventions.append({
                "type": "simplified_content",
                "priority": "high",
                "description": "Access simplified versions of the content"
            })
        elif comprehension_level == "medium":
            interventions.append({
                "type": "targeted_practice",
                "priority": "medium",
                "description": "Additional practice on specific topics recommended"
            })
        
        # Add interventions for difficulty areas
        for area in difficulty_areas:
            interventions.append({
                "type": "focused_review",
                "priority": "high",
                "description": f"Review {area['segment']} with additional explanations",
                "segment": area["segment"]
            })
        
        # Add interventions based on quiz performance
        incorrect_questions = [q for q in quiz_results if not q.get("correct", False)]
        if incorrect_questions:
            interventions.append({
                "type": "quiz_review",
                "priority": "medium",
                "description": f"Review {len(incorrect_questions)} incorrect quiz answers",
                "question_ids": [q["question_id"] for q in incorrect_questions]
            })
        
        return interventions