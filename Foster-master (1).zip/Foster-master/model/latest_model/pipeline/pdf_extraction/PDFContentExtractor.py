"""
Advanced PDF Content Extractor
------------------------------
Extracts content from PDFs with support for:
- Structured document understanding
- Mathematical expressions and equations
- Chemical formulas and reactions
- Tables and figures
- Document metadata
"""

import os
import re
import json
import numpy as np
import fitz  # PyMuPDF
import cv2
from PIL import Image
import io
import pytesseract
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTTextContainer, LTFigure, LTImage, LTTextBoxHorizontal
import tabula  # For table extraction
from sympy.parsing.latex import parse_latex
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Tuple
from enum import Enum

from pipeline.errors.WorkflowErrors import (
    PDFExtractionError, PDFParsingError, OCRError, ContentExtractionError
)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PDFQuality(Enum):
    """Represents the quality/complexity of a PDF document"""
    SIMPLE = "simple"       # Simple text-based PDF with basic formatting
    STANDARD = "standard"   # Standard PDF with some formatting and basic images
    COMPLEX = "complex"     # Complex PDF with advanced formatting, tables, etc.
    SCANNED = "scanned"     # Primarily scanned content requiring OCR
    PROBLEMATIC = "problematic"  # Problematic PDF with encryption or other issues

class PDFContentExtractor(ABC):
    """
    Base class for PDF content extraction
    Provides common functionality and defines the interface for extractors
    """
    
    def __init__(self, tesseract_path: Optional[str] = None, math_recognition: bool = False,
                chem_recognition: bool = False):
        """
        Initialize the PDF extractor
        
        Args:
            tesseract_path: Path to Tesseract OCR executable
            math_recognition: Whether to enable mathematical expression recognition
            chem_recognition: Whether to enable chemical formula recognition
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.tesseract_path = tesseract_path
        self.math_recognition = math_recognition
        self.chem_recognition = chem_recognition
        
        # Extraction statistics for adaptive processing
        self.extraction_stats = {
            "success_count": 0,
            "failure_count": 0,
            "ocr_count": 0,
            "average_extraction_time": 0,
            "total_extractions": 0
        }
        
        # Configure fallback strategies 
        self.fallback_strategies = [
            self._standard_extraction,
            self._ocr_based_extraction,
            self._hybrid_extraction,
            self._minimal_extraction
        ]
        
        # Initialize OCR configurations for different document qualities
        self._init_ocr_configurations()
            
        # Patterns for identifying mathematical content
        self.math_patterns = {
            'latex_delimiters': re.compile(r'\$(.*?)\$|\\\[(.*?)\\\]|\\\((.*?)\\\)'),
            'subscripts': re.compile(r'[a-zA-Z0-9]_\{[^}]+\}|[a-zA-Z0-9]_[0-9]'),
            'fractions': re.compile(r'\\frac\{[^}]+\}\{[^}]+\}'),
            'integrals': re.compile(r'\\int'),
            'summations': re.compile(r'\\sum'),
            'square_roots': re.compile(r'\\sqrt')
        }
        
        # Patterns for identifying chemical content
        self.chem_patterns = {
            'chemical_formulas': re.compile(r'[A-Z][a-z]?[0-9]*'),
            'reaction_arrows': re.compile(r'->|→|⟶|⇌|⇄|⇆|⇋|↔'),
            'subscripts': re.compile(r'_\{[^}]+\}|_[0-9]'),
            'superscripts': re.compile(r'\^\{[^}]+\}|\^[0-9\+\-]')
        }
        
    def _init_ocr_configurations(self) -> None:
        """Initialize OCR configurations for different document qualities"""
        # Base OCR configuration
        self.ocr_configs = {
            PDFQuality.SIMPLE: {
                "dpi": 200,
                "psm": 3,  # Fully automatic page segmentation
                "oem": 3,  # Default OCR engine mode
                "preprocess": False,
            },
            PDFQuality.STANDARD: {
                "dpi": 300,
                "psm": 3,
                "oem": 3,
                "preprocess": True,
            },
            PDFQuality.COMPLEX: {
                "dpi": 300,
                "psm": 11,  # Sparse text with OSD
                "oem": 2,  # Legacy + LSTM
                "preprocess": True,
            },
            PDFQuality.SCANNED: {
                "dpi": 400,
                "psm": 3,
                "oem": 2,
                "preprocess": True,
                "denoise": True,
                "deskew": True,
                "contrast_enhance": True,
            },
            PDFQuality.PROBLEMATIC: {
                "dpi": 600,
                "psm": 6,  # Assume a single uniform block of text
                "oem": 0,  # Legacy engine only
                "preprocess": True,
                "denoise": True,
                "deskew": True,
                "contrast_enhance": True,
                "force_ocr": True  # Force OCR even for text-based PDFs
            }
        }
    
    def extract_content(self, pdf_path: str, output_dir: str, 
                      extract_images: bool = True, extract_tables: bool = True,
                      **kwargs) -> Dict[str, Any]:
        """
        Extract content from a PDF file with progressive fallback strategies
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
            
        Raises:
            PDFExtractionError: If extraction fails with all strategies
        """
        # Validate inputs
        if not os.path.exists(pdf_path):
            raise PDFExtractionError(f"PDF file not found: {pdf_path}")
        
        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                raise PDFExtractionError(f"Failed to create output directory: {str(e)}")
        
        # Analyze PDF quality to determine optimal extraction approach
        pdf_quality = self.analyze_pdf_quality(pdf_path)
        self.logger.info(f"Determined PDF quality as: {pdf_quality.value}")
        
        # Update kwargs with quality-appropriate OCR settings
        if "ocr_quality" in kwargs:
            # Use a hybrid approach - take user settings but adapt based on document
            self._adapt_ocr_settings(kwargs, pdf_quality)
        else:
            # Use quality-determined OCR settings
            for key, value in self.ocr_configs[pdf_quality].items():
                if key not in kwargs:
                    kwargs[key] = value
        
        # Execute extraction with fallback strategies
        extraction_errors = []
        for strategy_index, strategy in enumerate(self.fallback_strategies):
            try:
                self.logger.info(f"Attempting extraction with strategy {strategy_index+1}")
                result = strategy(pdf_path, output_dir, extract_images, extract_tables, **kwargs)
                
                # Validate extraction result
                if self._validate_extraction_result(result):
                    # Update extraction statistics
                    self._update_extraction_stats(True, pdf_quality)
                    return result
                else:
                    extraction_errors.append(f"Strategy {strategy_index+1} produced invalid result")
            except Exception as e:
                self.logger.warning(f"Extraction strategy {strategy_index+1} failed: {str(e)}")
                extraction_errors.append(f"Strategy {strategy_index+1} error: {str(e)}")
        
        # If we reached here, all strategies failed
        self._update_extraction_stats(False, pdf_quality)
        
        # Compile error information for better diagnostics
        error_detail = "\n".join(extraction_errors)
        raise PDFExtractionError(
            f"All extraction strategies failed for {pdf_path}",
            details={
                "pdf_path": pdf_path,
                "pdf_quality": pdf_quality.value,
                "strategies_attempted": len(self.fallback_strategies),
                "errors": extraction_errors
            }
        )
    
    def _adapt_ocr_settings(self, kwargs: Dict[str, Any], pdf_quality: PDFQuality) -> None:
        """
        Adapt OCR settings based on PDF quality and user settings
        
        Args:
            kwargs: User-provided extraction options
            pdf_quality: Determined PDF quality
        """
        # Map user OCR quality setting to internal settings
        user_ocr_quality = kwargs.get("ocr_quality", "standard")
        
        # If PDF is SCANNED or PROBLEMATIC, increase OCR quality
        if pdf_quality in [PDFQuality.SCANNED, PDFQuality.PROBLEMATIC]:
            if user_ocr_quality == "low":
                kwargs["ocr_quality"] = "standard"
            elif user_ocr_quality == "standard":
                kwargs["ocr_quality"] = "high"
            
            # Force deskew and denoise for scanned documents unless explicitly disabled
            if "deskew_pages" not in kwargs:
                kwargs["deskew_pages"] = True
            if "denoise_images" not in kwargs:
                kwargs["denoise_images"] = True
    
    def _update_extraction_stats(self, success: bool, pdf_quality: PDFQuality) -> None:
        """
        Update extraction statistics for adaptive processing
        
        Args:
            success: Whether extraction was successful
            pdf_quality: Quality of the processed PDF
        """
        # Update success/failure counts
        if success:
            self.extraction_stats["success_count"] += 1
        else:
            self.extraction_stats["failure_count"] += 1
        
        # Update OCR count
        if pdf_quality in [PDFQuality.SCANNED, PDFQuality.PROBLEMATIC]:
            self.extraction_stats["ocr_count"] += 1
        
        # Update total extractions
        self.extraction_stats["total_extractions"] += 1
    
    def _validate_extraction_result(self, result: Dict[str, Any]) -> bool:
        """
        Validate extraction result to ensure it contains required data
        
        Args:
            result: Extraction result dictionary
            
        Returns:
            True if result is valid, False otherwise
        """
        # Check for required fields
        if not isinstance(result, dict):
            return False
        
        if "content" not in result or not result["content"]:
            return False
        
        if "pages" not in result or not isinstance(result["pages"], list):
            return False
        
        # Check that we have at least one page with content
        if not any(page.get("text") for page in result["pages"]):
            return False
        
        return True
    
    @abstractmethod
    def analyze_pdf_quality(self, pdf_path: str) -> PDFQuality:
        """
        Analyze PDF to determine its quality and complexity
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            PDFQuality enum indicating the document quality
        """
        pass
    
    @abstractmethod
    def is_scanned_document(self, pdf_path: str) -> bool:
        """
        Determine if the PDF is primarily a scanned document
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            True if document is primarily scanned, False otherwise
        """
        pass
    
    @abstractmethod
    def _standard_extraction(self, pdf_path: str, output_dir: str, 
                           extract_images: bool, extract_tables: bool, 
                           **kwargs) -> Dict[str, Any]:
        """
        Primary extraction strategy using PDF parsing
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        pass
    
    @abstractmethod
    def _ocr_based_extraction(self, pdf_path: str, output_dir: str, 
                            extract_images: bool, extract_tables: bool, 
                            **kwargs) -> Dict[str, Any]:
        """
        OCR-based extraction strategy for scanned documents
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        pass
    
    @abstractmethod
    def _hybrid_extraction(self, pdf_path: str, output_dir: str, 
                         extract_images: bool, extract_tables: bool, 
                         **kwargs) -> Dict[str, Any]:
        """
        Hybrid extraction strategy using both parsing and OCR
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        pass
    
    @abstractmethod
    def _minimal_extraction(self, pdf_path: str, output_dir: str, 
                          extract_images: bool, extract_tables: bool, 
                          **kwargs) -> Dict[str, Any]:
        """
        Minimal extraction strategy for problematic PDFs
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        pass
        
    def is_math_content(self, text):
        """Check if text contains mathematical expressions"""
        if not self.math_recognition:
            return False
            
        for pattern_name, pattern in self.math_patterns.items():
            if pattern.search(text):
                return True
        return False
        
    def is_chemical_content(self, text):
        """Check if text contains chemical formulas or reactions"""
        if not self.chem_recognition:
            return False
            
        # Count matches for chemical patterns
        matches = 0
        for pattern_name, pattern in self.chem_patterns.items():
            if pattern.search(text):
                matches += 1
        
        # If multiple patterns match, it's likely chemical content
        return matches >= 2
        
    def process_math_content(self, text):
        """Process and normalize mathematical content"""
        # Convert LaTeX math to a structured representation
        try:
            # Extract LaTeX expressions
            math_expressions = []
            for delim_pattern in [r'\$(.*?)\$', r'\\\[(.*?)\\\]', r'\\\((.*?)\\\)']:
                for match in re.finditer(delim_pattern, text, re.DOTALL):
                    expr = match.group(1)
                    if expr:
                        math_expressions.append({
                            'type': 'math_expression',
                            'latex': expr,
                            'position': match.span()
                        })
                        
            return math_expressions
        except Exception as e:
            logger.warning(f"Error processing math content: {e}")
            return text
            
    def process_chemical_content(self, text):
        """Process chemical formulas and reactions"""
        try:
            # Find reaction arrows
            reactions = []
            for match in self.chem_patterns['reaction_arrows'].finditer(text):
                # Look for chemical components before and after the arrow
                reaction_text = text[max(0, match.start() - 20):min(len(text), match.end() + 20)]
                reactions.append({
                    'type': 'chemical_reaction',
                    'text': reaction_text,
                    'position': match.span()
                })
                
            # Find standalone chemical formulas
            formulas = []
            for match in self.chem_patterns['chemical_formulas'].finditer(text):
                # Only consider it a formula if it matches certain patterns
                formula = match.group(0)
                if len(formula) > 1 and re.search(r'[A-Z][a-z]?[0-9]+', formula):
                    formulas.append({
                        'type': 'chemical_formula',
                        'text': formula,
                        'position': match.span()
                    })
                    
            return {'reactions': reactions, 'formulas': formulas}
        except Exception as e:
            logger.warning(f"Error processing chemical content: {e}")
            return text
            
    def extract_images(self, pdf_doc, output_dir=None):
        """Extract images from PDF with position information"""
        images = []

        for page_idx, page in enumerate(pdf_doc):
            image_list = page.get_images(full=True)

            for img_idx, img_info in enumerate(image_list):
                xref = img_info[0]
                base_image = pdf_doc.extract_image(xref)

                if not base_image:
                    continue

                image_bytes = base_image["image"]
                image_ext = base_image["ext"]

                # Get image position on page - Corrected method usage
                position = None
                for img_rect in page.get_image_rects(img_info):  #  Passing the image info as parameter
                    position = {
                        "x0": img_rect.x0,
                        "y0": img_rect.y0,
                        "x1": img_rect.x1,
                        "y1": img_rect.y1
                    }
                    break
                
                # Save image if output directory provided
                image_filename = None
                if output_dir:
                    os.makedirs(output_dir, exist_ok=True)
                    image_filename = f"page{page_idx+1}_img{img_idx +1}.{image_ext}"
                    image_path = os.path.join(output_dir,   image_filename)

                    with open(image_path, "wb") as img_file:
                        img_file.write(image_bytes)

                # Use OCR to extract any text in the image
                image_text = None
                try:
                    pil_image = Image.open(io.BytesIO(image_bytes))
                    image_text = pytesseract.image_to_string    (pil_image)
                    if not image_text.strip():
                        image_text = None
                except Exception as e:
                    logger.warning(f"OCR failed for image: {e}")

                images.append({
                    "page": page_idx + 1,
                    "index": img_idx + 1,
                    "position": position,
                    "file_name": image_filename,
                    "format": image_ext,
                    "ocr_text": image_text
                })

        return images
    
    def extract_tables(self, pdf_path):
        """Extract tables from PDF using tabula-py"""
        tables = []
        
        try:
            # Use tabula to extract tables from all pages
            # lattice=True works better for tables with visible borders
            # stream=True works better for tables without clear borders
            table_list = tabula.read_pdf(
                pdf_path,
                pages='all',
                multiple_tables=True,
                lattice=True,
                stream=True,
                guess=True
            )
            
            for i, df in enumerate(table_list):
                if not df.empty:
                    # Get the page number from tabula's metadata
                    page = i + 1  # Fallback if page info not available
                    
                    tables.append({
                        "page": page,
                        "index": i + 1,
                        "data": df.to_dict('records'),
                        "shape": df.shape,
                        "columns": df.columns.tolist()
                    })
        except Exception as e:
            logger.warning(f"Table extraction failed: {e}")
            
        return tables
        
    def extract_document_structure(self, pdf_path):
        """Extract document structure using pdfminer to understand layout"""
        structure = []
        
        for page_layout in extract_pages(pdf_path):
            page_struct = {"type": "page", "elements": []}
            
            # Sort elements by their vertical position (y-coordinate)
            elements = sorted(
                [element for element in page_layout],
                key=lambda e: -e.y0
            )
            
            for element in elements:
                if isinstance(element, LTTextBoxHorizontal):
                    text = element.get_text().strip()
                    if not text:
                        continue
                    
                    # Analyze font size to detect headers
                    font_sizes = []
                    for text_line in element:
                        for char in text_line:
                            if hasattr(char, "size"):
                                font_sizes.append(char.size)
                    
                    avg_font_size = sum(font_sizes) / len(font_sizes) if font_sizes else 0
                    
                    # Detect if this is likely a heading
                    is_heading = False
                    if avg_font_size > 12 and len(text) < 100:  # Simplified heuristic
                        is_heading = True
                    
                    page_struct["elements"].append({
                        "type": "heading" if is_heading else "text",
                        "text": text,
                        "position": {
                            "x0": element.x0,
                            "y0": element.y0,
                            "x1": element.x1,
                            "y1": element.y1
                        },
                        "font_size": avg_font_size if font_sizes else None
                    })
                    
                elif isinstance(element, (LTFigure, LTImage)):
                    page_struct["elements"].append({
                        "type": "figure",
                        "position": {
                            "x0": element.x0,
                            "y0": element.y0,
                            "x1": element.x1,
                            "y1": element.y1
                        }
                    })
            
            structure.append(page_struct)
            
        return structure
                    
    @staticmethod
    def preprocess_pdf_for_extraction(pdf_path, output_path=None):
        """Preprocess PDF to improve extraction quality (optional)"""
        if output_path is None:
            output_path = pdf_path.replace(".pdf", "_processed.pdf")
            
        doc = fitz.open(pdf_path)
        for page in doc:
            # Apply OCR to pages with little text
            if len(page.get_text().strip()) < 100:
                pix = page.get_pixmap()
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                text = pytesseract.image_to_string(img)
                
                # If OCR found text, add it to the page
                if text.strip():
                    page.insert_text((50, 50), text)
                    
        doc.save(output_path)
        doc.close()
        return output_path
