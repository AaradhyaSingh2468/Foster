"""
Enhanced PDF Content Extractor with Inheritance
----------------------------------------------
Extends the original PDFContentExtractor with improved:
- Text cleaning and noise removal
- Better heading detection
- Content organization
- JSON and TXT output formats
"""
import os
import re
from typing import Dict, List
from PDFContentExtractor import PDFContentExtractor
import logging
import unicodedata
import cv2
import numpy as np
from PIL import Image, ImageEnhance
import tempfile
import io
import pytesseract

class EnhancedPDFExtractor(PDFContentExtractor):
    def __init__(self, tesseract_path=None, math_recognition=True, chem_recognition=True):
        """
        Initialize the enhanced PDF content extractor, inheriting from PDFContentExtractor
        
        Args:
            tesseract_path: Path to Tesseract OCR executable
            math_recognition: Boolean to enable mathematical expression recognition
            chem_recognition: Boolean to enable chemical formula recognition
        """
        # Initialize the parent class
        super().__init__(tesseract_path, math_recognition, chem_recognition)
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        
        # Additional regex patterns for cleaning
        self.noise_patterns = [
            re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]'),  # Control characters
            re.compile(r'^\s*$'),  # Empty lines
            re.compile(r'^\s*[.•■□○●◆◇★☆♦♠♣♥→←↑↓⇒⇐⇑⇓⇔⇕⇖⇗⇘⇙]+\s*$'),  # Lines with only bullets/symbols
        ]
        
        # Potential headings detection
        self.heading_patterns = [
            re.compile(r'^[0-9]+\.[0-9.]*\s+[A-Z]'),  # Numbered headings (1.2 Title)
            re.compile(r'^[A-Z][a-z]*\s+[0-9]+\.\s'),  # Chapter/Section headings (Chapter 1.)
            re.compile(r'^[A-Z][A-Z\s]+$'),  # ALL CAPS headings
            re.compile(r'^[A-Z][a-z]+(\s+[A-Z][a-z]+){0,5}$')  # Title Case short lines
        ]
        
        # For filtering out irrelevant short fragments
        self.min_content_length = 10  # Minimum characters for content blocks
        self.min_words_for_content = 3  # Minimum words for content to be considered relevant
        
        # Font analysis parameters
        self.font_heading_threshold = 1.2  # Multiplier above avg font size to be considered heading
        self.font_title_threshold = 1.5   # Multiplier above avg font size to be considered title
        self.font_weight_threshold = 600  # Minimum font weight to be considered bold
    
    def _clean_text_internal(self, text):
        """Internal helper for text cleaning operations"""
        # Normalize unicode characters
        text = unicodedata.normalize('NFKC', text)

        # Replace common problematic characters
        text = text.replace('\u2028', '\n').replace('\u2029', '\n')  # Line/paragraph separators

        # Remove control characters and other noise
        for pattern in self.noise_patterns:
            text = pattern.sub('', text)

        # Fix spacing issues
        text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with single space
        text = re.sub(r'\n\s*\n+', '\n\n', text)  # Normalize multiple newlines

        # Normalize punctuation spacing
        text = re.sub(r'\s+([.,;:!?)])', r'\1', text)
        text = re.sub(r'([([{])\s+', r'\1', text)

        return text.strip()
    
    def _detect_heading_properties(self, text, font_size=None, avg_font_size=None, is_bold=False, font_stats=None):
        """
        Helper method to determine heading properties for a text block
        
        Args:
            text: The text to analyze
            font_size: Font size of this text (if available)
            avg_font_size: Average font size in the document (if available)
            is_bold: Whether the text is in bold font (if available)
            font_stats: Full font statistics from analyze_document_fonts (if available)
            
        Returns:
            Tuple of (is_heading, heading_level)
        """
        # Short text sanity check
        text = text.strip()
        if not text:
            return False, None
            
        if len(text) > 150:  # Headings shouldn't be too long
            return False, None
        
        # Initialize result and heading level
        is_heading = False
        heading_level = None
        
        # Font size check (if available)
        if font_size and avg_font_size:
            size_ratio = font_size / avg_font_size
            
            # Title/H1
            if size_ratio >= self.font_title_threshold:
                is_heading = True
                heading_level = 1
            # Subtitle/H2
            elif size_ratio >= self.font_heading_threshold:
                is_heading = True
                heading_level = 2
            # Potential section heading if bold and above average size
            elif is_bold and size_ratio >= 1.0:
                is_heading = True
                heading_level = 3
                
        # If we haven't determined it's a heading by font, check patterns
        if not is_heading:
            # Pattern matching for heading-like text
            for pattern in self.heading_patterns:
                if pattern.match(text):
                    is_heading = True
                    # Default to level 3 for pattern-matched headings 
                    # unless we have better information
                    heading_level = heading_level or 3
                    break
                    
            # Additional heuristics for headings
            if not is_heading:
                # Label-like headings ending with colon
                if text.endswith(':') and len(text.split()) < 7:
                    is_heading = True
                    heading_level = heading_level or 4
                
                # Title Case with 2-6 words
                elif len(text) < 50 and text[0].isupper() and not text.endswith('.'):
                    words = text.split()
                    if 2 <= len(words) <= 6 and all(w[0].isupper() for w in words if w[0].isalpha()):
                        is_heading = True
                        heading_level = heading_level or 4
        
        # Check if this text matches any heading candidates in font_stats
        if font_stats and "heading_candidates" in font_stats:
            for candidate in font_stats["heading_candidates"]:
                if text == candidate["text"]:
                    is_heading = True
                    # Use the level from font analysis if available
                    heading_level = candidate["heading_level"]
                    break
                    
        return is_heading, heading_level
    
    def _organize_content_hierarchy(self, blocks, respect_heading_levels=True):
        """
        Helper method to organize content blocks into a hierarchical structure

        Args:
            blocks: List of content blocks with type and text
            respect_heading_levels: Whether to create a hierarchical structure

        Returns:
            Structured content organized by headings
        """
        if not blocks:
            return []

        if not respect_heading_levels:
            # Simple flat structure
            current_heading = None
            structured_content = []

            for block in blocks:
                if block.get("type") == "heading":
                    current_heading = {
                        "heading": block["text"],
                        "content": [],
                        "font_size": block.get("font_size"),
                        "position": block.get("position"),
                        "heading_level": block.get("heading_level", 3)
                    }
                    structured_content.append(current_heading)
                elif current_heading is not None:
                    current_heading["content"].append(block["text"])
                else:
                    # Content without a heading
                    structured_content.append({
                        "heading": None,
                        "content": [block["text"]],
                        "position": block.get("position")
                    })

            return structured_content
        else:
            # Create hierarchical structure based on heading levels
            content_tree = {
                "heading": "Document",
                "heading_level": 0,
                "content": [],
                "children": []
            }

            # Current section pointers at each level
            current_sections = {0: content_tree}

            for block in blocks:
                if block.get("type") == "heading":
                    level = block.get("heading_level", 3)

                    # Create new section
                    new_section = {
                        "heading": block["text"],
                        "heading_level": level,
                        "content": [],
                        "children": [],
                        "font_size": block.get("font_size"),
                        "position": block.get("position")
                    }

                    # Find parent section (closest section with lower level)
                    parent_level = max([l for l in current_sections.keys() if l < level], default=0)
                    parent = current_sections[parent_level]

                    # Add to parent's children
                    parent["children"].append(new_section)

                    # Update current section for this level
                    current_sections[level] = new_section

                    # Clear any deeper levels
                    for deeper_level in list(current_sections.keys()):
                        if deeper_level > level:
                            del current_sections[deeper_level]

                else:
                    # Regular content - add to deepest current section
                    deepest_level = max(current_sections.keys())
                    current_sections[deepest_level]["content"].append(block["text"])

            # Function to flatten the tree for simple output
            def flatten_tree(node, sections=None):
                if sections is None:
                    sections = []

                if node["heading"] != "Document" or node["content"]:
                    sections.append({
                        "heading": node["heading"] if node["heading"] != "Document" else None,
                        "content": node["content"],
                        "heading_level": node["heading_level"],
                        "font_size": node.get("font_size"),
                        "position": node.get("position")
                    })

                for child in node["children"]:
                    flatten_tree(child, sections)

                return sections

            return flatten_tree(content_tree)
        
    def clean_text(self, text):
        """Clean text by removing noise and normalizing content"""
        return self._clean_text_internal(text)
    
    def analyze_document_fonts(self, pdf_doc):
        """
        Analyze fonts across the document to identify common sizes and styles
        
        Args:
            pdf_doc: The fitz PDF document object
            
        Returns:
            Dictionary with font statistics and hierarchical font information
        """
        font_sizes = []
        font_weights = []
        font_details = []
        
        for page_idx, page in enumerate(pdf_doc):
            # Get detailed text information including fonts
            text_dict = page.get_text("dict", flags=11)
            
            for block in text_dict.get("blocks", []):
                if "lines" not in block:
                    continue
                    
                for line in block.get("lines", []):
                    for span in line.get("spans", []):
                        text = span.get("text", "").strip()
                        if not text:
                            continue
                            
                        # Extract font information
                        font_name = span.get("font", "")
                        font_size = span.get("size", 0)
                        flags = span.get("flags", 0)
                        
                        # Determine if it's bold (bit 1 in flags is often used for bold)
                        is_bold = bool(flags & 1)
                        # Determine if it's italic (bit 2 in flags is often used for italic)
                        is_italic = bool(flags & 2)
                        
                        # Estimate font weight (400=normal, 700=bold)
                        font_weight = 700 if is_bold else 400
                        
                        # Store details
                        if font_size > 0:
                            font_sizes.append(font_size)
                            font_weights.append(font_weight)
                            
                            font_details.append({
                                "text": text,
                                "font_name": font_name,
                                "font_size": font_size,
                                "is_bold": is_bold,
                                "is_italic": is_italic,
                                "font_weight": font_weight,
                                "page": page_idx + 1,
                                "bbox": [span.get("bbox", [0, 0, 0, 0])]
                            })
        
        # Compute statistics
        if not font_sizes:
            return {
                "min_size": 0, 
                "max_size": 0, 
                "avg_size": 0, 
                "common_size": 0,
                "font_histogram": {},
                "heading_candidates": []
            }
        
        # Create a histogram of font sizes rounded to nearest 0.5
        font_counts = defaultdict(int)
        for size in font_sizes:
            rounded_size = round(size * 2) / 2
            font_counts[rounded_size] += 1
            
        # Sort by frequency to get most common sizes
        sorted_sizes = sorted(font_counts.items(), key=lambda x: x[1], reverse=True)
        common_size = sorted_sizes[0][0] if sorted_sizes else 0
        
        # Identify potential heading sizes (significantly larger than common size)
        avg_size = sum(font_sizes) / len(font_sizes)
        heading_sizes = [size for size in set(font_sizes) if size >= avg_size * self.font_heading_threshold]
        heading_sizes.sort(reverse=True)  # Sort from largest to smallest
        
        # Identify text that matches heading criteria
        heading_candidates = []
        for detail in font_details:
            # Consider it a heading candidate if:
            # 1. Font size is in heading_sizes list OR
            # 2. Font is bold and size is at least average
            if (detail["font_size"] in heading_sizes or 
                (detail["is_bold"] and detail["font_size"] >= avg_size)):
                
                # Classify heading level based on size
                if detail["font_size"] >= avg_size * self.font_title_threshold:
                    level = 1  # Title/h1
                elif detail["font_size"] >= avg_size * self.font_heading_threshold:
                    level = 2  # Subtitle/h2
                elif detail["is_bold"] and detail["font_size"] >= avg_size:
                    level = 3  # Section/h3
                else:
                    level = 4  # Subsection/h4
                
                heading_candidates.append({
                    "text": detail["text"],
                    "font_size": detail["font_size"],
                    "is_bold": detail["is_bold"],
                    "heading_level": level,
                    "page": detail["page"],
                    "bbox": detail["bbox"]
                })
        
        return {
            "min_size": min(font_sizes),
            "max_size": max(font_sizes),
            "avg_size": avg_size,
            "common_size": common_size,
            "font_histogram": dict(sorted_sizes),
            "heading_candidates": heading_candidates
        }
    
    def is_likely_heading(self, text, font_size=None, avg_font_size=None, is_bold=False, font_stats=None):
        """
        Determine if a text block is likely a heading based on content, font size and style

        Args:
            text: The text to analyze
            font_size: Font size of this text (if available)
            avg_font_size: Average font size in the document (if available)
            is_bold: Whether the text is in bold font (if available)
            font_stats: Full font statistics from analyze_document_fonts (if available)

        Returns:
            Boolean indicating if the text is likely a heading and estimated heading level
        """
        return self._detect_heading_properties(text, font_size, avg_font_size, is_bold, font_stats)

    def is_meaningful_content(self, text, is_heading_candidate=False):
        """Determine if text is meaningful content versus noise"""
        text = text.strip()
        if not text:
            return False

        # Special exception for heading candidates
        if is_heading_candidate:
            # For headings, we just need non-empty text, but still check for problematic characters
            non_ascii = sum(1 for c in text if ord(c) > 127)
            if non_ascii > len(text) * 0.3:  # More than 30% non-ASCII
                return False
            return True

        # For regular content, apply stricter rules
        # Check for minimum length
        if len(text) < self.min_content_length:
            return False

        # Check for minimum words
        words = [w for w in text.split() if w.strip(string.punctuation)]
        if len(words) < self.min_words_for_content:
            return False

        # Check for high proportion of problematic characters
        non_ascii = sum(1 for c in text if ord(c) > 127)
        if non_ascii > len(text) * 0.3:  # More than 30% non-ASCII
            return False

        return True
        
    def _group_content_by_headings(self, page_content, respect_heading_levels=True):
        """
        Group content items under their respective headings

        Args:
            page_content: Dictionary containing blocks of content
            respect_heading_levels: Whether to create a hierarchical structure based on heading levels

        Returns:
            List of content sections organized by headings
        """
        if not page_content.get("blocks"):
            return []

        return self._organize_content_hierarchy(page_content["blocks"], respect_heading_levels)
            
    def extract_content(self, pdf_path, output_dir=None, extract_images=True, extract_tables=True, 
                       extract_equations=True, ocr_quality="high", ocr_language="eng",
                       process_scanned=True, deskew_pages=True, denoise_images=True, 
                       is_scanned=None, contrast_enhancement=False, multi_language_detection=False, **kwargs):
        """
        Override of the parent extract_content method to handle additional parameters
        
        This method accepts all parameters that WorkflowCoordinator passes and forwards them
        to the appropriate extraction method.
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to save extracted images (optional)
            extract_images: Boolean indicating whether to extract images
            extract_tables: Boolean indicating whether to extract tables
            extract_equations: Boolean indicating whether to extract equations (math content)
            ocr_quality: Quality level for OCR ("low", "high", "highest")
            ocr_language: Language code for OCR
            process_scanned: Whether to apply special processing for scanned documents
            deskew_pages: Whether to deskew pages in scanned documents
            denoise_images: Whether to denoise images in scanned documents
            is_scanned: Whether the document is known to be scanned
            contrast_enhancement: Whether to enhance contrast in scanned documents
            multi_language_detection: Whether to detect multiple languages in the document
            **kwargs: Additional keyword arguments
            
        Returns:
            Dictionary containing all extracted content
        """
        # If is_scanned wasn't explicitly provided, detect it
        if is_scanned is None:
            is_scanned = self.is_scanned_document(pdf_path)
        
        # Enable or disable math recognition based on extract_equations parameter
        self.math_recognition = extract_equations
        
        # Configure OCR settings based on quality parameter
        ocr_config = {}
        if ocr_quality == "highest":
            ocr_config = {
                "oem": 1,  # LSTM only
                "psm": 6,  # Assume a single uniform block of text
                "lang": ocr_language
            }
        elif ocr_quality == "high":
            ocr_config = {
                "oem": 3,  # Default, based on what is available
                "psm": 6,  # Assume a single uniform block of text
                "lang": ocr_language
            }
        else:  # low
            ocr_config = {
                "oem": 0,  # Legacy engine only
                "psm": 6,  # Assume a single uniform block of text
                "lang": ocr_language
            }
            
        # Handle multi-language detection
        if multi_language_detection:
            ocr_config["lang"] = "+".join(["eng", "deu", "fra", "spa", "ita"])
        
        # Call the enhanced extraction method with all relevant parameters
        return self.extract_content_with_cleaning(
            pdf_path=pdf_path,
            output_dir=output_dir,
            extract_images=extract_images,
            extract_tables=extract_tables,
            respect_heading_hierarchy=True,
            process_scanned=process_scanned and is_scanned,
            deskew_pages=deskew_pages and is_scanned,
            denoise_images=denoise_images and is_scanned,
            contrast_enhancement=contrast_enhancement and is_scanned,
            ocr_config=ocr_config
        )

    def extract_content_with_cleaning(self, pdf_path, output_dir=None, extract_images=True, extract_tables=True, 
                                     respect_heading_hierarchy=True, process_scanned=False, deskew_pages=False,
                                     denoise_images=False, contrast_enhancement=False, ocr_config=None):
        """
        Enhanced extraction with text cleaning and better structure detection

        This method extends the parent's extract_content method with additional processing:
        - Cleans text to remove noise and unidentified symbols
        - Better detects headings and their relationship to content using font analysis
        - Filters out irrelevant short text fragments
        - Creates hierarchical structure based on heading levels
        - Handles scanned documents with improved OCR and image processing

        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to save extracted images (optional)
            extract_images: Boolean indicating whether to extract images
            extract_tables: Boolean indicating whether to extract tables
            respect_heading_hierarchy: Whether to create hierarchical structure based on heading levels
            process_scanned: Whether to apply special processing for scanned documents
            deskew_pages: Whether to deskew pages in scanned documents
            denoise_images: Whether to denoise images in scanned documents
            contrast_enhancement: Whether to enhance contrast in scanned documents
            ocr_config: Dictionary with OCR configuration parameters

        Returns:
            Dictionary containing all extracted and cleaned content, formatted for analyze_content
        """
        # Process scanned documents with special handling if needed
        if process_scanned:
            # Create a temporary processed PDF with improved quality for extraction
            processed_pdf_path = self._preprocess_scanned_document(
                pdf_path, 
                deskew=deskew_pages,
                denoise=denoise_images,
                enhance_contrast=contrast_enhancement,
                ocr_config=ocr_config
            )
            
            # Use the processed PDF for extraction
            extraction_path = processed_pdf_path
        else:
            extraction_path = pdf_path

        # First use the parent class to extract the raw content
        raw_result = super().extract_content(extraction_path, output_dir, extract_images, extract_tables)

        # Clean up temporary processed PDF if created
        if process_scanned and extraction_path != pdf_path:
            try:
                os.remove(extraction_path)
            except:
                pass  # Ignore errors in cleanup

        # Handle extraction errors
        if "error" in raw_result:
            return raw_result

        # Now enhance and clean the extracted content
        enhanced_result = raw_result.copy()

        try:
            # Reopen the PDF for font analysis
            pdf_doc = fitz.open(pdf_path)

            # Perform detailed font analysis
            self.logger.info("Performing detailed font analysis...")
            font_stats = self.analyze_document_fonts(pdf_doc)
            avg_font_size = font_stats["avg_size"]

            # Add font statistics to the result
            enhanced_result["font_statistics"] = {
                "avg_size": font_stats["avg_size"],
                "common_size": font_stats["common_size"],
                "min_size": font_stats["min_size"],
                "max_size": font_stats["max_size"],
                "size_distribution": font_stats["font_histogram"]
            }

            # Add heading candidates from font analysis
            enhanced_result["detected_headings"] = font_stats["heading_candidates"]

            # Process and clean each page
            enhanced_pages = []
            all_text = []

            # Create content_blocks list that analyze_content expects
            content_blocks = []

            # Create sections dictionary that analyze_content expects
            sections = {}
            current_section_id = None
            current_section_content = []

            for page in raw_result["pages"]:
                page_number = page["page_number"]
                enhanced_page = {
                    "page_number": page_number,
                    "blocks": []
                }

                # Process each text block
                for block in page["blocks"]:
                    # Clean the text
                    cleaned_text = self.clean_text(block["text"])

                    # Extract font information if available
                    font_size = None
                    is_bold = False

                    if "position" in block:
                        # Try to match this block with font information from our analysis
                        block_matches = []
                        block_pos = block["position"]

                        # Look for heading candidates that might match this block
                        for candidate in font_stats["heading_candidates"]:
                            if cleaned_text in candidate["text"] or candidate["text"] in cleaned_text:
                                block_matches.append(candidate)

                        if block_matches:
                            # Use font information from the best match
                            best_match = block_matches[0]  # Simple approach: just take first match
                            font_size = best_match["font_size"]
                            is_bold = best_match["is_bold"]
                        else:
                            # Fallback: estimate font size from position data
                            height = block_pos["y1"] - block_pos["y0"]
                            # Rough heuristic: font size ~ 1/2 of block height for single line
                            font_size = height / 2

                    # First check if this might be a heading
                    is_heading_candidate = self.is_likely_heading(
                        cleaned_text, 
                        font_size, 
                        avg_font_size,
                        is_bold,
                        font_stats
                    )[0]  # Just get the boolean, ignore the heading level for now

                    # Check if it's meaningful content, with special handling for headings
                    if not self.is_meaningful_content(cleaned_text, is_heading_candidate):
                        continue
                    
                    # Now get the full heading info including level
                    is_heading, heading_level = self.is_likely_heading(
                        cleaned_text, 
                        font_size, 
                        avg_font_size,
                        is_bold,
                        font_stats
                    )

                    # Create enhanced block
                    enhanced_block = {
                        "text": cleaned_text,
                        "type": "heading" if is_heading else "content",
                        "position": block.get("position"),
                        "font_size": font_size,
                        "is_bold": is_bold
                    }
    

                    # Add heading level if applicable
                    if is_heading and heading_level:
                        enhanced_block["heading_level"] = heading_level

                    # Keep any special content (math/chemical)
                    if "math_expressions" in block:
                        enhanced_block["math_expressions"] = block["math_expressions"]
                    if "chemical_content" in block:
                        enhanced_block["chemical_content"] = block["chemical_content"]

                    # Add to content_blocks (needed by analyze_content)
                    content_block = {
                        "text": cleaned_text,
                        "type": enhanced_block["type"],
                        "page": page_number,
                        "position": block.get("position")
                    }

                    if is_heading:
                        content_block["heading_level"] = heading_level

                        # Start a new section when we encounter a heading
                        if current_section_id:
                            # Save the previous section
                            sections[current_section_id] = "\n".join(current_section_content)

                        # Create new section ID (simple approach: use heading text)
                        current_section_id = f"section_{len(sections) + 1}_{cleaned_text[:20].replace(' ', '_')}"
                        current_section_content = [cleaned_text]
                    else:
                        # Add content to current section if there is one
                        if current_section_id:
                            current_section_content.append(cleaned_text)

                    # Add special content to content_block if available
                    if "math_expressions" in enhanced_block:
                        content_block["math_expressions"] = enhanced_block["math_expressions"]
                    if "chemical_content" in enhanced_block:
                        content_block["chemical_content"] = enhanced_block["chemical_content"]

                    content_blocks.append(content_block)
                    enhanced_page["blocks"].append(enhanced_block)
                    all_text.append(cleaned_text)

                # Group content by headings
                enhanced_page["structured_content"] = self._group_content_by_headings(
                    enhanced_page, 
                    respect_heading_levels=respect_heading_hierarchy
                )
                enhanced_pages.append(enhanced_page)

            # Save last section if it exists
            if current_section_id and current_section_content:
                sections[current_section_id] = "\n".join(current_section_content)

            # Update the result with enhanced pages
            enhanced_result["pages"] = enhanced_pages
            enhanced_result["text_content"] = "\n\n".join(all_text)

            # Add the expected keys for analyze_content
            enhanced_result["content_blocks"] = content_blocks
            enhanced_result["sections"] = sections

            # Close the document
            pdf_doc.close()

            return enhanced_result

        except Exception as e:
            self.logger.error(f"Error in enhanced extraction: {e}")
            import traceback
            traceback.print_exc()
            # Fall back to the original result if enhancement fails
            return raw_result
    
    def _preprocess_scanned_document(self, pdf_path, deskew=True, denoise=True, enhance_contrast=False, ocr_config=None):
        """
        Preprocess a scanned PDF document to improve extraction quality
        
        Args:
            pdf_path: Path to the PDF file
            deskew: Whether to deskew pages
            denoise: Whether to denoise images
            enhance_contrast: Whether to enhance contrast
            ocr_config: OCR configuration parameters
            
        Returns:
            Path to the processed PDF file
        """
        import cv2
        import numpy as np
        from PIL import Image, ImageEnhance
        import tempfile
        import os
        
        # Create temporary file for the processed PDF
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        output_path = temp_file.name
        temp_file.close()
        
        # Open the input PDF
        doc = fitz.open(pdf_path)
        output_doc = fitz.open()
        
        for page_idx, page in enumerate(doc):
            # Get the page as an image
            pix = page.get_pixmap()
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            img_np = np.array(img)
            
            # Apply image preprocessing if needed
            if deskew:
                # Convert to grayscale for deskewing
                gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)
                
                # Apply threshold to get binary image
                _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                
                # Find all contours
                contours, _ = cv2.findContours(binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
                
                # Find the largest contour - assume it's the text block
                if contours:
                    areas = [cv2.contourArea(c) for c in contours]
                    max_index = np.argmax(areas)
                    cnt = contours[max_index]
                    
                    # Find minimum area rectangle
                    rect = cv2.minAreaRect(cnt)
                    angle = rect[2]
                    
                    # Adjust angle - assumes text is horizontal or 90 degrees rotated
                    if angle < -45:
                        angle = 90 + angle
                    
                    # Only deskew if angle is significant
                    if abs(angle) > 0.5:
                        (h, w) = img_np.shape[:2]
                        center = (w // 2, h // 2)
                        M = cv2.getRotationMatrix2D(center, angle, 1.0)
                        img_np = cv2.warpAffine(img_np, M, (w, h), flags=cv2.INTER_CUBIC, 
                                              borderMode=cv2.BORDER_REPLICATE)
            
            # Apply denoising if needed
            if denoise:
                # Use Non-local Means Denoising algorithm
                img_np = cv2.fastNlMeansDenoisingColored(img_np, None, 10, 10, 7, 21)
            
            # Enhance contrast if needed
            if enhance_contrast:
                # Convert back to PIL for easier contrast enhancement
                img = Image.fromarray(img_np)
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(1.5)  # Increase contrast by 50%
                img_np = np.array(img)
            
            # Convert back to PIL image
            img = Image.fromarray(img_np)
            
            # Apply OCR if config provided
            if ocr_config:
                text = pytesseract.image_to_string(
                    img, 
                    config=f"-l {ocr_config.get('lang', 'eng')} --oem {ocr_config.get('oem', 3)} --psm {ocr_config.get('psm', 6)}"
                )
                
                # Create a new PDF page
                new_page = output_doc.new_page(width=pix.width, height=pix.height)
                
                # Add the image
                img_bytes = io.BytesIO()
                img.save(img_bytes, format="PNG")
                new_page.insert_image(rect=(0, 0, pix.width, pix.height), stream=img_bytes.getvalue())
                
                # Add the OCR text as invisible text for searchability
                if text:
                    new_page.insert_text((0, 0), text, fontsize=12, color=(0,0,0,0))  # Transparent text
            else:
                # Just add the processed image
                new_page = output_doc.new_page(width=pix.width, height=pix.height)
                img_bytes = io.BytesIO()
                img.save(img_bytes, format="PNG")
                new_page.insert_image(rect=(0, 0, pix.width, pix.height), stream=img_bytes.getvalue())
        
        # Save the processed document
        output_doc.save(output_path)
        output_doc.close()
        doc.close()
        
        return output_path
