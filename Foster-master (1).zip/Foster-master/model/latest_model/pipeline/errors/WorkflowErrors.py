"""
Workflow Error Classes
--------------------
Defines a structured error hierarchy for different types of workflow failures.
Enables more precise error handling and better diagnostics.
"""

from typing import Optional, Dict, Any, List


class WorkflowError(Exception):
    """Base class for all workflow-related errors"""
    
    def __init__(self, message: str, workflow_id: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        """
        Initialize workflow error.
        
        Args:
            message: Error message
            workflow_id: ID of the workflow that encountered the error
            details: Additional error details
        """
        super().__init__(message)
        self.workflow_id = workflow_id
        self.details = details or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert error to dictionary for serialization"""
        return {
            "error_type": self.__class__.__name__,
            "message": str(self),
            "workflow_id": self.workflow_id,
            "details": self.details
        }


# --- Input/Configuration Errors ---

class ConfigurationError(WorkflowError):
    """Error raised when there's an issue with the system or workflow configuration"""
    pass


class InvalidInputError(WorkflowError):
    """Error raised when workflow input is invalid or missing"""
    pass


class ResourceNotFoundError(WorkflowError):
    """Error raised when a required resource is not found"""
    
    def __init__(self, resource_type: str, resource_id: str, *args, **kwargs):
        """
        Initialize resource not found error.
        
        Args:
            resource_type: Type of resource (file, model, etc.)
            resource_id: Identifier for the resource
        """
        super().__init__(f"{resource_type} not found: {resource_id}", *args, **kwargs)
        self.resource_type = resource_type
        self.resource_id = resource_id
        self.details["resource_type"] = resource_type
        self.details["resource_id"] = resource_id


# --- PDF Extraction Errors ---

class PDFExtractionError(WorkflowError):
    """Base class for PDF extraction errors"""
    pass


class PDFParsingError(PDFExtractionError):
    """Error raised when PDF parsing fails"""
    pass


class OCRError(PDFExtractionError):
    """Error raised when OCR processing fails"""
    pass


class ContentExtractionError(PDFExtractionError):
    """Error raised when content extraction fails"""
    pass


# --- Content Analysis Errors ---

class ContentAnalysisError(WorkflowError):
    """Base class for content analysis errors"""
    pass


class DomainDetectionError(ContentAnalysisError):
    """Error raised when domain detection fails"""
    pass


class ContentStructuringError(ContentAnalysisError):
    """Error raised when content structuring fails"""
    pass


class SummarizationError(ContentAnalysisError):
    """Error raised when content summarization fails"""
    pass


# --- Multimedia Generation Errors ---

class MultimediaGenerationError(WorkflowError):
    """Base class for multimedia generation errors"""
    pass


class ScriptGenerationError(MultimediaGenerationError):
    """Error raised when script generation fails"""
    pass


class AnimationError(MultimediaGenerationError):
    """Error raised when animation generation fails"""
    pass


class AudioGenerationError(MultimediaGenerationError):
    """Error raised when audio generation fails"""
    pass


class VideoRenderingError(MultimediaGenerationError):
    """Error raised when video rendering fails"""
    pass


# --- Adaptive Learning Errors ---

class AdaptiveLearningError(WorkflowError):
    """Base class for adaptive learning errors"""
    pass


class StudentProfileError(AdaptiveLearningError):
    """Error raised when student profile operations fail"""
    pass


class LearningPathwayError(AdaptiveLearningError):
    """Error raised when learning pathway creation fails"""
    pass


# --- System/Resource Errors ---

class ResourceLimitError(WorkflowError):
    """Error raised when a resource limit is exceeded"""
    
    def __init__(self, resource_type: str, limit: Any, actual: Any, *args, **kwargs):
        """
        Initialize resource limit error.
        
        Args:
            resource_type: Type of resource (memory, CPU, etc.)
            limit: Resource limit
            actual: Actual resource usage
        """
        super().__init__(
            f"{resource_type} limit exceeded: {actual} > {limit}", 
            *args, **kwargs
        )
        self.resource_type = resource_type
        self.limit = limit
        self.actual = actual
        self.details.update({
            "resource_type": resource_type,
            "limit": str(limit),
            "actual": str(actual)
        })


class TimeoutError(WorkflowError):
    """Error raised when a workflow or step times out"""
    
    def __init__(self, operation: str, timeout: float, *args, **kwargs):
        """
        Initialize timeout error.
        
        Args:
            operation: The operation that timed out
            timeout: The timeout duration in seconds
        """
        super().__init__(f"{operation} timed out after {timeout} seconds", *args, **kwargs)
        self.operation = operation
        self.timeout = timeout
        self.details.update({
            "operation": operation,
            "timeout_seconds": timeout
        })


class ConcurrencyError(WorkflowError):
    """Error raised for concurrency-related issues"""
    pass


# --- Utility functions ---

def error_from_dict(error_dict: Dict[str, Any]) -> WorkflowError:
    """
    Create an error instance from a dictionary.
    
    Args:
        error_dict: Dictionary containing error information
        
    Returns:
        A WorkflowError instance
        
    Raises:
        ValueError: If the error type is not recognized
    """
    error_type = error_dict.get("error_type", "WorkflowError")
    message = error_dict.get("message", "Unknown error")
    workflow_id = error_dict.get("workflow_id")
    details = error_dict.get("details", {})
    
    # Get the error class by name
    error_classes = {cls.__name__: cls for cls in WorkflowError.__subclasses__()}
    
    # Add subclasses of subclasses
    for subcls in list(error_classes.values()):
        for subsub in subcls.__subclasses__():
            error_classes[subsub.__name__] = subsub
    
    # Create the error instance
    if error_type in error_classes:
        return error_classes[error_type](message, workflow_id=workflow_id, details=details)
    else:
        return WorkflowError(message, workflow_id=workflow_id, details=details) 