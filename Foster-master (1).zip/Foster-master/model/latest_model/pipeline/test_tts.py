"""
Test script for the TextToSpeech module.
This script creates a simple audio file using the TextToSpeechGenerator.
"""

import os
import sys
import json
import logging
from pathlib import Path

# Add parent directory to path to allow imports
current_dir = Path(__file__).parent
parent_dir = current_dir.parent
if str(parent_dir) not in sys.path:
    sys.path.append(str(parent_dir))

from multimedia.TextToSpeech import TextToSpeechGenerator

# Configure logging
logging.basicConfig(level=logging.DEBUG,  # Set to DEBUG for more detailed logs
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("TTSTest")

def main():
    logger.info("Starting TTS test")
    
    # Create output directory
    output_dir = os.path.join("output", "audio")
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"Output directory: {output_dir}")
    
    # Initialize the TTS generator
    logger.info("Initializing TTS generator")
    tts_generator = TextToSpeechGenerator(
        voice_id="professional",
        language_code="en-US",
        voice_speed=1.0,
        pitch=0,
        use_ssml=False
    )
    
    # Simple test text
    test_text = "This is a test of the text to speech system."
    logger.info(f"Test text: {test_text}")
    
    # Process the text
    logger.info("Processing text")
    processed_text = tts_generator._process_narration_text(test_text)
    logger.info(f"Processed text: {processed_text}")
    
    # Generate audio
    logger.info("Generating audio")
    audio_spec = tts_generator._generate_scene_audio(
        text=processed_text,
        scene_id="test_scene",
        scene_title="Test Scene"
    )
    
    # Check results
    if audio_spec.get("audio_file"):
        logger.info(f"Successfully generated audio: {audio_spec['audio_file']}")
        logger.info(f"Duration: {audio_spec['duration']:.2f} seconds")
    else:
        logger.error(f"Failed to generate audio: {audio_spec.get('error', 'Unknown error')}")

if __name__ == "__main__":
    main() 