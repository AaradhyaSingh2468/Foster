class BaseDomainProcessor:
    def __init__(self, domain_patterns=None, language_model=None):
        """
        Base class for domain-specific processors.
        
        Args:
            domain_patterns (dict): Patterns for the specific domain
            language_model: Optional pre-trained language model
        """
        self.domain_patterns = domain_patterns or {}
        self.language_model = language_model
    
    def process(self, extraction_result):
        """
        Process the extraction result with domain-specific logic.
        Should be implemented by subclasses.
        
        Args:
            extraction_result (dict): The extraction result from PDF processor
            
        Returns:
            Dictionary with domain-specific data
        """
        # Base implementation that returns a copy of the extraction result
        # Subclasses should override this method with domain-specific logic
        return extraction_result.copy() if hasattr(extraction_result, 'copy') else extraction_result


class PatternExtractor:
    """
    Utility class for extracting patterns from text content.
    """
    @staticmethod
    def extract_entities_by_pattern(text_content, pattern, group_indices=None):
        """
        Extract entities using regex pattern.
        
        Args:
            text_content (str): Text to extract from
            pattern: Regular expression pattern
            group_indices (tuple): Indices of groups to extract
            
        Returns:
            List of extracted entities
        """
        import re
        results = []
        
        for match in re.finditer(pattern, text_content):
            if group_indices:
                # Extract specific groups
                if len(group_indices) == 1:
                    # Single group extraction
                    entity = match.group(group_indices[0]).strip() if match.group(group_indices[0]) else ""
                    results.append(entity)
                else:
                    # Multiple group extraction as dictionary
                    entity = {}
                    for key, idx in group_indices.items():
                        entity[key] = match.group(idx).strip() if match.group(idx) else ""
                    results.append(entity)
            else:
                # Extract whole match
                results.append(match.group(0).strip())
                
        return results

class ScienceProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to scientific domains.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary with science-specific entities
        """
        scientific_entities = {
            'terminology': self.extract_scientific_terminology(extraction_result),
            'methods': self.identify_experiments_and_methods(extraction_result),
        }
        
        return scientific_entities
    
    def extract_scientific_terminology(self, extraction_result):
        """
        Extract scientific terms and classify by field.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary of scientific terminology by category
        """
        text_content = extraction_result.get('text_content', '')
        
        # Define common scientific terminology patterns
        scientific_terms = {
            'general': [],
            'methodology': [],
            'results': [],
            'concepts': []
        }
        
        # Lists of common scientific terms by category
        methodology_terms = ['experiment', 'method', 'procedure', 'protocol', 'analysis', 
                            'technique', 'assay', 'measurement', 'observation']
        
        result_terms = ['result', 'finding', 'data', 'evidence', 'observation', 
                       'outcome', 'conclusion', 'analysis', 'figure', 'table']
        
        concept_terms = ['theory', 'model', 'hypothesis', 'principle', 'law', 
                        'concept', 'framework', 'paradigm', 'mechanism']
        
        # Simple pattern matching for scientific terminology
        for term in methodology_terms:
            if term in text_content.lower():
                # Find the sentence containing the term
                sentences = text_content.replace('!', '.').replace('?', '.').split('.')
                for sentence in sentences:
                    if term in sentence.lower():
                        scientific_terms['methodology'].append(sentence.strip())
        
        for term in result_terms:
            if term in text_content.lower():
                sentences = text_content.replace('!', '.').replace('?', '.').split('.')
                for sentence in sentences:
                    if term in sentence.lower():
                        scientific_terms['results'].append(sentence.strip())
        
        for term in concept_terms:
            if term in text_content.lower():
                sentences = text_content.replace('!', '.').replace('?', '.').split('.')
                for sentence in sentences:
                    if term in sentence.lower():
                        scientific_terms['concepts'].append(sentence.strip())
        
        # Extract other scientific terms using patterns
        import re
        
        # Pattern for scientific terms (simplified)
        scientific_term_pattern = re.compile(r'(?i)([A-Z][a-z]+(?:ology|ography|ometry|onomy|physics|chemistry|ics))')
        matches = scientific_term_pattern.findall(text_content)
        
        scientific_terms['general'] = list(set(matches))
        
        return scientific_terms
    
    def identify_experiments_and_methods(self, extraction_result):
        """
        Identify experimental procedures and methods in the content.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary of identified experiments and methods
        """
        text_content = extraction_result.get('text_content', '')
        
        experiments_and_methods = {
            'experiments': [],
            'methods': [],
            'procedures': []
        }
        
        import re
        
        # Extract methods
        if 'method_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['method_pattern'], text_content):
                method_text = match.group(2).strip()
                experiments_and_methods['methods'].append(method_text)
        
        # Extract experiments
        if 'experiment_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['experiment_pattern'], text_content):
                experiment_text = match.group(2).strip()
                experiments_and_methods['experiments'].append(experiment_text)
        
        # Look for procedure keywords
        procedure_keywords = ['procedure', 'protocol', 'step', 'process']
        sentences = text_content.replace('!', '.').replace('?', '.').split('.')
        
        for sentence in sentences:
            if any(keyword in sentence.lower() for keyword in procedure_keywords):
                experiments_and_methods['procedures'].append(sentence.strip())
        
        return experiments_and_methods


class MathProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to mathematical domains.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary with math-specific entities
        """
        return {
            'mathematical_entities': self.extract_mathematical_entities(extraction_result),
            'problem_classifications': self.classify_math_problems(extraction_result)
        }
    
    def extract_mathematical_entities(self, extraction_result):
        """
        Extract theorems, formulas, proofs, and other mathematical entities.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary of mathematical entities by type
        """
        text_content = extraction_result.get('text_content', '')
        
        math_entities = {
            'theorems': [],
            'proofs': [],
            'equations': [],
            'definitions': []
        }
        
        # Extract theorems
        if 'theorem_pattern' in self.domain_patterns:
            theorem_group_indices = {'type': 1, 'name': 2, 'content': 3}
            math_entities['theorems'] = PatternExtractor.extract_entities_by_pattern(
                text_content, 
                self.domain_patterns['theorem_pattern'],
                theorem_group_indices
            )
        
        # Extract proofs
        if 'proof_pattern' in self.domain_patterns:
            math_entities['proofs'] = PatternExtractor.extract_entities_by_pattern(
                text_content, 
                self.domain_patterns['proof_pattern'],
                (1,)
            )
        
        # Extract equations
        if 'equation_pattern' in self.domain_patterns:
            equation_group_indices = {'number': lambda m: m.group(1) or m.group(2), 'content': 3}
            equations = PatternExtractor.extract_entities_by_pattern(
                text_content, 
                self.domain_patterns['equation_pattern'],
                equation_group_indices
            )
            math_entities['equations'] = equations
        
        # Extract definitions
        import re
        definition_pattern = re.compile(r'(?i)Definition\s*(\d+|[\w\s]+)?[:]\s*(.*?)(?=\n\n|\Z)')
        definition_group_indices = {'name': 1, 'content': 2}
        math_entities['definitions'] = PatternExtractor.extract_entities_by_pattern(
            text_content,
            definition_pattern,
            definition_group_indices
        )
        
        return math_entities

    
    def classify_math_problems(self, extraction_result):
        """
        Classify mathematical problems by type and difficulty.

        Args:
            extraction_result (dict): The extraction result

        Returns:
            Dictionary of classified mathematical problems
        """
        text_content = extraction_result.get('text_content', '')
        import re

        # Pattern to identify problems
        problem_pattern = re.compile(r'(?i)(?:Problem|Exercise|Question)\s*(\d+|[\w\s]+)?[:]\s*(.*?)(?=\n\n|\Z|Solution)')
        problem_group_indices = {'number': 1, 'text': 2}

        problems = PatternExtractor.extract_entities_by_pattern(
            text_content,
            problem_pattern,
            problem_group_indices
        )

        math_problems = []

        for problem in problems:
            problem_num = problem['number']
            problem_text = problem['text']

            # Try to find the solution if available
            solution_pattern = re.compile(f'(?i)Solution(?:\s*to\s*(?:Problem|Exercise|Question)?\s*{re.escape(problem_num) if problem_num else ""})?\s*[:]\s*(.*?)(?=\n\n|\Z|Problem|Exercise|Question)')
            solutions = PatternExtractor.extract_entities_by_pattern(
                text_content,
                solution_pattern,
                (1,)
            )

            solution_text = solutions[0] if solutions else ""

            # Classify problem type
            problem_type = self._classify_math_problem_type(problem_text)

            # Estimate difficulty
            difficulty = self._estimate_math_problem_difficulty(problem_text, solution_text)

            math_problems.append({
                'number': problem_num,
                'text': problem_text,
                'solution': solution_text,
                'type': problem_type,
                'difficulty': difficulty
            })

        return math_problems
    
    def _classify_math_problem_type(self, problem_text):
        """
        Classify the type of a mathematical problem.
        
        Args:
            problem_text (str): The text of the problem
            
        Returns:
            The type of the mathematical problem
        """
        problem_text = problem_text.lower()
        
        # Define keywords for different problem types
        type_keywords = {
            'algebra': ['solve', 'equation', 'polynomial', 'factor', 'simplify', 'expression'],
            'calculus': ['derivative', 'integral', 'differentiate', 'integrate', 'limit', 'maximize', 'minimize'],
            'geometry': ['triangle', 'circle', 'angle', 'polygon', 'rectangle', 'square', 'perimeter', 'area', 'volume'],
            'probability': ['probability', 'random', 'chance', 'likelihood', 'expected value', 'variance'],
            'statistics': ['mean', 'median', 'mode', 'standard deviation', 'normal distribution', 'variance'],
            'number theory': ['prime', 'divisor', 'factor', 'gcd', 'lcm', 'modulo', 'congruence'],
            'linear algebra': ['matrix', 'vector', 'eigenvalue', 'eigenvector', 'linear transformation'],
            'discrete math': ['graph', 'tree', 'network', 'combinatorial', 'permutation', 'combination']
        }
        
        # Count occurrences of each category's keywords
        type_scores = {category: 0 for category in type_keywords}
        
        for category, keywords in type_keywords.items():
            for keyword in keywords:
                if keyword in problem_text:
                    type_scores[category] += 1
        
        # Return the category with the highest score
        if any(type_scores.values()):
            return max(type_scores.items(), key=lambda x: x[1])[0]
        else:
            return 'general'
    
    def _estimate_math_problem_difficulty(self, problem_text, solution_text=""):
        """
        Estimate the difficulty level of a mathematical problem.
        
        Args:
            problem_text (str): The text of the problem
            solution_text (str): The text of the solution
            
        Returns:
            The estimated difficulty level (elementary, intermediate, advanced)
        """
        # Combine problem and solution for analysis
        combined_text = problem_text + " " + solution_text
        combined_text = combined_text.lower()
        
        # Define difficulty indicators
        elementary_indicators = ['basic', 'simple', 'elementary', 'straightforward', 'easy', 'find']
        advanced_indicators = ['complex', 'challenging', 'advanced', 'difficult', 'prove', 'proof', 'theorem', 'lemma']
        
        # Count advanced mathematical terms
        advanced_math_terms = ['eigenvalue', 'eigenvector', 'homomorphism', 'isomorphism', 'bijection',
                              'riemann', 'laplace', 'fourier', 'lebesgue', 'optimization', 'stochastic',
                              'differential equation', 'partial derivative', 'tensor', 'manifold', 'topology']
        
        # Count occurrences
        elementary_count = sum(indicator in combined_text for indicator in elementary_indicators)
        advanced_count = sum(indicator in combined_text for indicator in advanced_indicators)
        advanced_term_count = sum(term in combined_text for term in advanced_math_terms)
        
        # Text complexity heuristics
        word_count = len(combined_text.split())
        sentence_count = max(1, len(combined_text.split('.')))
        average_sentence_length = word_count / sentence_count
        
        # Decision logic for difficulty level
        if advanced_term_count >= 2 or advanced_count >= 3 or average_sentence_length > 25:
            return 'advanced'
        elif elementary_count > advanced_count or (word_count < 50 and advanced_term_count == 0):
            return 'elementary'
        else:
            return 'intermediate'


class LiteratureProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to literature domains by using the LiteraryWorkAnalyzer.

        Args:
            extraction_result (dict): The extraction result

        Returns:
            Dictionary with literature-specific entities
        """
        text_content = extraction_result.get('text_content', '')

        # Determine work type to use appropriate analyzer
        work_type = 'general'
        import re
        
        if 'shakespeare' in extraction_result.get('metadata', {}).get('title', '').lower() or 'shakespeare' in text_content.lower():
            work_type = 'play:shakespeare'
        elif re.search(r'([A-Z]{2,}[A-Z\s]*)[\.:]\s', text_content):
            work_type = 'play'
        elif re.search(r'Chapter [IVXLCDM]+|Chapter \d+', text_content):
            work_type = 'novel'

        # Use the dedicated LiteraryWorkAnalyzer
        literary_analyzer = LiteraryWorkAnalyzer(work_type)

        return {
            'literary_structure': literary_analyzer.identify_scenes(text_content),
            'literary_devices': literary_analyzer.detect_literary_devices(text_content)
        }


class ChemistryProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to chemistry domains.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary with chemistry-specific entities
        """
        text_content = extraction_result.get('text_content', '')
        import re
        
        compounds = set()
        reactions = []
        conditions = []
        
        # Extract compounds
        if 'compound_pattern' in self.domain_patterns:
            compounds = set(re.findall(self.domain_patterns['compound_pattern'], text_content))
            # Filter common false positives
            compounds = {c for c in compounds if len(c) > 1 and any(char.isdigit() for char in c)}
        
        # Extract reactions
        if 'reaction_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['reaction_pattern'], text_content):
                reactants = match.group(1).strip()
                products = match.group(2).strip()
                reactions.append({
                    'reactants': reactants,
                    'products': products,
                    'full_reaction': f"{reactants} → {products}"
                })
        
        # Extract conditions
        if 'condition_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['condition_pattern'], text_content):
                conditions.append(match.group(0))
        
        return {
            'compounds': list(compounds),
            'reactions': reactions,
            'reaction_conditions': conditions
        }


class BiologyProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to biology domains.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary with biology-specific entities
        """
        text_content = extraction_result.get('text_content', '')
        import re
        
        species = set()
        genes = set()
        pathways = set()
        
        # Extract species
        if 'species_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['species_pattern'], text_content):
                species_name = match.group(1)
                # Filter common false positives
                if len(species_name.split()) == 2 and all(len(word) > 1 for word in species_name.split()):
                    species.add(species_name)
        
        # Extract genes
        if 'gene_pattern' in self.domain_patterns:
            potential_genes = re.findall(self.domain_patterns['gene_pattern'], text_content)
            # Filter common false positives
            genes = {g for g in potential_genes if len(g) >= 2 and g.isupper()}
        
        # Extract pathways
        if 'pathway_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['pathway_pattern'], text_content):
                pathways.add(match.group(0))
        
        return {
            'species': list(species),
            'genes': list(genes),
            'biological_pathways': list(pathways)
        }


class PhysicsProcessor(BaseDomainProcessor):
    def process(self, extraction_result):
        """
        Process content specific to physics domains.
        
        Args:
            extraction_result (dict): The extraction result
            
        Returns:
            Dictionary with physics-specific entities
        """
        text_content = extraction_result.get('text_content', '')
        import re
        
        laws = set()
        physical_quantities = []
        equations = []
        
        # Extract physical laws
        if 'law_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['law_pattern'], text_content):
                laws.add(match.group(0))
        
        # Extract physical quantities with units
        if 'units_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['units_pattern'], text_content):
                value = match.group(1)
                unit = match.group(2)
                exponent = match.group(3) if match.group(3) else "1"
                
                physical_quantities.append({
                    'value': float(value),
                    'unit': unit,
                    'exponent': int(exponent),
                    'display': f"{value} {unit}{'' if exponent == '1' else f'^{exponent}'}"
                })
        
        # Extract equations
        if 'equation_pattern' in self.domain_patterns:
            for match in re.finditer(self.domain_patterns['equation_pattern'], text_content):
                equation_num = match.group(1) or match.group(2)
                equation_text = match.group(3)
                
                equations.append({
                    'equation_number': equation_num,
                    'equation_text': equation_text
                })
        
        return {
            'physical_laws': list(laws),
            'physical_quantities': physical_quantities,
            'physics_equations': equations
        }
