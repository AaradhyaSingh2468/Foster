class DomainRulesManager:
    """Centralized manager for domain-specific rules and patterns"""
    
    @staticmethod
    def get_domain_rules(domain):
        """
        Load domain-specific rules and patterns for content analysis.
        
        Args:
            domain: The domain to load rules for
            
        Returns:
            Dictionary of rules and patterns specific to the domain
        """
        import re
        
        if domain is None:
            return {}
            
        # Consolidated domain rules
        domain_rules = {
            'science': {
                'terminologies': ['experiment', 'hypothesis', 'theory', 'data'],
                'section_types': ['methodology', 'results', 'discussion', 'conclusion'],
                'entity_patterns': [r'[A-Z][a-z]+ [a-z]+ium', r'\d+\.\d+ [a-z]+'],
                'method_pattern': re.compile(r'(?i)(methods?|procedure|protocol)[:]\s*(.*?)(?=\n\n|\Z)'),
                'result_pattern': re.compile(r'(?i)(results?|findings)[:]\s*(.*?)(?=\n\n|\Z)'),
                'experiment_pattern': re.compile(r'(?i)(experiment|study|investigation)[\s\d]*[:]\s*(.*?)(?=\n\n|\Z)')
            },
            'math': {
                'terminologies': ['theorem', 'proof', 'lemma', 'corollary'],
                'section_types': ['definition', 'theorem', 'proof', 'example'],
                'entity_patterns': [r'[A-Z][a-z]+ (theorem|formula|equation)', r'equation \(\d+\)'],
                'theorem_pattern': re.compile(r'(?i)(theorem|lemma|corollary|proposition)\s*(\d+|[\w\s]+)[:]\s*(.*?)(?=\n\n|\Z|proof)'),
                'proof_pattern': re.compile(r'(?i)proof[:]\s*(.*?)(?=\n\n|\Z|q\.e\.d\.|□)'),
                'equation_pattern': re.compile(r'(?i)(?:\((\d+)\)|equation\s*(\d+))[:]\s*(.*?)(?=\n\n|\Z)')
            },
            'literature': {
                'terminologies': ['symbolism', 'metaphor', 'character', 'plot', 'theme', 'motif', 'foreshadowing', 'irony', 'allegory', 'setting'],
                'section_types': ['exposition', 'climax', 'resolution', 'analysis', 'chapter', 'prologue', 'epilogue', 'act', 'scene', 'soliloquy'],
                'entity_patterns': [
                    r'[A-Z][a-z]+ (symbolizes|represents)', 
                    r'theme of [a-z]+', 
                    r'Chapter [IVXLCDM]+', 
                    r'Chapter \d+',
                    r'Act [IVXLCDM]+', 
                    r'Scene [IVXLCDM]+', 
                    r'Enter [A-Z][a-z]+', 
                    r'\[Exit[^\]]*\]', 
                    r'\[Aside\]'
                ],
                'character_pattern': re.compile(r'(?i)([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)[:]\s*["\'](.+?)["\']'),
                'theme_pattern': re.compile(r'(?i)(theme|motif|symbol)[\s\w]*[:]\s*(.*?)(?=\n\n|\Z)'),
                'plot_pattern': re.compile(r'(?i)(exposition|rising action|climax|falling action|resolution)[:]\s*(.*?)(?=\n\n|\Z)'),
                'subtypes': {
                    'play': {
                        'shakespeare': {
                            'terminologies': ['soliloquy', 'aside', 'iambic pentameter', 'sonnet', 'blank verse', 'couplet', 'quatrain', 'folio', 'quarto'],
                            'themes': ['power_corruption', 'love_romance', 'betrayal', 'appearance_reality', 'supernatural', 'order_chaos', 'revenge']
                        },
                        'modern': {
                            'terminologies': ['dialogue', 'stage direction', 'monologue', 'act', 'scene']
                        }
                    },
                    'novel': {
                        'terminologies': ['narrator', 'protagonist', 'antagonist', 'setting', 'plot', 'chapter']
                    },
                    'poem': {
                        'terminologies': ['stanza', 'verse', 'rhyme', 'meter', 'rhythm', 'sonnet', 'ode', 'elegy']
                    }
                }
            },
            'chemistry': {
                'compound_pattern': re.compile(r'(?i)([A-Z][a-z]?\d*)+'),
                'reaction_pattern': re.compile(r'(?i)(.+?)\s*(?:→|⟶|⇒|⇌|⇆)\s*(.+)'),
                'condition_pattern': re.compile(r'(?i)(?:at|under|in)\s+(\d+(?:\.\d+)?)\s*(?:°C|K|atm|bar|MPa|kPa)')
            },
            'biology': {
                'species_pattern': re.compile(r'(?i)([A-Z][a-z]+\s+[a-z]+)'),
                'gene_pattern': re.compile(r'(?i)([A-Z0-9]+)(?:\s+gene)?'),
                'pathway_pattern': re.compile(r'(?i)([\w\s]+)(?:pathway|cycle|cascade)')
            },
            'physics': {
                'law_pattern': re.compile(r'(?i)([\w\s]+)(?:\'s)?\s+(?:law|principle|theory)'),
                'units_pattern': re.compile(r'(\d+(?:\.\d+)?)\s*(m|kg|s|A|K|mol|cd|N|Pa|J|W|V)(?:\^?(-?\d+))?'),
                'equation_pattern': re.compile(r'(?i)(?:\((\d+)\)|equation\s*(\d+))[:]\s*(.*?)(?=\n\n|\Z)')
            }
        }
        
        return domain_rules.get(domain.lower(), {})
