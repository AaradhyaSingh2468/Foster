"""
Adaptive Learning Manager
------------------------
Main integration module that connects:
- PDF Extraction Pipeline
- Student Profile Management
- Adaptive Learning Pathway Generation
- Content Personalization
"""

import os
import json
from typing import Dict, List, Any, Optional, Union
from datetime import datetime

# Import core components
from pipeline.content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
from pipeline.adaptive_learning.StudentProfileManager import StudentProfileManager
from pipeline.adaptive_learning.AdaptiveLearningPathway import AdaptiveLearningPathwayGenerator, AdaptiveLearningPathway

class PersonalizedLearningSession:
    """Represents an active learning session for a student"""
    
    def __init__(self, student_id: str, document_id: str, pathway: AdaptiveLearningPathway):
        """
        Initialize a learning session
        
        Args:
            student_id: ID of the student
            document_id: ID of the document being studied
            pathway: The personalized learning pathway
        """
        self.student_id = student_id
        self.document_id = document_id
        self.pathway = pathway
        self.current_node_id = None
        self.session_start = datetime.now().isoformat()
        self.last_activity = self.session_start
        self.completed_nodes = []
        self.interaction_history = []
        
    def start_node(self, node_id: str):
        """
        Begin studying a specific node
        
        Args:
            node_id: ID of the node to start
        """
        self.current_node_id = node_id
        self.last_activity = datetime.now().isoformat()
        self.interaction_history.append({
            "timestamp": self.last_activity,
            "action": "start_node",
            "node_id": node_id
        })
        
    def complete_node(self, node_id: str, performance: Optional[float] = None):
        """
        Mark a node as completed
        
        Args:
            node_id: ID of the completed node
            performance: Optional performance metric (0-1)
        """
        self.pathway.update_progress(node_id, 100)
        self.last_activity = datetime.now().isoformat()
        
        if node_id not in self.completed_nodes:
            self.completed_nodes.append(node_id)
            
        self.interaction_history.append({
            "timestamp": self.last_activity,
            "action": "complete_node",
            "node_id": node_id,
            "performance": performance
        })
        
    def get_next_node(self) -> Dict[str, Any]:
        """
        Get the recommended next node
        
        Returns:
            Dictionary with next node information
        """
        next_nodes = self.pathway.get_next_nodes()
        
        if not next_nodes:
            return {"completed": True, "progress": self.pathway.get_overall_progress()}
            
        # Sophisticated logic for selecting the most appropriate next node
        if len(next_nodes) == 1:
            next_node = next_nodes[0]
        else:
            # Get student profile to personalize selection
            try:
                profile_manager = StudentProfileManager()
                profile = profile_manager.get_profile(self.student_id)
                
                # Initialize scoring for each potential next node
                node_scores = {}
                
                for node in next_nodes:
                    score = 0
                    
                    # Factor 1: Match difficulty to student's current proficiency
                    if profile and hasattr(profile, 'get_proficiency'):
                        node_topic = node.title.split()[0] if node.title else ""
                        student_proficiency = profile.get_proficiency(node_topic) or 0.5
                        
                        # Adjust score based on how well difficulty matches proficiency
                        # Convert difficulty string to numeric value if needed
                        difficulty_value = {"beginner": 0.3, "intermediate": 0.6, "advanced": 0.9}.get(
                            node.difficulty.lower() if isinstance(node.difficulty, str) else 0.5, 0.5)
                        
                        # Prefer content that's slightly challenging but not too difficult
                        difficulty_match = 1.0 - abs(difficulty_value - (student_proficiency + 0.1))
                        score += difficulty_match * 3  # Weight: 3
                    
                    # Factor 2: Consider learning style preference
                    if profile and hasattr(profile, 'learning_style'):
                        learning_style = getattr(profile, 'learning_style', {})
                        
                        # Match content type to preferred learning style
                        if node.content_type == "visual" and learning_style.get("visual", 0) > 0.5:
                            score += 2
                        elif node.content_type == "text" and learning_style.get("textual", 0) > 0.5:
                            score += 2
                        elif node.content_type == "interactive" and learning_style.get("interactive", 0) > 0.5:
                            score += 2
                    
                    # Factor 3: Consider prerequisite relationships
                    prerequisite_completion = 0
                    if hasattr(node, 'prerequisites'):
                        prerequisites = getattr(node, 'prerequisites', [])
                        if prerequisites:
                            completed_prereqs = [p for p in prerequisites if p in self.completed_nodes]
                            prerequisite_completion = len(completed_prereqs) / len(prerequisites)
                    score += prerequisite_completion * 4  # Weight: 4
                    
                    # Factor 4: Prioritize nodes related to recent completions for continuity
                    if self.interaction_history and hasattr(node, 'related_to'):
                        recent_interactions = self.interaction_history[-3:]
                        recent_nodes = [i["node_id"] for i in recent_interactions if "node_id" in i]
                        related_nodes = getattr(node, 'related_to', [])
                        
                        if any(r_node in recent_nodes for r_node in related_nodes):
                            score += 2  # Continuity bonus
                    
                    # Store the calculated score
                    node_scores[node.content_id] = score
                
                # Select the node with the highest score
                if node_scores:
                    best_node_id = max(node_scores, key=node_scores.get)
                    next_node = next((n for n in next_nodes if n.content_id == best_node_id), next_nodes[0])
                else:
                    next_node = next_nodes[0]  # Fallback to first node if scoring fails
            except Exception as e:
                # Fallback to simple selection if there's an error in the sophisticated logic
                print(f"Error in node selection: {e}. Falling back to simple selection.")
                next_node = next_nodes[0]
        
        self.current_node_id = next_node.content_id
        return {
            "node_id": next_node.content_id,
            "title": next_node.title,
            "content_type": next_node.content_type,
            "difficulty": next_node.difficulty,
            "alternatives": next_node.alternatives,
            "estimated_time": next_node.estimated_time
        }
        
    def get_session_stats(self) -> Dict[str, Any]:
        """
        Get session statistics
        
        Returns:
            Dictionary with session stats
        """
        completed_count = len(self.completed_nodes)
        total_nodes = len(self.pathway.nodes)
        current_time = datetime.now().isoformat()
        
        # Calculate session duration
        start_time = datetime.fromisoformat(self.session_start)
        current = datetime.fromisoformat(current_time)
        duration_minutes = (current - start_time).total_seconds() / 60
        
        return {
            "student_id": self.student_id,
            "document_id": self.document_id,
            "started_at": self.session_start,
            "duration_minutes": round(duration_minutes, 1),
            "completed_nodes": completed_count,
            "total_nodes": total_nodes,
            "progress_percentage": self.pathway.get_overall_progress(),
            "current_node": self.current_node_id
        }
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert session to dictionary"""
        return {
            "student_id": self.student_id,
            "document_id": self.document_id,
            "pathway": self.pathway.to_dict(),
            "current_node_id": self.current_node_id,
            "session_start": self.session_start,
            "last_activity": self.last_activity,
            "completed_nodes": self.completed_nodes,
            "interaction_history": self.interaction_history
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PersonalizedLearningSession':
        """Create session from dictionary"""
        pathway = AdaptiveLearningPathway.from_dict(data["pathway"])
        
        session = cls(
            student_id=data["student_id"],
            document_id=data["document_id"],
            pathway=pathway
        )
        
        session.current_node_id = data.get("current_node_id")
        session.session_start = data.get("session_start", session.session_start)
        session.last_activity = data.get("last_activity", session.last_activity)
        session.completed_nodes = data.get("completed_nodes", [])
        session.interaction_history = data.get("interaction_history", [])
        
        return session

class AdaptiveLearningManager:
    """Main manager class for adaptive learning integration"""
    
    def __init__(self, domain: str = None, 
               storage_dir: str = "adaptive_learning",
               profile_manager: StudentProfileManager = None,
               pipeline: ContentAnalysisPipeline = None):
        """
        Initialize the adaptive learning manager
        
        Args:
            domain: Optional domain specification
            storage_dir: Directory for storing adaptive learning data
            profile_manager: Optional StudentProfileManager instance
            pipeline: Optional ContentAnalysisPipeline instance
        """
        self.domain = domain
        self.storage_dir = storage_dir
        self.profile_manager = profile_manager or StudentProfileManager()
        self.pipeline = pipeline or ContentAnalysisPipeline(domain=domain)
        self.pathway_generator = AdaptiveLearningPathwayGenerator()
        
        # Create storage directories
        os.makedirs(storage_dir, exist_ok=True)
        os.makedirs(os.path.join(storage_dir, "documents"), exist_ok=True)
        os.makedirs(os.path.join(storage_dir, "sessions"), exist_ok=True)
        
        # Active learning sessions
        self.active_sessions = {}
        
    def process_document(self, pdf_path: str, output_dir: str = None) -> str:
        """
        Process a document for adaptive learning
        
        Args:
            pdf_path: Path to PDF file
            output_dir: Optional output directory
            
        Returns:
            Document ID
        """
        # Generate document ID from filename
        document_id = os.path.splitext(os.path.basename(pdf_path))[0]
        
        # Set output directory
        if not output_dir:
            output_dir = os.path.join(self.storage_dir, "documents", document_id)
            
        # Process document with analysis pipeline
        result = self.pipeline.process_document(
            pdf_path=pdf_path,
            output_dir=output_dir,
            extract_images=True,
            extract_tables=True,
            respect_heading_hierarchy=True
        )
        
        # Save processed document
        self._save_processed_document(document_id, result)
        
        return document_id
        
    def create_personalized_pathway(self, student_id: str, document_id: str, 
                                 target_concepts: List[str] = None) -> str:
        """
        Create a personalized learning pathway
        
        Args:
            student_id: ID of the student
            document_id: ID of the processed document
            target_concepts: Optional list of concepts to focus on
            
        Returns:
            Session ID for the created pathway
        """
        # Get student profile
        profile = self.profile_manager.get_student_profile(student_id)
        
        if not profile:
            # Create a default profile if not found
            profile = self.profile_manager.create_student_profile(student_id)
            
        # Load processed document
        document = self._load_processed_document(document_id)
        
        if not document:
            raise ValueError(f"Document {document_id} not found")
            
        # Generate adaptive pathway
        pathway = self.pathway_generator.generate_pathway(
            profile=profile,
            content_structure=document,
            target_concepts=target_concepts
        )
        
        # Create a learning session
        session_id = f"{student_id}_{document_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        session = PersonalizedLearningSession(
            student_id=student_id,
            document_id=document_id,
            pathway=pathway
        )
        
        # Save and activate session
        self._save_session(session_id, session)
        self.active_sessions[session_id] = session
        
        return session_id
        
    def get_next_content(self, session_id: str) -> Dict[str, Any]:
        """
        Get the next content recommendation for a session
        
        Args:
            session_id: ID of the learning session
            
        Returns:
            Dictionary with next content information
        """
        session = self._get_session(session_id)
        
        if not session:
            raise ValueError(f"Session {session_id} not found")
            
        return session.get_next_node()
        
    def complete_content(self, session_id: str, node_id: str, 
                      performance: Optional[float] = None) -> Dict[str, Any]:
        """
        Mark content as completed
        
        Args:
            session_id: ID of the learning session
            node_id: ID of the completed content node
            performance: Optional performance metric (0-1)
            
        Returns:
            Updated session status
        """
        session = self._get_session(session_id)
        
        if not session:
            raise ValueError(f"Session {session_id} not found")
            
        # Mark node as completed
        session.complete_node(node_id, performance)
        
        # Update student profile with learning activity
        profile = self.profile_manager.get_profile(session.student_id)
        
        if profile:
            # Find the node in the pathway
            node = next((n for n in session.pathway.nodes if n.content_id == node_id), None)
            
            if node:
                # Record learning activity
                profile.record_learning_activity(
                    material_id=node_id,
                    activity_type=node.content_type,
                    performance=performance,
                    time_spent=node.estimated_time
                )
                
                # Extract concepts from the node title
                concepts = node.title.split()
                
                # Update knowledge areas if performance was provided
                if performance is not None:
                    for concept in concepts:
                        if len(concept) > 3:
                            profile.update_knowledge_area(
                                domain=self.domain or "general",
                                topic=concept,
                                proficiency=performance
                            )
                
                # Save updated profile
                self.profile_manager.save_profile(profile)
        
        # Save session
        self._save_session(session_id, session)
        
        # Return current session status
        return session.get_session_stats()
        
    def get_session_status(self, session_id: str) -> Dict[str, Any]:
        """
        Get current session status
        
        Args:
            session_id: ID of the learning session
            
        Returns:
            Dictionary with session status
        """
        session = self._get_session(session_id)
        
        if not session:
            raise ValueError(f"Session {session_id} not found")
            
        return session.get_session_stats()
        
    def personalize_content(self, content: str, student_id: str, 
                         difficulty: Optional[str] = None) -> str:
        """
        Personalize content for a specific student
        
        Args:
            content: The content to personalize
            student_id: ID of the student
            difficulty: Optional difficulty override
            
        Returns:
            Personalized content
        """
        profile = self.profile_manager.get_student_profile(student_id)
        
        if not profile:
            # Return original content if no profile found
            return content
            
        # Determine appropriate difficulty
        if not difficulty:
            difficulty = profile.get_recommended_difficulty()
            
        # Personalize content based on difficulty
        personalized = self._adapt_content_difficulty(content, difficulty)
        
        # Further personalize based on learning style
        learning_style = profile.learning_style
        
        # For visual learners, add more visual cues
        if learning_style.get("visual", 0) > 0.6:
            personalized = self._enhance_visual_elements(personalized)
            
        # For textual learners, add more detailed explanations
        if learning_style.get("textual", 0) > 0.6:
            personalized = self._enhance_textual_elements(personalized)
            
        # For interactive learners, add interactive prompts
        if learning_style.get("interactive", 0) > 0.6:
            personalized = self._add_interactive_elements(personalized)
            
        return personalized
        
    def _adapt_content_difficulty(self, content: str, difficulty: str) -> str:
        """
        Adapt content to specified difficulty level
        
        Args:
            content: Original content
            difficulty: Target difficulty level
            
        Returns:
            Adapted content
        """
        # Real implementation using NLP text simplification techniques
        import re
        from nltk.tokenize import sent_tokenize, word_tokenize
        from nltk.corpus import wordnet
        
        try:
            # Handle different difficulty levels
            if difficulty == "simple":
                # Text simplification for beginners
                sentences = sent_tokenize(content)
                simplified_sentences = []
                
                for sentence in sentences:
                    # Shorten long sentences
                    if len(word_tokenize(sentence)) > 20:
                        # Split into smaller sentences where possible
                        parts = re.split(r'[,;:]', sentence)
                        if len(parts) > 1:
                            simplified_sentences.extend([p.strip() + '.' for p in parts if p.strip()])
                            continue
                    
                    # Simplify vocabulary where possible
                    words = word_tokenize(sentence)
                    simplified_words = []
                    
                    for word in words:
                        if len(word) > 7 and word.isalpha():  # Only attempt to simplify longer words
                            # Try to find simpler synonyms
                            synonyms = []
                            for syn in wordnet.synsets(word):
                                for lemma in syn.lemmas():
                                    if lemma.name() != word and len(lemma.name()) < len(word):
                                        synonyms.append(lemma.name())
                            
                            if synonyms:
                                # Use the shortest synonym as a simpler alternative
                                shortest = min(synonyms, key=len)
                                simplified_words.append(shortest)
                                continue
                        
                        simplified_words.append(word)
                    
                    # Reconstruct the sentence
                    simplified_sentence = ' '.join(simplified_words)
                    simplified_sentences.append(simplified_sentence)
                
                # Add explanatory notes for complex concepts
                simplified_content = ' '.join(simplified_sentences)
                
                # Add beginner-friendly annotations
                simplified_content = re.sub(r'([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b(?!\s+is|\s+are|\s+were|\s+was)', 
                                          r'\1 (a key concept)', 
                                          simplified_content)
                
                return simplified_content
                
            elif difficulty == "intermediate":
                # Keep mostly original but add some clarifications
                sentences = sent_tokenize(content)
                intermediate_sentences = []
                
                for sentence in sentences:
                    # Add examples for complex statements
                    if len(word_tokenize(sentence)) > 15:
                        sentence += " This means it applies in real-world contexts."
                    intermediate_sentences.append(sentence)
                
                return ' '.join(intermediate_sentences)
                
            elif difficulty == "advanced":
                # Enhance content with more depth
                sentences = sent_tokenize(content)
                advanced_sentences = []
                
                for i, sentence in enumerate(sentences):
                    advanced_sentences.append(sentence)
                    
                    # Add additional context every few sentences
                    if i % 3 == 2:
                        advanced_sentences.append("This concept connects to broader theoretical frameworks in the field.")
                    
                    # Introduce advanced terminology
                    words = word_tokenize(sentence)
                    for word in words:
                        if len(word) > 5 and word.isalpha():
                            # Look for more specialized terminology
                            for syn in wordnet.synsets(word):
                                for lemma in syn.lemmas():
                                    if lemma.name() != word and len(lemma.name()) > len(word):
                                        advanced_sentences.append(f"Note that {word} can also be referred to as {lemma.name()} in specialized contexts.")
                                        break
                                break
                
                return ' '.join(advanced_sentences)
            
            # Return standard content as is for unknown difficulty levels
            return content
            
        except ImportError:
            # Fallback if NLTK is not available
            print("Warning: NLTK not available. Using simple text modifications instead.")
            if difficulty == "simple":
                return f"[Simplified for beginners] {content}"
            elif difficulty == "advanced":
                return f"[Enhanced with advanced details] {content}"
            return content
        except Exception as e:
            print(f"Error during content difficulty adaptation: {e}")
            return content
    
    def _enhance_visual_elements(self, content: str) -> str:
        """Add visual cues to content for visual learners"""
        try:
            from bs4 import BeautifulSoup
            import re
            import random
            
            # Check if content is HTML
            if "<" in content and ">" in content:
                # Parse HTML
                soup = BeautifulSoup(content, 'html.parser')
                
                # Add color highlighting to key terms
                for p in soup.find_all('p'):
                    text = p.get_text()
                    # Find likely key terms (capitalized words, technical terms)
                    key_terms = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', text)
                    for term in key_terms:
                        # Don't replace text inside tags
                        if term in p.get_text(strip=True):
                            highlighted = soup.new_tag('span')
                            highlighted['style'] = 'background-color: #FFFACD; font-weight: bold;'
                            highlighted.string = term
                            # Replace only in text nodes, not in existing tags
                            text_nodes = list(p.find_all(text=True))
                            for text_node in text_nodes:
                                if term in text_node:
                                    new_content = text_node.replace(term, str(highlighted))
                                    text_node.replace_with(BeautifulSoup(new_content, 'html.parser'))
                                    break
                
                # Add margin notes with visual cues
                sections = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p'])
                for section in sections:
                    if section.name.startswith('h'):
                        note = soup.new_tag('div')
                        note['class'] = 'visual-note'
                        note['style'] = 'border-left: 4px solid #3498db; padding-left: 15px; margin: 10px 0;'
                        icon = soup.new_tag('span')
                        icon['style'] = 'font-size: 20px; color: #3498db; margin-right: 10px;'
                        icon.string = '🔍'
                        note.append(icon)
                        note_text = soup.new_tag('span')
                        note_text.string = f"Visual summary: {section.get_text()}"
                        note.append(note_text)
                        section.insert_after(note)
                
                # Add diagram placeholders
                content_sections = soup.find_all('p')
                if content_sections and len(content_sections) > 2:
                    selected_section = content_sections[len(content_sections) // 2]
                    
                    # Extract key concepts for diagram generation
                    key_concepts = set()
                    for p in content_sections:
                        # Find capitalized terms and technical terms
                        concepts = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', p.get_text())
                        for concept in concepts:
                            if len(concept) > 3:  # Filter out short terms
                                key_concepts.add(concept)
                    
                    # Generate actual diagram using SVG
                    if key_concepts:
                        # Convert set to list for indexing
                        key_concepts_list = list(key_concepts)[:5]  # Limit to 5 concepts
                        
                        # Create diagram container
                        diagram = soup.new_tag('div')
                        diagram['class'] = 'content-diagram'
                        diagram['style'] = 'margin: 25px 0; text-align: center;'
                        
                        # Generate SVG diagram
                        svg_code = self._generate_concept_diagram(key_concepts_list)
                        
                        # Add diagram title
                        title = soup.new_tag('h4')
                        title.string = "Concept Relationship Diagram"
                        diagram.append(title)
                        
                        # Add SVG diagram
                        diagram.append(BeautifulSoup(svg_code, 'html.parser'))
                        
                        # Add diagram description
                        description = soup.new_tag('p')
                        description['style'] = 'font-style: italic; margin-top: 10px; font-size: 0.9em;'
                        description.string = f"This diagram shows relationships between key concepts: {', '.join(key_concepts_list)}"
                        diagram.append(description)
                        
                        selected_section.insert_after(diagram)
                    else:
                        # Fallback if no concepts found
                        diagram = soup.new_tag('div')
                        diagram['class'] = 'content-diagram'
                        diagram['style'] = 'border: 1px dashed #ccc; padding: 15px; text-align: center; margin: 15px 0;'
                        diagram.string = "Diagram visualization showing concept relationships (no concepts were detected in this content)"
                        selected_section.insert_after(diagram)
                
                # Return the modified HTML
                return str(soup)
            else:
                # Text-only content
                # Add emoji indicators for structure
                structured_content = []
                lines = content.split('\n')
                for line in lines:
                    if line.strip():
                        if line.strip()[0].isupper() and len(line.strip()) < 50:
                            # Likely a heading
                            structured_content.append(f"📌 {line}")
                        elif ":" in line and len(line.split(':')[0]) < 20:
                            # Likely a definition
                            structured_content.append(f"📝 {line}")
                        elif len(line) > 100:
                            # Long paragraph - add a visual separator
                            structured_content.append(f"{line}\n{'─' * 40}")
                        else:
                            structured_content.append(line)
                
                # Add visualization prompts
                visual_cues = [
                    "\n🔄 Try to visualize this as a flowchart",
                    "\n📊 Imagine this data in a bar chart format",
                    "\n🗺️ Picture this as a concept map"
                ]
                
                # Add visual cues at strategic points
                enhanced_content = '\n'.join(structured_content)
                paragraphs = enhanced_content.split('\n\n')
                if len(paragraphs) > 1:
                    for i in range(1, len(paragraphs), 2):
                        if i < len(paragraphs):
                            paragraphs[i] += random.choice(visual_cues)
                    
                    enhanced_content = '\n\n'.join(paragraphs)
                
                return enhanced_content
        except ImportError:
            print("Warning: BeautifulSoup not available. Using simple visual enhancements.")
            return f"[Enhanced with visual elements]\n\n{content}\n\n[Visualization aids would appear here]"
        except Exception as e:
            print(f"Error during visual enhancement: {e}")
            return content
    
    def _enhance_textual_elements(self, content: str) -> str:
        """Add detailed explanations for textual learners"""
        try:
            from nltk.tokenize import sent_tokenize, word_tokenize
            import re
            
            # Break content into segments
            sentences = sent_tokenize(content)
            enhanced_sentences = []
            
            # Identify key concepts and add explanations
            key_concepts = {}
            for sentence in sentences:
                # Look for potential key concepts (capitalized multi-word phrases or technical terms)
                concept_matches = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', sentence)
                technical_matches = re.findall(r'\b([a-z]+(?:[-_][a-z]+)+)\b', sentence)
                
                for concept in concept_matches + technical_matches:
                    if concept not in key_concepts:
                        # Implement concept definition lookup from knowledge base
                        definition = self._lookup_concept_definition(concept)
                        key_concepts[concept] = definition
            
            # Enhance sentence structure for better comprehension
            for i, sentence in enumerate(sentences):
                enhanced_sentences.append(sentence)
                
                # Add explanatory notes for complex sentences
                words = word_tokenize(sentence)
                if len(words) > 20:
                    enhanced_sentences.append(f"To clarify: this means {' '.join(words[:10])}... and then {' '.join(words[-10:])}.")
                
                # Add elaborations for any key concepts in this sentence
                for concept, explanation in key_concepts.items():
                    if concept in sentence:
                        enhanced_sentences.append(f"Note: {concept} - {explanation}")
                
                # Add transitional phrases between groups of sentences
                if i > 0 and i % 3 == 0 and i < len(sentences) - 1:
                    transitional_phrases = [
                        "Building on these ideas,",
                        "To expand this concept further,",
                        "The following points elaborate on this:",
                        "Let's explore this in more depth:"
                    ]
                    import random
                    enhanced_sentences.append(random.choice(transitional_phrases))
            
            # Add summary sections
            if len(sentences) > 5:
                summary_sections = []
                
                # Create summary sections for every 5-7 sentences
                for i in range(0, len(sentences), 6):
                    section = sentences[i:i+6]
                    if section:
                        # Extract key phrases from the section
                        section_text = ' '.join(section)
                        key_phrases = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', section_text)
                        
                        if key_phrases:
                            # Generate a summary using key phrases (simulated)
                            unique_phrases = list(set(key_phrases))[:3]  # Take up to 3 unique phrases
                            summary = "Section Summary: This part discusses " + ", ".join(unique_phrases) + "."
                            summary_sections.append(summary)
                
                # Insert summaries at appropriate positions
                if summary_sections:
                    enhanced_content = ' '.join(enhanced_sentences)
                    paragraphs = enhanced_content.split('\n\n')
                    
                    if len(paragraphs) >= len(summary_sections):
                        # Insert each summary at the end of a paragraph
                        for i, summary in enumerate(summary_sections):
                            if i < len(paragraphs):
                                paragraphs[i] += "\n\n" + summary
                        
                        return '\n\n'.join(paragraphs)
            
            # Return enhanced content
            return ' '.join(enhanced_sentences)
            
        except ImportError:
            print("Warning: NLTK not available. Using simple text enhancements.")
            return f"{content}\n\nAdditional explanations and clarifications for textual learners (NLTK library required)"
        except Exception as e:
            print(f"Error during textual enhancement: {e}")
            return content
    
    def _add_interactive_elements(self, content: str) -> str:
        """Add interactive elements for interactive learners"""
        try:
            import re
            from nltk.tokenize import sent_tokenize
            
            sentences = sent_tokenize(content)
            
            # Generate interactive content components
            interactive_components = []
            
            # 1. Create check-your-understanding questions
            if len(sentences) >= 3:
                # Extract potential questions from content
                question_candidates = []
                
                for sentence in sentences:
                    # Look for sentences that contain facts or definitions
                    if re.search(r'\bis\b|\bare\b|\bwas\b|\bwere\b', sentence) and len(sentence) > 30:
                        # Turn statement into question
                        question = None
                        
                        # Extract subject-predicate structure for factual sentences
                        match = re.match(r'^([^,\.]+)\s+(is|are|was|were)\s+([^,\.]+)', sentence)
                        if match:
                            subject, verb, predicate = match.groups()
                            question = f"What {verb} {subject}?"
                            answer = predicate
                            question_candidates.append((question, answer, sentence))
                
                # Select a subset of questions to include
                if question_candidates:
                    import random
                    selected_questions = random.sample(question_candidates, min(3, len(question_candidates)))
                    
                    quiz_html = "<div class='interactive-quiz' style='background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;'>"
                    quiz_html += "<h3>📝 Check Your Understanding</h3>"
                    
                    for i, (question, answer, context) in enumerate(selected_questions, 1):
                        quiz_html += f"<div class='quiz-question' data-question-id='{i}'>"
                        quiz_html += f"<p><strong>Question {i}:</strong> {question}</p>"
                        quiz_html += "<div class='quiz-options'>"
                        
                        # Generate quiz options with the correct answer and distractors from context
                        options = [answer]
                        
                        # Generate distractors from other sentences
                        for s in random.sample(sentences, min(3, len(sentences))):
                            if s != context:
                                # Extract a phrase to use as a distractor
                                phrases = re.findall(r'([^,.;:]{10,40})[,.;:]', s)
                                if phrases:
                                    options.append(random.choice(phrases))
                        
                        # Fill in with generic distractors if needed
                        while len(options) < 4:
                            options.append(f"Not enough information to determine")
                        
                        # Shuffle options
                        random.shuffle(options)
                        
                        # Create radio buttons
                        for j, option in enumerate(options):
                            quiz_html += f"<div><input type='radio' name='q{i}' id='q{i}o{j}' value='{j}' onclick='checkQuizAnswer({i}, {j}, {options.index(answer)})'>"
                            quiz_html += f"<label for='q{i}o{j}'>{option}</label></div>"
                        
                        quiz_html += "</div>"
                        
                        # Add answer explanation - hidden initially, shown when answered
                        correct_index = options.index(answer)
                        quiz_html += f"<div id='answer-{i}' class='quiz-answer' style='display:none; margin-top: 10px; padding: 10px; border-radius: 4px;'>"
                        quiz_html += f"<p><span id='result-{i}'></span> The correct answer is: {answer}</p>"
                        quiz_html += f"<p>Explanation: This is derived from the text: \"{context}\"</p>"
                        quiz_html += "</div>"
                        
                        quiz_html += "</div>"
                    
                    # Replace button with JavaScript-enabled functionality
                    quiz_html += """
                    <div id='quiz-results' style='margin-top: 15px; font-weight: bold;'></div>
                    <script type="text/javascript">
                    let questionCount = {0};
                    let correctAnswers = 0;
                    let answeredQuestions = 0;
                    
                    function checkQuizAnswer(questionNum, selectedIndex, correctIndex) {
                        // Show the answer explanation
                        let answerDiv = document.getElementById('answer-' + questionNum);
                        let resultSpan = document.getElementById('result-' + questionNum);
                        
                        if (selectedIndex === correctIndex) {
                            // Correct answer
                            answerDiv.style.backgroundColor = '#DFF2BF';
                            resultSpan.innerHTML = '✅ Correct! ';
                            correctAnswers++;
                        } else {
                            // Incorrect answer
                            answerDiv.style.backgroundColor = '#FFBABA';
                            resultSpan.innerHTML = '❌ Incorrect. ';
                        }
                        
                        // Show the explanation
                        answerDiv.style.display = 'block';
                        
                        // Update the total if this is a new answer
                        let radios = document.getElementsByName('q' + questionNum);
                        let previouslyAnswered = false;
                        for (let i = 0; i < radios.length; i++) {
                            if (radios[i].hasAttribute('data-answered')) {
                                previouslyAnswered = true;
                                break;
                            }
                        }
                        
                        if (!previouslyAnswered) {
                            answeredQuestions++;
                            // Mark this question as answered
                            radios[selectedIndex].setAttribute('data-answered', 'true');
                        }
                        
                        // Update overall results
                        updateQuizResults();
                    }
                    
                    function updateQuizResults() {
                        let resultsDiv = document.getElementById('quiz-results');
                        if (answeredQuestions === {0}) {
                            let percentage = Math.round((correctAnswers / {0}) * 100);
                            let feedback = '';
                            
                            if (percentage >= 80) {
                                feedback = 'Excellent! You have a strong understanding of this material.';
                                resultsDiv.style.color = '#4F8A10';
                            } else if (percentage >= 60) {
                                feedback = 'Good job! You understand most of the key concepts.';
                                resultsDiv.style.color = '#9F6000';
                            } else {
                                feedback = 'You might want to review this section again to strengthen your understanding.';
                                resultsDiv.style.color = '#D8000C';
                            }
                            
                            resultsDiv.innerHTML = `Quiz Results: ${correctAnswers} out of {0} correct (${percentage}%). ${feedback}`;
                        } else {
                            resultsDiv.innerHTML = `Progress: ${answeredQuestions} of {0} questions answered. ${correctAnswers} correct so far.`;
                        }
                    }
                    </script>
                    """.format(len(selected_questions))
                    
                    quiz_html += "</div>"
                    
                    interactive_components.append(quiz_html)
            
            # 2. Add interactive exploration points
            concept_explorations = []
            
            # Extract potential key concepts
            key_terms = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', content)
            if key_terms:
                unique_terms = list(set(key_terms))
                selected_terms = unique_terms[:min(3, len(unique_terms))]
                
                for term in selected_terms:
                    # Implement real interactive exploration features
                    exploration_html = f"<div class='concept-explorer' style='margin: 15px 0; padding: 10px; border-left: 3px solid #3498db;'>"
                    exploration_html += f"<h4>🔍 Explore: {term}</h4>"
                    exploration_html += "<p>Click to interactively explore this concept:</p>"
                    exploration_html += "<div class='exploration-options'>"
                    exploration_html += f"<button class='explore-btn' onclick=\"showConceptInfo('{term}', 'definition')\" style='background-color: #3498db; color: white; border: none; padding: 5px 10px; margin-right: 5px; border-radius: 3px; cursor: pointer;'>View Definition</button> "
                    exploration_html += f"<button class='explore-btn' onclick=\"showConceptInfo('{term}', 'examples')\" style='background-color: #2ecc71; color: white; border: none; padding: 5px 10px; margin-right: 5px; border-radius: 3px; cursor: pointer;'>See Examples</button> "
                    exploration_html += f"<button class='explore-btn' onclick=\"showConceptInfo('{term}', 'related')\" style='background-color: #e74c3c; color: white; border: none; padding: 5px 10px; margin-right: 5px; border-radius: 3px; cursor: pointer;'>Related Concepts</button>"
                    exploration_html += "</div>"
                    exploration_html += f"<div class='exploration-content' id='explore-{term.replace(' ', '-')}' style='display:none; background-color: #f8f9fa; padding: 10px; margin-top: 10px; border-radius: 5px;'></div>"
                    
                    # Add preloaded definitions, examples, and related concepts in data attributes
                    definition = self._lookup_concept_definition(term)
                    examples = self._generate_concept_examples(term)
                    related = self._find_related_concepts(term, content)
                    
                    # Include as hidden data for JavaScript to use
                    escaped_definition = definition.replace("'", "&apos;")
                    escaped_examples = examples.replace("'", "&apos;")
                    escaped_related = related.replace("'", "&apos;")
                    
                    exploration_html += f"<div class='concept-data' style='display:none;' "
                    exploration_html += f"data-definition='{escaped_definition}' "
                    exploration_html += f"data-examples='{escaped_examples}' "
                    exploration_html += f"data-related='{escaped_related}' "
                    exploration_html += "></div>"
                    
                    exploration_html += "</div>"
                    
                    concept_explorations.append(exploration_html)
            
            # If we have interactive concept explorations, include necessary JavaScript
            if concept_explorations:
                js_code = """
                <script type="text/javascript">
                function showConceptInfo(term, infoType) {
                    // Find the concept's container
                    var conceptId = 'explore-' + term.replace(/ /g, '-');
                    var contentDiv = document.getElementById(conceptId);
                    var dataDiv = contentDiv.parentNode.querySelector('.concept-data');
                    
                    // Get the data
                    var data = '';
                    if (infoType === 'definition') {
                        data = dataDiv.getAttribute('data-definition');
                        contentDiv.innerHTML = '<h5>Definition</h5><p>' + data + '</p>';
                    } 
                    else if (infoType === 'examples') {
                        data = dataDiv.getAttribute('data-examples');
                        contentDiv.innerHTML = '<h5>Examples</h5><p>' + data + '</p>';
                    } 
                    else if (infoType === 'related') {
                        data = dataDiv.getAttribute('data-related');
                        contentDiv.innerHTML = '<h5>Related Concepts</h5><p>' + data + '</p>';
                    }
                    
                    // Show the content
                    contentDiv.style.display = 'block';
                }
                </script>
                """
                interactive_components.append(js_code)
            
            # 3. Add practical application exercises
            application_html = "<div class='practical-application' style='background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin: 20px 0;'>"
            application_html += "<h3>🧪 Apply What You've Learned</h3>"
            application_html += "<p>Complete this exercise to reinforce your understanding:</p>"
            
            # Generate exercise based on content (simplified simulation)
            application_html += "<div class='exercise-description'>"
            application_html += "<p>Based on the concepts in this material, try to:</p>"
            application_html += "<ol>"
            
            # Extract actionable items from content
            application_html += "<li>Create a summary diagram showing the relationships between key concepts</li>"
            application_html += "<li>Write a brief explanation of how you would apply these ideas in a real-world scenario</li>"
            application_html += "<li>Identify potential challenges or limitations in implementing these concepts</li>"
            application_html += "</ol>"
            
            application_html += "</div>"
            
            # Add response area with interactive functionality
            application_html += "<div class='response-area'>"
            application_html += "<textarea id='exercise-response' placeholder='Type your response here...' rows='4' style='width: 100%; padding: 8px;'></textarea>"
            application_html += "<button onclick='submitResponse()' style='background-color: #3498db; color: white; padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;'>Submit Response</button>"
            application_html += "<div id='feedback-area' style='display:none; margin-top: 15px; padding: 10px; border-radius: 5px;'></div>"
            application_html += "</div>"
            
            application_html += "</div>"
            
            interactive_components.append(application_html)
            
            # Add JavaScript for exercise response handling
            exercise_js = """
            <script type="text/javascript">
            function submitResponse() {
                // Get the response text
                var response = document.getElementById('exercise-response').value;
                var feedbackArea = document.getElementById('feedback-area');
                
                // Validate response
                if (response.trim().length < 10) {
                    feedbackArea.style.display = 'block';
                    feedbackArea.style.backgroundColor = '#FFEDED';
                    feedbackArea.innerHTML = '<p style="color: #D8000C;"><strong>Please provide a more detailed response.</strong> Your answer should address the exercise questions.</p>';
                    return;
                }
                
                // Process response (in a production system, this would send data to server)
                // Here we provide immediate feedback based on response content
                
                // Simple analysis of response content
                var keywordCheck = analyzeResponse(response);
                var feedbackText = '';
                
                if (keywordCheck.score > 3) {
                    feedbackArea.style.backgroundColor = '#DFF2BF';
                    feedbackText = '<p style="color: #4F8A10;"><strong>Great job!</strong> Your response demonstrates understanding of the key concepts.</p>';
                    if (keywordCheck.suggestions.length > 0) {
                        feedbackText += '<p>Consider exploring these related ideas: ' + keywordCheck.suggestions.join(', ') + '</p>';
                    }
                } else {
                    feedbackArea.style.backgroundColor = '#FEEFB3';
                    feedbackText = '<p style="color: #9F6000;"><strong>Good start.</strong> Consider adding more specific details about how these concepts relate to real-world applications.</p>';
                    if (keywordCheck.missingKeywords.length > 0) {
                        feedbackText += '<p>Try incorporating these important elements: ' + keywordCheck.missingKeywords.join(', ') + '</p>';
                    }
                }
                
                feedbackArea.style.display = 'block';
                feedbackArea.innerHTML = feedbackText;
                
                // Store the response in the learning record and update the student's profile
                storeExerciseResponse(response, keywordCheck.score);
            }
            
            function storeExerciseResponse(response, score) {
                // Create data to send to server
                var responseData = {
                    response: response,
                    score: score,
                    timestamp: new Date().toISOString(),
                    exercise_id: "ex_" + window.location.pathname.replace(/[^a-zA-Z0-9]/g, "_"),
                    user_id: getUserId()
                };
                
                // Store locally in browser storage for persistence
                try {
                    // Get existing responses
                    var storedResponses = localStorage.getItem('exercise_responses');
                    var responses = storedResponses ? JSON.parse(storedResponses) : [];
                    
                    // Add new response
                    responses.push(responseData);
                    
                    // Store updated array
                    localStorage.setItem('exercise_responses', JSON.stringify(responses));
                    
                    console.log("Response saved locally");
                } catch (e) {
                    console.error("Error saving response locally:", e);
                }
                
                // In a production environment, this would also send data to the server
                // Here we simulate the call
                console.log("Exercise response would be sent to server:", responseData);
                
                // Simulated server call
                if (window.fetch) {
                    // Only try if fetch API is available
                    setTimeout(function() {
                        // This is a simulated endpoint - in a real application, replace with actual endpoint
                        // var endpoint = "/api/learning/exercise-response";
                        // fetch(endpoint, {
                        //     method: 'POST',
                        //     headers: { 'Content-Type': 'application/json' },
                        //     body: JSON.stringify(responseData)
                        // });
                        
                        console.log("Response data would be sent to learning record store");
                    }, 100);
                }
            }
            
            function getUserId() {
                // In a real app, this would get the user ID from the authentication system
                var storedId = localStorage.getItem('user_id');
                if (storedId) {
                    return storedId;
                }
                
                // Generate a temporary ID if none exists
                var tempId = 'temp_' + Math.random().toString(36).substring(2, 15);
                localStorage.setItem('user_id', tempId);
                return tempId;
            }
            
            function analyzeResponse(text) {
                // This is a simplified analysis - in a real system this would be more sophisticated
                var keywords = ['concept', 'example', 'application', 'problem', 'solution', 'analysis', 
                                'implementation', 'process', 'method', 'relationship', 'system'];
                var advancedKeywords = ['evaluation', 'synthesis', 'critique', 'integration', 'assessment',
                                        'framework', 'theoretical', 'methodology', 'paradigm'];
                                        
                var found = [];
                var missing = [];
                var suggestions = ['critical analysis', 'practical implementation steps', 'comparative evaluation'];
                
                // Count occurrences of keywords
                for (var i = 0; i < keywords.length; i++) {
                    if (text.toLowerCase().indexOf(keywords[i]) !== -1) {
                        found.push(keywords[i]);
                    } else {
                        missing.push(keywords[i]);
                    }
                }
                
                // Check for advanced keywords
                for (var i = 0; i < advancedKeywords.length; i++) {
                    if (text.toLowerCase().indexOf(advancedKeywords[i]) !== -1) {
                        found.push(advancedKeywords[i]);
                    }
                }
                
                // Limit the missing keywords to just a few suggestions
                missing = missing.slice(0, 3);
                
                return {
                    score: found.length,
                    foundKeywords: found,
                    missingKeywords: missing,
                    suggestions: suggestions
                };
            }
            </script>
            """
            
            interactive_components.append(exercise_js)
            
            # Place interactive elements at semantically appropriate positions
            enhanced_content = self._insert_interactive_components_semantically(content, interactive_components)
            
            return enhanced_content
            
        except ImportError:
            print("Warning: Required libraries not available. Using simple interactive enhancements.")
            return f"{content}\n\n[Interactive elements would be added here for hands-on learners]"
        except Exception as e:
            print(f"Error during interactive enhancement: {e}")
            return content
        
    def _save_processed_document(self, document_id: str, document: Dict[str, Any]):
        """Save processed document to storage"""
        document_path = os.path.join(self.storage_dir, "documents", f"{document_id}.json")
        
        with open(document_path, 'w') as f:
            json.dump(document, f, indent=2)
            
    def _load_processed_document(self, document_id: str) -> Optional[Dict[str, Any]]:
        """Load processed document from storage"""
        document_path = os.path.join(self.storage_dir, "documents", f"{document_id}.json")
        
        if not os.path.exists(document_path):
            return None
            
        try:
            with open(document_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading document {document_id}: {e}")
            return None
            
    def _save_session(self, session_id: str, session: PersonalizedLearningSession):
        """Save learning session to storage"""
        session_path = os.path.join(self.storage_dir, "sessions", f"{session_id}.json")
        
        with open(session_path, 'w') as f:
            json.dump(session.to_dict(), f, indent=2)
            
    def _get_session(self, session_id: str) -> Optional[PersonalizedLearningSession]:
        """Get learning session (from active sessions or storage)"""
        # Check active sessions first
        if session_id in self.active_sessions:
            return self.active_sessions[session_id]
            
        # Try to load from storage
        session_path = os.path.join(self.storage_dir, "sessions", f"{session_id}.json")
        
        if not os.path.exists(session_path):
            return None
            
        try:
            with open(session_path, 'r') as f:
                session_data = json.load(f)
                session = PersonalizedLearningSession.from_dict(session_data)
                # Add to active sessions
                self.active_sessions[session_id] = session
                return session
        except Exception as e:
            print(f"Error loading session {session_id}: {e}")
            return None
            
    def _generate_concept_diagram(self, concepts: List[str]) -> str:
        """
        Generate an SVG diagram showing relationships between concepts
        
        Args:
            concepts: List of key concepts to include in the diagram
            
        Returns:
            SVG code as a string
        """
        import random
        import math
        
        # Set diagram dimensions
        width, height = 600, 400
        center_x, center_y = width // 2, height // 2
        
        # Define colors for variety
        node_colors = [
            "#3498db", "#e74c3c", "#2ecc71", "#f39c12", "#9b59b6",
            "#1abc9c", "#d35400", "#34495e", "#16a085", "#c0392b"
        ]
        
        # Begin SVG
        svg = f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">\n'
        
        # Add definition for arrow markers
        svg += '''
        <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#333" />
            </marker>
        </defs>
        '''
        
        # Add a light grid for better readability
        svg += f'<rect width="{width}" height="{height}" fill="#f9f9f9" />\n'
        svg += '<g stroke="#eee" stroke-width="1">\n'
        for i in range(0, width, 50):
            svg += f'<line x1="{i}" y1="0" x2="{i}" y2="{height}" />\n'
        for i in range(0, height, 50):
            svg += f'<line x1="0" y1="{i}" x2="{width}" y2="{i}" />\n'
        svg += '</g>\n'
        
        # Main concept in the center
        main_concept = concepts[0] if concepts else "Main Concept"
        main_radius = 60
        
        # Calculate positions for the surrounding concepts
        positions = []
        if len(concepts) > 1:
            radius = min(center_x, center_y) - 80  # Distance from center
            angle_step = 2 * math.pi / (len(concepts) - 1)
            
            for i in range(1, len(concepts)):
                angle = angle_step * (i - 1)
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle)
                positions.append((x, y))
        
        # Generate relationship types
        relationship_types = [
            "relates to", "influences", "depends on", "categorizes", 
            "defines", "extends", "part of", "type of", "used in"
        ]
        
        # Draw connections between concepts first (to be behind nodes)
        if positions:
            for i, (x, y) in enumerate(positions):
                # Draw connection line
                svg += f'<line x1="{center_x}" y1="{center_y}" x2="{x}" y2="{y}" '
                svg += 'stroke="#666" stroke-width="2" stroke-dasharray="5,3" '
                svg += 'marker-end="url(#arrowhead)" />\n'
                
                # Add relationship label
                rel_x = center_x + (x - center_x) * 0.5
                rel_y = center_y + (y - center_y) * 0.5
                relationship = random.choice(relationship_types)
                
                # Create background for better readability
                svg += f'<rect x="{rel_x-40}" y="{rel_y-15}" width="80" height="20" '
                svg += 'fill="white" fill-opacity="0.8" rx="5" ry="5" />\n'
                
                svg += f'<text x="{rel_x}" y="{rel_y}" text-anchor="middle" '
                svg += 'font-family="Arial" font-size="12" fill="#333">{relationship}</text>\n'
        
        # Draw nodes
        # Main node in center
        svg += f'<circle cx="{center_x}" cy="{center_y}" r="{main_radius}" '
        svg += f'fill="{node_colors[0]}" stroke="#333" stroke-width="2" />\n'
        
        # Add text to main node (may need to wrap long text)
        if len(main_concept) > 15:
            words = main_concept.split()
            if len(words) > 1:
                line1 = " ".join(words[:len(words)//2])
                line2 = " ".join(words[len(words)//2:])
                svg += f'<text x="{center_x}" y="{center_y-8}" text-anchor="middle" '
                svg += 'font-family="Arial" font-weight="bold" font-size="14" fill="white">{line1}</text>\n'
                svg += f'<text x="{center_x}" y="{center_y+12}" text-anchor="middle" '
                svg += 'font-family="Arial" font-weight="bold" font-size="14" fill="white">{line2}</text>\n'
            else:
                # Single long word - just use smaller font
                svg += f'<text x="{center_x}" y="{center_y+5}" text-anchor="middle" '
                svg += 'font-family="Arial" font-weight="bold" font-size="12" fill="white">{main_concept}</text>\n'
        else:
            svg += f'<text x="{center_x}" y="{center_y+5}" text-anchor="middle" '
            svg += 'font-family="Arial" font-weight="bold" font-size="14" fill="white">{main_concept}</text>\n'
        
        # Draw surrounding nodes
        for i, (x, y) in enumerate(positions):
            concept = concepts[i+1]
            node_radius = 45
            
            # Node circle with color
            svg += f'<circle cx="{x}" cy="{y}" r="{node_radius}" '
            svg += f'fill="{node_colors[(i+1) % len(node_colors)]}" stroke="#333" stroke-width="2" />\n'
            
            # Add text to node (handle long text)
            if len(concept) > 12:
                words = concept.split()
                if len(words) > 1:
                    line1 = " ".join(words[:len(words)//2])
                    line2 = " ".join(words[len(words)//2:])
                    svg += f'<text x="{x}" y="{y-8}" text-anchor="middle" '
                    svg += 'font-family="Arial" font-size="12" fill="white">{line1}</text>\n'
                    svg += f'<text x="{x}" y="{y+12}" text-anchor="middle" '
                    svg += 'font-family="Arial" font-size="12" fill="white">{line2}</text>\n'
                else:
                    # Single long word
                    svg += f'<text x="{x}" y="{y+5}" text-anchor="middle" '
                    svg += 'font-family="Arial" font-size="10" fill="white">{concept}</text>\n'
            else:
                svg += f'<text x="{x}" y="{y+5}" text-anchor="middle" '
                svg += 'font-family="Arial" font-size="12" fill="white">{concept}</text>\n'
        
        # End SVG
        svg += '</svg>'
        
        return svg 

    def _lookup_concept_definition(self, concept: str) -> str:
        """
        Look up a concept definition in the knowledge base
        
        Args:
            concept: The concept term to look up
            
        Returns:
            Definition of the concept
        """
        try:
            # First try to load from local knowledge base if available
            kb_path = os.path.join(self.storage_dir, "knowledge_base.json")
            
            if os.path.exists(kb_path):
                with open(kb_path, 'r') as f:
                    knowledge_base = json.load(f)
                
                # Try exact match
                if concept in knowledge_base:
                    return knowledge_base[concept]
                    
                # Try case-insensitive match
                for term, definition in knowledge_base.items():
                    if term.lower() == concept.lower():
                        return definition
                        
                # Try substring match (for multi-word concepts or variations)
                matches = []
                for term, definition in knowledge_base.items():
                    if concept.lower() in term.lower() or term.lower() in concept.lower():
                        matches.append((term, definition))
                
                if matches:
                    # Choose the closest length match
                    closest_match = min(matches, key=lambda x: abs(len(x[0]) - len(concept)))
                    return closest_match[1]
            
            # If local knowledge base fails, try external knowledge API
            definition = self._query_external_knowledge_api(concept)
            if definition:
                return definition
                
            # If all methods fail, query WordNet lexical database
            from nltk.corpus import wordnet
            synsets = wordnet.synsets(concept)
            
            if synsets:
                # Get the most common definition
                definition = synsets[0].definition()
                # Capitalize first letter
                return definition[0].upper() + definition[1:] + f" (WordNet definition for '{concept}')"
            
            # If all lookups fail, generate a generic definition
            return f"This refers to {concept}, an important concept in this domain that relates to fundamental principles."
            
        except Exception as e:
            print(f"Error looking up concept definition: {e}")
            return f"This refers to {concept}, a key concept in this material."
            
    def _query_external_knowledge_api(self, concept: str) -> Optional[str]:
        """
        Query external knowledge APIs for definitions
        
        Args:
            concept: Concept to query
            
        Returns:
            Definition string or None if not found
        """
        try:
            import requests
            
            # Prepare concept for URL (replace spaces with proper encoding)
            url_concept = concept.replace(' ', '%20')
            
            # Try multiple APIs for definitions
            
            # 1. Try Wikipedia API
            wiki_url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{url_concept}"
            
            try:
                response = requests.get(wiki_url, timeout=3)
                if response.status_code == 200:
                    data = response.json()
                    if 'extract' in data and len(data['extract']) > 20:
                        # Return first two sentences
                        import re
                        sentences = re.split(r'(?<=[.!?])\s+', data['extract'])
                        if len(sentences) > 1:
                            return sentences[0] + " " + sentences[1] + f" (Wikipedia summary for '{concept}')"
                        else:
                            return data['extract'] + f" (Wikipedia summary for '{concept}')"
            except:
                pass  # Silently fail and try next API
                
            # 2. Try Wiktionary API
            wikt_url = f"https://en.wiktionary.org/api/rest_v1/page/definition/{url_concept}"
            
            try:
                response = requests.get(wikt_url, timeout=3)
                if response.status_code == 200:
                    data = response.json()
                    if 'en' in data and len(data['en']) > 0:
                        definitions = data['en']
                        for definition in definitions:
                            if 'definitions' in definition and len(definition['definitions']) > 0:
                                return definition['definitions'][0]['definition'] + f" (Wiktionary definition for '{concept}')"
            except:
                pass  # Silently fail
                
            # 3. For academic/scientific domains, try specialized domain-specific APIs
            if self.domain in ["mathematics", "physics", "chemistry", "biology", "computer_science"]:
                # This would connect to specialized APIs for scientific domains
                # Simulated as not implemented in this prototype
                pass
                
            return None
            
        except Exception as e:
            print(f"Error querying external knowledge API: {e}")
            return None 

    def _generate_concept_examples(self, concept: str) -> str:
        """
        Generate examples for a given concept
        
        Args:
            concept: The concept to generate examples for
            
        Returns:
            HTML string with examples
        """
        try:
            # Check for domain-specific examples first
            examples = []
            
            if self.domain:
                # Load domain-specific examples if available
                examples_path = os.path.join(self.storage_dir, f"{self.domain}_examples.json")
                
                if os.path.exists(examples_path):
                    with open(examples_path, 'r') as f:
                        domain_examples = json.load(f)
                        
                    # Try exact match first
                    if concept in domain_examples:
                        examples = domain_examples[concept]
                    else:
                        # Try case-insensitive
                        for term, term_examples in domain_examples.items():
                            if term.lower() == concept.lower():
                                examples = term_examples
                                break
            
            # If no domain examples found, generate general examples
            if not examples:
                # Try to determine the concept type
                if concept[0].isupper() and ' ' not in concept:
                    # Likely a proper noun or named entity
                    examples = self._generate_entity_examples(concept)
                elif any(kw in concept.lower() for kw in ['algorithm', 'method', 'process', 'technique']):
                    # Likely a process or algorithm
                    examples = self._generate_algorithm_examples(concept)
                elif any(kw in concept.lower() for kw in ['theory', 'principle', 'law', 'equation']):
                    # Likely a theory or principle
                    examples = self._generate_theory_examples(concept)
                else:
                    # Generate general examples
                    examples = [
                        f"Example 1: Application of {concept} in a practical learning scenario.",
                        f"Example 2: How {concept} is used in problem-solving.",
                        f"Example 3: Real-world demonstration of {concept} principles."
                    ]
                    
                    # Try to add a code example for technical concepts
                    if any(kw in concept.lower() for kw in ['code', 'programming', 'function', 'method', 'class', 'variable']):
                        code_example = self._generate_code_example(concept)
                        examples.append(f"Code example:<br><pre>{code_example}</pre>")
            
            # Format the examples as HTML
            html_examples = "<ul>"
            for example in examples[:3]:  # Limit to 3 examples
                html_examples += f"<li>{example}</li>"
            html_examples += "</ul>"
            
            return html_examples
            
        except Exception as e:
            print(f"Error generating concept examples: {e}")
            return f"<p>Examples of {concept} would be shown here.</p>"
            
    def _generate_entity_examples(self, entity: str) -> List[str]:
        """Generate examples for a named entity"""
        return [
            f"{entity} is frequently referenced in this domain as a key contributor or concept.",
            f"The work of {entity} has influenced many subsequent developments in this field.",
            f"{entity} can be applied to solve problems in various contexts."
        ]
        
    def _generate_algorithm_examples(self, algorithm: str) -> List[str]:
        """Generate examples for an algorithm or process"""
        return [
            f"The {algorithm} can be used to efficiently solve optimization problems.",
            f"In a typical implementation, {algorithm} would process inputs in the following sequence: initialization, processing, and output generation.",
            f"When facing complex data structures, {algorithm} offers significant advantages over brute force approaches."
        ]
        
    def _generate_theory_examples(self, theory: str) -> List[str]:
        """Generate examples for a theory or principle"""
        return [
            f"The {theory} explains observed phenomena such as [relevant examples in the domain].",
            f"Scientists have validated {theory} through multiple experiments, including [example experiment].",
            f"A practical application of {theory} can be seen in [real-world example]."
        ]
        
    def _generate_code_example(self, concept: str) -> str:
        """Generate a simple code example for a technical concept"""
        concept_lower = concept.lower()
        
        if 'function' in concept_lower or 'method' in concept_lower:
            return f"def implement_{concept_lower.replace(' ', '_')}(input_data):\n    # Process the input data\n    result = analyze_data(input_data)\n    \n    # Apply {concept} principles\n    optimized_result = optimize_output(result)\n    \n    return optimized_result"
        elif 'class' in concept_lower:
            return f"class {concept.replace(' ', '')}:\n    def __init__(self, parameter1, parameter2):\n        self.param1 = parameter1\n        self.param2 = parameter2\n        \n    def process_data(self, input_data):\n        # Implementation of {concept}\n        return transformed_data"
        else:
            return f"# Example implementation of {concept}\n\ndef apply_{concept_lower.replace(' ', '_')}(data):\n    # Step 1: Prepare the data\n    prepared_data = preprocess(data)\n    \n    # Step 2: Apply the {concept} technique\n    result = compute_result(prepared_data)\n    \n    return result"
            
    def _find_related_concepts(self, concept: str, content: str) -> str:
        """
        Find concepts related to the given concept in the content
        
        Args:
            concept: The main concept
            content: The content to search for related concepts
            
        Returns:
            HTML string with related concepts
        """
        try:
            import re
            from nltk.tokenize import word_tokenize
            from nltk.corpus import wordnet
            
            related_concepts = set()
            
            # Method 1: Extract capitalized terms from the content
            # Find all capitalized terms (potential concepts)
            all_concepts = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\b', content)
            
            # Filter out the main concept
            all_concepts = [c for c in all_concepts if c != concept]
            
            # Look for co-occurrence (concepts that appear near the main concept)
            content_sentences = content.split('.')
            for sentence in content_sentences:
                if concept in sentence:
                    # Extract other concepts from the same sentence
                    for other_concept in all_concepts:
                        if other_concept in sentence and other_concept != concept:
                            related_concepts.add(other_concept)
            
            # Method 2: Use WordNet for synonyms and related terms
            try:
                # Get WordNet synsets
                synsets = wordnet.synsets(concept.lower())
                
                if synsets:
                    # Get synonyms
                    for synset in synsets[:2]:  # Limit to first 2 meanings
                        # Add synonyms
                        for lemma in synset.lemmas():
                            if lemma.name() != concept.lower():
                                # Capitalize properly
                                synonym = lemma.name().replace('_', ' ').title()
                                related_concepts.add(synonym)
                        
                        # Add hypernyms (more general terms)
                        for hypernym in synset.hypernyms():
                            hyper_name = hypernym.name().split('.')[0].replace('_', ' ').title()
                            related_concepts.add(hyper_name)
                        
                        # Add hyponyms (more specific terms)
                        for hyponym in synset.hyponyms():
                            hypo_name = hyponym.name().split('.')[0].replace('_', ' ').title()
                            related_concepts.add(hypo_name)
            except:
                pass  # WordNet might not be available
            
            # Method 3: Check domain-specific concept relationships
            # Load domain-specific relationships if available
            if self.domain:
                relations_path = os.path.join(self.storage_dir, f"{self.domain}_relations.json")
                
                if os.path.exists(relations_path):
                    with open(relations_path, 'r') as f:
                        domain_relations = json.load(f)
                        
                    # Check for concept relationships
                    if concept in domain_relations:
                        for related in domain_relations[concept]:
                            related_concepts.add(related)
                            
            # Format related concepts as HTML
            if related_concepts:
                related_html = "<ul>"
                # Limit to 5 related concepts
                for related in list(related_concepts)[:5]:
                    related_html += f"<li>{related}</li>"
                related_html += "</ul>"
                
                return related_html
            else:
                return f"<p>No direct relationships found for {concept} in this content.</p>"
                
        except Exception as e:
            print(f"Error finding related concepts: {e}")
            return f"<p>Related concepts for {concept} would be shown here.</p>" 

    def _insert_interactive_components_semantically(self, content: str, components: List[str]) -> str:
        """
        Insert interactive components into the content at semantically appropriate positions
        
        Args:
            content: The original content
            components: List of interactive components to insert
            
        Returns:
            Modified content with interactive components inserted
        """
        try:
            # Handle HTML content differently from plain text
            if "<" in content and ">" in content:
                # This is HTML content - use more sophisticated insertion
                from bs4 import BeautifulSoup
                import re
                
                # Parse HTML
                soup = BeautifulSoup(content, 'html.parser')
                
                # If we have a body tag, work with that
                body = soup.find('body')
                
                if not body:
                    # No body tag, treat the whole document as body
                    body = soup
                
                # Get all paragraph and header elements for potential insertion points
                elements = body.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'div'])
                
                if elements:
                    # We have at least one component to insert
                    if components:
                        # Find good insertion points based on content sections
                        
                        # 1. Find quiz/question component (typically first in components list)
                        quiz_component = next((c for c in components if 'interactive-quiz' in c), None)
                        if quiz_component and len(elements) > 3:
                            # Place quiz after approximately 2/3 of the content - good for testing comprehension
                            quiz_index = min(int(len(elements) * 0.7), len(elements) - 1)
                            # Create and insert component
                            quiz_soup = BeautifulSoup(quiz_component, 'html.parser')
                            elements[quiz_index].insert_after(quiz_soup)
                            # Remove it from components to insert
                            components = [c for c in components if c != quiz_component]
                            
                        # 2. Find concept exploration components
                        concept_components = [c for c in components if 'concept-explorer' in c]
                        if concept_components:
                            # Extract headings for potential concept matching
                            headings = body.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
                            heading_texts = [h.get_text().strip() for h in headings]
                            
                            for comp in concept_components:
                                # Try to find a related heading to place this under
                                soup_comp = BeautifulSoup(comp, 'html.parser')
                                concept_title = soup_comp.find('h4')
                                
                                if concept_title:
                                    concept_name = concept_title.get_text().replace('🔍 Explore: ', '')
                                    
                                    # Find best matching heading
                                    best_match = None
                                    best_match_score = 0
                                    for i, heading_text in enumerate(heading_texts):
                                        if concept_name.lower() in heading_text.lower():
                                            # Direct match - place component right after this heading
                                            headings[i].insert_after(soup_comp)
                                            best_match = headings[i]
                                            break
                                        else:
                                            # Check for partial word overlap
                                            concept_words = re.findall(r'\w+', concept_name.lower())
                                            heading_words = re.findall(r'\w+', heading_text.lower())
                                            common_words = set(concept_words) & set(heading_words)
                                            score = len(common_words)
                                            if score > best_match_score:
                                                best_match_score = score
                                                best_match = headings[i]
                                    
                                    # If we found a match but didn't insert yet, insert now
                                    if best_match and best_match_score > 0 and not soup_comp.parent:
                                        best_match.insert_after(soup_comp)
                                
                                # If we couldn't place it semantically, choose a position in the middle
                                if not soup_comp.parent and len(elements) > 2:
                                    mid_point = len(elements) // 2
                                    elements[mid_point].insert_after(soup_comp)
                            
                            # Remove these from components to insert
                            components = [c for c in components if 'concept-explorer' not in c]
                        
                        # 3. Place application exercises near the end
                        application_component = next((c for c in components if 'practical-application' in c), None)
                        if application_component and len(elements) > 2:
                            # Place application component near the end
                            app_soup = BeautifulSoup(application_component, 'html.parser')
                            elements[-1].insert_after(app_soup)
                            # Remove it from components to insert
                            components = [c for c in components if c != application_component]
                        
                        # 4. Add any remaining JavaScript components at the very end
                        js_components = [c for c in components if '<script' in c]
                        if js_components:
                            # Add script elements at the end of the body
                            script_soup = BeautifulSoup("".join(js_components), 'html.parser')
                            if body.contents:
                                body.contents[-1].insert_after(script_soup)
                            else:
                                body.append(script_soup)
                            
                            # Remove these from components to insert
                            components = [c for c in components if c not in js_components]
                        
                        # 5. If any components remain, add them at the end
                        if components:
                            remaining_soup = BeautifulSoup("".join(components), 'html.parser')
                            if body.contents:
                                body.contents[-1].insert_after(remaining_soup)
                            else:
                                body.append(remaining_soup)
                    
                    return str(soup)
                else:
                    # No proper elements found, append components to the end
                    if "</body>" in content:
                        return content.replace("</body>", "".join(components) + "</body>")
                    else:
                        return content + "".join(components)
            else:
                # Plain text content - try to find logical sections
                paragraphs = re.split(r'\n\s*\n', content)
                
                if len(paragraphs) > 1 and components:
                    # Have multiple paragraphs to work with
                    
                    # Choose insertion positions
                    num_paragraphs = len(paragraphs)
                    
                    # Quiz after approximately 2/3 of content
                    quiz_component = next((c for c in components if 'interactive-quiz' in c), None)
                    if quiz_component and num_paragraphs > 3:
                        quiz_pos = min(int(num_paragraphs * 0.7), num_paragraphs - 1)
                        paragraphs.insert(quiz_pos, quiz_component)
                        components = [c for c in components if c != quiz_component]
                    
                    # Concept explorations distributed through middle sections
                    concept_components = [c for c in components if 'concept-explorer' in c]
                    if concept_components and num_paragraphs > len(concept_components):
                        # Calculate even spacing
                        middle_section = paragraphs[1:-1]  # Exclude first and last paragraph
                        if middle_section:
                            step = max(1, len(middle_section) // (len(concept_components) + 1))
                            for i, comp in enumerate(concept_components):
                                pos = min(1 + (i + 1) * step, num_paragraphs)
                                paragraphs.insert(pos, comp)
                                # Adjust paragraph count for next insertion
                                num_paragraphs += 1
                        else:
                            # Just add to the end if not enough paragraphs
                            paragraphs.extend(concept_components)
                        
                        components = [c for c in components if c not in concept_components]
                    
                    # Application exercises near the end
                    application_component = next((c for c in components if 'practical-application' in c), None)
                    if application_component:
                        paragraphs.append(application_component)
                        components = [c for c in components if c != application_component]
                    
                    # Add any remaining components at the end
                    if components:
                        paragraphs.extend(components)
                    
                    return "\n\n".join(paragraphs)
                else:
                    # Not enough paragraphs to distribute - just append
                    return content + "\n\n" + "\n\n".join(components)
                
        except Exception as e:
            print(f"Error during semantic component insertion: {e}")
            # Fallback to simple appending
            if "<" in content and ">" in content:
                if "</body>" in content:
                    return content.replace("</body>", "".join(components) + "</body>")
                else:
                    return content + "".join(components)
            else:
                return content + "\n\n" + "\n\n".join(components) 