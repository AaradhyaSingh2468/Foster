"""
Student Profile Manager
----------------------
Manages student profiles for adaptive learning, including:
- Academic level and preferences
- Learning pace and style
- Knowledge history and progression
- Subject strengths and weaknesses
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional, Union
import logging
import time
import uuid
import re
import threading
from jsonschema import validate, ValidationError

from pipeline.errors.WorkflowErrors import (
    AdaptiveLearningError, StudentProfileError
)

class ProfileValidationSchema:
    """Schema definitions for student profile validation"""
    
    # Base profile schema
    STUDENT_PROFILE_SCHEMA = {
        "type": "object",
        "required": ["student_id", "created_at", "updated_at", "profile_version"],
        "properties": {
            "student_id": {
                "type": "string",
                "pattern": "^[a-zA-Z0-9_-]{4,64}$"
            },
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "profile_version": {"type": "string"},
            "personal_info": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "email": {
                        "type": "string",
                        "format": "email"
                    },
                    "grade_level": {"type": "string"},
                    "educational_institution": {"type": "string"}
                }
            },
            "learning_preferences": {
                "type": "object",
                "properties": {
                    "preferred_learning_style": {
                        "type": "string",
                        "enum": ["visual", "auditory", "reading", "kinesthetic", "multimodal"]
                    },
                    "pace_preference": {
                        "type": "string",
                        "enum": ["slower", "standard", "faster"]
                    },
                    "difficulty_preference": {
                        "type": "string",
                        "enum": ["easier", "standard", "challenging"]
                    },
                    "interests": {
                        "type": "array",
                        "items": {"type": "string"}
                    }
                }
            },
            "learning_history": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["content_id", "timestamp", "completion_status"],
                    "properties": {
                        "content_id": {"type": "string"},
                        "content_type": {"type": "string"},
                        "timestamp": {"type": "string", "format": "date-time"},
                        "completion_status": {
                            "type": "string",
                            "enum": ["not_started", "in_progress", "completed", "abandoned"]
                        },
                        "score": {"type": "number", "minimum": 0, "maximum": 100},
                        "time_spent": {"type": "number", "minimum": 0}
                    }
                }
            },
            "knowledge_state": {
                "type": "object",
                "properties": {
                    "concepts": {
                        "type": "object",
                        "additionalProperties": {
                            "type": "object",
                            "properties": {
                                "mastery_level": {"type": "number", "minimum": 0, "maximum": 1},
                                "last_assessed": {"type": "string", "format": "date-time"},
                                "assessment_count": {"type": "integer", "minimum": 0},
                                "relevance": {"type": "number", "minimum": 0, "maximum": 1}
                            }
                        }
                    },
                    "domains": {
                        "type": "object",
                        "additionalProperties": {
                            "type": "object",
                            "properties": {
                                "proficiency_level": {"type": "number", "minimum": 0, "maximum": 1},
                                "interest_level": {"type": "number", "minimum": 0, "maximum": 1},
                                "experience_level": {"type": "string", "enum": ["novice", "beginner", "intermediate", "advanced", "expert"]}
                            }
                        }
                    }
                }
            },
            "adaptive_parameters": {
                "type": "object",
                "properties": {
                    "difficulty_factor": {"type": "number", "minimum": 0.1, "maximum": 2.0},
                    "content_diversity": {"type": "number", "minimum": 0.1, "maximum": 1.0},
                    "repetition_interval": {"type": "number", "minimum": 1},
                    "mastery_threshold": {"type": "number", "minimum": 0.1, "maximum": 1.0}
                }
            },
            "goals": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["goal_id", "description", "created_at"],
                    "properties": {
                        "goal_id": {"type": "string"},
                        "description": {"type": "string"},
                        "created_at": {"type": "string", "format": "date-time"},
                        "target_date": {"type": "string", "format": "date-time"},
                        "status": {"type": "string", "enum": ["active", "completed", "abandoned"]},
                        "progress": {"type": "number", "minimum": 0, "maximum": 1}
                    }
                }
            }
        },
        "additionalProperties": true
    }
    
    # Profile update schema (subset of fields that can be updated)
    PROFILE_UPDATE_SCHEMA = {
        "type": "object",
        "properties": {
            "personal_info": {
                "type": "object"
            },
            "learning_preferences": {
                "type": "object"
            },
            "goals": {
                "type": "array"
            },
            "adaptive_parameters": {
                "type": "object"
            }
        },
        "additionalProperties": false
    }
    
    # Learning history entry schema
    LEARNING_HISTORY_ENTRY_SCHEMA = {
        "type": "object",
        "required": ["content_id", "timestamp", "completion_status"],
        "properties": {
            "content_id": {"type": "string"},
            "content_type": {"type": "string"},
            "timestamp": {"type": "string", "format": "date-time"},
            "completion_status": {
                "type": "string",
                "enum": ["not_started", "in_progress", "completed", "abandoned"]
            },
            "score": {"type": "number", "minimum": 0, "maximum": 100},
            "time_spent": {"type": "number", "minimum": 0}
        }
    }
    
    # Concept knowledge update schema
    CONCEPT_KNOWLEDGE_SCHEMA = {
        "type": "object",
        "required": ["concept_id", "mastery_level"],
        "properties": {
            "concept_id": {"type": "string"},
            "mastery_level": {"type": "number", "minimum": 0, "maximum": 1},
            "assessment_info": {
                "type": "object",
                "properties": {
                    "assessment_id": {"type": "string"},
                    "score": {"type": "number", "minimum": 0, "maximum": 100},
                    "timestamp": {"type": "string", "format": "date-time"}
                }
            }
        }
    }

class StudentProfile:
    """Represents a student's learning profile and preferences"""
    
    def __init__(self, student_id: str, name: str = "", email: str = "", 
                 academic_level: str = "intermediate", learning_pace: str = "standard"):
        """
        Initialize a student profile
        
        Args:
            student_id: Unique identifier for the student
            name: Student's name
            email: Student's email address
            academic_level: Academic level (beginner, intermediate, advanced)
            learning_pace: Preferred learning pace (slow, standard, fast)
        """
        self.student_id = student_id
        self.name = name
        self.email = email
        self.created_at = datetime.now().isoformat()
        self.updated_at = self.created_at
        
        # Learning preferences
        self.academic_level = academic_level  # beginner, intermediate, advanced
        self.learning_pace = learning_pace  # slow, standard, fast
        self.learning_style = {
            "visual": 0.5,       # 0-1 preference for visual learning
            "textual": 0.5,      # 0-1 preference for text-based learning
            "interactive": 0.5,  # 0-1 preference for interactive learning
        }
        
        # Knowledge tracking
        self.knowledge_areas = {}  # Domain → proficiency level (0-1)
        self.completed_materials = []  # List of completed material IDs
        self.learning_history = []  # Chronological learning events
        
        # Performance metrics
        self.strengths = []  # List of strong knowledge areas
        self.weaknesses = []  # List of areas needing improvement
        self.retention_metrics = {}  # Topic → retention score (0-1)
        
    def update_knowledge_area(self, domain: str, topic: str, proficiency: float):
        """
        Update proficiency in a specific knowledge area
        
        Args:
            domain: The domain (e.g., "math", "science")
            topic: The specific topic within the domain
            proficiency: Proficiency level (0-1)
        """
        if domain not in self.knowledge_areas:
            self.knowledge_areas[domain] = {}
            
        self.knowledge_areas[domain][topic] = proficiency
        self.updated_at = datetime.now().isoformat()
        
        # Update strengths and weaknesses
        self._recalculate_strengths_weaknesses()
        
    def record_learning_activity(self, material_id: str, activity_type: str, 
                               performance: Optional[float] = None, time_spent: Optional[int] = None):
        """
        Record a learning activity in the student's history
        
        Args:
            material_id: ID of the learning material
            activity_type: Type of activity (read, quiz, practice, etc.)
            performance: Optional performance metric (0-1)
            time_spent: Optional time spent in seconds
        """
        activity = {
            "timestamp": datetime.now().isoformat(),
            "material_id": material_id,
            "activity_type": activity_type
        }
        
        if performance is not None:
            activity["performance"] = performance
            
        if time_spent is not None:
            activity["time_spent"] = time_spent
            
        self.learning_history.append(activity)
        
        # Add to completed materials if not already present
        if material_id not in self.completed_materials:
            self.completed_materials.append(material_id)
            
        self.updated_at = datetime.now().isoformat()
        
    def update_learning_preferences(self, **preferences):
        """
        Update the student's learning preferences
        
        Args:
            **preferences: Keyword arguments for preferences to update
        """
        valid_preferences = [
            "academic_level", "learning_pace", "visual", 
            "textual", "interactive"
        ]
        
        for key, value in preferences.items():
            if key in valid_preferences:
                if key in ["visual", "textual", "interactive"]:
                    self.learning_style[key] = value
                else:
                    setattr(self, key, value)
                    
        self.updated_at = datetime.now().isoformat()
        
    def get_recommended_difficulty(self) -> str:
        """
        Calculate the recommended content difficulty based on profile
        
        Returns:
            String indicating recommended difficulty (simple, standard, advanced)
        """
        # Base recommendation on academic level
        if self.academic_level == "beginner":
            base_difficulty = "simple"
        elif self.academic_level == "intermediate":
            base_difficulty = "standard"
        else:  # advanced
            base_difficulty = "advanced"
            
        # Adjust based on overall performance in knowledge areas
        if self.knowledge_areas:
            avg_proficiency = 0
            count = 0
            
            for domain in self.knowledge_areas.values():
                for proficiency in domain.values():
                    avg_proficiency += proficiency
                    count += 1
            
            if count > 0:
                avg_proficiency /= count
                
                # Adjust difficulty based on proficiency
                if avg_proficiency > 0.8 and base_difficulty != "advanced":
                    # Step up difficulty if doing very well
                    if base_difficulty == "simple":
                        return "standard"
                    else:
                        return "advanced"
                elif avg_proficiency < 0.4 and base_difficulty != "simple":
                    # Step down difficulty if struggling
                    if base_difficulty == "advanced":
                        return "standard"
                    else:
                        return "simple"
        
        return base_difficulty
        
    def _recalculate_strengths_weaknesses(self):
        """
        Internal method to recalculate strengths and weaknesses
        based on knowledge area proficiencies
        """
        strengths = []
        weaknesses = []
        
        for domain, topics in self.knowledge_areas.items():
            for topic, proficiency in topics.items():
                if proficiency >= 0.75:
                    strengths.append({"domain": domain, "topic": topic, "proficiency": proficiency})
                elif proficiency <= 0.4:
                    weaknesses.append({"domain": domain, "topic": topic, "proficiency": proficiency})
        
        # Sort by proficiency (descending for strengths, ascending for weaknesses)
        self.strengths = sorted(strengths, key=lambda x: x["proficiency"], reverse=True)
        self.weaknesses = sorted(weaknesses, key=lambda x: x["proficiency"])
        
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert profile to dictionary for serialization
        
        Returns:
            Dictionary representation of the profile
        """
        return {
            "student_id": self.student_id,
            "name": self.name,
            "email": self.email,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "academic_level": self.academic_level,
            "learning_pace": self.learning_pace,
            "learning_style": self.learning_style,
            "knowledge_areas": self.knowledge_areas,
            "completed_materials": self.completed_materials,
            "learning_history": self.learning_history,
            "strengths": self.strengths,
            "weaknesses": self.weaknesses,
            "retention_metrics": self.retention_metrics
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'StudentProfile':
        """
        Create a profile from a dictionary
        
        Args:
            data: Dictionary representation of a profile
            
        Returns:
            StudentProfile instance
        """
        profile = cls(
            student_id=data["student_id"],
            name=data.get("name", ""),
            email=data.get("email", ""),
            academic_level=data.get("academic_level", "intermediate"),
            learning_pace=data.get("learning_pace", "standard")
        )
        
        # Restore other properties
        profile.created_at = data.get("created_at", profile.created_at)
        profile.updated_at = data.get("updated_at", profile.updated_at)
        profile.learning_style = data.get("learning_style", profile.learning_style)
        profile.knowledge_areas = data.get("knowledge_areas", {})
        profile.completed_materials = data.get("completed_materials", [])
        profile.learning_history = data.get("learning_history", [])
        profile.strengths = data.get("strengths", [])
        profile.weaknesses = data.get("weaknesses", [])
        profile.retention_metrics = data.get("retention_metrics", {})
        
        return profile

class StudentProfileManager:
    """
    Manages student profiles for adaptive learning
    with robust validation and versioning
    """
    
    def __init__(self, storage_dir: str = "student_profiles", 
                backup_dir: Optional[str] = None,
                auto_backup: bool = True,
                backup_interval: int = 3600):
        """
        Initialize student profile manager
        
        Args:
            storage_dir: Directory for storing student profiles
            backup_dir: Directory for profile backups
            auto_backup: Whether to automatically backup profiles
            backup_interval: Backup interval in seconds
        """
        self.storage_dir = storage_dir
        self.backup_dir = backup_dir or os.path.join(storage_dir, "backups")
        self.auto_backup = auto_backup
        self.backup_interval = backup_interval
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Create storage directories
        os.makedirs(storage_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        
        # Cache for recently accessed profiles
        self.profile_cache: Dict[str, Dict[str, Any]] = {}
        self.cache_lock = threading.RLock()
        
        # Set of profiles that have been modified
        self.modified_profiles: Set[str] = set()
        
        # Current profile version
        self.profile_version = "1.3.0"
        
        # Start backup thread if auto_backup is enabled
        if auto_backup:
            self.backup_thread_running = True
            self.backup_thread = threading.Thread(target=self._backup_thread, daemon=True)
            self.backup_thread.start()
            self.logger.info(f"Auto-backup thread started with interval {backup_interval} seconds")
    
    def get_student_profile(self, student_id: str, create_if_missing: bool = True) -> Dict[str, Any]:
        """
        Get a student profile by ID
        
        Args:
            student_id: Student identifier
            create_if_missing: Whether to create a profile if not found
            
        Returns:
            Student profile dictionary
            
        Raises:
            StudentProfileError: If profile not found and create_if_missing is False
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Check cache first
        with self.cache_lock:
            if student_id in self.profile_cache:
                return self.profile_cache[student_id]
        
        # Check disk storage
        profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
        
        if os.path.exists(profile_path):
            try:
                # Load profile from disk
                with open(profile_path, "r") as f:
                    profile = json.load(f)
                
                # Validate the loaded profile
                self._validate_profile(profile)
                
                # Check if profile needs migration
                if self._needs_version_migration(profile):
                    profile = self._migrate_profile(profile)
                    # Save migrated profile
                    self.save_student_profile(student_id, profile)
                
                # Add to cache
                with self.cache_lock:
                    self.profile_cache[student_id] = profile
                
                return profile
                
            except (json.JSONDecodeError, IOError) as e:
                error_msg = f"Error loading profile for student {student_id}: {str(e)}"
                self.logger.error(error_msg)
                
                # Try to load from backup if available
                backup_profile = self._load_from_backup(student_id)
                if backup_profile:
                    self.logger.info(f"Restored profile for student {student_id} from backup")
                    
                    # Add to cache
                    with self.cache_lock:
                        self.profile_cache[student_id] = backup_profile
                    
                    return backup_profile
                
                if create_if_missing:
                    # Create new profile if loading failed
                    self.logger.warning(f"Creating new profile for student {student_id} after load failure")
                    return self.create_student_profile(student_id)
                else:
                    raise StudentProfileError(f"Failed to load student profile: {error_msg}")
            
            except ValidationError as e:
                error_msg = f"Invalid profile format for student {student_id}: {e.message}"
                self.logger.error(error_msg)
                
                # Try to load from backup
                backup_profile = self._load_from_backup(student_id)
                if backup_profile:
                    self.logger.info(f"Restored profile for student {student_id} from backup")
                    
                    # Add to cache
                    with self.cache_lock:
                        self.profile_cache[student_id] = backup_profile
                    
                    return backup_profile
                
                if create_if_missing:
                    # Create new profile if validation failed
                    self.logger.warning(f"Creating new profile for student {student_id} after validation failure")
                    return self.create_student_profile(student_id)
                else:
                    raise StudentProfileError(f"Invalid student profile format: {error_msg}")
        
        elif create_if_missing:
            # Create new profile
            return self.create_student_profile(student_id)
        
        else:
            error_msg = f"Student profile not found for ID: {student_id}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
    
    def create_student_profile(self, student_id: str) -> Dict[str, Any]:
        """
        Create a new student profile
        
        Args:
            student_id: Student identifier
            
        Returns:
            Newly created student profile
            
        Raises:
            StudentProfileError: If a profile already exists for the student
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Check if profile already exists
        profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
        
        if os.path.exists(profile_path) and not self._is_empty_or_corrupt(profile_path):
            error_msg = f"Student profile already exists for ID: {student_id}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
        
        # Create timestamp
        now = datetime.utcnow().isoformat() + "Z"
        
        # Create new profile with default values
        profile = {
            "student_id": student_id,
            "created_at": now,
            "updated_at": now,
            "profile_version": self.profile_version,
            "personal_info": {
                "grade_level": "unknown"
            },
            "learning_preferences": {
                "preferred_learning_style": "multimodal",
                "pace_preference": "standard",
                "difficulty_preference": "standard",
                "interests": []
            },
            "learning_history": [],
            "knowledge_state": {
                "concepts": {},
                "domains": {}
            },
            "adaptive_parameters": {
                "difficulty_factor": 1.0,
                "content_diversity": 0.5,
                "repetition_interval": 7,
                "mastery_threshold": 0.8
            },
            "goals": []
        }
        
        # Validate profile
        self._validate_profile(profile)
        
        # Save to disk
        try:
            with open(profile_path, "w") as f:
                json.dump(profile, f, indent=2)
            
            # Add to cache
            with self.cache_lock:
                self.profile_cache[student_id] = profile
                self.modified_profiles.add(student_id)
            
            self.logger.info(f"Created new profile for student {student_id}")
            
            return profile
            
        except (IOError, OSError) as e:
            error_msg = f"Failed to save new profile for student {student_id}: {str(e)}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
    
    def update_student_profile(self, student_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update a student profile
        
        Args:
            student_id: Student identifier
            updates: Dictionary of profile updates
            
        Returns:
            Updated student profile
            
        Raises:
            StudentProfileError: If profile not found or invalid updates
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Validate update data
        try:
            validate(instance=updates, schema=ProfileValidationSchema.PROFILE_UPDATE_SCHEMA)
        except ValidationError as e:
            error_msg = f"Invalid profile update data: {e.message}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
        
        # Get current profile
        profile = self.get_student_profile(student_id, False)
        
        # Update timestamp
        profile["updated_at"] = datetime.utcnow().isoformat() + "Z"
        
        # Apply updates
        for key, value in updates.items():
            if key in ["personal_info", "learning_preferences", "adaptive_parameters"]:
                # Merge dictionaries
                if key in profile:
                    profile[key].update(value)
                else:
                    profile[key] = value
            elif key == "goals":
                # Replace goals list
                profile[key] = value
            elif key in profile:
                # Direct update
                profile[key] = value
        
        # Validate updated profile
        self._validate_profile(profile)
        
        # Save updated profile
        self.save_student_profile(student_id, profile)
        
        return profile
    
    def add_learning_history(self, student_id: str, learning_entry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Add a learning history entry to a student profile
        
        Args:
            student_id: Student identifier
            learning_entry: Learning history entry
            
        Returns:
            Updated student profile
            
        Raises:
            StudentProfileError: If profile not found or invalid entry
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Validate learning history entry
        try:
            validate(instance=learning_entry, schema=ProfileValidationSchema.LEARNING_HISTORY_ENTRY_SCHEMA)
        except ValidationError as e:
            error_msg = f"Invalid learning history entry: {e.message}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
        
        # Get current profile
        profile = self.get_student_profile(student_id, False)
        
        # Update timestamp
        profile["updated_at"] = datetime.utcnow().isoformat() + "Z"
        
        # Add entry to learning history
        profile["learning_history"].append(learning_entry)
        
        # Save updated profile
        self.save_student_profile(student_id, profile)
        
        return profile
    
    def update_knowledge_state(self, student_id: str, concept_update: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update a student's knowledge state for a specific concept
        
        Args:
            student_id: Student identifier
            concept_update: Concept knowledge update
            
        Returns:
            Updated student profile
            
        Raises:
            StudentProfileError: If profile not found or invalid update
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Validate concept knowledge update
        try:
            validate(instance=concept_update, schema=ProfileValidationSchema.CONCEPT_KNOWLEDGE_SCHEMA)
        except ValidationError as e:
            error_msg = f"Invalid concept knowledge update: {e.message}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
        
        # Get current profile
        profile = self.get_student_profile(student_id, False)
        
        # Update timestamp
        profile["updated_at"] = datetime.utcnow().isoformat() + "Z"
        
        # Get concept ID and mastery level
        concept_id = concept_update["concept_id"]
        mastery_level = concept_update["mastery_level"]
        
        # Ensure concepts dictionary exists
        if "knowledge_state" not in profile:
            profile["knowledge_state"] = {"concepts": {}, "domains": {}}
        elif "concepts" not in profile["knowledge_state"]:
            profile["knowledge_state"]["concepts"] = {}
        
        # Update or create concept entry
        if concept_id in profile["knowledge_state"]["concepts"]:
            # Update existing concept
            profile["knowledge_state"]["concepts"][concept_id]["mastery_level"] = mastery_level
            profile["knowledge_state"]["concepts"][concept_id]["last_assessed"] = datetime.utcnow().isoformat() + "Z"
            profile["knowledge_state"]["concepts"][concept_id]["assessment_count"] = profile["knowledge_state"]["concepts"][concept_id].get("assessment_count", 0) + 1
            
            # Include assessment info if provided
            if "assessment_info" in concept_update:
                if "assessments" not in profile["knowledge_state"]["concepts"][concept_id]:
                    profile["knowledge_state"]["concepts"][concept_id]["assessments"] = []
                
                profile["knowledge_state"]["concepts"][concept_id]["assessments"].append(concept_update["assessment_info"])
        else:
            # Create new concept entry
            profile["knowledge_state"]["concepts"][concept_id] = {
                "mastery_level": mastery_level,
                "last_assessed": datetime.utcnow().isoformat() + "Z",
                "assessment_count": 1,
                "relevance": 1.0  # Default relevance
            }
            
            # Include assessment info if provided
            if "assessment_info" in concept_update:
                profile["knowledge_state"]["concepts"][concept_id]["assessments"] = [concept_update["assessment_info"]]
        
        # Save updated profile
        self.save_student_profile(student_id, profile)
        
        return profile
        
    def save_student_profile(self, student_id: str, profile: Dict[str, Any]) -> None:
        """
        Save a student profile to disk
        
        Args:
            student_id: Student identifier
            profile: Student profile to save
            
        Raises:
            StudentProfileError: If save fails
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Validate profile
        self._validate_profile(profile)
        
        # Ensure student_id in profile matches the provided ID
        if profile.get("student_id") != student_id:
            error_msg = f"Student ID mismatch: {profile.get('student_id')} != {student_id}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
        
        # Update timestamp
        profile["updated_at"] = datetime.utcnow().isoformat() + "Z"
        
        # Save to disk
        profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
        
        try:
            # Create a temporary file first
            temp_path = f"{profile_path}.tmp"
            with open(temp_path, "w") as f:
                json.dump(profile, f, indent=2)
            
            # Rename temp file to target file (atomic operation)
            os.replace(temp_path, profile_path)
            
            # Update cache
            with self.cache_lock:
                self.profile_cache[student_id] = profile
                self.modified_profiles.add(student_id)
            
            self.logger.debug(f"Saved profile for student {student_id}")
            
        except (IOError, OSError) as e:
            error_msg = f"Failed to save profile for student {student_id}: {str(e)}"
            self.logger.error(error_msg)
            
            # Clean up temp file if it exists
            if os.path.exists(f"{profile_path}.tmp"):
                try:
                    os.remove(f"{profile_path}.tmp")
                except:
                    pass
                
            raise StudentProfileError(error_msg)
    
    def delete_student_profile(self, student_id: str) -> bool:
        """
        Delete a student profile
        
        Args:
            student_id: Student identifier
            
        Returns:
            True if profile was deleted, False if not found
            
        Raises:
            StudentProfileError: If deletion fails
        """
        # Validate student ID format
        self._validate_student_id(student_id)
        
        # Check if profile exists
        profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
        
        if not os.path.exists(profile_path):
            self.logger.warning(f"Profile not found for student {student_id}")
            return False
        
        try:
            # Create backup before deletion
            self._backup_profile(student_id)
            
            # Delete profile file
            os.remove(profile_path)
            
            # Remove from cache
            with self.cache_lock:
                if student_id in self.profile_cache:
                    del self.profile_cache[student_id]
                self.modified_profiles.discard(student_id)
            
            self.logger.info(f"Deleted profile for student {student_id}")
            return True
            
        except (IOError, OSError) as e:
            error_msg = f"Failed to delete profile for student {student_id}: {str(e)}"
            self.logger.error(error_msg)
            raise StudentProfileError(error_msg)
    
    def _validate_student_id(self, student_id: str) -> None:
        """
        Validate student ID format
        
        Args:
            student_id: Student identifier
            
        Raises:
            StudentProfileError: If ID format is invalid
        """
        # Check if ID is a string
        if not isinstance(student_id, str):
            raise StudentProfileError(f"Student ID must be a string, got {type(student_id)}")
        
        # Check ID format with regex pattern
        if not re.match(r"^[a-zA-Z0-9_-]{4,64}$", student_id):
            raise StudentProfileError(
                f"Invalid student ID format: {student_id}. " + 
                "ID must be 4-64 characters and contain only letters, numbers, underscores, and hyphens."
            )
    
    def _validate_profile(self, profile: Dict[str, Any]) -> None:
        """
        Validate a student profile against the schema
        
        Args:
            profile: Student profile to validate
            
        Raises:
            ValidationError: If profile is invalid
        """
        validate(instance=profile, schema=ProfileValidationSchema.STUDENT_PROFILE_SCHEMA)
    
    def _is_empty_or_corrupt(self, profile_path: str) -> bool:
        """
        Check if a profile file is empty or corrupt
        
        Args:
            profile_path: Path to profile file
            
        Returns:
            True if file is empty or corrupt, False otherwise
        """
        try:
            # Check file size
            if os.path.getsize(profile_path) == 0:
                return True
            
            # Try to load JSON
            with open(profile_path, "r") as f:
                profile = json.load(f)
            
            # Check if it has required fields
            if not isinstance(profile, dict) or "student_id" not in profile:
                return True
            
            return False
            
        except (IOError, json.JSONDecodeError):
            return True
    
    def _backup_profile(self, student_id: str) -> bool:
        """
        Create a backup of a student profile
        
        Args:
            student_id: Student identifier
            
        Returns:
            True if backup was created, False otherwise
        """
        profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
        
        if not os.path.exists(profile_path):
            return False
            
        try:
            # Create timestamp for backup filename
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(self.backup_dir, f"{student_id}_{timestamp}.json")
            
            # Copy file to backup directory
            with open(profile_path, "r") as src:
                with open(backup_path, "w") as dst:
                    dst.write(src.read())
            
            self.logger.debug(f"Created backup of profile for student {student_id}")
            return True
            
        except (IOError, OSError) as e:
            self.logger.error(f"Failed to backup profile for student {student_id}: {str(e)}")
            return False
            
    def _load_from_backup(self, student_id: str) -> Optional[Dict[str, Any]]:
        """
        Load a student profile from the latest backup
        
        Args:
            student_id: Student identifier
        
        Returns:
            Student profile from backup, or None if no backup found
        """
        # Find all backups for this student
        backup_files = []
        for filename in os.listdir(self.backup_dir):
            if filename.startswith(f"{student_id}_") and filename.endswith(".json"):
                backup_files.append(filename)
        
        if not backup_files:
            return None
        
        # Sort by timestamp (descending)
        backup_files.sort(reverse=True)
        
        # Try to load the latest backup
        latest_backup = os.path.join(self.backup_dir, backup_files[0])
        
        try:
            with open(latest_backup, "r") as f:
                profile = json.load(f)
            
            # Validate the profile
            self._validate_profile(profile)
            
            return profile
            
        except (IOError, json.JSONDecodeError, ValidationError) as e:
            self.logger.error(f"Failed to load backup for student {student_id}: {str(e)}")
            return None
    
    def _needs_version_migration(self, profile: Dict[str, Any]) -> bool:
        """
        Check if a profile needs version migration
        
        Args:
            profile: Student profile to check
            
        Returns:
            True if migration is needed, False otherwise
        """
        # Check if profile has a version
        if "profile_version" not in profile:
            return True
        
        # Compare versions (simple string comparison for now)
        return profile["profile_version"] != self.profile_version
    
    def _migrate_profile(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Migrate a profile to the current version
        
        Args:
            profile: Student profile to migrate
            
        Returns:
            Migrated profile
        """
        # Get current version
        current_version = profile.get("profile_version", "1.0.0")
        
        # Clone the profile
        migrated = dict(profile)
        
        # Update version
        migrated["profile_version"] = self.profile_version
        
        # Perform migration based on current version
        if current_version == "1.0.0":
            # Migrate from 1.0.0 to 1.1.0
            if "knowledge_state" not in migrated:
                migrated["knowledge_state"] = {"concepts": {}, "domains": {}}
            if "goals" not in migrated:
                migrated["goals"] = []
        
        if current_version <= "1.1.0":
            # Migrate from 1.1.0 to 1.2.0
            if "adaptive_parameters" not in migrated:
                migrated["adaptive_parameters"] = {
                    "difficulty_factor": 1.0,
                    "content_diversity": 0.5,
                    "repetition_interval": 7,
                    "mastery_threshold": 0.8
                }
        
        if current_version <= "1.2.0":
            # Migrate from 1.2.0 to 1.3.0
            if "learning_history" not in migrated:
                migrated["learning_history"] = []
        
        self.logger.info(f"Migrated profile from version {current_version} to {self.profile_version}")
        
        return migrated
    
    def _backup_thread(self) -> None:
        """Background thread for automatic profile backups"""
        while self.backup_thread_running:
            try:
                # Sleep for the backup interval
                time.sleep(self.backup_interval)
                
                # Get modified profiles
                modified = set()
                with self.cache_lock:
                    modified = self.modified_profiles.copy()
                    self.modified_profiles.clear()
                
                # Backup each modified profile
                for student_id in modified:
                    self._backup_profile(student_id)
                
                if modified:
                    self.logger.info(f"Auto-backup completed for {len(modified)} profiles")
                
            except Exception as e:
                self.logger.error(f"Error in backup thread: {str(e)}")
    
    def shutdown(self) -> None:
        """Shutdown the profile manager and save all cached profiles"""
        self.logger.info("Shutting down profile manager")
        
        # Stop backup thread
        if hasattr(self, 'backup_thread_running'):
            self.backup_thread_running = False
            if hasattr(self, 'backup_thread') and self.backup_thread.is_alive():
                self.backup_thread.join(timeout=5)
        
        # Save all cached profiles
        with self.cache_lock:
            for student_id, profile in self.profile_cache.items():
                try:
                    # Save each profile
                    profile_path = os.path.join(self.storage_dir, f"{student_id}.json")
                    with open(profile_path, "w") as f:
                        json.dump(profile, f, indent=2)
                    
                    # Create backup
                    self._backup_profile(student_id)
                    
                except Exception as e:
                    self.logger.error(f"Error saving profile {student_id} during shutdown: {str(e)}")
        
        self.logger.info("Profile manager shutdown complete") 