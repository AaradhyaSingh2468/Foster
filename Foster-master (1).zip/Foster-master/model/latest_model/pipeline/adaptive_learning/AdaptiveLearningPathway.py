"""
Adaptive Learning Pathway Generator
----------------------------------
Generates personalized learning pathways based on:
- Student profile and learning history
- Document content and structure
- Knowledge prerequisites and relationships
"""

import json
from typing import Dict, List, Any, Optional, Tuple
from pipeline.adaptive_learning.StudentProfileManager import StudentProfile
from pipeline.content_analysis.ContentRelationshipAnalyzer import ContentRelationshipAnalyzer

class LearningPathwayNode:
    """Represents a node in a learning pathway"""
    
    def __init__(self, content_id: str, title: str, content_type: str, 
                difficulty: str = "standard", prerequisites: List[str] = None,
                estimated_time: int = 0):
        """
        Initialize a learning pathway node
        
        Args:
            content_id: Unique identifier for the content
            title: Title of the content
            content_type: Type of content (text, video, quiz, etc.)
            difficulty: Difficulty level (simple, standard, advanced)
            prerequisites: List of prerequisite content IDs
            estimated_time: Estimated time to complete in minutes
        """
        self.content_id = content_id
        self.title = title
        self.content_type = content_type
        self.difficulty = difficulty
        self.prerequisites = prerequisites or []
        self.estimated_time = estimated_time
        self.alternatives = []  # Alternative content covering same topics
        
    def add_alternative(self, alt_content_id: str, alt_title: str, 
                      alt_content_type: str, alt_difficulty: str):
        """
        Add an alternative version of this content
        
        Args:
            alt_content_id: ID of the alternative content
            alt_title: Title of the alternative
            alt_content_type: Type of alternative content
            alt_difficulty: Difficulty of alternative content
        """
        self.alternatives.append({
            "content_id": alt_content_id,
            "title": alt_title,
            "content_type": alt_content_type,
            "difficulty": alt_difficulty
        })
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            "content_id": self.content_id,
            "title": self.title,
            "content_type": self.content_type,
            "difficulty": self.difficulty,
            "prerequisites": self.prerequisites,
            "estimated_time": self.estimated_time,
            "alternatives": self.alternatives
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LearningPathwayNode':
        """Create from dictionary representation"""
        node = cls(
            content_id=data["content_id"],
            title=data["title"],
            content_type=data["content_type"],
            difficulty=data.get("difficulty", "standard"),
            prerequisites=data.get("prerequisites", []),
            estimated_time=data.get("estimated_time", 0)
        )
        node.alternatives = data.get("alternatives", [])
        return node

class AdaptiveLearningPathway:
    """Represents a personalized learning pathway"""
    
    def __init__(self, student_id: str, title: str = "", description: str = ""):
        """
        Initialize a learning pathway
        
        Args:
            student_id: ID of the student this pathway is for
            title: Title of the learning pathway
            description: Description of the pathway
        """
        self.student_id = student_id
        self.title = title
        self.description = description
        self.nodes = []  # Learning content nodes
        self.edges = []  # Connections between nodes
        self.progress = {}  # Node ID → completion percentage
        
    def add_node(self, node: LearningPathwayNode) -> str:
        """
        Add a content node to the pathway
        
        Args:
            node: The learning content node
            
        Returns:
            ID of the added node
        """
        self.nodes.append(node)
        self.progress[node.content_id] = 0
        return node.content_id
        
    def add_edge(self, from_node: str, to_node: str, edge_type: str = "next"):
        """
        Add a directed edge between nodes
        
        Args:
            from_node: ID of the source node
            to_node: ID of the target node
            edge_type: Type of connection (next, optional, prerequisite)
        """
        self.edges.append({
            "from": from_node,
            "to": to_node,
            "type": edge_type
        })
        
    def update_progress(self, node_id: str, completion_percentage: float):
        """
        Update progress for a specific node
        
        Args:
            node_id: ID of the node
            completion_percentage: Percentage completed (0-100)
        """
        if node_id in self.progress:
            self.progress[node_id] = min(100, max(0, completion_percentage))
            
    def get_next_nodes(self) -> List[LearningPathwayNode]:
        """
        Get the next recommended nodes based on current progress
        
        Returns:
            List of next recommended nodes
        """
        completed_nodes = [node_id for node_id, progress in self.progress.items() 
                         if progress >= 100]
        
        # Find nodes where all prerequisites are completed
        available_nodes = []
        for node in self.nodes:
            # Skip completed nodes
            if node.content_id in completed_nodes:
                continue
                
            # Check if all prerequisites are completed
            prereqs_met = all(prereq in completed_nodes for prereq in node.prerequisites)
            
            # Check incoming edges as well
            for edge in self.edges:
                if edge["to"] == node.content_id and edge["type"] == "prerequisite":
                    if edge["from"] not in completed_nodes:
                        prereqs_met = False
                        break
                        
            if prereqs_met:
                available_nodes.append(node)
                
        return available_nodes
        
    def get_overall_progress(self) -> float:
        """
        Calculate overall completion percentage
        
        Returns:
            Overall completion percentage (0-100)
        """
        if not self.nodes:
            return 0
            
        total_progress = sum(self.progress.values())
        return total_progress / len(self.nodes)
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation"""
        return {
            "student_id": self.student_id,
            "title": self.title,
            "description": self.description,
            "nodes": [node.to_dict() for node in self.nodes],
            "edges": self.edges,
            "progress": self.progress
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AdaptiveLearningPathway':
        """Create from dictionary representation"""
        pathway = cls(
            student_id=data["student_id"],
            title=data.get("title", ""),
            description=data.get("description", "")
        )
        
        pathway.nodes = [LearningPathwayNode.from_dict(node_data) 
                       for node_data in data.get("nodes", [])]
        pathway.edges = data.get("edges", [])
        pathway.progress = data.get("progress", {})
        
        return pathway

class AdaptiveLearningPathwayGenerator:
    """Generates personalized learning pathways based on student profiles"""
    
    def __init__(self, relationship_analyzer: Optional[ContentRelationshipAnalyzer] = None):
        """
        Initialize the pathway generator
        
        Args:
            relationship_analyzer: Optional analyzer for content relationships
        """
        self.relationship_analyzer = relationship_analyzer
        
    def generate_pathway(self, profile: StudentProfile, 
                       content_structure: Dict[str, Any],
                       target_concepts: List[str] = None) -> AdaptiveLearningPathway:
        """
        Generate a personalized learning pathway
        
        Args:
            profile: Student profile to personalize for
            content_structure: Structure of the content document
            target_concepts: Optional list of target concepts to focus on
            
        Returns:
            Personalized AdaptiveLearningPathway
        """
        # Create a new pathway for this student
        pathway = AdaptiveLearningPathway(
            student_id=profile.student_id,
            title=f"Personalized pathway for {content_structure.get('metadata', {}).get('title', 'Document')}",
            description=f"Custom learning pathway adapted to {profile.name}'s profile"
        )
        
        # Extract metadata and structure
        metadata = content_structure.get("metadata", {})
        document_title = metadata.get("title", "Document")
        
        # Determine appropriate difficulty level based on student profile
        difficulty = profile.get_recommended_difficulty()
        
        # Find content blocks and segments
        content_blocks = content_structure.get("content_blocks", [])
        content_segments = content_structure.get("semantic_analysis", {}).get("content_segments", [])
        
        # Get concept relationships if available
        concept_graph = content_structure.get("relationships", {}).get("concept_graph", {})
        prerequisites = content_structure.get("relationships", {}).get("prerequisites", {})
        
        # Build learning path nodes
        nodes_by_id = {}
        nodes_by_concept = {}
        
        # Process structured content sections
        sections = self._extract_content_sections(content_structure)
        
        # 1. Create nodes for each relevant section
        for i, section in enumerate(sections):
            # Skip sections that are too advanced or too basic based on profile
            section_difficulty = self._estimate_section_difficulty(section)
            
            node_id = f"section-{i+1}"
            
            # Create node for this section
            node = LearningPathwayNode(
                content_id=node_id,
                title=section.get("heading", f"Section {i+1}"),
                content_type="text",
                difficulty=section_difficulty,
                estimated_time=self._estimate_reading_time(section.get("content", ""))
            )
            
            # Extract main concepts from this section
            section_concepts = self._extract_concepts_from_section(section)
            
            # Check if student already knows these concepts well
            if self._student_knows_concepts(profile, section_concepts) and difficulty != "advanced":
                # For sections the student already knows, make them optional
                node.difficulty = "review"
                
            # Check if section covers target concepts
            if target_concepts and not any(concept in section_concepts for concept in target_concepts):
                # Skip sections not relevant to target concepts unless they're prerequisites
                if not self._is_prerequisite_for_targets(section_concepts, target_concepts, prerequisites):
                    continue
                    
            # Add node to pathway
            pathway.add_node(node)
            nodes_by_id[node_id] = node
            
            # Map concepts to this node
            for concept in section_concepts:
                if concept not in nodes_by_concept:
                    nodes_by_concept[concept] = []
                nodes_by_concept[concept].append(node_id)
                
        # 2. Connect nodes based on prerequisites and structure
        for node_id, node in nodes_by_id.items():
            # Find prerequisites for this node's concepts
            node_concepts = self._extract_concepts_from_section(
                next((s for s in sections if s.get("heading") == node.title), {})
            )
            
            for concept in node_concepts:
                if concept in prerequisites:
                    for prereq_concept in prerequisites[concept]:
                        # Find nodes containing this prerequisite concept
                        if prereq_concept in nodes_by_concept:
                            for prereq_node_id in nodes_by_concept[prereq_concept]:
                                # Add prerequisite relationship
                                pathway.add_edge(prereq_node_id, node_id, "prerequisite")
                                # Add to node's prerequisites
                                if prereq_node_id not in node.prerequisites:
                                    node.prerequisites.append(prereq_node_id)
        
        # 3. Add alternative versions of content based on learning style
        self._add_content_alternatives(pathway, profile, content_structure)
        
        # 4. Optimize pathway based on student's pace
        self._optimize_for_learning_pace(pathway, profile.learning_pace)
        
        return pathway
    
    def _extract_content_sections(self, content_structure: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract structured sections from content"""
        sections = []
        
        # Check for document structure
        if "document_structure" in content_structure:
            return content_structure["document_structure"]
            
        # Check for content blocks organized by heading
        if "semantic_analysis" in content_structure and "content_blocks" in content_structure["semantic_analysis"]:
            current_section = None
            
            for block in content_structure["semantic_analysis"]["content_blocks"]:
                if block.get("type") == "heading":
                    # Start a new section
                    if current_section:
                        sections.append(current_section)
                        
                    current_section = {
                        "heading": block.get("text", "Unnamed Section"),
                        "content": "",
                        "level": block.get("level", 1)
                    }
                elif current_section:
                    # Add content to current section
                    current_section["content"] += block.get("text", "") + "\n"
            
            # Add the last section
            if current_section:
                sections.append(current_section)
                
        # Fall back to raw extraction if no structure
        if not sections and "raw_extraction" in content_structure:
            text = content_structure["raw_extraction"].get("text", "")
            sections.append({
                "heading": "Complete Document",
                "content": text,
                "level": 0
            })
            
        return sections
    
    def _estimate_section_difficulty(self, section: Dict[str, Any]) -> str:
        """Estimate section difficulty based on content"""
        content = section.get("content", "")
        
        # Simple heuristics for difficulty estimation
        word_count = len(content.split())
        avg_word_length = sum(len(word) for word in content.split()) / max(1, word_count)
        
        if word_count > 1000 and avg_word_length > 7:
            return "advanced"
        elif word_count > 500 and avg_word_length > 6:
            return "standard"
        else:
            return "simple"
            
    def _estimate_reading_time(self, content: str) -> int:
        """Estimate reading time in minutes"""
        word_count = len(content.split())
        # Average reading speed: 200-250 words per minute
        return max(1, word_count // 225)
        
    def _extract_concepts_from_section(self, section: Dict[str, Any]) -> List[str]:
        """Extract key concepts from a section"""
        concepts = []
        
        if "concepts" in section:
            concepts = section["concepts"]
        elif "semantic_tags" in section:
            concepts = section["semantic_tags"]
        elif self.relationship_analyzer and "content" in section:
            # Use relationship analyzer to extract concepts
            extracted = self.relationship_analyzer.extract_key_concepts(section["content"])
            if extracted:
                concepts = extracted
                
        # If no concepts detected, extract from heading
        if not concepts and "heading" in section:
            heading = section["heading"]
            # Simple extraction from heading
            concepts = [word.strip() for word in heading.split() 
                      if len(word) > 3 and word.lower() not in ["and", "the", "for", "with"]]
                
        return concepts
        
    def _student_knows_concepts(self, profile: StudentProfile, concepts: List[str]) -> bool:
        """Check if student already knows the concepts well"""
        if not profile.knowledge_areas:
            return False
            
        # For each domain in the student's knowledge areas
        for domain, topics in profile.knowledge_areas.items():
            # Check if any concept matches a known topic with high proficiency
            for concept in concepts:
                concept_lower = concept.lower()
                for topic, proficiency in topics.items():
                    if concept_lower in topic.lower() and proficiency >= 0.8:
                        # Student knows this concept well
                        return True
                        
        return False
        
    def _is_prerequisite_for_targets(self, concepts: List[str], targets: List[str], 
                                  prerequisites: Dict[str, List[str]]) -> bool:
        """Check if concepts are prerequisites for target concepts"""
        # For each target concept
        for target in targets:
            # Check if it has prerequisites
            if target in prerequisites:
                # Check if any of our concepts are prerequisites for it
                for concept in concepts:
                    if concept in prerequisites[target]:
                        return True
                        
                # Recursively check through the prerequisite chain
                for prereq in prerequisites[target]:
                    if self._is_prerequisite_for_targets([prereq], targets, prerequisites):
                        return True
                        
        return False
        
    def _add_content_alternatives(self, pathway: AdaptiveLearningPathway, 
                               profile: StudentProfile, 
                               content_structure: Dict[str, Any]):
        """Add alternative content formats based on learning style"""
        # Get learning style preferences
        visual_pref = profile.learning_style.get("visual", 0.5)
        textual_pref = profile.learning_style.get("textual", 0.5)
        interactive_pref = profile.learning_style.get("interactive", 0.5)
        
        # Get available visualizations
        visualizations = content_structure.get("visual_elements", {}).get("diagrams", [])
        
        # Get additional explanations
        explanations = content_structure.get("enrichments", {}).get("explanations", {})
        
        # For each node in the pathway
        for node in pathway.nodes:
            # For visual learners, add diagram alternatives
            if visual_pref > 0.6:
                for viz in visualizations:
                    # Check if visualization is relevant to this node
                    if any(keyword in node.title.lower() for keyword in viz.get("keywords", [])):
                        node.add_alternative(
                            alt_content_id=f"{node.content_id}-visual",
                            alt_title=f"{node.title} (Visual Version)",
                            alt_content_type="visualization",
                            alt_difficulty=node.difficulty
                        )
            
            # For interactive learners, add quiz alternatives
            if interactive_pref > 0.6:
                node.add_alternative(
                    alt_content_id=f"{node.content_id}-interactive",
                    alt_title=f"{node.title} (Interactive Version)",
                    alt_content_type="quiz",
                    alt_difficulty=node.difficulty
                )
                
            # For textual learners, add detailed explanation alternatives
            if textual_pref > 0.6:
                # Check if there are enriched explanations available
                has_explanation = False
                for concept, explanation in explanations.items():
                    if concept.lower() in node.title.lower():
                        node.add_alternative(
                            alt_content_id=f"{node.content_id}-detailed",
                            alt_title=f"{node.title} (Detailed Explanation)",
                            alt_content_type="text",
                            alt_difficulty=node.difficulty
                        )
                        has_explanation = True
                        break
                
                # Add simpler explanation for difficult content
                if node.difficulty == "advanced" and not has_explanation:
                    node.add_alternative(
                        alt_content_id=f"{node.content_id}-simplified",
                        alt_title=f"{node.title} (Simplified)",
                        alt_content_type="text",
                        alt_difficulty="standard"
                    )
        
    def _optimize_for_learning_pace(self, pathway: AdaptiveLearningPathway, pace: str):
        """Optimize the pathway based on student's learning pace"""
        if pace == "fast":
            # For fast learners, reduce repetition and simplify prerequisites
            self._optimize_for_fast_learners(pathway)
        elif pace == "slow":
            # For slow learners, add more reinforcement nodes
            self._optimize_for_slow_learners(pathway)
    
    def _optimize_for_fast_learners(self, pathway: AdaptiveLearningPathway):
        """Optimize pathway for fast learners"""
        # Identify redundant nodes (nodes covering same concepts)
        redundant_nodes = []
        concept_coverage = {}
        
        # Map concepts to nodes
        for node in pathway.nodes:
            node_concepts = []
            for alt in node.alternatives:
                if alt["content_type"] == "text" and "Detailed" in alt["title"]:
                    # Favor detailed explanations for fast learners
                    node.title = alt["title"]
                    node.content_id = alt["content_id"]
                    break
        
        # Prune edges to simplify the pathway
        simplified_edges = []
        for edge in pathway.edges:
            # Keep only the most important prerequisite edges
            if edge["type"] == "prerequisite":
                # Check if there's a transitive prerequisite
                has_transitive = False
                for other_edge in pathway.edges:
                    if other_edge["to"] == edge["to"] and other_edge["from"] != edge["from"]:
                        # Check if edge["from"] is prerequisite of other_edge["from"]
                        for third_edge in pathway.edges:
                            if third_edge["to"] == other_edge["from"] and third_edge["from"] == edge["from"]:
                                has_transitive = True
                                break
                
                if not has_transitive:
                    simplified_edges.append(edge)
            else:
                simplified_edges.append(edge)
                
        pathway.edges = simplified_edges
        
    def _optimize_for_slow_learners(self, pathway: AdaptiveLearningPathway):
        """Optimize pathway for slow learners"""
        # Add reinforcement nodes between complex topics
        new_nodes = []
        new_edges = []
        
        for i, node in enumerate(pathway.nodes):
            # If this is a complex node
            if node.difficulty == "advanced" or node.difficulty == "standard":
                # Add a reinforcement node after it
                review_node = LearningPathwayNode(
                    content_id=f"{node.content_id}-review",
                    title=f"Review: {node.title}",
                    content_type="quiz",
                    difficulty="simple",
                    prerequisites=[node.content_id],
                    estimated_time=15
                )
                new_nodes.append(review_node)
                
                # Connect review node to original node
                new_edges.append({
                    "from": node.content_id,
                    "to": review_node.content_id,
                    "type": "next"
                })
                
                # Find nodes that had the original node as prerequisite
                for edge in pathway.edges:
                    if edge["from"] == node.content_id:
                        # Make those nodes depend on the review instead
                        new_edges.append({
                            "from": review_node.content_id,
                            "to": edge["to"],
                            "type": edge["type"]
                        })
        
        # Add new nodes and edges to pathway
        for node in new_nodes:
            pathway.add_node(node)
            
        pathway.edges.extend(new_edges)
        
        # Also, favor simplified versions of content for slow learners
        for node in pathway.nodes:
            for alt in node.alternatives:
                if alt["content_type"] == "text" and "Simplified" in alt["title"]:
                    # Use simplified versions as default for slow learners
                    node.title = alt["title"]
                    node.content_id = alt["content_id"]
                    break 