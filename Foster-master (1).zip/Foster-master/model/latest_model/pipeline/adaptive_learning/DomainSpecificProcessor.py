from DomainRulesManager import DomainRulesManager
from domainicProcessor import *

class DomainSpecificProcessor:
    def __init__(self, domain_type, language_model=None):
        """
        Initialize the DomainSpecificProcessor with a specified domain type.

        Args:
            domain_type (str): The domain type to specialize in (science, math, literature, etc.)
            language_model: Optional pre-trained language model
        """
        self.domain_type = domain_type.lower() if domain_type else None
        self.language_model = language_model

        # Domain-specific entity patterns
        self.domain_patterns = self._initialize_domain_patterns()

        # Initialize domain processors
        self._initialize_domain_processors()
    
    def _initialize_domain_patterns(self):
        """
        Initialize regex patterns and rules for different domains.

        Returns:
            Dictionary of patterns for each domain
        """
        # Simply use the domain rules manager instead of recreating logic
        domains = ['science', 'math', 'literature', 'chemistry', 'biology', 'physics']
        patterns = {}
     
        # Load rules for each domain
        for domain in domains:
            patterns[domain] = DomainRulesManager.get_domain_rules(domain)
            
        return patterns
    
    def _initialize_domain_processors(self):
        """
        Initialize domain-specific processors.
        """
        # Initialize domain processors with appropriate patterns
        self.domain_processors = {
            'science': ScienceProcessor(self.domain_patterns.get('science', {})),
            'math': MathProcessor(self.domain_patterns.get('math', {})),
            'literature': LiteratureProcessor(self.domain_patterns.get('literature', {})),
            'chemistry': ChemistryProcessor(self.domain_patterns.get('chemistry', {})),
            'biology': BiologyProcessor(self.domain_patterns.get('biology', {})),
            'physics': PhysicsProcessor(self.domain_patterns.get('physics', {}))
        }
        
        # If language model is provided, update processor initialization
        if self.language_model is not None:
            for domain, processor in self.domain_processors.items():
                processor.language_model = self.language_model
    
    def process_domain_content(self, extraction_result):
        """
        Process content according to domain-specific rules.

        Args:
            extraction_result (dict): The extraction result from PDF processor

        Returns:
            Dictionary with domain-specific processing results added
        """
        if not self.domain_type or self.domain_type not in self.domain_processors:
            # If domain is not supported, return the original extraction result
            return extraction_result

        # Create a copy of the extraction result to modify
        processed_result = extraction_result.copy()

        # If language model is available, use it for enhanced processing
        if self.language_model is not None:
            return self._process_with_language_model(processed_result)

        # Apply domain-specific processing
        domain_processor = self.domain_processors[self.domain_type]
        domain_specific_data = domain_processor.process(processed_result)

        # Add domain-specific results to the processed result
        processed_result['domain_analysis'] = {
            'domain_type': self.domain_type,
            'domain_entities': domain_specific_data
        }

        return processed_result
    
    def _process_with_language_model(self, extraction_result):
        """
        Use the provided language model to perform domain-specific content analysis.

        Args:
            extraction_result (dict): Dictionary containing the extracted content

        Returns:
            Dictionary with enhanced domain-specific analysis from the language model
        """
        processed_result = extraction_result.copy()
        text_content = extraction_result.get('text_content', '')

        if not text_content:
            # Fallback to original method if no text content is available
            return self.process_domain_content(extraction_result)

        # Get common analysis applicable to all domains
        model_analysis = {
            'keywords_and_concepts': self.language_model.extract_keywords(text_content, self.domain_type),
            'content_segments': self.language_model.segment_content(text_content),
            'semantic_tags': self.language_model.generate_semantic_tags(text_content, self.domain_type)
        }

        # Add domain-specific analysis
        if self.domain_type == 'science':
            model_analysis['science_analysis'] = self.language_model.analyze_scientific_content(
                text_content
            )
        elif self.domain_type == 'math':
            model_analysis['math_analysis'] = self.language_model.analyze_mathematical_content(
                text_content
            )
        elif self.domain_type == 'literature':
            model_analysis['literary_analysis'] = self.language_model.analyze_literary_content(
                text_content
            )
        elif self.domain_type == 'chemistry':
            model_analysis['chemistry_analysis'] = self.language_model.analyze_chemical_content(
                text_content
            )
        elif self.domain_type == 'biology':
            model_analysis['biology_analysis'] = self.language_model.analyze_biological_content(
                text_content
            )
        elif self.domain_type == 'physics':
            model_analysis['physics_analysis'] = self.language_model.analyze_physics_content(
                text_content
            )

        # Add section-specific analysis if sections exist
        if 'sections' in extraction_result:
            model_analysis['section_analysis'] = {}
            for section_id, section_content in extraction_result['sections'].items():
                model_analysis['section_analysis'][section_id] = self.language_model.analyze_section(
                    section_content, self.domain_type
                )

        # Add domain-specific results to the processed result
        processed_result['domain_analysis'] = {
            'domain_type': self.domain_type,
            'domain_entities': model_analysis
        }

        return processed_result