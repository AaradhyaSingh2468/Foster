# Educational Content Pipeline

## Table of Contents
- [Introduction](#introduction)
- [Installation](#installation)
- [Project Structure](#project-structure)
- [Core Architecture](#core-architecture)
  - [WorkflowCoordinator](#workflowcoordinator)
  - [PDF Extraction Module](#pdf-extraction-module)
  - [Content Analysis Pipeline](#content-analysis-pipeline)
  - [Multimedia Generation](#multimedia-generation)
  - [Adaptive Learning System](#adaptive-learning-system)
- [Support Architecture](#support-architecture)
  - [Dependency Injection](#dependency-injection)
  - [Event System](#event-system)
  - [Error Handling](#error-handling)
  - [Configuration Management](#configuration-management)
- [Component Interactions](#component-interactions)
  - [Workflow Process](#workflow-process)
  - [Communication Flow](#communication-flow)
- [Technical Features](#technical-features)
  - [Parallel Processing](#parallel-processing)
  - [Monitoring & Metrics](#monitoring--metrics)
  - [Configuration](#configuration)
- [Development & Testing](#development--testing)
- [References](#references)

---

## Introduction
The Educational Content Pipeline is a modular, scalable system designed to process PDF inputs into enriched multimedia assets and adaptive learning feedback. It orchestrates extraction, analysis, generation, and personalization in a seamless, event-driven workflow.

## Installation
```bash
pip install -r requirements.txt
```

## Project Structure

### Root Directory
- `WorkflowCoordinator.py`: Orchestrates the pipeline end-to-end, manages configuration, parallel/distributed execution, and event coordination.
- `__init__.py`: Package initialization.
- `requirements.txt`: Lists Python dependencies.

### pdf_extraction/
- `PDFContentExtractor.py`: Core PDF text and structural extraction logic.
- `EnhancedPDFExtractor.py`: Advanced PDF parsing and preprocessing.
- `__init__.py`: Module initializer.

### content_analysis/
- `ContentAnalysisPipeline.py`: Orchestrates document analysis workflow.
- `ContentAnalyzer.py`: Performs semantic and structural analysis.
- `ContentEnrichment.py`: Enhances content with metadata and context.
- `VisualizationElementExtractor.py`: Extracts visual elements (images, tables, charts).
- `ContentRelationshipAnalyzer.py`: Identifies relationships within content.
- `LiteraryWorkAnalyzer.py`: Handles literary content-specific analysis.
- `utils.py`, `contentHelper.py`: Helper utilities and functions.
- `config.py`: Content-analysis-specific configuration definitions.

### multimedia/
- `MultimediaPipeline.py`: Oversees multimedia asset generation.
- `ScriptGenerator.py`: Generates narrative scripts and makes HTTP requests to external language-model APIs.
- `TextToSpeech.py`: Converts text into speech audio.
- `AnimationGenerator.py`: Creates animations and calls external APIs.
- `VideoCompiler.py`: Compiles and synchronizes video assets.
- `mistralModel.py`: Integrates with Mistral backend via HTTP requests.

### adaptive_learning/
- `AdaptiveLearningManager.py`: Manages adaptive learning workflow; fetches external data via HTTP (e.g., wiki lookups).
- `StudentProfileManager.py`: Handles student profile data and persistence.
- `AdaptiveLearningPathway.py`: Constructs personalized learning pathways.
- `DomainSpecificProcessor.py`, `domainicProcessor.py`: Applies domain-specific content processing rules.
- `DomainRulesManager.py`: Stores and manages domain processing rules.

### di/
- `DependencyContainer.py`: Dependency Injection container for component instantiation and lifecycle management.

### events/
- `EventSystem.py`: Implements the event bus, event types, and monitoring utilities.

### errors/
- `WorkflowErrors.py`: Defines custom error classes for each pipeline stage.

### config/
- `ComponentConfig.py`: Defines typed configuration classes and loaders.

### workflow/
- `services/`: Workflow-related service implementations (backend tasks, scheduling).
- `persistence/`: Persistence layer models and data access objects.
- `models/`: Domain models for workflow data.

### services/
- (Internal service connectors, if any).

### tests/
- Contains unit and integration tests for all components.

> **Note:** All components are backend modules. There is no frontend/UI code. Some modules make HTTP calls to external services (ScriptGenerator, mistralModel, AnimationGenerator, AdaptiveLearningManager) but none expose HTTP endpoints for frontend consumption.

## Core Architecture

### WorkflowCoordinator
Coordinates the end-to-end workflow, handles parallel and distributed execution, error management, and event-based monitoring.

### PDF Extraction Module
Responsible for extracting text and visual elements from uploaded PDFs to prepare data for analysis.

### Content Analysis Pipeline
Analyzes document structure, semantic relationships, and enriches content with additional context and metadata.

### Multimedia Generation
Converts analyzed content into synchronized video and audio assets, integrating visual elements for instructional delivery.

### Adaptive Learning System
Manages student profiles, adapts learning paths based on performance, and generates personalized feedback loops.

## Support Architecture

### Dependency Injection
Implements a DI container for component instantiation, configuration management, and lifecycle control.

### Event System
Provides an asynchronous, pub/sub event bus for communication between modules, including event monitoring and logging.

### Error Handling
Defines specialized error classes per stage—extraction, analysis, multimedia, adaptive learning—to enable granular recovery strategies.

### Configuration Management
Centralizes settings in typed configurations, supports environment-specific overrides, and dynamic updates.

## Component Interactions

### Workflow Process
1. **Extraction**: PDF → raw content
2. **Analysis**: raw content → enriched insights
3. **Multimedia Generation**: insights → multimedia assets
4. **Adaptive Feedback**: assets + student data → personalized feedback

### Communication Flow
Modules exchange status and data via the EventBus, while the WorkflowCoordinator orchestrates task scheduling and error handling.

## Technical Features

### Parallel Processing
- Thread pools for I/O-bound tasks
- Process pools for CPU-bound tasks
- Optional distributed processing via Ray

### Monitoring & Metrics
Real-time tracking of performance, resource utilization, and workflow stages for observability and scaling decisions.

### Configuration
Typed, validated configuration with support for deep-merging custom options without altering original settings.

## Development & Testing

- **Testing**: Unit and integration tests are located in the `tests/` directory.
- **Linting**: Enforce code style with `flake8`.
- **Continuous Integration**: Automated pipelines for builds and tests (e.g., GitHub Actions).

## References
1. File and Folder Exclude Architecture (r1soft) [1]
2. Including an empty directory in a Maven assembly (StackOverflow) [2]
3. Writing and Organizing Tests in Cypress (Cypress Docs) [3]

---

[1]: http://wiki.r1soft.com/display/TP/File+and+Folder+Exclude+Architecture
[2]: https://stackoverflow.com/questions/7909183/how-do-i-include-an-empty-directory-in-a-maven-assembly
[3]: https://docs.cypress.io/app/core-concepts/writing-and-organizing-tests 