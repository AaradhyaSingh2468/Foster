"""
Event System
-----------
Provides event bus functionality for workflow event handling and monitoring.
"""

from enum import Enum, auto
from typing import Dict, Any, Optional, List, Callable
import logging
from datetime import datetime

class EventType(Enum):
    """Workflow event types"""
    # Workflow lifecycle events
    WORKFLOW_STARTED = auto()
    WORKFLOW_COMPLETED = auto()
    WORKFLOW_FAILED = auto()
    
    # PDF extraction events
    EXTRACTION_STARTED = auto()
    EXTRACTION_COMPLETED = auto()
    EXTRACTION_FAILED = auto()
    
    # Content analysis events
    ANALYSIS_STARTED = auto()
    ANALYSIS_COMPLETED = auto()
    ANALYSIS_FAILED = auto()
    
    # Multimedia generation events
    MULTIMEDIA_STARTED = auto()
    MULTIMEDIA_COMPLETED = auto()
    MULTIMEDIA_FAILED = auto()
    
    # Adaptive learning events
    ADAPTIVE_STARTED = auto()
    ADAPTIVE_COMPLETED = auto()
    ADAPTIVE_FAILED = auto()
    
    # Resource events
    RESOURCE_LIMIT_WARNING = auto()
    RESOURCE_LIMIT_EXCEEDED = auto()

class Event:
    """Represents a workflow event"""
    
    def __init__(self, event_type: EventType, workflow_id: str, data: Optional[Dict[str, Any]] = None):
        """
        Initialize an event
        
        Args:
            event_type: Type of event
            workflow_id: ID of the workflow that generated the event
            data: Optional event data
        """
        self.type = event_type
        self.workflow_id = workflow_id
        self.data = data or {}
        self.timestamp = datetime.now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary for serialization"""
        return {
            "type": self.type.name,
            "workflow_id": self.workflow_id,
            "data": self.data,
            "timestamp": self.timestamp.isoformat()
        }

class EventBus:
    """
    Event bus for workflow event handling.
    Implements publish-subscribe pattern.
    """
    
    def __init__(self):
        """Initialize event bus"""
        self.subscribers: Dict[EventType, List[Callable]] = {}
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Initialize empty subscriber lists for all event types
        for event_type in EventType:
            self.subscribers[event_type] = []
    
    def subscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """
        Subscribe to events of a specific type
        
        Args:
            event_type: Type of events to subscribe to
            callback: Function to call when event occurs
        """
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(callback)
    
    def unsubscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> None:
        """
        Unsubscribe from events of a specific type
        
        Args:
            event_type: Type of events to unsubscribe from
            callback: Function to unsubscribe
        """
        if event_type in self.subscribers and callback in self.subscribers[event_type]:
            self.subscribers[event_type].remove(callback)
    
    def publish(self, event: Event) -> None:
        """
        Publish an event to all subscribers
        
        Args:
            event: Event to publish
        """
        if event.type in self.subscribers:
            for callback in self.subscribers[event.type]:
                try:
                    callback(event)
                except Exception as e:
                    self.logger.error(f"Error in event handler: {str(e)}")
    
    def publish_for_workflow(self, workflow_id: str, event_type: EventType, 
                           data: Optional[Dict[str, Any]] = None) -> None:
        """
        Publish an event for a specific workflow
        
        Args:
            workflow_id: ID of the workflow
            event_type: Type of event
            data: Optional event data
        """
        event = Event(event_type, workflow_id, data)
        self.publish(event)

    def subscribe_to_all(self, callback: Callable[[Event], None]) -> None:
        """
        Subscribe to all event types
        
        Args:
            callback: Function to call when any event occurs
        """
        for event_type in EventType:
            self.subscribe(event_type, callback)

# Global event bus instance
_event_bus = None

def get_event_bus() -> EventBus:
    """Get the global event bus instance"""
    global _event_bus
    if _event_bus is None:
        _event_bus = EventBus()
    return _event_bus

def reset_event_bus() -> None:
    """Reset the global event bus (mainly for testing)"""
    global _event_bus
    _event_bus = None 