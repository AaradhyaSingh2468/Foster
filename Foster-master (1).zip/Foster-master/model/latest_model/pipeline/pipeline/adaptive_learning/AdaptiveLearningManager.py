"""
Adaptive Learning Manager
------------------------
Main integration module that connects:
- PDF Extraction Pipeline
- Student Profile Management
- Adaptive Learning Pathway Generation
- Content Personalization
"""

import os
import json
import uuid
from typing import Dict, List, Any, Optional, Union
from datetime import datetime

# Import core components
from pipeline.content_analysis.ContentAnalysisPipeline import ContentAnalysisPipeline
from pipeline.adaptive_learning.StudentProfileManager import StudentProfileManager, StudentProfile
from pipeline.adaptive_learning.AdaptiveLearningPathway import AdaptiveLearningPathwayGenerator, AdaptiveLearningPathway
from pipeline.adaptive_learning.PersonalizedLearningSession import PersonalizedLearningSession

class AdaptiveLearningManager:
    """Main manager class for adaptive learning integration"""
    
    def __init__(self, domain: str = None, 
               storage_dir: str = "adaptive_learning",
               profile_manager: StudentProfileManager = None,
               pipeline: ContentAnalysisPipeline = None):
        """
        Initialize the adaptive learning manager
        
        Args:
            domain: Optional domain specification
            storage_dir: Directory for storing adaptive learning data
            profile_manager: Optional StudentProfileManager instance
            pipeline: Optional ContentAnalysisPipeline instance
        """
        self.domain = domain
        self.storage_dir = storage_dir
        self.profile_manager = profile_manager or StudentProfileManager()
        self.pipeline = pipeline or ContentAnalysisPipeline(domain=domain)
        self.pathway_generator = AdaptiveLearningPathwayGenerator()
        
        # Create storage directories
        os.makedirs(storage_dir, exist_ok=True)
        os.makedirs(os.path.join(storage_dir, "documents"), exist_ok=True)
        os.makedirs(os.path.join(storage_dir, "sessions"), exist_ok=True)
        
        # Active learning sessions
        self.active_sessions = {}

    def process_document(self, pdf_path: str, output_dir: Optional[str] = None) -> str:
        """
        Process a document for adaptive learning
        
        Args:
            pdf_path: Path to the PDF document
            output_dir: Optional output directory for processed content
            
        Returns:
            Document ID for the processed content
        """
        # Generate a unique document ID
        document_id = str(uuid.uuid4())
        
        # Always store in the documents subdirectory of storage_dir for consistency
        document_dir = os.path.join(self.storage_dir, "documents", document_id)
        os.makedirs(document_dir, exist_ok=True)
        
        # If output_dir is specified, use it as an additional output location
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        # Process the document using the content analysis pipeline
        analysis_result = self.pipeline.process_document(
            pdf_path=pdf_path,
            output_dir=document_dir  # Always save to document_dir first
        )
        
        # Save the analysis result in the document directory
        result_path = os.path.join(document_dir, "analysis_result.json")
        with open(result_path, "w") as f:
            json.dump(analysis_result, f, indent=2)
        
        # If output_dir was specified, also save there
        if output_dir:
            output_result_path = os.path.join(output_dir, "analysis_result.json")
            with open(output_result_path, "w") as f:
                json.dump(analysis_result, f, indent=2)
        
        return document_id

    def create_personalized_pathway(self, student_id: str, document_id: str, 
                                     target_concepts: List[str] = None) -> str:
        """
        Create a personalized learning pathway
        
        Args:
            student_id: ID of the student
            document_id: ID of the processed document
            target_concepts: Optional list of concepts to focus on
            
        Returns:
            Session ID for the created pathway
        """
        # Get student profile
        profile_dict = self.profile_manager.get_student_profile(student_id)
        
        if not profile_dict:
            # Create a default profile if not found
            profile_dict = self.profile_manager.create_student_profile(student_id)
            
        # Convert dictionary to StudentProfile object
        profile = StudentProfile.from_dict(profile_dict)
        
        # Load processed document
        document = self._load_processed_document(document_id)
        
        if not document:
            raise ValueError(f"Document {document_id} not found")
        
        # Generate adaptive pathway
        pathway = self.pathway_generator.generate_pathway(
            profile=profile,
            content_structure=document,
            target_concepts=target_concepts
        )
        
        # Create a learning session
        session_id = f"{student_id}_{document_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        session = PersonalizedLearningSession(
            student_id=student_id,
            document_id=document_id,
            pathway=pathway
        )
        
        # Save and activate session
        self._save_session(session_id, session)
        self.active_sessions[session_id] = session
        
        return session_id

    def _load_processed_document(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Load a processed document's analysis results
        
        Args:
            document_id: ID of the document to load
            
        Returns:
            Document analysis results or None if not found
        """
        # Always look in the documents subdirectory of storage_dir
        result_path = os.path.join(self.storage_dir, "documents", document_id, "analysis_result.json")
        
        if not os.path.exists(result_path):
            return None
            
        try:
            with open(result_path, "r") as f:
                return json.load(f)
        except (IOError, json.JSONDecodeError):
            return None

    def _save_session(self, session_id: str, session: PersonalizedLearningSession) -> None:
        """
        Save a learning session to disk
        
        Args:
            session_id: ID of the session
            session: The learning session to save
        """
        session_path = os.path.join(self.storage_dir, "sessions", f"{session_id}.json")
        
        try:
            with open(session_path, "w") as f:
                json.dump(session.to_dict(), f, indent=2)
        except (IOError, TypeError) as e:
            raise ValueError(f"Failed to save session {session_id}: {str(e)}") 