"""
Enhanced PDF Content Extractor with Inheritance
----------------------------------------------
Extends the original PDFContentExtractor with improved:
- Text cleaning and noise removal
- Better heading detection
- Content organization
- JSON and TXT output formats
"""
import os
import re
from typing import Dict, List
from pipeline.pdf_extraction.PDFContentExtractor import PDFContentExtractor, PDFQuality
import logging
import unicodedata
import cv2
import numpy as np
from PIL import Image, ImageEnhance
import tempfile
import io
import pytesseract
import fitz
from collections import defaultdict
import string

class EnhancedPDFExtractor(PDFContentExtractor):
    def __init__(self, tesseract_path=None, math_recognition=True, chem_recognition=True):
        """
        Initialize the enhanced PDF content extractor, inheriting from PDFContentExtractor
        
        Args:
            tesseract_path: Path to Tesseract OCR executable
            math_recognition: Boolean to enable mathematical expression recognition
            chem_recognition: Boolean to enable chemical formula recognition
        """
        # Initialize the parent class
        super().__init__(tesseract_path, math_recognition, chem_recognition)
        
        # Configure logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(__name__)
        
        # Additional regex patterns for cleaning
        self.noise_patterns = [
            re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]'),  # Control characters
            re.compile(r'^\s*$'),  # Empty lines
            re.compile(r'^\s*[.•■□○●◆◇★☆♦♠♣♥→←↑↓⇒⇐⇑⇓⇔⇕⇖⇗⇘⇙]+\s*$'),  # Lines with only bullets/symbols
        ]
        
        # Thresholds for content analysis
        self.min_content_length = 10  # Minimum characters for meaningful content
        self.min_words_for_content = 3  # Minimum words for meaningful content
        self.font_title_threshold = 1.5  # Font size ratio for titles
        self.font_heading_threshold = 1.2  # Font size ratio for headings

    def analyze_pdf_quality(self, pdf_path: str) -> PDFQuality:
        """
        Analyze PDF to determine its quality and complexity
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            PDFQuality enum indicating the document quality
        """
        try:
            doc = fitz.open(pdf_path)
            
            # Initialize quality indicators
            text_based = 0
            image_based = 0
            formatting_complexity = 0
            total_pages = len(doc)
            
            for page in doc:
                # Check text content
                text = page.get_text()
                if len(text.strip()) > 100:
                    text_based += 1
                
                # Check images
                image_list = page.get_images()
                if len(image_list) > 0:
                    image_based += 1
                    
                # Check formatting (fonts, colors)
                fonts = page.get_fonts()
                if len(fonts) > 2:  # More than 2 fonts indicates complex formatting
                    formatting_complexity += 1
            
            doc.close()
            
            # Calculate ratios
            text_ratio = text_based / total_pages
            image_ratio = image_based / total_pages
            format_ratio = formatting_complexity / total_pages
            
            # Determine quality based on ratios
            if text_ratio < 0.1 and image_ratio > 0.8:
                return PDFQuality.SCANNED
            elif format_ratio > 0.7 or (text_ratio > 0.4 and image_ratio > 0.4):
                return PDFQuality.COMPLEX
            elif text_ratio > 0.8 and format_ratio < 0.3:
                return PDFQuality.SIMPLE
            elif text_ratio > 0.5 or image_ratio > 0.5:
                return PDFQuality.STANDARD
            else:
                return PDFQuality.PROBLEMATIC
                
        except Exception as e:
            self.logger.error(f"Error analyzing PDF quality: {e}")
            return PDFQuality.PROBLEMATIC

    def is_scanned_document(self, pdf_path: str) -> bool:
        """
        Determine if the PDF is primarily a scanned document
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            True if document is primarily scanned, False otherwise
        """
        try:
            doc = fitz.open(pdf_path)
            total_pages = len(doc)
            scanned_pages = 0
            
            for page in doc:
                # Get text content
                text = page.get_text().strip()
                
                # Get images
                images = page.get_images()
                
                # Criteria for a scanned page:
                # 1. Little to no text content
                # 2. Contains full-page image
                if len(text) < 100 and images:
                    # Check if any image covers most of the page
                    for img in images:
                        xref = img[0]
                        image = doc.extract_image(xref)
                        if image:
                            # Compare image size to page size
                            page_width = page.rect.width
                            page_height = page.rect.height
                            img_width = image["width"]
                            img_height = image["height"]
                            
                            # If image covers >80% of page area, consider it scanned
                            if (img_width * img_height) / (page_width * page_height) > 0.8:
                                scanned_pages += 1
                                break
            
            doc.close()
            
            # Consider document scanned if >50% of pages are scanned
            return scanned_pages / total_pages > 0.5
            
        except Exception as e:
            self.logger.error(f"Error checking if document is scanned: {e}")
            return False

    def _standard_extraction(self, pdf_path: str, output_dir: str, 
                           extract_images: bool, extract_tables: bool, 
                           **kwargs) -> Dict[str, Any]:
        """
        Primary extraction strategy using PDF parsing
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        try:
            doc = fitz.open(pdf_path)
            result = {
                "content": "",
                "pages": [],
                "images": [] if extract_images else None,
                "tables": [] if extract_tables else None,
                "metadata": doc.metadata
            }
            
            # Extract content page by page
            for page_idx, page in enumerate(doc):
                page_content = {
                    "page_number": page_idx + 1,
                    "text": page.get_text(),
                    "blocks": []
                }
                
                # Get text blocks with position information
                blocks = page.get_text("dict")["blocks"]
                for block in blocks:
                    if "lines" in block:
                        text = ""
                        for line in block["lines"]:
                            for span in line["spans"]:
                                text += span["text"]
                        
                        if text.strip():
                            page_content["blocks"].append({
                                "text": text,
                                "position": {
                                    "x0": block["bbox"][0],
                                    "y0": block["bbox"][1],
                                    "x1": block["bbox"][2],
                                    "y1": block["bbox"][3]
                                }
                            })
                
                result["pages"].append(page_content)
                result["content"] += page_content["text"] + "\n\n"
            
            # Extract images if requested
            if extract_images:
                result["images"] = self.extract_images(doc, output_dir)
            
            # Extract tables if requested
            if extract_tables:
                result["tables"] = self.extract_tables(pdf_path)
            
            doc.close()
            return result
            
        except Exception as e:
            self.logger.error(f"Error in standard extraction: {e}")
            raise

    def _ocr_based_extraction(self, pdf_path: str, output_dir: str, 
                            extract_images: bool, extract_tables: bool, 
                            **kwargs) -> Dict[str, Any]:
        """
        OCR-based extraction strategy for scanned documents
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        try:
            doc = fitz.open(pdf_path)
            result = {
                "content": "",
                "pages": [],
                "images": [] if extract_images else None,
                "tables": [] if extract_tables else None,
                "metadata": doc.metadata
            }
            
            # Configure OCR
            ocr_config = kwargs.get('ocr_config', {})
            lang = ocr_config.get('lang', 'eng')
            psm = ocr_config.get('psm', 3)
            oem = ocr_config.get('oem', 3)
            
            for page_idx, page in enumerate(doc):
                # Convert page to image
                pix = page.get_pixmap()
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                
                # Apply preprocessing if specified
                if kwargs.get('preprocess', True):
                    img = self._preprocess_image(img)
                
                # Perform OCR
                text = pytesseract.image_to_string(
                    img,
                    lang=lang,
                    config=f'--psm {psm} --oem {oem}'
                )
                
                page_content = {
                    "page_number": page_idx + 1,
                    "text": text,
                    "blocks": [{
                        "text": text,
                        "position": {
                            "x0": 0,
                            "y0": 0,
                            "x1": page.rect.width,
                            "y1": page.rect.height
                        }
                    }]
                }
                
                result["pages"].append(page_content)
                result["content"] += text + "\n\n"
            
            # Extract images if requested
            if extract_images:
                result["images"] = self.extract_images(doc, output_dir)
            
            # Extract tables if requested
            if extract_tables:
                result["tables"] = self.extract_tables(pdf_path)
            
            doc.close()
            return result
            
        except Exception as e:
            self.logger.error(f"Error in OCR-based extraction: {e}")
            raise

    def _hybrid_extraction(self, pdf_path: str, output_dir: str, 
                         extract_images: bool, extract_tables: bool, 
                         **kwargs) -> Dict[str, Any]:
        """
        Hybrid extraction strategy using both parsing and OCR
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        try:
            doc = fitz.open(pdf_path)
            result = {
                "content": "",
                "pages": [],
                "images": [] if extract_images else None,
                "tables": [] if extract_tables else None,
                "metadata": doc.metadata
            }
            
            for page_idx, page in enumerate(doc):
                # Try standard text extraction first
                text = page.get_text()
                
                # If little text found, try OCR
                if len(text.strip()) < 100:
                    pix = page.get_pixmap()
                    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                    
                    if kwargs.get('preprocess', True):
                        img = self._preprocess_image(img)
                    
                    ocr_text = pytesseract.image_to_string(img)
                    
                    # Use OCR text if it found more content
                    if len(ocr_text.strip()) > len(text.strip()):
                        text = ocr_text
                
                page_content = {
                    "page_number": page_idx + 1,
                    "text": text,
                    "blocks": [{
                        "text": text,
                        "position": {
                            "x0": 0,
                            "y0": 0,
                            "x1": page.rect.width,
                            "y1": page.rect.height
                        }
                    }]
                }
                
                result["pages"].append(page_content)
                result["content"] += text + "\n\n"
            
            # Extract images if requested
            if extract_images:
                result["images"] = self.extract_images(doc, output_dir)
            
            # Extract tables if requested
            if extract_tables:
                result["tables"] = self.extract_tables(pdf_path)
            
            doc.close()
            return result
            
        except Exception as e:
            self.logger.error(f"Error in hybrid extraction: {e}")
            raise

    def _minimal_extraction(self, pdf_path: str, output_dir: str, 
                          extract_images: bool, extract_tables: bool, 
                          **kwargs) -> Dict[str, Any]:
        """
        Minimal extraction strategy for problematic PDFs
        
        Args:
            pdf_path: Path to the PDF file
            output_dir: Directory to store extracted content
            extract_images: Whether to extract images
            extract_tables: Whether to extract tables
            **kwargs: Additional extraction options
            
        Returns:
            Dictionary containing extracted content
        """
        try:
            doc = fitz.open(pdf_path)
            result = {
                "content": "",
                "pages": [],
                "images": None,
                "tables": None,
                "metadata": doc.metadata
            }
            
            for page_idx, page in enumerate(doc):
                # Simple text extraction without any special processing
                text = page.get_text()
                
                page_content = {
                    "page_number": page_idx + 1,
                    "text": text,
                    "blocks": [{
                        "text": text,
                        "position": None
                    }]
                }
                
                result["pages"].append(page_content)
                result["content"] += text + "\n\n"
            
            doc.close()
            return result
            
        except Exception as e:
            self.logger.error(f"Error in minimal extraction: {e}")
            raise

    def _preprocess_image(self, img):
        """Helper method to preprocess images for OCR"""
        # Convert to grayscale
        img = img.convert('L')
        
        # Enhance contrast
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(2.0)
        
        # Convert to numpy array for OpenCV operations
        img_np = np.array(img)
        
        # Denoise
        img_np = cv2.fastNlMeansDenoising(img_np)
        
        # Adaptive thresholding
        img_np = cv2.adaptiveThreshold(
            img_np, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            11, 2
        )
        
        return Image.fromarray(img_np)

    # ... rest of the existing methods ... 