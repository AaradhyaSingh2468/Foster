# Foster Educational Content Generation System

An advanced AI-powered system for transforming educational PDFs into engaging multimedia content with adaptive learning capabilities.

## System Overview

The Foster system can process educational PDFs, analyze their content, and generate personalized educational videos with adaptive learning pathways. Key features include:

- **Enhanced PDF Extraction**: Process both digital and scanned documents with high accuracy
- **Content Analysis**: Extract key concepts and structure educational narratives
- **Multimedia Generation**: Create engaging videos with animations and text-to-speech narration
- **Adaptive Learning**: Personalize content based on student profiles and performance
- **Scalability**: Support for parallel processing and distributed workflows

## Setup Instructions

### Prerequisites

- Python 3.8 or higher
- Required packages (listed in requirements.txt)
- Tesseract OCR for scanned document processing (optional)

### Installation

1. Clone the repository
2. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Set up optional components:
   - Tesseract OCR: [Installation instructions](https://github.com/tesseract-ocr/tesseract)
   - FFmpeg: [Installation instructions](https://ffmpeg.org/download.html)

## Running the Pipeline

### Basic Usage

The simplest way to run the complete pipeline is using the example workflow script:

```python
python example_workflow.py
```

This demo script:
1. Creates sample PDF files with different characteristics
2. Processes each PDF with appropriate settings
3. Generates educational videos
4. Simulates student feedback
5. Displays performance metrics

### Custom Usage

To integrate the system into your own application:

```python
from WorkflowCoordinator import WorkflowCoordinator

# Initialize the coordinator
coordinator = WorkflowCoordinator(
    output_dir="my_output",
    config={
        "video_format": "mp4",
        "video_quality": "high",
        "async_processing": True
    }
)

# Process a PDF
result = coordinator.process_pdf(
    pdf_path="path/to/document.pdf",
    student_id="student_123",  # Optional
    custom_options={
        # Custom processing options
    }
)

# Get the generated video path
video_path = result.get('video_path')

# Process student feedback (optional)
feedback_result = coordinator.process_student_feedback({
    "student_id": "student_123",
    "video_id": "video_123",
    "interactions": {
        # Viewing behavior and quiz results
    },
    "explicit_feedback": {
        # Rating and comments
    }
})
```

## Multimedia Generation Components

The system includes a powerful multimedia pipeline for creating engaging educational videos:

### Animation Generator

The `AnimationGenerator` creates visual content using AI-powered image generation:

- **Multiple Style Options**: Choose from modern, minimalist, or playful visual styles
- **Color Schemes**: Educational, vibrant, or monochrome palettes
- **Animation Complexity**: Simple, standard, or complex animation levels
- **AI-Powered Visuals**: Leverages Stable Diffusion models for high-quality image generation
- **Scheduler Options**: 
  - DDIM scheduler (default): Better for general purpose visuals
  - LMS scheduler: Optimized for diagrams and concept visualizations

Example usage:
```python
from pipeline.multimedia.AnimationGenerator import AnimationGenerator

animator = AnimationGenerator(
    style="modern",
    color_scheme="educational",
    animation_level="standard",
    use_ai=True,
    model_id="stabilityai/stable-diffusion-2-1-base",
    scheduler_type="lms",  # Use LMS for better diagram generation
    output_dir="output/animations"
)

animation_data = animator.generate_animations(script_data)
```

### AI-Powered Animation Capabilities

The system includes advanced AI capabilities for generating educational visuals:

#### Requirements

To use the AI animation features, you need:

- CUDA-compatible GPU with at least 6GB VRAM (recommended: 8GB+)
- PyTorch with CUDA support installed
- Hugging Face Diffusers library

Install the AI dependencies:

```bash
pip install torch==2.0.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html
pip install diffusers transformers accelerate
```

#### Advanced Animation Features

- **Specialized Visual Types**: Automatically generates title slides, diagrams, concept graphs, and more
- **Intelligent Pipeline Selection**: Uses specialized `DiffusionPipeline` for diagrams and technical content
- **Scheduler Optimization**:
  - DDIM: Faster generation for general-purpose visuals
  - LMS: Better defined lines and shapes for STEM subjects and technical illustrations

Run the example script to test different animation options:

```bash
python pipeline/examples/example_ai_animation.py --scheduler lms --style modern
```

For full details about AI animation capabilities, see the [AI Animation Documentation](AI_ANIMATION_README.md).

### Text-to-Speech Generator

Converts narration text into natural-sounding audio:

- Multiple voice options with customizable speed and pitch
- Automatic word timing for synchronized animations
- Support for emphasis and pauses in narration

### Video Compiler

Combines animations and audio into the final educational video:

- Synchronizes visuals with narration
- Adds smooth transitions between scenes
- Generates subtitles for accessibility
- Supports multiple output formats and quality levels

## Performance Optimization

The system supports several optimization strategies:

- **Parallel Processing**: Enable with `async_processing: True` in the configuration
- **Auto-scaling**: Configure with thresholds in the `auto_scaling` section
- **Distributed Processing**: Set up with `use_distributed: True` and appropriate configuration

## Extending the System

- Add new domain-specific processors in `DomainSpecificProcessor.py`
- Customize animation styles in `multimedia_generation/AnimationGenerator.py`
- Add new voice profiles in `multimedia_generation/TextToSpeech.py`

## License

MIT License 