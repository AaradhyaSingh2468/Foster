#!/bin/bash

# Script to run the AI animation example
# Set up environment variables and run the example

# Export Hugging Face API token (replace with your actual token)
# Get a token from https://huggingface.co/settings/tokens
echo "Setting up environment variables for AI animation generation..."
export HUGGINGFACE_API_TOKEN="YOUR_HUGGINGFACE_TOKEN_HERE"

# Run the example script
echo "Running AI animation generation example..."
cd "$(dirname "$0")"
python -m multimedia_generation.example_ai_animation

echo "AI animation generation example completed!"
echo "Check the 'output/ai_animation_demo' directory for generated animations." 