"""
Script Generator Module
----------------------
This module provides functionality for generating educational scripts from content analysis data.
It works with the MultimediaGenerationPipeline to create structured scripts for educational videos.
"""

import os
import json
import time
import logging
import requests
from typing import Dict, Any, List, Optional, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ScriptGenerator:
    """
    Generates educational scripts from content analysis data.
    
    This class takes content analysis data and transforms it into a structured script
    that can be used for educational video creation. It supports various customization
    options for tone, verbosity, and target audience.
    """
    
    def __init__(self, model_name: str = "google/gemma-2-2b-it", language: str = "en-US", api_token: Optional[str] = None):
        """
        Initialize the ScriptGenerator with the specified model and language.
        
        Args:
            model_name: The name or configuration of the language model to use
            language: The language code for script generation
            api_token: Hugging Face API token for authentication (optional)
                       If not provided, will attempt to use HUGGINGFACE_API_TOKEN from environment variables
        """
        self.model_name = model_name
        self.language = language
        self.default_style = {
            "tone": "neutral",
            "verbosity": "moderate",
            "target_audience": "general",
            "language": language
        }
        
        # Use provided token or fall back to environment variable
        self.api_token = api_token or os.environ.get("HUGGINGFACE_API_TOKEN")
        if not self.api_token:
            logger.warning("No Hugging Face API token provided and HUGGINGFACE_API_TOKEN not found in environment variables. Using limited API access.")
        
        self.api_url = f"https://api-inference.huggingface.co/models/{model_name}"
        self.headers = {
            "Authorization": f"Bearer {self.api_token}" if self.api_token else "",
            "Content-Type": "application/json"
        }
        
        logger.info(f"Initialized ScriptGenerator with model '{model_name}' and language '{language}'")
    
    def generate_script(self, content_analysis: Dict[str, Any], style: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        Generate a complete educational script from content analysis data.
        
        Args:
            content_analysis: Content analysis data containing topic, key concepts, etc.
            style: Style options for script generation (tone, verbosity, etc.)
            
        Returns:
            A dictionary containing the generated script and metadata
        """
        start_time = time.time()
        style = style or self.default_style
        
        # Extract topic from ContentAnalysisPipeline structure
        topic = self._extract_topic(content_analysis)
        subject = self._extract_subject(content_analysis)
        
        logger.info(f"Generating script for topic: {topic}")
        logger.info(f"Style settings: {style}")
        
        # Extract key concepts from ContentAnalysisPipeline structure
        key_concepts = self._extract_key_concepts(content_analysis)
        
        # Create script structure based on content analysis
        structure = content_analysis.get("suggested_structure", [])
        if not structure:
            # Get visual elements for potential inclusion in the structure
            visual_elements = self._extract_visual_elements(content_analysis)
            structure = self._create_default_structure(
                {"topic": topic, "key_concepts": key_concepts, "visual_elements": visual_elements}
            )
        
        # Generate script sections
        script_sections = []
        for section in structure:
            section_content = self._generate_section(section, content_analysis, style)
            script_sections.append({
                "title": section["section"],
                "content": section_content,
                "duration": section.get("duration", 60),
                "markers": self._extract_visual_markers(section_content)
            })
        
        # Generate introduction and conclusion if not already included
        has_intro = any(s["title"].lower() == "introduction" for s in script_sections)
        has_conclusion = any(s["title"].lower() in ["conclusion", "summary"] for s in script_sections)
        
        if not has_intro:
            intro = self._generate_introduction(content_analysis, style)
            script_sections.insert(0, intro)
        
        if not has_conclusion:
            conclusion = self._generate_conclusion(content_analysis, style)
            script_sections.append(conclusion)
        
        # Assemble the complete script
        full_script = self._assemble_script(script_sections, content_analysis, style)
        
        # Extract learning objectives if available
        learning_objectives = self._extract_learning_objectives(content_analysis)
        
        # Extract grade level and difficulty if available
        grade_level = self._extract_grade_level(content_analysis)
        difficulty = self._extract_difficulty(content_analysis)
        
        # Add metadata
        processing_time = time.time() - start_time
        script_result = {
            "script": full_script,
            "sections": script_sections,
            "word_count": self._count_words(full_script),
            "estimated_duration": sum(s.get("duration", 60) for s in script_sections),
            "metadata": {
                "topic": topic,
                "subject": subject,
                "grade_level": grade_level,
                "difficulty": difficulty,
                "learning_objectives": learning_objectives,
                "style": style,
                "processing_time": processing_time
            }
        }
        
        logger.info(f"Script generation completed in {processing_time:.2f} seconds")
        return script_result
    
    def _extract_topic(self, content_analysis: Dict[str, Any]) -> str:
        """Extract topic from ContentAnalysisPipeline output"""
        # Try multiple paths to find the topic
        if "topic" in content_analysis:
            return content_analysis["topic"]
        
        # Check in document metadata
        if "document_metadata" in content_analysis and isinstance(content_analysis["document_metadata"], dict):
            metadata = content_analysis["document_metadata"]
            if "title" in metadata:
                return metadata["title"]
        
        # Check in semantic analysis
        if "semantic_analysis" in content_analysis and isinstance(content_analysis["semantic_analysis"], dict):
            if "keywords_and_concepts" in content_analysis["semantic_analysis"]:
                keywords = content_analysis["semantic_analysis"]["keywords_and_concepts"]
                if keywords and isinstance(keywords, list) and len(keywords) > 0:
                    # Use the first keyword/concept as the topic
                    if isinstance(keywords[0], dict) and "name" in keywords[0]:
                        return keywords[0]["name"]
                    elif isinstance(keywords[0], str):
                        return keywords[0]
        
        return "Unknown Topic"
    
    def _extract_subject(self, content_analysis: Dict[str, Any]) -> str:
        """Extract subject from ContentAnalysisPipeline output"""
        # Try to extract the subject field directly
        if "subject" in content_analysis:
            return content_analysis["subject"]
        
        # Try to infer subject from domain-specific data
        if "domain_specific" in content_analysis and isinstance(content_analysis["domain_specific"], dict):
            # If any domain-specific keys are present, use the first one as the subject
            for domain in ["scientific_terminology", "mathematical_entities", "literary_structure", 
                          "chemical_compounds", "physical_laws"]:
                if domain in content_analysis["domain_specific"]:
                    # Convert key like "scientific_terminology" to "Science"
                    subject_map = {
                        "scientific_terminology": "Science",
                        "mathematical_entities": "Mathematics",
                        "literary_structure": "Literature",
                        "chemical_compounds": "Chemistry",
                        "physical_laws": "Physics"
                    }
                    return subject_map.get(domain, "General")
        
        return "General"
    
    def _extract_key_concepts(self, content_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract key concepts from ContentAnalysisPipeline output"""
        # Try multiple paths to find key concepts
        concepts = []
        
        # First, check if there's a direct key_concepts field
        if "key_concepts" in content_analysis and isinstance(content_analysis["key_concepts"], list):
            return content_analysis["key_concepts"]
        
        # Check in semantic analysis
        if "semantic_analysis" in content_analysis and isinstance(content_analysis["semantic_analysis"], dict):
            if "keywords_and_concepts" in content_analysis["semantic_analysis"]:
                keywords = content_analysis["semantic_analysis"]["keywords_and_concepts"]
                if keywords and isinstance(keywords, list):
                    # Convert to the expected format if needed
                    for keyword in keywords:
                        if isinstance(keyword, dict):
                            # Already in expected format
                            concepts.append(keyword)
                        elif isinstance(keyword, str):
                            # Convert string to dict format
                            concepts.append({"name": keyword, "description": ""})
        
        # If still no concepts, check if there are relationships or domain-specific entities
        if not concepts and "relationships" in content_analysis and isinstance(content_analysis["relationships"], dict):
            if "concept_graph" in content_analysis["relationships"]:
                graph = content_analysis["relationships"]["concept_graph"]
                if isinstance(graph, dict):
                    # Extract nodes as concepts
                    for node, attrs in graph.items():
                        if isinstance(node, str) and node:
                            if isinstance(attrs, dict) and "description" in attrs:
                                concepts.append({"name": node, "description": attrs["description"]})
                            else:
                                concepts.append({"name": node, "description": ""})
        
        # Try domain-specific data as a last resort
        if not concepts and "domain_specific" in content_analysis and isinstance(content_analysis["domain_specific"], dict):
            domain_data = content_analysis["domain_specific"]
            # Look for terminology or entities that could serve as concepts
            for field in ["scientific_terminology", "mathematical_entities", "literary_devices", 
                         "chemical_compounds", "physical_laws"]:
                if field in domain_data and domain_data[field]:
                    items = domain_data[field]
                    if isinstance(items, list):
                        for item in items:
                            if isinstance(item, dict) and "name" in item:
                                concepts.append(item)
                            elif isinstance(item, str):
                                concepts.append({"name": item, "description": ""})
                    break
        
        return concepts
    
    def _extract_visual_elements(self, content_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract visual elements from ContentAnalysisPipeline output"""
        visual_elements = []
        
        # Check if visual_elements are directly available
        if "visual_elements" in content_analysis and isinstance(content_analysis["visual_elements"], dict):
            elements = content_analysis["visual_elements"]
            
            # Extract diagrams
            if "diagrams" in elements and isinstance(elements["diagrams"], list):
                for diagram in elements["diagrams"]:
                    if isinstance(diagram, dict):
                        visual_elements.append({
                            "type": "diagram",
                            "title": diagram.get("title", "Diagram"),
                            "description": diagram.get("description", "")
                        })
            
            # Extract figures
            if "figures" in elements and isinstance(elements["figures"], list):
                for figure in elements["figures"]:
                    if isinstance(figure, dict):
                        visual_elements.append({
                            "type": "figure",
                            "title": figure.get("title", "Figure"),
                            "description": figure.get("description", "")
                        })
        
        # Check raw extraction for images
        if not visual_elements and "raw_extraction" in content_analysis and isinstance(content_analysis["raw_extraction"], dict):
            if "images" in content_analysis["raw_extraction"] and isinstance(content_analysis["raw_extraction"]["images"], list):
                for i, image in enumerate(content_analysis["raw_extraction"]["images"]):
                    visual_elements.append({
                        "type": "image",
                        "title": f"Image {i+1}",
                        "description": image.get("caption", f"Visual illustration {i+1}")
                    })
        
        return visual_elements
    
    def _extract_learning_objectives(self, content_analysis: Dict[str, Any]) -> List[str]:
        """Extract learning objectives from ContentAnalysisPipeline output"""
        objectives = []
        
        # First check for explicit learning objectives
        if "learning_objectives" in content_analysis and isinstance(content_analysis["learning_objectives"], list):
            return content_analysis["learning_objectives"]
        
        # Try to extract from enrichments
        if "enrichments" in content_analysis and isinstance(content_analysis["enrichments"], dict):
            if "explanations" in content_analysis["enrichments"] and isinstance(content_analysis["enrichments"]["explanations"], dict):
                explanations = content_analysis["enrichments"]["explanations"]
                if "objectives" in explanations and isinstance(explanations["objectives"], list):
                    return explanations["objectives"]
        
        # Try to generate objectives from key concepts
        key_concepts = self._extract_key_concepts(content_analysis)
        if key_concepts:
            for concept in key_concepts[:3]:  # Limit to top 3 concepts
                if isinstance(concept, dict) and "name" in concept:
                    objectives.append(f"Understand the concept of {concept['name']}")
        
        # Fallback to a default objective
        if not objectives:
            topic = self._extract_topic(content_analysis)
            objectives.append(f"Understand the key principles of {topic}")
        
        return objectives
    
    def _extract_grade_level(self, content_analysis: Dict[str, Any]) -> str:
        """Extract grade level from ContentAnalysisPipeline output"""
        # Try multiple paths to find grade level
        if "grade_level" in content_analysis:
            return content_analysis["grade_level"]
        
        # Check in document metadata
        if "document_metadata" in content_analysis and isinstance(content_analysis["document_metadata"], dict):
            metadata = content_analysis["document_metadata"]
            if "grade_level" in metadata:
                return metadata["grade_level"]
            if "audience" in metadata:
                return metadata["audience"]
        
        # Check in semantic analysis
        if "semantic_analysis" in content_analysis and isinstance(content_analysis["semantic_analysis"], dict):
            if "literary_analysis" in content_analysis["semantic_analysis"] and isinstance(content_analysis["semantic_analysis"]["literary_analysis"], dict):
                analysis = content_analysis["semantic_analysis"]["literary_analysis"]
                if "education_level" in analysis:
                    return analysis["education_level"]
                if "audience" in analysis:
                    return analysis["audience"]
        
        return "all"
    
    def _extract_difficulty(self, content_analysis: Dict[str, Any]) -> str:
        """Extract difficulty level from ContentAnalysisPipeline output"""
        # Try multiple paths to find difficulty
        if "difficulty" in content_analysis:
            return content_analysis["difficulty"]
        
        # Check in document metadata
        if "document_metadata" in content_analysis and isinstance(content_analysis["document_metadata"], dict):
            metadata = content_analysis["document_metadata"]
            if "difficulty" in metadata:
                return metadata["difficulty"]
            if "complexity" in metadata:
                return metadata["complexity"]
        
        # Check in semantic analysis
        if "semantic_analysis" in content_analysis and isinstance(content_analysis["semantic_analysis"], dict):
            if "literary_analysis" in content_analysis["semantic_analysis"] and isinstance(content_analysis["semantic_analysis"]["literary_analysis"], dict):
                analysis = content_analysis["semantic_analysis"]["literary_analysis"]
                if "difficulty" in analysis:
                    return analysis["difficulty"]
                if "complexity" in analysis:
                    return analysis["complexity"]
        
        return "intermediate"
    
    def _create_default_structure(self, content_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create a default structure if none is provided in the content analysis"""
        topic = content_analysis.get("topic", "the topic")
        key_concepts = content_analysis.get("key_concepts", [])
        visual_elements = content_analysis.get("visual_elements", [])
        
        structure = [
            {"section": "Introduction", "duration": 30, "description": f"Introduction to {topic}"}
        ]
        
        # Add sections for each key concept
        for concept in key_concepts:
            concept_name = concept.get("name", "Concept")
            structure.append({
                "section": concept_name,
                "duration": 60,
                "description": concept.get("description", f"Details about {concept_name}")
            })
        
        # Add sections for important visual elements if not already covered in concepts
        concept_names = [c.get("name", "").lower() for c in key_concepts]
        for visual in visual_elements:
            visual_name = visual.get("title", "")
            # Only add if it's not already covered by a concept
            if visual_name.lower() not in " ".join(concept_names).lower():
                structure.append({
                    "section": visual_name,
                    "duration": 45,
                    "description": visual.get("description", f"Explanation of {visual_name}"),
                    "visual_element": visual
                })
        
        structure.append({
            "section": "Summary", 
            "duration": 30, 
            "description": f"Review of {topic} and key takeaways"
        })
        
        return structure
    
    def _generate_section(self, section: Dict[str, Any], content_analysis: Dict[str, Any], style: Dict[str, str]) -> str:
        """Generate content for a specific section of the script using Hugging Face API"""
        section_title = section["section"]
        section_description = section.get("description", "")
        
        if section_title.lower() == "introduction":
            return self._generate_introduction_content(content_analysis, style)
        elif section_title.lower() in ["summary", "conclusion"]:
            return self._generate_conclusion_content(content_analysis, style)
        else:
            return self._generate_section_content(section_title, section_description, content_analysis, style)
    
    def _extract_visual_markers(self, text: str) -> List[Dict[str, Any]]:
        """Extract markers for visual elements from the script text"""
        # This implementation keeps the same logic to extract markers
        markers = []
        
        # Look for potential visual elements
        if "diagram" in text.lower():
            markers.append({"type": "diagram", "description": "Insert relevant diagram here"})
        if "graph" in text.lower():
            markers.append({"type": "graph", "description": "Insert relevant graph here"})
        if "animation" in text.lower():
            markers.append({"type": "animation", "description": "Insert animation sequence here"})
        if "example" in text.lower():
            markers.append({"type": "example", "description": "Illustrate this example visually"})
        if "figure" in text.lower():
            markers.append({"type": "figure", "description": "Insert relevant figure here"})
        if "image" in text.lower():
            markers.append({"type": "image", "description": "Insert appropriate image here"})
        
        return markers
    
    def _assemble_script(self, sections: List[Dict[str, Any]], content_analysis: Dict[str, Any], style: Dict[str, str]) -> str:
        """Assemble the complete script from individual sections"""
        topic = self._extract_topic(content_analysis)
        full_script = f"# {topic}\n\n"
        
        for section in sections:
            full_script += f"## {section['title']}\n\n"
            full_script += f"{section['content']}\n\n"
            
            # Add visual cues if present
            if section.get("markers"):
                full_script += "### Visual elements:\n"
                for marker in section["markers"]:
                    full_script += f"- {marker['type']}: {marker['description']}\n"
                full_script += "\n"
            
            # Add any visual element explicitly associated with this section
            if section.get("visual_element"):
                visual = section["visual_element"]
                full_script += "### Visual inclusion:\n"
                full_script += f"- {visual.get('type', 'Visual')}: {visual.get('title', 'Element')} - {visual.get('description', '')}\n\n"
        
        return full_script
    
    def _count_words(self, text: str) -> int:
        """Count the number of words in the script"""
        return len(text.split())
    
    def _generate_introduction(self, content_analysis: Dict[str, Any], style: Dict[str, str]) -> Dict[str, Any]:
        """Generate an introduction section if not present in the structure"""
        intro_content = self._generate_introduction_content(content_analysis, style)
        return {
            "title": "Introduction",
            "content": intro_content,
            "duration": 30,
            "markers": self._extract_visual_markers(intro_content)
        }
    
    def _generate_conclusion(self, content_analysis: Dict[str, Any], style: Dict[str, str]) -> Dict[str, Any]:
        """Generate a conclusion section if not present in the structure"""
        conclusion_content = self._generate_conclusion_content(content_analysis, style)
        return {
            "title": "Conclusion",
            "content": conclusion_content,
            "duration": 30,
            "markers": self._extract_visual_markers(conclusion_content)
        }
    
    def save_script(self, script_data: Dict[str, Any], output_path: str) -> str:
        """
        Save the generated script to a file.
        
        Args:
            script_data: The script data dictionary
            output_path: Path where to save the script
            
        Returns:
            Path to the saved script file
        """
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Save the markdown script
        script_content = script_data["script"]
        md_path = output_path if output_path.endswith(".md") else f"{output_path}.md"
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(script_content)
        
        # Save the script data as JSON
        json_path = f"{os.path.splitext(output_path)[0]}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(script_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Script saved to {md_path} and {json_path}")
        return md_path
    
    def customize_style(self, **kwargs) -> Dict[str, str]:
        """
        Create a custom style configuration by overriding default values.
        
        Args:
            **kwargs: Style parameters to override (tone, verbosity, etc.)
            
        Returns:
            A dictionary with the customized style settings
        """
        style = self.default_style.copy()
        for key, value in kwargs.items():
            if key in style:
                style[key] = value
        return style
    
    def _query_huggingface_api(self, prompt: str, max_tokens: int = 500) -> str:
        """
        Send a query to the Hugging Face API and return the generated text.
        
        Args:
            prompt: The text prompt to send to the API
            max_tokens: Maximum number of tokens to generate
            
        Returns:
            Generated text response
        """
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": max_tokens,
                "temperature": 0.7,
                "top_p": 0.9,
                "do_sample": True
            }
        }
        
        try:
            response = requests.post(self.api_url, headers=self.headers, json=payload)
            response.raise_for_status()
            
            # Extract generated text from the response
            if isinstance(response.json(), list) and len(response.json()) > 0:
                result = response.json()[0].get("generated_text", "")
                # Remove the prompt from the response if it's included
                if result.startswith(prompt):
                    result = result[len(prompt):].strip()
                return result
            else:
                logger.error(f"Unexpected API response format: {response.json()}")
                return "Error generating text."
                
        except Exception as e:
            logger.error(f"Error calling Hugging Face API: {str(e)}")
            # Fallback to a basic response if the API call fails
            return f"Content for this section could not be generated due to an API error: {str(e)}"
    
    def _generate_introduction_content(self, content_analysis: Dict[str, Any], style: Dict[str, str]) -> str:
        """Generate introduction content using Hugging Face API"""
        # Use the extracted topic rather than direct access
        topic = self._extract_topic(content_analysis)
        objectives = self._extract_learning_objectives(content_analysis)
        
        # Format objectives as a string
        objectives_text = "\n".join([f"- {objective}" for objective in objectives])
        
        # Prepare the prompt based on style
        prompt = (
            f"Write an engaging introduction for an educational video about {topic}. "
            f"The tone should be {style.get('tone', 'neutral')} and the verbosity should be "
            f"{style.get('verbosity', 'moderate')}. The target audience is {style.get('target_audience', 'general')}. "
            f"Include these learning objectives:\n{objectives_text}\n\n"
        )
        
        # Call the Hugging Face API
        return self._query_huggingface_api(prompt)
    
    def _generate_conclusion_content(self, content_analysis: Dict[str, Any], style: Dict[str, str]) -> str:
        """Generate conclusion content using Hugging Face API"""
        # Use the extracted topic rather than direct access
        topic = self._extract_topic(content_analysis)
        key_concepts = self._extract_key_concepts(content_analysis)
        
        # Format key concepts as a string
        concepts_text = ""
        for concept in key_concepts:
            name = concept.get("name", "Key concept")
            description = concept.get("description", "")
            concepts_text += f"- {name}: {description}\n"
        
        # Prepare the prompt based on style
        prompt = (
            f"Write a conclusion for an educational video about {topic}. "
            f"The tone should be {style.get('tone', 'neutral')} and the verbosity should be "
            f"{style.get('verbosity', 'moderate')}. The target audience is {style.get('target_audience', 'general')}. "
            f"Summarize these key concepts:\n{concepts_text}\n\n"
        )
        
        # Call the Hugging Face API
        return self._query_huggingface_api(prompt)
    
    def _generate_section_content(self, title: str, description: str, content_analysis: Dict[str, Any], style: Dict[str, str]) -> str:
        """Generate section content using Hugging Face API"""
        # Use extracted data
        topic = self._extract_topic(content_analysis)
        key_concepts = self._extract_key_concepts(content_analysis)
        
        # Find any matching key concepts or examples in the content analysis
        matching_concept = None
        matching_example = None
        
        for concept in key_concepts:
            if concept.get("name", "").lower() in title.lower():
                matching_concept = concept
                break
        
        # For examples, we still need to check in the content_analysis directly
        # as we don't have an extractor for examples yet
        examples = []
        # Try different paths to find examples
        if "examples" in content_analysis:
            examples = content_analysis["examples"]
        elif "semantic_analysis" in content_analysis and isinstance(content_analysis["semantic_analysis"], dict):
            if "examples" in content_analysis["semantic_analysis"]:
                examples = content_analysis["semantic_analysis"]["examples"]
        elif "enrichments" in content_analysis and isinstance(content_analysis["enrichments"], dict):
            if "examples" in content_analysis["enrichments"]:
                examples = content_analysis["enrichments"]["examples"]
        
        for example in examples:
            if isinstance(example, dict) and example.get("title", "").lower() in title.lower():
                matching_example = example
                break
        
        # Prepare concept and example information if available
        concept_text = ""
        if matching_concept:
            concept_text = (
                f"This section is about the concept: {matching_concept.get('name', '')}\n"
                f"Description: {matching_concept.get('description', '')}\n"
            )
            if matching_concept.get("importance", "") == "high":
                concept_text += "This is a fundamental concept that's essential to understand.\n"
        
        example_text = ""
        if matching_example:
            example_text = (
                f"Include this example: {matching_example.get('title', '')}\n"
                f"Example details: {matching_example.get('description', '')}\n"
            )
            if matching_example.get("visual_elements"):
                # Make sure visual_elements is a list
                visual_elements_list = matching_example.get("visual_elements", [])
                if isinstance(visual_elements_list, list):
                    visual_elements = "\n".join([f"- {element}" for element in visual_elements_list])
                else:
                    # Handle case where visual_elements is not a list
                    visual_elements = f"- {visual_elements_list}"
                example_text += f"Visual elements to mention:\n{visual_elements}\n"
        
        # Prepare the prompt based on style
        prompt = (
            f"Write educational content for a section titled '{title}' in a video about "
            f"{topic}. {description}\n\n"
            f"The tone should be {style.get('tone', 'neutral')} and the verbosity should be "
            f"{style.get('verbosity', 'moderate')}. The target audience is {style.get('target_audience', 'general')}.\n\n"
            f"{concept_text}\n{example_text}\n"
        )
        
        # Call the Hugging Face API
        return self._query_huggingface_api(prompt) 