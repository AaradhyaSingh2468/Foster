# AI-Powered Animation Generation

This document explains how to use the AI-powered animation capabilities in the Foster Educational Content Generation System.

## Overview

The `AnimationGenerator` component can leverage AI models to create educational visuals automatically. It uses Hugging Face's Stable Diffusion models to generate images that match the educational content and style requirements.

## Requirements

To use the AI animation features, you need:

- CUDA-compatible GPU with at least 6GB VRAM (recommended: 8GB+)
- PyTorch with CUDA support installed
- Hugging Face Diffusers library
- A Hugging Face API token (for some models)

Install the required dependencies:

```bash
pip install torch==2.0.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html
pip install diffusers transformers accelerate
```

## Scheduler Options

The AnimationGenerator supports different schedulers that affect the image generation process:

### DDIM Scheduler (Default)

The Denoising Diffusion Implicit Models (DDIM) scheduler is the default option:

- Better for general purpose visuals and artistic representations
- Slightly faster generation speed
- Good for creating standard educational visuals

```python
animator = AnimationGenerator(
    scheduler_type="ddim",  # This is the default
    # other parameters...
)
```

### LMS Scheduler

The Linear Multistep Scheduler (LMS) is optimized for certain types of visuals:

- Superior for diagrams, concept graphs, and technical illustrations
- Better defined lines and shapes
- Recommended for STEM subjects and technical content

```python
animator = AnimationGenerator(
    scheduler_type="lms",
    # other parameters...
)
```

## Using DiffusionPipeline

For specialized content like diagrams and concept graphs, the `AnimationGenerator` can use the specialized `DiffusionPipeline` instead of the standard `StableDiffusionPipeline`:

```python
# This is handled automatically in the AnimationGenerator
if element_type in ["diagram", "concept_graph"] and self.diffusion_pipe is not None:
    image = self.diffusion_pipe(
        prompt=prompt,
        num_inference_steps=30,
        guidance_scale=7.5,
    ).images[0]
```

The system automatically selects the appropriate pipeline based on the visual element type.

## Example Usage

Run the example script to test AI animation generation:

```bash
python pipeline/examples/example_ai_animation.py --scheduler lms --style modern
```

Command line options:
- `--scheduler`: Choose between `ddim` (default) or `lms`
- `--style`: Choose between `modern`, `minimalist`, or `playful`

## Customizing Prompts

The system generates prompts based on the content, but you can customize the prompt templates in the `_generate_scene_visuals` method of the `AnimationGenerator` class.

## Sample Outputs

The AI animation system generates different types of visuals:

1. **Title Slides**: Clean, branded title slides with course information
2. **Text Slides**: Text with supporting visuals
3. **Bullet Points**: Visual representations of key points
4. **Diagrams**: Educational diagrams matching the content
5. **Figures**: Illustrative figures and charts
6. **Concept Graphs**: Visual representations of relationships between concepts
7. **Whiteboard Style**: Simulated hand-drawn content for explaining complex ideas

## Troubleshooting

- **Out of Memory errors**: Reduce batch size or use a smaller model
- **Slow generation**: Check for CPU fallback, ensure CUDA is properly configured
- **Low quality images**: Adjust prompt engineering or increase inference steps

## Advanced Configuration

For advanced users, you can modify the `_initialize_ai_model` method to use different models or configurations:

```python
# Example of customizing the model initialization
def _initialize_ai_model(self):
    scheduler = LMSDiscreteScheduler.from_pretrained(
        self.model_id, 
        subfolder="scheduler",
        use_karras_sigmas=True  # Advanced option for better quality
    )
    
    self.pipe = StableDiffusionPipeline.from_pretrained(
        self.model_id,
        scheduler=scheduler,
        torch_dtype=torch.float16,
        safety_checker=None  # Only for educational content
    ).to(self.device)
```

## References

- [Stable Diffusion Documentation](https://huggingface.co/docs/diffusers/api/pipelines/stable_diffusion)
- [Scheduler Types Explained](https://huggingface.co/docs/diffusers/api/schedulers) 