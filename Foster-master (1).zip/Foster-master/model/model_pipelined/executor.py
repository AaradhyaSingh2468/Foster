import os
from pipeline import PDFToAnimationPipeline

def main():
    try:
        print("\nInitializing Foster Animation Pipeline...")
        hf_token = os.getenv('HF_TOKEN')
        if not hf_token:
            hf_token = "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"
        
        pipeline = PDFToAnimationPipeline(hf_token, 'audio_config.yml')
        print("\nStarting animation generation...")
        
        video_path = pipeline.generate_animation(
            pdf_path="input.pdf",
            duration=300  # 5 minutes
        )
        
        if video_path:
            print(f"\nSuccess! Generated video saved to: {video_path}")
        else:
            print("\nFailed to generate video")
            
    except Exception as e:
        print(f"\nError in main: {str(e)}")

if __name__ == "__main__":
    main()