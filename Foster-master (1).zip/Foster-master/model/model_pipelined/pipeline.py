import json
import multiprocessing
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional, List, Dict
import torch
import torchaudio
import yaml
from moviepy.editor import AudioFileClip, CompositeAudioClip, concatenate_videoclips
from PIL import Image
import soundfile as sf
from tqdm import tqdm
from models.text_generation import TextGenerator
from models.image_generation import ImageGenerator
from models.PDFExtractor import PDFTextExtractor
from audio.music_generator import MusicGenerator
from audio.speech_generator import SpeechGenerator
from visualization.clip_generator import ClipGenerator
from config import AudioConfig

class PDFToAnimationPipeline:
    def __init__(self, hf_token: str, config_path: Optional[str] = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.audio_config = self._load_config(config_path)

        # Initialize components
        self.text_generator = TextGenerator(self.device)
        self.image_generator = ImageGenerator(self.device, hf_token)
        self.music_generator = MusicGenerator(self.device)
        self.speech_generator = SpeechGenerator(self.device, self.audio_config)
        self.clip_generator = ClipGenerator()
        self.pdf_extractor = PDFTextExtractor() 

        # Setup directories
        self.audio_dir = Path("audio_files")
        self.output_dir = Path("output")
        self.audio_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)

        # Initialize thread pool
        self.thread_pool = ThreadPoolExecutor(max_workers=multiprocessing.cpu_count())

    def _load_config(self, config_path: Optional[str]) -> AudioConfig:
        if config_path and Path(config_path).exists():
            with open(config_path, 'r') as f:
                config_dict = yaml.safe_load(f)
                return AudioConfig(**config_dict)
        return AudioConfig()

    def generate_animation(
        self,
        pdf_path: str,
        duration: Optional[float] = None,
        force_regenerate: bool = False
    ) -> Optional[str]:
        try:
            print("\n========== Starting Animation Generation ==========")
            scene_descriptions = []
            if not force_regenerate:
                print("\nChecking for existing scene descriptions...")
                scene_descriptions = self._load_scene_descriptions()

            if not scene_descriptions:
                print("\nExtracting text from PDF...")
                text_content = self.pdf_extractor.extract_text(pdf_path)
                if not text_content:
                    raise ValueError("No text content extracted from PDF")
                print(f"✓ Successfully extracted {len(text_content.split())} words")

                print("\nGenerating scene descriptions from text...")
                scene_descriptions = self._generate_scene_descriptions(text_content)
                print(f"✓ Generated {len(scene_descriptions)} scene descriptions")

            if not scene_descriptions:
                raise ValueError("No scene descriptions available")

            print("\nCalculating scene durations...")
            duration_per_scene = duration / len(scene_descriptions) if duration else 5.0
            print(f"✓ Each scene will be approximately {duration_per_scene:.1f} seconds")

            return self._create_animation(scene_descriptions, duration_per_scene)

        except Exception as e:
            print(f"\n❌ Error in animation pipeline: {str(e)}")
            return None

    def _generate_scene_descriptions(self, text_content: str) -> List[Dict[str, str]]:
        segments = [seg.strip() for seg in text_content.split('\n\n') if seg.strip()]
        scene_descriptions = []

        print("\nGenerating scene descriptions...")
        for segment in tqdm(segments, desc="Processing text segments"):
            try:
                truncated_segment = segment[:200]
                visual_prompt = f"Create a brief visual scene description: {truncated_segment}"

                visual_description = self.text_generator.generate_text(
                    visual_prompt,
                    max_length=77
                )

                scene_descriptions.append({
                    'text': segment,
                    'visual_description': visual_description.strip()
                })

            except Exception as e:
                print(f"Error generating scene description:{str(e)}")
                continue

        self._save_scene_descriptions(scene_descriptions)
        return scene_descriptions

    def _save_scene_descriptions(self, scene_descriptions: List[Dict[str, str]]) -> None:
        output_dir = Path("scene_descriptions")
        output_dir.mkdir(exist_ok=True)

        with open(output_dir / "all_scenes.json", 'w', encoding='utf-8') as f:
            json.dump(scene_descriptions, f, ensure_ascii=False, indent=2)

    def _load_scene_descriptions(self) -> List[Dict[str, str]]:
        try:
            with open(Path("scene_descriptions/all_scenes.json"), 'r', encoding='utf-8') as f:
                scenes = json.load(f)
            print("🟢Scene descriptions found and updated")
            return scenes
        except FileNotFoundError:
            print("No saved scene descriptions found.")
            return []
        except Exception as e:
            print(f"Error loading scene descriptions: {str(e)}")
            return []

    def _create_animation(
        self,
        scene_descriptions: List[Dict[str, str]],
        duration_per_scene: float = 5.0
    ) -> Optional[str]:
        clips = []

        try:
            # Generate initial background music
            print("\nGenerating background music...")
            music_audio = self.music_generator.generate_music(
                self.audio_config.music_prompt,
                duration=30
            )
            print("\nCreating scene clips...")
            pbar = tqdm(total=len(scene_descriptions),  desc="Generating scenes")

            for i, scene in enumerate(scene_descriptions):
                pbar.set_description(f"Scene {i+1}/{len(scene_descriptions)}")

                narrative_text = self.text_generator.generate_text(
                    f"Convert this educational content into an engaging narrative: {scene['text'][:500]}"
                )

                image = self.image_generator.generate_image(scene['visual_description'])
                speech_audio = self.speech_generator.generate_speech(narrative_text)


                # Create audio clip
                if len(speech_audio) > 0:
                    speech_path = self.audio_dir / f"speech_{i:03d}.wav"
                    sf.write(str(speech_path), speech_audio, samplerate=16000)
                    audio_clip = AudioFileClip(str(speech_path))

                    # Mix with background music if available
                    if music_audio is not None:
                        background_path = self.audio_dir / f"background_{i:03d}.wav"
                        torchaudio.save(
                            str(background_path),
                            music_audio.squeeze(0),
                            sample_rate=32000
                        )
                        music_clip = AudioFileClip(str(background_path))

                        # Adjust volumes and mix
                        speech_volume = audio_clip.volumex(self.audio_config.voice_volume)
                        music_volume = music_clip.volumex(self.audio_config.background_music_volume)
                        audio_clip = CompositeAudioClip([speech_volume, music_volume])
                else:
                    audio_clip = None

                # Create scene clip
                clip = self.clip_generator.create_scene_clip(
                    image=image,
                    text=narrative_text,
                    audio_clip=audio_clip,
                    duration=max(duration_per_scene, audio_clip.duration if audio_clip else duration_per_scene)
                )

                if clip is not None:
                    clips.append(clip)
                pbar.update(1)

            pbar.close()
            if not clips:
                raise ValueError("No clips were generated")

            # Concatenate clips and write final video
            print("\nConcatenating clips and rendering final video...")
            final_clip = concatenate_videoclips(clips, method="compose")
            output_path = str(self.output_dir / 'enhanced_narrated_output.mp4')

            final_clip = concatenate_videoclips(clips, method="compose")
            output_path = str(self.output_dir / 'enhanced_narrated_output.mp4')

            final_clip.write_videofile(
                output_path,
                fps=24,
                codec='h264_nvenc' if torch.cuda.is_available() else 'libx264', # Use GPU encoding if available
                audio_codec='aac',
                audio_bitrate='192k',
                threads=multiprocessing.cpu_count(), # Use all available CPU cores
                preset='fast', # Use faster encoding preset
            )

            print(f"\nVideo saved to: {output_path}")
            return output_path

        except Exception as e:
            print(f"Error creating animation: {str(e)}")
            return None
        finally:
            for clip in clips:
                try:
                    clip.close()
                except:
                    pass

