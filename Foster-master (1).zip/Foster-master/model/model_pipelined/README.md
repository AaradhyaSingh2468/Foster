# PDF to Animation Pipeline

This project converts PDF documents into animated videos with narration and background music.

## Installation

1. Clone this repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. Set your Hugging Face token as an environment variable:
   ```
   export HF_TOKEN=your_token_here
   ```
2. Run the pipeline:
   ```
   python pipeline.py
   ```
