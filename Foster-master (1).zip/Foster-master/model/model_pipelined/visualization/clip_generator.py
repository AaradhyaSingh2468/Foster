import numpy as np
from moviepy.editor import ImageClip, CompositeVideoClip, AudioFileClip
from PIL import Image, ImageDraw, ImageFont
import textwrap
from tqdm import tqdm
from typing import Optional

class ClipGenerator:
    def __init__(self):
        pass

    def create_scene_clip(
        self,
        image: np.ndarray,
        text: str,
        audio_clip: Optional[AudioFileClip] = None,
        duration: float = 5.0
    ) -> Optional[CompositeVideoClip]:
        try:
            with tqdm(total=4, desc="Creating scene clip") as pbar:
                # Process image
                if image.shape[2] == 4:
                    image = image[..., :3]
                image_clip = ImageClip(image).set_duration(duration)
                pbar.update(1)

                # Create text overlay
                text_overlay = self._create_text_overlay(text)
                text_rgb = text_overlay[..., :3]
                text_alpha = text_overlay[..., 3]
                pbar.update(1)

                # Create text clip
                text_clip = (ImageClip(text_rgb)
                            .set_duration(duration)
                            .set_mask(ImageClip(text_alpha, ismask=True)))
                text_clip = text_clip.set_position(('center', 'bottom'))
                pbar.update(1)

                # Compose final clip
                clip = CompositeVideoClip([image_clip, text_clip])
                if audio_clip:
                    clip = clip.set_audio(audio_clip)
                pbar.update(1)

            print("✓ Scene clip created successfully!")
            return clip

        except Exception as e:
            print(f"Error creating scene clip: {str(e)}")
            return None

    def _create_text_overlay(
        self,
        text: str,
        width: int = 600,
        bg_color: tuple = (0, 0, 0, 180)
    ) -> np.ndarray:
        with tqdm(total=3, desc="Creating text overlay") as pbar:
            # Initialize image and font
            txt_img = Image.new('RGBA', (width, 480), (0, 0, 0, 0))
            draw = ImageDraw.Draw(txt_img)
            try:
                font = ImageFont.truetype("arial.ttf", 24)
            except:
                font = ImageFont.load_default()
            pbar.update(1)

            # Process text layout
            wrapper = textwrap.TextWrapper(width=40)
            text_lines = wrapper.wrap(text)
            line_height = 30
            text_height = len(text_lines) * line_height
            margin = 20
            pbar.update(1)

            # Create and draw text
            text_bg_height = text_height + 2 * margin
            text_bg = Image.new('RGBA', (width, text_bg_height), bg_color)
            txt_img.paste(text_bg, (0, 480 - text_bg_height))

            y = 480 - text_bg_height + margin
            for line in text_lines:
                line_width = draw.textlength(line, font=font)
                x = (width - line_width) // 2
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
                y += line_height
            pbar.update(1)

        return np.array(txt_img)



