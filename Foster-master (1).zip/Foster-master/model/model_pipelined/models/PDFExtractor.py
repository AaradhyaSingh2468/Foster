import os
import pytesseract
from pdf2image import convert_from_path
import PyPDF2
import cv2
import numpy as np
from typing import List, Dict, Tuple, Optional, Union

class PDFTextExtractor:
    """
    Enhanced text extractor for PDF files that can handle both digital and scanned content
    with automatic detection and appropriate processing for each page type.
    """
    
    def __init__(self, lang: str = 'eng', dpi: int = 300, ocr_config: str = '--psm 1'):
        """
        Initialize the PDF text extractor with configurable parameters.
        
        Args:
            lang (str): Language for OCR (default: 'eng')
            dpi (int): DPI for image conversion (higher values for better quality but slower)
            ocr_config (str): Tesseract OCR configuration string
        """
        self.lang = lang
        self.dpi = dpi
        self.ocr_config = ocr_config
        self.min_text_threshold = 10  # Minimum characters to consider a page as digital
    
    def is_scanned_page(self, pdf_reader: PyPDF2.PdfReader, page_num: int) -> bool:
        """
        Determine if a page is scanned (image-based) or digital (text-based).
        
        Args:
            pdf_reader: PyPDF2 PdfReader object
            page_num: Page number to check
            
        Returns:
            bool: True if page appears to be scanned, False if digital
        """
        try:
            page = pdf_reader.pages[page_num]
            text = page.extract_text()
            
            # If page has sufficient text, consider it digital
            if len(text.strip()) > self.min_text_threshold:
                return False
                
            # Check if page has images
            if '/XObject' in page:
                xobjects = page['/XObject']
                if isinstance(xobjects, dict):
                    for obj in xobjects:
                        if xobjects[obj].get('/Subtype') == '/Image':
                            return True
            
            # Default to treating as scanned if little text was found
            return True
            
        except Exception:
            # If extraction fails, assume it's a scanned page
            return True
    
    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        Enhance image quality for better OCR results.
        
        Args:
            image: Input image as numpy array
            
        Returns:
            Preprocessed image
        """
        # Convert to grayscale if not already
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
            
        # Apply adaptive thresholding to handle varying lighting conditions
        binary = cv2.adaptiveThreshold(
            gray, 
            255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 
            11, 
            2
        )
        
        # Noise removal (optional, can be adjusted based on document quality)
        denoised = cv2.medianBlur(binary, 3)
        
        return denoised
    
    def ocr_image(self, image) -> str:
        """
        Perform OCR on a single image with preprocessing.
        
        Args:
            image: Image to perform OCR on
            
        Returns:
            str: Extracted text
        """
        # Convert PIL Image to numpy array if needed
        if not isinstance(image, np.ndarray):
            image_np = np.array(image)
        else:
            image_np = image
            
        # Preprocess the image for better OCR results
        processed_img = self.preprocess_image(image_np)
        
        # Perform OCR with the specified configuration
        text = pytesseract.image_to_string(
            processed_img, 
            lang=self.lang,
            config=self.ocr_config
        )
        
        return text
    
    def extract_text_from_digital(self, pdf_path: str, page_nums: Optional[List[int]] = None) -> Dict[int, str]:
        """
        Extract text from digital PDF pages using PyPDF2.
        
        Args:
            pdf_path: Path to the PDF file
            page_nums: Specific pages to extract, None for all pages
            
        Returns:
            Dictionary mapping page numbers to extracted text
        """
        results = {}
        
        try:
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                total_pages = len(pdf_reader.pages)
                
                pages_to_process = page_nums if page_nums is not None else range(total_pages)
                
                for page_num in pages_to_process:
                    if 0 <= page_num < total_pages:
                        page = pdf_reader.pages[page_num]
                        text = page.extract_text()
                        results[page_num] = text
        except Exception as e:
            raise Exception(f"Error extracting text from digital PDF: {str(e)}")
            
        return results
    
    def extract_text_from_scanned(self, pdf_path: str, page_nums: Optional[List[int]] = None) -> Dict[int, str]:
        """
        Extract text from scanned PDF pages using OCR.
        
        Args:
            pdf_path: Path to the PDF file
            page_nums: Specific pages to extract, None for all pages
            
        Returns:
            Dictionary mapping page numbers to extracted text
        """
        results = {}
        
        try:
            # Convert PDF pages to images
            images = convert_from_path(pdf_path, dpi=self.dpi)
            total_pages = len(images)
            
            pages_to_process = page_nums if page_nums is not None else range(total_pages)
            
            for page_idx in pages_to_process:
                if 0 <= page_idx < total_pages:
                    image = images[page_idx]
                    text = self.ocr_image(image)
                    results[page_idx] = text
                    
        except Exception as e:
            raise Exception(f"Error extracting text from scanned PDF: {str(e)}")
            
        return results
    
    def extract_text(self, pdf_path: str, force_ocr: bool = False) -> str:
        """
        Extract text from a PDF file, automatically detecting and handling both 
        scanned and digital pages appropriately.
        
        Args:
            pdf_path (str): Path to the PDF file
            force_ocr (bool): Force OCR processing for all pages regardless of detection
            
        Returns:
            str: Extracted text content
        """
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF file not found: {pdf_path}")
            
        try:
            all_text = []
            page_texts = {}
            
            # First pass: identify page types and extract digital text
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                total_pages = len(pdf_reader.pages)
                
                scanned_pages = []
                digital_pages = []
                
                # Detect page types
                for page_num in range(total_pages):
                    if force_ocr or self.is_scanned_page(pdf_reader, page_num):
                        scanned_pages.append(page_num)
                    else:
                        digital_pages.append(page_num)
                
                # Process digital pages with PyPDF2
                if digital_pages:
                    digital_texts = self.extract_text_from_digital(pdf_path, digital_pages)
                    page_texts.update(digital_texts)
            
            # Process scanned pages with OCR
            if scanned_pages:
                scanned_texts = self.extract_text_from_scanned(pdf_path, scanned_pages)
                page_texts.update(scanned_texts)
                
            # Combine all texts in page order
            for page_num in range(total_pages):
                if page_num in page_texts:
                    text = page_texts[page_num].strip()
                    if text:
                        all_text.append(text)
            
            return "\n\n".join(all_text)
            
        except Exception as e:
            raise Exception(f"Error extracting text from PDF: {str(e)}")

    def get_page_types(self, pdf_path: str) -> Dict[int, str]:
        """
        Analyze a PDF and return the detected type of each page.
        
        Args:
            pdf_path (str): Path to the PDF file
            
        Returns:
            Dict mapping page numbers to page types ('scanned' or 'digital')
        """
        page_types = {}
        
        try:
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                total_pages = len(pdf_reader.pages)
                
                for page_num in range(total_pages):
                    page_type = 'scanned' if self.is_scanned_page(pdf_reader, page_num) else 'digital'
                    page_types[page_num] = page_type
                    
            return page_types
            
        except Exception as e:
            raise Exception(f"Error analyzing PDF page types: {str(e)}")
    
    def save_extracted_text(self, pdf_path, output_path):
        """
        Extract text from a PDF and save it to the specified output file.
        
        Args:
            pdf_path (str): Path to the PDF file
            output_path (str): Path where the extracted text should be saved
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Extract the text
            text = self.extract_text(pdf_path)
            
            # Ensure the directory exists
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)
            
            # Write the text to the file
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(text)
            
            print("Saved to : {output_path}")    
            return True
        except Exception as e:
            print(f"Error saving extracted text: {str(e)}")
            return False