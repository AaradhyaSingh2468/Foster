import torch
import numpy as np
from tqdm import tqdm
from huggingface_hub import snapshot_download
from diffusers import StableDiffusionPipeline
import cv2

class ImageGenerator:
    def __init__(self, device, hf_token: str):
        self.device = device
        self._initialize_model(hf_token)

    def _initialize_model(self, hf_token: str):
        print("\nInitializing Stable Diffusion...")
        with tqdm(total=2, desc="Loading image generator") as pbar:
            model_id = "CompVis/stable-diffusion-v1-4"
            cache_dir = snapshot_download(
                repo_id=model_id,
                use_auth_token=hf_token,
                revision="main"
            )
            pbar.update(1)

            self.model = StableDiffusionPipeline.from_pretrained(
                cache_dir,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                safety_checker=None,
                local_files_only=True
            ).to(self.device)
            pbar.update(1)
        print("✓ Image generation model loaded successfully!")

    def generate_image(self, prompt: str, size: tuple = (640, 480)) -> np.ndarray:
        try:
            print("\nGenerating image...")
            enhanced_prompt = f"educational illustration of {prompt[:150]}"[:250]
            
            with tqdm(total=1, desc="Generating image") as pbar:  # Changed total to 1
                def progress_callback(step: int, timestep: int, latents: torch.FloatTensor) -> None:
                    # Remove step checking to avoid modulo operations
                    pass  # Simply pass instead of trying to calculate progress
                
                # Generate image without progress tracking first
                image = self.model(
                    enhanced_prompt,
                    num_inference_steps=30,
                    guidance_scale=7.5,
                    callback=None  # Temporarily disable callback
                ).images[0]
                pbar.update(1)
                
                resized_image = np.array(image.resize(size))
            
            print("✓ Image generated successfully!")
            return resized_image
        
        except Exception as e:
            print(f"Error generating image: {str(e)}")
            # Create a blank error image
            blank_image = np.ones((size[1], size[0], 3), dtype=np.uint8) * 255
            cv2.putText(
                blank_image,
                f"Image Generation Failed: {str(e)}",
                (50, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 0),
                2
            )
            return blank_image


