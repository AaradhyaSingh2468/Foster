from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm

class TextGenerator:
    def __init__(self, device):
        self.device = device
        print(f"\nUsing device: {self.device}")
        self._initialize_model()

    def _initialize_model(self):
        print("\nLoading text generation model...")
        try:
            with tqdm(total=2, desc="Loading GPT-Neo") as pbar:
                # Load model with GPU support if available
                self.model = AutoModelForCausalLM.from_pretrained(
                    "EleutherAI/gpt-neo-125M",
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                    device_map="auto" if torch.cuda.is_available() else None
                ).to(self.device)
                self.model.eval()  # Set to evaluation mode
                pbar.update(1)

                self.tokenizer = AutoTokenizer.from_pretrained(
                    "EleutherAI/gpt-neo-125M"
                )
                pbar.update(1)
            print(f"✓ Text generation model loaded successfully on {self.device}!")
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            raise

    def generate_text(self, prompt: str, max_length: int = 512) -> str:
        try:
            with tqdm(total=3, desc="Generating text") as pbar:
                # Tokenization
                inputs = self.tokenizer(
                    prompt,
                    return_tensors="pt",
                    truncation=True,
                    max_length=max_length
                ).to(self.device)
                pbar.update(1)
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
                # Text generation
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=50,
                    num_return_sequences=1,
                    do_sample=True,
                    temperature=0.7,
                    top_k=50,
                    top_p=0.9,
                    pad_token_id=self.tokenizer.eos_token_id
                )
                pbar.update(1)
                outputs = outputs.cpu()
                # Decoding
                generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
                pbar.update(1)
                
            print("✓ Text generated successfully!")
            return generated_text
            
        except Exception as e:
            print(f"Error generating text: {str(e)}")
            return prompt  # Return original prompt if generation fails
        
def main():
    
    try:
        # Initialize the generator
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        generator = TextGenerator(device)
        import pytesseract
        from pdf2image import convert_from_path
        
        def _extract_text_from_pdf(pdf_path: str) -> str:
            images = convert_from_path(pdf_path)
            text_content = []

            for img in images:
                text = pytesseract.image_to_string(img)
                if text.strip():
                    text_content.append(text)
            
            return "\n\n".join(text_content)
        
        text_content = _extract_text_from_pdf("input.pdf")
        
        segments = [seg.strip() for seg in text_content.split('\n\n') if seg.strip()]
        
        scene_descriptions = []

        print("\nGenerating scene descriptions...")
        for segment in tqdm(segments, desc="Processing text segments"):
            try:
                truncated_segment = segment[:200]
                visual_prompt = f"Create a brief visual scene description: {truncated_segment}"

                visual_description = generate_text(
                    visual_prompt,
                    max_length=77
                )

                scene_descriptions.append({
                    'text': segment,
                    'visual_description': visual_description.strip()
                })

            except Exception as e:
                print(f"Error generating scene description:{str(e)}")
                continue
        
    except Exception as e:
        print(f"Error in main: {str(e)}")

if __name__ == "__main__":
    main()