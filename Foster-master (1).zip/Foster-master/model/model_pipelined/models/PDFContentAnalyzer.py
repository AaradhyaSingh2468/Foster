from collections import Counter
from PDFExtractor import PDFTextExtractor
class PDFContentAnalyzer:
    def __init__(self, pdf_path=None):
        self.pdf_path = pdf_path
        self.text_extractor = PDFTextExtractor()
        
    def extract_domain_terms(self, text):
        """
        Automatically extract potential domain-specific terms from the document.
        
        Args:
            text (str): The full text content of the document
            
        Returns:
            set: A set of potential domain-specific terms
        """
        import re
        import string
        from nltk.corpus import stopwords
        from nltk.util import ngrams
        import nltk
        
        # Download required NLTK resources if not already present
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')

        # Clean the text
        text = text.lower()

        # Get English stopwords
        stop_words = set(stopwords.words('english'))

        # Add punctuation to stopwords
        stop_words.update(string.punctuation)
        stop_words.update(['[', ']', '(', ')', '{', '}', '«', '»', '"', '"', ''', '''])

        # Tokenize the text
        words = re.findall(r'\b[a-z][a-z\-]+[a-z]\b', text)

        # Filter out stopwords and very short words
        filtered_words = [word for word in words if word not in stop_words and len(word) > 3]

        # Count word frequencies
        word_freq = Counter(filtered_words)

        # Extract potential terms - words that appear multiple times and might be domain-specific
        # Words that appear more than average frequency are potential domain terms
        mean_freq = sum(word_freq.values()) / max(1, len(word_freq))

        # Get higher-frequency words (appearing more than average)
        common_words = {word for word, count in word_freq.items() if count > mean_freq}

        # Also collect technical-looking compound terms (multi-word terms)
        # Extract bigrams and trigrams
        tokens = [word for word in words if word not in stop_words]
        bi_grams = list(ngrams(tokens, 2))
        tri_grams = list(ngrams(tokens, 3))

        # Count frequencies
        bigram_freq = Counter(bi_grams)
        trigram_freq = Counter(tri_grams)

        # Extract compound terms
        compound_terms = set()

        # Significant bigrams that appear multiple times
        for gram, count in bigram_freq.items():
            if count > 1:  # Appears at least twice
                compound_terms.add(gram[0] + gram[1])  # Combined form

        # Significant trigrams
        for gram, count in trigram_freq.items():
            if count > 1:  # Appears at least twice
                compound_terms.add(gram[0] + gram[1] + gram[2])  # Combined form

        # Combine single words and compound terms
        domain_terms = common_words.union(compound_terms)

        # Also add some camelCase and snake_case identifiers which are common in technical docs
        code_identifiers = re.findall(r'\b([a-z]+[A-Z][a-zA-Z]*)\b|\b([a-z]+_[a-z]+(_[a-z]+)*)\b', text)
        flat_identifiers = [item for sublist in code_identifiers for item in sublist if item]
        domain_terms.update(flat_identifiers)

        return domain_terms

    def fix_split_words(self, text):
        """
        Fix anomalies where words are incorrectly split with spaces,
        like 'gr een' instead of 'green', using context-aware detection
        and automatically extracted domain terms.
    
        Args:
            text (str): The text content that might contain split words
    
        Returns:
            str: Text with incorrectly split words corrected
        """
        import re
        from nltk.corpus import words as nltk_words
        import nltk
    
        # Download required NLTK resources if not already present
        try:
            nltk.data.find('corpora/words')
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('words')
            nltk.download('punkt')
    
        # Get English words set
        english_words = set(w.lower() for w in nltk_words.words())
    
        # Extract domain-specific terms from the document itself
        domain_terms = self.extract_domain_terms(text)
    
        # Add domain terms to our vocabulary
        english_words.update(domain_terms)
    
        # Create a dictionary to track word corrections for consistency
        corrections = {}
    
        # Analyze the document to find potential recurring split pattern
        split_patterns = re.findall(r'\b([a-zA-Z]{1,4})\s+([a-zA-Z]{1,4})\b', text)
        pattern_freq = Counter(split_patterns)
        consistent_splits = {pattern for pattern, count in pattern_freq.items() if count > 2}
    
        # First, let's fix the split words within the text
        # Find potential split word patterns
        potential_splits = re.finditer(r'\b([a-zA-Z]{1,4})\s+([a-zA-Z]{1,4})\b', text)
        replacements = []
    
        for match in potential_splits:
            part1 = match.group(1).lower()
            part2 = match.group(2).lower()
            combined = part1 + part2
    
            # Check if we've already made a decision on this pattern
            if (part1, part2) in corrections:
                if corrections[(part1, part2)]:  # If we should merge
                    replacements.append((match.span(), combined))
                continue
            
            # Context awareness checks
            # 1. Check if the combined form is a valid English word or domain term
            if combined in english_words:
                # Get some context around the match
                start = max(0, match.start() - 20)
                end = min(len(text), match.end() + 20)
                context = text[start:end].lower()
    
                # 2. Check if the parts are valid standalone words
                both_valid_words = part1 in english_words and part2 in english_words
    
                # 3. Check for special cases we want to preserve
                preserve_cases = [
                    # Preserve cases where both parts might be intentional
                    part1 in {"de", "et", "per", "in", "ad", "ex", "a", "e", "i", "o", "u"},
                    # Check if these appear to be acronyms or abbreviations
                    part1.isupper() and len(part1) <= 3,
                    part2.isupper() and len(part2) <= 3
                ]
    
                # Calculate a confidence score for merging
                merge_confidence = 0
    
                # If this pattern appears consistently throughout the document
                if (part1, part2) in consistent_splits:
                    merge_confidence += 0.25
    
                # If combined form is in our domain terms, strong signal to merge
                if combined in domain_terms:
                    merge_confidence += 0.4
    
                # If both parts are not valid words, higher confidence to merge
                if not both_valid_words:
                    merge_confidence += 0.3
    
                # Special case: if neither part is a valid word but combined is
                if part1 not in english_words and part2 not in english_words and combined in english_words:
                    merge_confidence += 0.4
    
                # Capitalize matching - if both parts match capitalization pattern
                if part1[0].isupper() == part2[0].isupper():
                    merge_confidence += 0.1
    
                # Determine if we should merge based on confidence
                should_merge = not any(preserve_cases) and merge_confidence > 0.3
    
                if should_merge:
                    # Preserve the original capitalization
                    if match.group(1)[0].isupper():
                        combined = combined[0].upper() + combined[1:]
                    replacements.append((match.span(), combined))
    
                # Store this decision for consistency
                corrections[(part1, part2)] = should_merge
    
        # Apply replacements in reverse order to maintain correct indices
        if replacements:
            new_text = list(text)
            for span, replacement in sorted(replacements, key=lambda x: x[0], reverse=True):
                start, end = span
                new_text[start:end] = replacement
            text = ''.join(new_text)
        
        # Now fix duplicate punctuation issues
        # Fix patterns like ". ." or ", ," or "? ?" etc.
        text = re.sub(r'(\.\s+\.|\,\s+\,|\?\s+\?|\!\s+\!|\:\s+\:|\;\s+\;)', r'\1', text)
        
        # Also fix consecutive periods, commas, etc.
        text = re.sub(r'\.{2,}', '.', text)
        text = re.sub(r'\,{2,}', ',', text)
        text = re.sub(r'\?{2,}', '?', text)
        text = re.sub(r'\!{2,}', '!', text)
        text = re.sub(r'\:{2,}', ':', text)
        text = re.sub(r'\;{2,}', ';', text)
        
        # Fix spaces before punctuation (e.g., "word ." → "word.")
        text = re.sub(r'\s+\.', '.', text)
        text = re.sub(r'\s+\,', ',', text)
        text = re.sub(r'\s+\?', '?', text)
        text = re.sub(r'\s+\!', '!', text)
        text = re.sub(r'\s+\:', ':', text)
        text = re.sub(r'\s+\;', ';', text)
        
        # Fix multiple spaces
        text = re.sub(r'\s{2,}', ' ', text)
        
        return text

    def extract_and_analyze(self, output_path=None, extraction=True):
        # Extract text from PDF
        if output_path:
            extracted = None
            if extraction:
                extracted = self.text_extractor.save_extracted_text(self.pdf_path, output_path)
            with open(output_path, 'r', encoding='utf-8') as f:
                text_content = f.read()
        else:
            text_content = self.text_extractor.extract_text(self.pdf_path)

        # Fix split words anomaly in the extracted text with context awareness
        # and automatic domain term extraction
        text_content = self.fix_split_words(text_content)

        # Use the section extractor to identify headings
        section_extractor = PDFSectionExtractor(text_content)
        sections = section_extractor.identify_potential_heading()

        # Enhance sections with content analysis
        enhanced_sections = self.improve_heading_content_relation(sections)

        # Split sections that have embedded headings in their content
        expanded_sections = self.split_content_with_embedded_headings(enhanced_sections,section_extractor.getPattern())

        # Fix any content issues in the expanded sections
        final_sections = self.fix_content_issues(expanded_sections)

        return final_sections
    
    def improve_heading_content_relation(self, sections):
        """Improve the relationship between headings and content through analysis"""
        enhanced_sections = []
        
        for i, section in enumerate(sections):
            heading = section['heading']
            content = section['content']
            
            # 1. Verify heading format consistency
            section['heading_level'] = self.determine_heading_level(heading)
            
            # 2. Analyze content relevance to heading
            section['relevance_score'] = self.calculate_relevance(heading, content)
            
            # 3. Check if content seems truncated or merged incorrectly
            section['content_analysis'] = self.analyze_content_integrity(content)
            
            # 4. Verify hierarchical consistency with surrounding sections
            if i > 0 and i < len(sections) - 1:
                prev_heading = sections[i-1]['heading']
                next_heading = sections[i+1]['heading']
                section['hierarchy_consistency'] = self.check_heading_hierarchy(
                    prev_heading, heading, next_heading
                )
            
            enhanced_sections.append(section)
        
        # Perform a second pass to fix detected issues
        fixed_sections = self.fix_content_issues(enhanced_sections)
        
        return fixed_sections
    
    def determine_heading_level(self, heading):
        """Determine the hierarchical level of a heading"""
        import re
        
        # Check for chapter patterns
        if re.match(r'^Chapter\s+\d+', heading):
            return 1
        # Check for section patterns (e.g., 1.1)
        elif re.match(r'^\d+\.\d+\s+[A-Za-z]', heading):
            return 2
        # Check for subsection patterns (e.g., 1.1.1)
        elif re.match(r'^\d+\.\d+\.\d+\s+[A-Za-z]', heading):
            return 3
        # Check for other heading patterns
        elif re.match(r'^UNIT\s+\d+', heading):
            return 1
        elif re.match(r'^[A-Z][A-Z\s]+$', heading):
            return 1
        # Default level
        return 0
    
    def calculate_relevance(self,heading, content):
        """
        Calculate relevance between heading and content using a comprehensive, multi-dimensional approach
        that works across various document types and subject matters.

        Args:
            heading (str): The section heading
            content (str): The content text to evaluate

        Returns:
            float: Relevance score between 0 and 1
        """
        import re
        import nltk
        import math
        from nltk.corpus import stopwords
        from nltk.stem import WordNetLemmatizer
        from sklearn.feature_extraction.text import TfidfVectorizer
        from collections import Counter
        from statistics import stdev

        # Initialize NLTK resources
        try:
            nltk.data.find('tokenizers/punkt')
            nltk.data.find('corpora/stopwords')
            nltk.data.find('corpora/wordnet_ic') or nltk.download('wordnet2022')
        except LookupError:
            nltk.download('punkt')
            nltk.download('stopwords')
            nltk.download('wordnet')

        lemmatizer = WordNetLemmatizer()
        stop_words = set(stopwords.words('english'))

        # Clean heading (remove numbering and standardize)
        clean_heading = re.sub(r'^\d+\.?\d*\.?\d*\s+', '', heading)
        clean_heading = re.sub(r'^Chapter\s+\d+\s*', '', clean_heading)
        clean_heading = re.sub(r'^UNIT\s+\d+\s*', '', clean_heading)
        clean_heading = clean_heading.strip().lower()

        # Set up predefined common document section types
        common_sections = {
        # Front matter
        "abstract": 0.85,
        "summary": 0.85,
        "introduction": 0.80,
        "overview": 0.80,
        "preface": 0.75,

        # Structural sections
        "conclusion": 0.85,
        "discussion": 0.80,
        "results": 0.85,
        "analysis": 0.80,
        "methodology": 0.80,
        "methods": 0.80,
        "background": 0.75,
        "appendix": 0.85,
        "references": 0.90,
        "bibliography": 0.90,

        # Educational sections
        "case study": 0.80,
        "review": 0.80,
        "exercises": 0.85,
        "objectives": 0.85,
        "experiments": 0.85,
        "glossary": 0.90
    }

        # First check for common sections
        for section_name, score in common_sections.items():
            if clean_heading == section_name or clean_heading.endswith(section_name):
                # Minimal content validation
                if len(content) > 50:
                    return score

        # Check if heading or content is too short for meaningful analysis
        if len(clean_heading) < 3 or len(content) < 20:
            return 0.60  # Neutral score for very short content

        # Determine heading type
        is_question = '?' in clean_heading
        is_technical = any(term in clean_heading.lower() for term in [
            'theory', 'hypothesis', 'mechanism', 'process', 'method', 'technique', 
            'algorithm', 'function', 'structure', 'system', 'analysis'
        ])

        # Extract key terms from heading
        heading_words = [lemmatizer.lemmatize(w.lower()) for w in re.findall(r'\b\w+\b', clean_heading)
                         if w.lower() not in stop_words and len(w) > 2]

        # If heading has no meaningful words after filtering, use a fallback
        if not heading_words:
            heading_words = [w.lower() for w in re.findall(r'\b\w+\b', clean_heading) if len(w) > 2]

        # For question headings, exclude question words but keep them in a separate list
        if is_question:
            question_words = ['what', 'where', 'when', 'why', 'how', 'which', 'who', 'whom', 'whose']
            heading_focus_terms = [w for w in heading_words if w not in question_words]
            # If all terms were question words, keep some to avoid empty list
            if not heading_focus_terms and heading_words:
                heading_focus_terms = heading_words
        else:
            heading_focus_terms = heading_words

        # Extract content samples of different lengths
        paragraphs = content.split('\n\n') if '\n\n' in content else [content]
        first_paragraph = paragraphs[0] if paragraphs else content[:500]
        content_sample = content[:min(3000, len(content))]  # Larger sample for better analysis

        # 1. TERM FREQUENCY ANALYSIS
        # -------------------------------------------
        # Count direct occurrences of heading terms in content
        term_counts = {}
        for word in heading_focus_terms:
            pattern = r'\b' + re.escape(word) + r'\b'
            matches = re.findall(pattern, content_sample, re.IGNORECASE)
            term_counts[word] = len(matches)

        # Calculate term frequency score with log normalization
        total_matches = sum(term_counts.values())
        avg_term_count = total_matches / max(1, len(term_counts))
        term_freq_score = min(1.0, math.log(1 + avg_term_count) / math.log(10))

        # Calculate term density (per 1000 words)
        total_words = len(re.findall(r'\b\w+\b', content_sample.lower()))
        heading_term_density = total_matches / max(1, total_words) * 1000
        term_density_score = min(1.0, heading_term_density / 10)  # Cap at 1.0

        # 2. DISTRIBUTION ANALYSIS
        # -------------------------------------------
        # Calculate term distribution (how evenly terms are spread throughout content)
        term_positions = []
        content_length = len(content)

        for term in heading_focus_terms:
            positions = [m.start() / content_length for m in re.finditer(r'\b' + re.escape(term) + r'\b', content.lower())]
            term_positions.extend(positions)

        distribution_score = 0
        if term_positions:
            # Use standard deviation of positions - lower std dev means more even distribution
            if len(term_positions) > 1:
                std_dev = stdev(term_positions)
                distribution_score = max(0, 1 - std_dev * 2)  # Transform to 0-1 scale
            else:
                distribution_score = 0.5  # Single occurrence

        # Split content into segments for another distribution approach
        num_segments = 3
        segment_size = max(1, len(content_sample) // num_segments)
        segments = [content_sample[i:i+segment_size] for i in range(0, len(content_sample), segment_size)]
        segments = segments[:num_segments]  # Ensure we have exactly num_segments

        # Count terms in each segment
        segment_scores = []
        for segment in segments:
            segment_count = 0
            for word in heading_focus_terms:
                pattern = r'\b' + re.escape(word) + r'\b'
                matches = re.findall(pattern, segment, re.IGNORECASE)
                segment_count += len(matches)
            segment_scores.append(segment_count / max(1, len(heading_focus_terms)))

        # Calculate weighted distribution score
        # Higher scores for evenly distributed terms or terms concentrated at beginning
        if len(segment_scores) >= 3:
            segment_distribution_score = (segment_scores[0] * 0.5 + segment_scores[1] * 0.3 + segment_scores[2] * 0.2)
        else:
            segment_distribution_score = sum(segment_scores) / len(segment_scores)

        # Combine both distribution approaches
        distribution_score = (distribution_score + segment_distribution_score) / 2

        # 3. POSITION AND PROXIMITY ANALYSIS
        # -------------------------------------------
        # Calculate proximity score (higher if terms appear earlier)
        proximity_score = 0
        if term_positions:
            avg_position = sum(term_positions) / len(term_positions)
            proximity_score = 1 - avg_position  # Earlier positions get higher scores

        # Check if heading terms appear early in the content
        first_sentences = nltk.sent_tokenize(first_paragraph)[:3]
        first_sentences_text = ' '.join(first_sentences).lower()

        early_matches = 0
        for word in heading_focus_terms:
            if re.search(r'\b' + re.escape(word) + r'\b', first_sentences_text, re.IGNORECASE):
                early_matches += 1

        early_mention_score = early_matches / max(1, len(heading_focus_terms))
        position_score = (proximity_score + early_mention_score) / 2

        # Check for heading terms appearing close to each other
        sentences = nltk.sent_tokenize(content_sample)
        term_proximity_score = 0
        if len(heading_focus_terms) >= 2:
            for sentence in sentences:
                matched_terms = set()
                for word in heading_focus_terms:
                    if re.search(r'\b' + re.escape(word) + r'\b', sentence, re.IGNORECASE):
                        matched_terms.add(word)

                # If multiple terms appear in the same sentence
                if len(matched_terms) >= 2:
                    term_proximity_score += len(matched_terms) / len(heading_focus_terms)

        # Normalize
        term_proximity_score = min(1.0, term_proximity_score / 5)

        # 4. SEMANTIC EXPANSION ANALYSIS
        # -------------------------------------------
        # Create expanded sets of terms related to heading words
        expanded_terms = set()
        for word in heading_focus_terms:
            # Add singular/plural forms and common variants
            expanded_terms.add(word)
            # Simple singular/plural handling
            if word.endswith('s') and len(word) > 4:
                expanded_terms.add(word[:-1])  # Remove 's'
            else:
                expanded_terms.add(word + 's')  # Add 's'
            # Add common suffixes
            if len(word) > 4:
                expanded_terms.add(word + 'ing')
                expanded_terms.add(word + 'ed')
                expanded_terms.add(word + 'al')
                expanded_terms.add(word + 'ic')

        # Calculate semantic expansion score
        expanded_matches = 0
        for term in expanded_terms:
            if term not in heading_focus_terms:  # Avoid double counting
                pattern = r'\b' + re.escape(term) + r'\b'
                expanded_matches += len(re.findall(pattern, content_sample, re.IGNORECASE))

        # Normalize with diminishing returns
        semantic_score = min(1.0, math.log(1 + expanded_matches) / math.log(20))

        # 5. PHRASE ANALYSIS
        # -------------------------------------------
        # Check for multi-word phrases from heading
        phrases = []
        if len(heading_focus_terms) >= 2:
            for i in range(len(heading_focus_terms) - 1):
                phrases.append(heading_focus_terms[i] + ' ' + heading_focus_terms[i+1])

        # Calculate phrase score
        phrase_matches = 0
        for phrase in phrases:
            phrase_matches += len(re.findall(re.escape(phrase), content_sample, re.IGNORECASE))

        # Normalize
        phrase_score = min(1.0, phrase_matches / max(1, len(phrases)))

        # 6. CONTEXTUAL ANALYSIS
        # -------------------------------------------
        # Extract key phrases from content
        content_words = [lemmatizer.lemmatize(w.lower()) for w in nltk.word_tokenize(content_sample) 
                         if w.lower() not in stop_words and len(w) > 2]
        word_freq = Counter(content_words)

        # Find potential topic words (excluding heading terms)
        topic_words = [word for word, count in word_freq.most_common(10) 
                       if word not in heading_focus_terms]

        # Create a contextual window around heading terms
        context_windows = []

        for sentence in sentences:
            for word in heading_focus_terms:
                if re.search(r'\b' + re.escape(word) + r'\b', sentence, re.IGNORECASE):
                    context_windows.append(sentence)
                    break
                
        # Calculate contextual score
        context_score = min(1.0, len(context_windows) / 10)

        # Calculate conceptual relevance based on co-occurrence
        concept_score = 0
        for sentence in sentences:
            sentence_lower = sentence.lower()
            heading_terms_in_sentence = sum(1 for term in heading_focus_terms if term in sentence_lower)
            topic_terms_in_sentence = sum(1 for term in topic_words if term in sentence_lower)

            if heading_terms_in_sentence > 0 and topic_terms_in_sentence > 0:
                concept_score += (heading_terms_in_sentence * topic_terms_in_sentence) / (len(heading_focus_terms) * len(topic_words))

        concept_score = min(1.0, concept_score)

        # 7. QUESTION-SPECIFIC ANALYSIS
        # -------------------------------------------
        # For questions, look for direct answer patterns
        direct_answer_score = 0
        if is_question:
            # Look for answer patterns in first 2 paragraphs
            early_content = ' '.join(paragraphs[:2]) if len(paragraphs) > 1 else first_paragraph

            # General answer patterns
            answer_patterns = [
                r'is used (to|for|in)',
                r'are used (to|for|in)',
                r'function of .{1,50} is to',
                r'purpose of .{1,50} is',
                r'refers to',
                r'defined as',
                r'means that'
            ]

            for pattern in answer_patterns:
                if re.search(pattern, early_content.lower()):
                    direct_answer_score += 0.25

            # Look for definitional structures
            for term in heading_focus_terms:
                if re.search(r'\b' + re.escape(term) + r'\b.{1,30}(is|are|refers to|means|consists of)', early_content.lower()):
                    direct_answer_score += 0.25

            direct_answer_score = min(1.0, direct_answer_score)

        # 8. VECTOR ANALYSIS
        # -------------------------------------------
        # Use TF-IDF for semantic similarity
        try:
            vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2))
            tfidf_matrix = vectorizer.fit_transform([clean_heading, content_sample])
            tfidf_score = tfidf_matrix[0].dot(tfidf_matrix[1].T).toarray()[0][0]
        except:
            tfidf_score = 0.5  # Default to mid-range on failure

        # 9. CALCULATE FINAL SCORE
        # -------------------------------------------
        # Combine all metrics with weighted importance based on heading type

        # Define weights for different heading types
        if is_question:
            weights = {
                'term_freq_score': 0.10,
                'term_density_score': 0.05,
                'distribution_score': 0.10,
                'position_score': 0.15,
                'term_proximity_score': 0.05,
                'semantic_score': 0.10,
                'phrase_score': 0.05,
                'context_score': 0.10,
                'concept_score': 0.10,
                'direct_answer_score': 0.15,
                'tfidf_score': 0.05
            }
        elif is_technical:
            weights = {
                'term_freq_score': 0.15,
                'term_density_score': 0.10,
                'distribution_score': 0.10,
                'position_score': 0.10,
                'term_proximity_score': 0.05,
                'semantic_score': 0.10,
                'phrase_score': 0.10,
                'context_score': 0.05,
                'concept_score': 0.15,
                'tfidf_score': 0.10
            }
        else:
            weights = {
                'term_freq_score': 0.15,
                'term_density_score': 0.10,
                'distribution_score': 0.10,
                'position_score': 0.15,
                'term_proximity_score': 0.05,
                'semantic_score': 0.10,
                'phrase_score': 0.05,
                'context_score': 0.10,
                'concept_score': 0.10,
                'tfidf_score': 0.10
            }

        # Create a dictionary of all scores
        scores = {
            'term_freq_score': term_freq_score,
            'term_density_score': term_density_score,
            'distribution_score': distribution_score,
            'position_score': position_score,
            'term_proximity_score': term_proximity_score,
            'semantic_score': semantic_score,
            'phrase_score': phrase_score,
            'context_score': context_score,
            'concept_score': concept_score,
            'tfidf_score': tfidf_score
        }

        # Add direct_answer_score only for questions
        if is_question:
            scores['direct_answer_score'] = direct_answer_score

        # Calculate weighted score
        raw_score = sum(scores[metric] * weights[metric] for metric in weights)

        # 10. APPLY SCORE ADJUSTMENTS
        # -------------------------------------------
        # Apply sigmoid-like transformation to favor mid-range scores
        def sigmoid_transform(x):
            # Centered around 0.5, with smoother transition
            return 0.5 + 0.45 * math.tanh(2.5 * (x - 0.5))

        # Apply confidence adjustments
        confidence_factor = 1.0

        # Reduced confidence if very few heading terms
        if len(heading_focus_terms) == 0:
            confidence_factor *= 0.7
        elif len(heading_focus_terms) == 1:
            confidence_factor *= 0.9

        # Reduced confidence for very short content
        if len(content) < 200:
            confidence_factor *= 0.9

        # Reduced confidence for extremely sparse matches
        if sum(term_counts.values()) == 0:
            confidence_factor *= 0.6
        elif sum(term_counts.values()) <= 2:
            confidence_factor *= 0.8

        # Apply confidence adjustment by pulling score toward neutral (0.5)
        adjusted_score = 0.5 + (raw_score - 0.5) * confidence_factor

        # Apply sigmoid transformation for final smoothing
        transformed_score = sigmoid_transform(adjusted_score)

        # 11. PREPARE FINAL SCORE
        # -------------------------------------------
        # Ensure score is between 0.1 and 0.95
        final_score = max(0.1, min(0.95, transformed_score))

        # Optional: For debugging or detailed analysis, uncomment to return score components
        # score_components = {
        #     'raw_scores': scores,
        #     'weights': weights,
        #     'raw_score': raw_score,
        #     'adjusted_score': adjusted_score,
        #     'confidence_factor': confidence_factor,
        #     'transformed_score': transformed_score,
        #     'final_score': final_score
        # }
        # return final_score, score_components

        return final_score
    
    def analyze_content_integrity(self, content):
        """Analyze if content appears complete or has potential issues"""
        from nltk.tokenize import sent_tokenize
        import re
        
        result = {
            'seems_truncated': False,
            'has_continuation_markers': False,
            'sentence_count': 0,
            'avg_sentence_length': 0,
            'has_formatting_issues': False
        }
        
        # Skip empty content
        if not content.strip():
            return result
        
        # Get sentences
        try:
            sentences = sent_tokenize(content)
            result['sentence_count'] = len(sentences)
            
            if sentences:
                # Check if last sentence appears truncated
                last_sent = sentences[-1].strip()
                if last_sent and not re.search(r'[.!?]$', last_sent):
                    result['seems_truncated'] = True
                
                # Check for continuation markers
                if re.search(r'(continued|cont\'d|\.{3}|…)$', content, re.IGNORECASE):
                    result['has_continuation_markers'] = True
                
                # Calculate average sentence length
                total_length = sum(len(s) for s in sentences)
                result['avg_sentence_length'] = total_length / len(sentences)
            
            # Check for formatting issues (repeating patterns, etc.)
            if re.search(r'(\[\\\w+\])', content):
                result['has_formatting_issues'] = True
        except:
            pass
            
        return result
    
    def check_heading_hierarchy(self, prev_heading, current_heading, next_heading):
        """Check if headings follow a logical hierarchical structure"""
        prev_level = self.determine_heading_level(prev_heading)
        current_level = self.determine_heading_level(current_heading)
        next_level = self.determine_heading_level(next_heading)
        
        result = {
            'consistent': True,
            'issues': []
        }
        
        # Check for unexpected jumps in heading levels
        if prev_level < current_level and current_level > next_level:
            # If current heading is deeper than both neighbors, it might be misplaced
            result['consistent'] = False
            result['issues'].append('isolated_deeper_heading')
        
        # Check for consistent numbering
        if current_level == prev_level:
            # Consecutive headings at same level should have sequential numbers
            import re
            
            prev_num = re.search(r'^(\d+)\.', prev_heading)
            current_num = re.search(r'^(\d+)\.', current_heading)
            
            if prev_num and current_num:
                if int(current_num.group(1)) != int(prev_num.group(1)) + 1:
                    result['consistent'] = False
                    result['issues'].append('non_sequential_numbering')
        
        return result
    
    def fix_content_issues(self, sections):
        """Attempt to fix identified content-heading relationship issues"""
        fixed_sections = sections.copy()
        
        # Find and fix potential content misassignments
        for i in range(len(fixed_sections) - 1):
            current = fixed_sections[i]
            next_section = fixed_sections[i + 1]
            
            # If current content seems truncated and next section is at same or higher level
            current_analysis = current.get('content_analysis', {})
            if (current_analysis.get('seems_truncated', False) or 
                current_analysis.get('has_continuation_markers', False)):
                
                current_level = current.get('heading_level', 0)
                next_level = next_section.get('heading_level', 0)
                
                # If next section isn't a subsection of current, content might continue
                if next_level <= current_level:
                    # Check relevance of next section's initial content to current heading
                    next_content = next_section['content']
                    first_para = next_content.split('\n\n')[0] if '\n\n' in next_content else next_content
                    
                    relevance = self.calculate_relevance(current['heading'], first_para)
                    
                    # If highly relevant, might be continuation
                    if relevance > 0.3:
                        current['content_issues'] = 'Possible continuation in next section'
                        next_section['content_issues'] = 'Might contain content from previous section'
        
        # Merge sections with continuation issues
        merged_sections = self.merge_continuation_sections(fixed_sections)
        
        # Handle sections with low relevance scores
        final_sections = self.handle_low_relevance_sections(merged_sections)
        
        return final_sections
    
    def handle_low_relevance_sections(self, sections):
        """
        Handle sections with low relevance scores by either finding a better heading
        or merging with the previous section.
        
        Args:
            sections (list): List of section dictionaries
            
        Returns:
            list: A new list with low-relevance sections handled appropriately
        """
        if not sections:
            return []
        
        # Threshold for low relevance
        low_relevance_threshold = 0.295
        
        # We'll build a new list of sections
        improved_sections = []
        
        # Keep track of sections to skip (those that were merged)
        sections_to_skip = set()
        
        for i, section in enumerate(sections):
            # Skip sections that were already merged
            if i in sections_to_skip:
                continue
            
            # Check if the current section has a low relevance score
            if section.get('relevance_score', 1.0) < low_relevance_threshold:
                # Try to find a better heading
                better_heading = self.extract_better_heading(section)
                
                if better_heading:
                    # Update the section with the better heading
                    updated_section = section.copy()
                    updated_section['original_heading'] = section['heading']
                    updated_section['heading'] = better_heading
                    updated_section['heading_level'] = self.determine_heading_level(better_heading)
                    updated_section['relevance_score'] = self.calculate_relevance(better_heading, updated_section['content'])
                    updated_section['heading_improved'] = True
                    
                    # Add the updated section to our list
                    improved_sections.append(updated_section)
                else:
                    # No better heading found, try to merge with previous section
                    if i > 0 and not sections[i-1].get('is_merged', False):
                        # Merge with previous section
                        merged_section = sections[i-1].copy()
                        merged_section['is_merged'] = True
                        merged_section['merge_info'] = f"MERGED WITH LOW RELEVANCE SECTION: '{section['heading']}'"
                        merged_section['merged_due_to_low_relevance'] = True
                        
                        # Create a snippet of the merged content for context
                        prev_content_end = merged_section['content'].rstrip()[-100:] if len(merged_section['content']) > 100 else merged_section['content'].rstrip()
                        current_content_start = section['content'][:100] if len(section['content']) > 100 else section['content']
                        merged_section['merge_context'] = f"End of previous section: \"...{prev_content_end}\"\nStart of low relevance section: \"{current_content_start}...\""
                        
                        # Add the merged content
                        merged_section['content'] = merged_section['content'].rstrip() + "\n"+section['heading']+"\n" + section['content']
                        
                        # Recalculate relevance score
                        merged_section['relevance_score'] = self.calculate_relevance(merged_section['heading'], merged_section['content'])
                        
                        # Replace the previous section with the merged one
                        if improved_sections:
                            improved_sections.pop()  # Remove the previous section
                        improved_sections.append(merged_section)
                    else:
                        # Can't merge with previous section, add as is with a note
                        marked_section = section.copy()
                        marked_section['low_relevance_warning'] = True
                        marked_section['no_better_heading_found'] = True
                        improved_sections.append(marked_section)
            else:
                # Section has good relevance, add as is
                improved_sections.append(section)
        
        # Update indices for all sections
        for idx, section in enumerate(improved_sections):
            section['index'] = idx
        
        return improved_sections
    
    def extract_better_heading(self, section):
        """
        Attempt to extract a better heading from section content.
        
        Args:
            section (dict): Section dictionary with content
            
        Returns:
            str: Improved heading or None if no better heading found
        """
        import re
        from nltk.tokenize import sent_tokenize
        import nltk
        from nltk.corpus import stopwords
        from nltk.util import ngrams
        from collections import Counter
        
        # Ensure required NLTK resources are available
        try:
            nltk.data.find('corpora/stopwords')
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('stopwords')
            nltk.download('punkt')
        
        content = section['content']
        
        # Skip if content is too short
        if len(content) < 50:
            return None
        
        stop_words = set(stopwords.words('english'))
        
        # 1. Look for potential topic sentences in the first paragraph
        paragraphs = content.split('\n\n')
        first_paragraph = paragraphs[0] if paragraphs else content[:200]
        
        # Extract sentences from the first paragraph
        sentences = sent_tokenize(first_paragraph)
        if not sentences:
            return None
        
        # Focus on the first 2-3 sentences
        topic_sentences = sentences[:min(3, len(sentences))]
        
        # 2. Look for patterns that suggest a topic or main idea
        potential_headings = []
        
        # Pattern 1: Sentences with "this chapter", "this section", "we discuss", etc.
        intro_patterns = [
            r'this (chapter|section|unit|part) (discusses|covers|examines|explores|focuses on|introduces|presents|describes|is about|deals with) (.*?)[.;]',
            r'(in|this) (chapter|section|unit|part),? we (discuss|cover|examine|explore|focus on|introduce|present|describe) (.*?)[.;]',
            r'(the|this) (chapter|section|unit|part) (is|provides) (a|an) (overview|introduction|examination|analysis|discussion|description) of (.*?)[.;]'
        ]
        
        for sentence in topic_sentences:
            sentence_lower = sentence.lower()
            
            # Check for intro patterns
            for pattern in intro_patterns:
                match = re.search(pattern, sentence_lower)
                if match:
                    # Extract the topic from the match
                    # The topic is usually in the last capturing group
                    topic = match.group(match.lastindex)
                    # Clean up the topic
                    topic = topic.strip()
                    # Capitalize the first letter of each word
                    topic = ' '.join(word.capitalize() for word in topic.split())
                    potential_headings.append((topic, 0.8))  # High confidence
        
        # Pattern 2: Look for "is defined as", "refers to", "is a", etc.
        definition_patterns = [
            r'([a-z\s]+) (is|are) defined as (.*?)[.;]',
            r'([a-z\s]+) refers to (.*?)[.;]',
            r'([a-z\s]+) (is|are) (a|an) (.*?)[.;]'
        ]
        
        for sentence in topic_sentences:
            sentence_lower = sentence.lower()
            
            for pattern in definition_patterns:
                match = re.search(pattern, sentence_lower)
                if match:
                    # For definition patterns, use the term being defined as the heading
                    term = match.group(1).strip()
                    # Capitalize the first letter of each word
                    term = ' '.join(word.capitalize() for word in term.split())
                    potential_headings.append((term, 0.7))  # Good confidence
        
        # 3. Extract key terms from the first paragraph
        # Tokenize and filter out stopwords
        words = re.findall(r'\b[a-z][a-z\-]+[a-z]\b', first_paragraph.lower())
        filtered_words = [word for word in words if word not in stop_words and len(word) > 3]
        
        # Get word frequencies
        word_freq = Counter(filtered_words)
        
        # Extract bigrams
        bigrams = list(ngrams(filtered_words, 2))
        bigram_freq = Counter(bigrams)
        
        # Find the most common bigrams
        common_bigrams = bigram_freq.most_common(3)
        for bigram, count in common_bigrams:
            if count > 1:  # Appears multiple times
                bigram_heading = ' '.join(bigram).title()
                potential_headings.append((bigram_heading, 0.6))  # Lower confidence
        
        # Find the most common individual words
        common_words = word_freq.most_common(5)
        for word, count in common_words:
            if count > 2:  # Appears multiple times
                word_heading = word.title()
                potential_headings.append((word_heading, 0.5))  # Lower confidence
        
        # 4. If no potential headings found, try to use the first sentence (if it's not too long)
        if not potential_headings and sentences:
            first_sentence = sentences[0]
            # Use the first sentence if it's reasonably short
            if len(first_sentence) < 60:
                potential_headings.append((first_sentence.strip(), 0.4))  # Low confidence
        
        # 5. Evaluate each potential heading against the content
        best_heading = None
        best_relevance = 0.85  # Minimum threshold
        
        for heading, confidence in potential_headings:
            relevance = self.calculate_relevance(heading, content)
            # Weight by confidence
            weighted_relevance = relevance * confidence
            
            if weighted_relevance > best_relevance:
                best_heading = heading
                best_relevance = weighted_relevance
        
        return best_heading
    
    def merge_continuation_sections(self, sections):
        """
        Merge sections where content appears to continue from one section to the next.
        
        Args:
            sections (list): List of section dictionaries with identified content issues
            
        Returns:
            list: A new list with problematic sections merged appropriately, with merge markers
        """
        if not sections:
            return []
        
        merged_sections = []
        i = 0
        
        while i < len(sections):
            current_section = sections[i].copy()
            
            # Check if current section has continuation issue and we're not at the last section
            if (i < len(sections) - 1 and 
                current_section.get('content_issues') == 'Possible continuation in next section' and
                sections[i + 1].get('content_issues') == 'Might contain content from previous section'):
                
                # Merge the content with the next section's content
                next_section = sections[i + 1]
                
                # Get snippets from end of first section and beginning of second section
                first_section_end = current_section['content'].rstrip()[-150:] if len(current_section['content']) > 150 else current_section['content'].rstrip()
                second_section_start = next_section['content'][:150] if len(next_section['content']) > 150 else next_section['content']
                
                # Store merge information that can be printed with other section details
                current_section['is_merged'] = True
                current_section['merge_info'] = f"MERGED WITH SECTION: '{next_section['heading']}'"
                current_section['merge_context'] = f"End of first section: \"...{first_section_end}\"\nStart of second section: \"{second_section_start}...\""
                
                # Add the full merged content
                current_section['content'] = current_section['content'].rstrip() + "\n\n" + next_section['heading']+"\n" +next_section['content']
                
                # Recalculate relevance score for the merged content
                current_section['relevance_score'] = self.calculate_relevance(current_section['heading'], current_section['content'])
                
                # Remove the continuation issue flag since we've addressed it
                if 'content_issues' in current_section:
                    del current_section['content_issues']
                
                # Add the merged section
                merged_sections.append(current_section)
                
                # Skip the next section since we've merged it
                i += 2
            else:
                # Add the current section as is
                current_section['is_merged'] = False
                merged_sections.append(current_section)
                i += 1
        
        # Update any remaining section references or indices
        for idx, section in enumerate(merged_sections):
            section['index'] = idx
        
        return merged_sections
    
    def split_content_with_embedded_headings(self, sections, heading_patterns):
        """
        Identify and split sections where content contains embedded headings.
        
        Args:
            sections (list): List of section dictionaries
            
        Returns:
            list: Expanded list of sections with embedded headings properly separated
        """
        import re
        
        # Enhanced patterns to catch cases like "11.2EARLY EXPERIMENTS"
        
        
        # Compile a single regex pattern that matches any of the heading patterns
        combined_pattern = '|'.join(f'({pattern})' for pattern in heading_patterns)
        heading_regex = re.compile(combined_pattern)
        
        # Function to normalize headings with missing spaces
        def normalize_heading(heading):
            # Fix cases like "11.2EARLY EXPERIMENTS" -> "11.2 EARLY EXPERIMENTS"
            match = re.match(r'^(\d+\.\d+)([A-Z].*)', heading)
            if match:
                return f"{match.group(1)} {match.group(2)}"
            
            # Fix cases like "11.2.3EARLY EXPERIMENTS" -> "11.2.3 EARLY EXPERIMENTS"
            match = re.match(r'^(\d+\.\d+\.\d+)([A-Z].*)', heading)
            if match:
                return f"{match.group(1)} {match.group(2)}"
                
            return heading
        
        expanded_sections = []
        
        for section in sections:
            content = section['content']
            # Split content by lines to check for embedded headings
            content_lines = content.split('\n')
            
            # If content is too short, just add the section as is
            if len(content_lines) <= 3:
                expanded_sections.append(section)
                continue
            
            # Look for embedded headings in content
            embedded_headings = []
            for i, line in enumerate(content_lines):
                line = line.strip()
                if heading_regex.match(line):
                    # Don't consider the very first line (could be a repeat of the section heading)
                    if i > 0:
                        # Normalize the heading before adding it
                        normalized_heading = normalize_heading(line)
                        embedded_headings.append((i, normalized_heading))
            
            # If no embedded headings found, add section as is
            if not embedded_headings:
                expanded_sections.append(section)
                continue
            
            # We found embedded headings, let's split the content
            # First, add the initial content up to the first embedded heading
            initial_section = section.copy()
            initial_section['content'] = '\n'.join(content_lines[:embedded_headings[0][0]])
            initial_section['contains_embedded_headings'] = True
            initial_section['embedded_headings_count'] = len(embedded_headings)
            expanded_sections.append(initial_section)
            
            # Now add each embedded heading as a new section
            for i, (line_idx, heading_text) in enumerate(embedded_headings):
                # Determine the end of this section's content
                end_idx = embedded_headings[i+1][0] if i < len(embedded_headings)-1 else len(content_lines)
                
                # Create the new section
                new_section = {
                    'heading': heading_text,
                    'heading_level': self.determine_heading_level(heading_text),
                    'content': '\n'.join(content_lines[line_idx+1:end_idx]),
                    'original_section': section['heading'],
                    'is_embedded_section': True,
                    'embedded_index': i+1
                }
                
                # Calculate relevance score and content analysis for the new section
                new_section['relevance_score'] = self.calculate_relevance(heading_text, new_section['content'])
                new_section['content_analysis'] = self.analyze_content_integrity(new_section['content'])
                
                expanded_sections.append(new_section)
        
        # Update indices for all sections
        for idx, section in enumerate(expanded_sections):
            section['index'] = idx
        
        return expanded_sections
    
    def write_extracted_sections(self, sections, output_path):
        """
        Write the extracted sections (headings and their contents) to a file.
        
        Args:
            sections (list): List of section dictionaries
            output_path (str): Path to the output file
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                for section in sections:
                    # Write heading with appropriate level formatting
                    heading_level = section.get('heading_level', 0)
                    prefix = '#' * (heading_level + 1) if heading_level > 0 else '##'
                    
                    # Check if section was merged or has special properties
                    notes = []
                    if section.get('is_merged', False):
                        notes.append("MERGED")
                    if section.get('heading_improved', False):
                        notes.append("IMPROVED HEADING")
                    if section.get('is_embedded_section', False):
                        notes.append(f"EMBEDDED SECTION from {section.get('original_section', '')}")
                    
                    # Add notes to heading if present
                    heading_notes = f" ({', '.join(notes)})" if notes else ""
                    
                    # Write the heading
                    f.write(f"{prefix} {section['heading']}{heading_notes}\n\n")
                    
                    # Write the content
                    f.write(f"{section['content']}\n\n")
                    
                    # Add a separator between sections
                    f.write('-' * 80 + '\n\n')
            
            return True
        except Exception as e:
            print(f"Error writing extracted sections: {str(e)}")
            return False
    
    def generate_statistics(self, sections, output_path=None):
        """
        Generate statistics about the extracted sections and optionally write them to a file.
        
        Args:
            sections (list): List of section dictionaries
            output_path (str, optional): Path to the output file. If None, statistics are only returned.
        
        Returns:
            dict: Statistics about the extracted sections
        """
        import numpy as np
        from collections import Counter
        
        stats = {}
        
        # Basic statistics
        stats['total_sections'] = len(sections)
        
        # Heading level distribution
        heading_levels = [section.get('heading_level', 0) for section in sections]
        stats['heading_level_counts'] = dict(Counter(heading_levels))
        stats['max_heading_level'] = max(heading_levels) if heading_levels else 0
        stats['min_heading_level'] = min(heading_levels) if heading_levels else 0
        
        # Content length statistics
        content_lengths = [len(section['content']) for section in sections]
        stats['total_content_length'] = sum(content_lengths)
        stats['avg_content_length'] = np.mean(content_lengths) if content_lengths else 0
        stats['median_content_length'] = np.median(content_lengths) if content_lengths else 0
        stats['min_content_length'] = min(content_lengths) if content_lengths else 0
        stats['max_content_length'] = max(content_lengths) if content_lengths else 0
        stats['std_dev_content_length'] = np.std(content_lengths) if content_lengths else 0
        
        # Relevance score statistics
        relevance_scores = [section.get('relevance_score', 0) for section in sections]
        stats['avg_relevance_score'] = np.mean(relevance_scores) if relevance_scores else 0
        stats['median_relevance_score'] = np.median(relevance_scores) if relevance_scores else 0
        stats['min_relevance_score'] = min(relevance_scores) if relevance_scores else 0
        stats['max_relevance_score'] = max(relevance_scores) if relevance_scores else 0
        
        # Count special cases
        stats['merged_sections'] = sum(1 for section in sections if section.get('is_merged', False))
        stats['improved_headings'] = sum(1 for section in sections if section.get('heading_improved', False))
        stats['embedded_sections'] = sum(1 for section in sections if section.get('is_embedded_section', False))
        stats['low_relevance_warnings'] = sum(1 for section in sections if section.get('low_relevance_warning', False))
        
        # If output path is provided, write statistics to file
        if output_path:
            try:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write("# PDF Content Analysis Statistics\n\n")
                    
                    f.write("## Basic Statistics\n")
                    f.write(f"- Total sections: {stats['total_sections']}\n")
                    f.write(f"- Total content length: {stats['total_content_length']} characters\n\n")
                    
                    f.write("## Heading Level Distribution\n")
                    for level, count in sorted(stats['heading_level_counts'].items()):
                        level_name = "Unknown" if level == 0 else f"Level {level}"
                        f.write(f"- {level_name}: {count} sections\n")
                    f.write("\n")
                    
                    f.write("## Content Length Statistics\n")
                    f.write(f"- Average: {stats['avg_content_length']:.2f} characters\n")
                    f.write(f"- Median: {stats['median_content_length']:.2f} characters\n")
                    f.write(f"- Minimum: {stats['min_content_length']} characters\n")
                    f.write(f"- Maximum: {stats['max_content_length']} characters\n")
                    f.write(f"- Standard deviation: {stats['std_dev_content_length']:.2f} characters\n\n")
                    
                    f.write("## Relevance Score Statistics\n")
                    f.write(f"- Average: {stats['avg_relevance_score']:.4f}\n")
                    f.write(f"- Median: {stats['median_relevance_score']:.4f}\n")
                    f.write(f"- Minimum: {stats['min_relevance_score']:.4f}\n")
                    f.write(f"- Maximum: {stats['max_relevance_score']:.4f}\n\n")
                    
                    f.write("## Special Cases\n")
                    f.write(f"- Merged sections: {stats['merged_sections']}\n")
                    f.write(f"- Sections with improved headings: {stats['improved_headings']}\n")
                    f.write(f"- Embedded sections: {stats['embedded_sections']}\n")
                    f.write(f"- Sections with low relevance warnings: {stats['low_relevance_warnings']}\n")
            except Exception as e:
                print(f"Error writing statistics to file: {str(e)}")
        
        return stats
    
    def save_all_outputs(self, sections, content_output_path, stats_output_path):
        """
        Convenience method to save both section content and statistics.
        
        Args:
            sections (list): List of section dictionaries
            content_output_path (str): Path to save sections content
            stats_output_path (str): Path to save section statistics
        
        Returns:
            tuple: (bool, dict) - Success flag for content writing and statistics dictionary
        """
        content_success = self.write_extracted_sections(sections, content_output_path)
        stats = self.generate_statistics(sections, stats_output_path)
        
        return content_success, stats