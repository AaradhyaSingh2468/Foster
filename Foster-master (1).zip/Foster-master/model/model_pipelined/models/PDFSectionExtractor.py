class PDFSectionExtractor:
    def __init__(self, text):
        self.text_content = text
        self.lines = self.text_content.split('\n')
    
    def identify_potential_heading(self):
        potential_headings = []
        patterns = [
            r'^Chapter\s+\d+',                    # Chapter 1, Chapter 2
            r'^(11\.1|11\.1\.1)\s+[A-Za-z]',      # 11.1 or 11.1.1 followed by a phrase (not just numbers)
            r'^\d+\.\d+\s+[A-Za-z]',              # 1.1, 1.2 followed by a phrase (ignores plain 11.7)
            r'^\d+\.\d+\.\d+\s+[A-Za-z]',         # 1.1.1, 1.1.2 followed by a phrase (ignores 11.1.1.)
            r'^UNIT\s+\d+',                       # UNIT 1, UNIT 2
            r'^[A-Z][A-Z\s]+$',                   # ALL CAPS HEADINGS
        ]
        
        import re
        current_content = []
        matched_pattern = ""
        for i, line in enumerate(self.lines):
            line = line.strip()
            
            # Check if line matches any heading pattern
            is_heading = False
            for pattern in patterns:
                if re.match(pattern, line):
                    matched_pattern = pattern 
                    is_heading = True
                    break
            
            if is_heading:
                # If we found a heading and already have headings in our list,
                # add the collected content to the previous heading
                if potential_headings:
                    potential_headings[-1]['content'] = "\n".join(current_content)
                
                # Add the new heading
                potential_headings.append({
                    'heading': line,
                    'line_number': i,
                    'content': "",  # Content will be filled later
                    'matched with pattern': matched_pattern
                })
                
                # Reset content collection for the new heading
                current_content = []
            else:
                # Add non-heading line to current content if it's not empty
                if line and line!="[\BREAK]":
                    current_content.append(line)
        
        # Add content to the last heading
        if potential_headings:
            potential_headings[-1]['content'] = "\n".join(current_content)
        
        potential_headings = self.__remove_wrongly_identified_headings(potential_headings)      
        return potential_headings
    
    def __remove_wrongly_identified_headings(self, potential_headings):
        # Remove headings that are too short or have no content
        from nltk.tokenize import sent_tokenize
        return [h for h in potential_headings if len(h['content'])>0 and len(sent_tokenize(h['content']))>2]

text_content = None
file = "output.txt"
with open(file, 'r', encoding='utf-8') as f:
    text_content = f.read()

headings = PDFSectionExtractor(text_content).identify_potential_heading()
headings