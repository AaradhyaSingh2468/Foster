from dataclasses import dataclass

@dataclass
class AudioConfig:
    """Configuration for audio generation and mixing"""
    def __init__(self, voice_speed: float = 1.0, background_music_volume: float = 0.2, voice_volume: float = 1.0, fade_duration: float = 0.5, noise_reduction: bool = True, audio_enhancer: bool = True, music_prompt: str = "calm ambient background music for educational content", music_temperature: float = 0.7):
        self.voice_speed = voice_speed
        self.background_music_volume = background_music_volume
        self.voice_volume = voice_volume
        self.fade_duration = fade_duration
        self.noise_reduction = noise_reduction
        self.audio_enhancer = audio_enhancer
        self.music_prompt = music_prompt
        self.music_temperature = music_temperature


