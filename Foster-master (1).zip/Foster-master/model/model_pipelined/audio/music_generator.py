import torch
from tqdm import tqdm
from transformers import MusicgenForConditionalGeneration, AutoProcessor
from typing import Optional

class MusicGenerator:
    def __init__(self, device):
        self.device = device
        self._initialize_model()

    def _initialize_model(self):
        try:
            print("\nInitializing music generation...")
            with tqdm(total=2, desc="Loading MusicGen") as pbar:
                self.model = MusicgenForConditionalGeneration.from_pretrained(
                    "facebook/musicgen-small",
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
                ).to(self.device)
                pbar.update(1)

                self.processor = AutoProcessor.from_pretrained("facebook/musicgen-small")
                pbar.update(1)
            print("✓ Music generation model loaded successfully!")
        except Exception as e:
            print(f"Error loading music generation model: {str(e)}")
            raise

    def generate_music(self, prompt: str, duration: int = 10, temperature: float = 0.7) -> Optional[str]:
        try:
            with tqdm(total=3, desc="Generating music") as pbar:
                # Process input
                inputs = self.processor(
                    text=[prompt],
                    padding=True,
                    return_tensors="pt"
                ).to(self.device)
                pbar.update(1)

                # Generate audio
                print(f"\nGenerating {duration} seconds of music...")
                audio_values = self.model.generate(
                    **inputs,
                    do_sample=True,
                    guidance_scale=3,
                    max_new_tokens=duration * 50,
                    temperature=temperature
                )
                pbar.update(1)

                # Process output
                audio_output = audio_values.cpu().to(torch.float32)
                pbar.update(1)

            print("✓ Music generated successfully!")
            return audio_output

        except Exception as e:
            print(f"Error generating music: {str(e)}")
            return None


