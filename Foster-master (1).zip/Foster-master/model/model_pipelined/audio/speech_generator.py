from config import AudioConfig
import torch
import numpy as np
from tqdm import tqdm
from transformers import SpeechT5Processor, SpeechT5ForTextToSpeech, SpeechT5HifiGan
from datasets import load_dataset
import librosa
import scipy.signal

class SpeechGenerator:
    def __init__(self, device, audio_config: AudioConfig):
        self.device = device
        self.audio_config = audio_config
        self._initialize_models()

    def _initialize_models(self):
        print("\nInitializing speech synthesis...")
        with tqdm(total=4, desc="Loading TTS models") as pbar:
            self.processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
            pbar.update(1)

            self.tts_model = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts").to(self.device)
            pbar.update(1)

            self.vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan").to(self.device)
            pbar.update(1)

            dataset = load_dataset("Matthijs/cmu-arctic-xvectors", split="validation")
            self.speaker_embeddings = torch.tensor(dataset[7306]["xvector"]).unsqueeze(0).to(self.device)
            pbar.update(1)
        print("✓ Speech synthesis models loaded successfully!")

    def generate_speech(self, text: str) -> np.ndarray:
        try:
            with tqdm(total=4, desc="Generating speech") as pbar:
                # Text preprocessing
                sentences = text.split('.')
                truncated_text = ''
                for sent in sentences:
                    if len(truncated_text) + len(sent) < 200:
                        truncated_text += sent + '.'
                    else:
                        break
                pbar.update(1)

                # Tokenization
                inputs = self.processor(
                    text=truncated_text,
                    return_tensors="pt",
                    padding="max_length",
                    max_length=600
                ).to(self.device)
                pbar.update(1)

                # Speech synthesis
                speech = self.tts_model.generate_speech(
                    inputs["input_ids"],
                    self.speaker_embeddings,
                    vocoder=self.vocoder
                )
                speech = speech.cpu().numpy()
                pbar.update(1)

                # Audio processing
                processed_audio = self._process_audio(speech)
                pbar.update(1)

            print("✓ Speech generated successfully!")
            return processed_audio

        except Exception as e:
            print(f"Error generating speech: {str(e)}")
            return np.zeros(0)

    def _process_audio(self, audio_data: np.ndarray) -> np.ndarray:
        with tqdm(total=3, desc="Processing audio") as pbar:
            if self.audio_config.noise_reduction:
                audio_data = self._reduce_noise(audio_data)
                pbar.update(1)

            if self.audio_config.audio_enhancer:
                audio_data = self._enhance_audio(audio_data)
                pbar.update(1)

            if self.audio_config.voice_speed != 1.0:
                audio_data = librosa.effects.time_stretch(audio_data, rate=self.audio_config.voice_speed)
                pbar.update(1)

        return audio_data

    def _reduce_noise(self, audio_data: np.ndarray) -> np.ndarray:
        noise_clip = audio_data[:int(len(audio_data) * 0.1)]
        noise_spectrum = np.mean(np.abs(librosa.stft(noise_clip)), axis=1)
        audio_spectrum = librosa.stft(audio_data)
        audio_spectrum_clean = audio_spectrum * (np.abs(audio_spectrum) > 2 * noise_spectrum[:, np.newaxis])
        return librosa.istft(audio_spectrum_clean)

    def _enhance_audio(self, audio_data: np.ndarray) -> np.ndarray:
        # Compression
        db = 20 * np.log10(np.abs(audio_data) + 1e-8)
        mask = db > -20
        compression = (db[mask] - (-20)) * (1 - 1/4)
        audio_data[mask] *= 10 ** (-compression/20)

        # EQ
        sos = scipy.signal.butter(2, [2000, 4000], 'bandpass', fs=16000, output='sos')
        filtered = scipy.signal.sosfilt(sos, audio_data)
        return audio_data + 0.3 * filtered


