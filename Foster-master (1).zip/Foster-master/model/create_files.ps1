$baseFolder = "model_pipelined"
$codeFilePath = "scr2.py" # Path to the provided script

# Read the entire content of the provided script
$codeContent = Get-Content -Path $codeFilePath -Raw

# Define file paths and their corresponding classes
$classesToFile = @{
    "AudioConfig"          = "config.py"
    "TextGenerator"        = "models/text_generation.py"
    "ImageGenerator"       = "models/image_generation.py"
    "MusicGenerator"       = "audio/music_generator.py"
    "SpeechGenerator"      = "audio/speech_generator.py"
    "ClipGenerator"        = "visualization/clip_generator.py"
    "PDFToAnimationPipeline" = "pipeline.py"
}

# Ensure the base folder exists
if (-Not (Test-Path $baseFolder)) {
    New-Item -Path $baseFolder -ItemType Directory
}

# Function to extract class code and write/update the corresponding file
function WriteClassToFile($className, $filePath) {
    $pattern = "(class $className\b[\s\S]*?)(?=\n(class\s|#\s|$))"
    $matches = [regex]::Matches($codeContent, $pattern)

    if ($matches.Count -gt 0) {
        $classCode = $matches[0].Groups[1].Value
        
        # Create full path and ensure directory exists
        $fullPath = Join-Path -Path $baseFolder -ChildPath $filePath
        $dir = Split-Path -Path $fullPath -Parent
        if (-Not (Test-Path $dir)) {
            New-Item -Path $dir -ItemType Directory
        }

        # Write or update the file
        Set-Content -Path $fullPath -Value $classCode
        Write-Host "Updated $fullPath with $className"
    }
    else {
        Write-Host "Class $className not found in the script."
    }
}

# Loop through each class and write/update the corresponding file
foreach ($className in $classesToFile.Keys) {
    $filePath = $classesToFile[$className]
    WriteClassToFile -className $className -filePath $filePath
}

Write-Host "`nAll files have been updated successfully!"
