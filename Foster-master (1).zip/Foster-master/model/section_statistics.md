# PDF Content Analysis Statistics

## Basic Statistics
- Total sections: 20
- Total content length: 43575 characters

## Heading Level Distribution
- Level 1: 3 sections
- Level 2: 9 sections
- Level 3: 8 sections

## Content Length Statistics
- Average: 2178.75 characters
- Median: 1659.00 characters
- Minimum: 438 characters
- Maximum: 4661 characters
- Standard deviation: 1300.95 characters

## Relevance Score Statistics
- Average: 0.6127
- Median: 0.5959
- Minimum: 0.3517
- Maximum: 0.8500

## Special Cases
- Merged sections: 6
- Sections with improved headings: 0
- Embedded sections: 0
- Sections with low relevance warnings: 0
