from dataclasses import dataclass

@dataclass
class AudioConfig:
    """Configuration for audio generation and mixing"""
    voice_speed: float = 1.0
    background_music_volume: float = 0.2
    voice_volume: float = 1.0
    fade_duration: float = 0.5
    noise_reduction: bool = True
    audio_enhancer: bool = True
    music_prompt: str = "calm ambient background music for educational content"
    music_temperature: float = 0.7

import os
import json
import yaml
import torch
import torchaudio
import multiprocessing
import numpy as np
import cv2
import scipy.signal
import textwrap
from pathlib import Path
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

from tqdm import tqdm
from contextlib import nullcontext

from transformers import (
    AutoModelForCausalLM, AutoTokenizer,
    MusicgenForConditionalGeneration, AutoProcessor,
    SpeechT5Processor, SpeechT5ForTextToSpeech
)

from diffusers import StableDiffusionPipeline

from pdf2image import convert_from_path
import pytesseract
import librosa
import soundfile as sf

from PIL import Image, ImageDraw, ImageFont

from datasets import load_dataset

# MoviePy imports (consolidated)
from moviepy.editor import (
    ImageClip, CompositeVideoClip, AudioFileClip, CompositeAudioClip, concatenate_videoclips
)


class TextGenerator:
    def __init__(self, device):
        self.device = device
        print(f"\nUsing device: {self.device}")
        self._initialize_model()

    def _initialize_model(self):
        print("\nLoading text generation model...")
        try:
            with tqdm(total=2, desc="Loading GPT-Neo") as pbar:
                # Load model with GPU support if available
                self.model = AutoModelForCausalLM.from_pretrained(
                    "EleutherAI/gpt-neo-125M",
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                    device_map="auto" if torch.cuda.is_available() else None
                ).to(self.device)
                self.model.eval()  # Set to evaluation mode
                pbar.update(1)

                self.tokenizer = AutoTokenizer.from_pretrained(
                    "EleutherAI/gpt-neo-125M"
                )
                pbar.update(1)
            print(f"✓ Text generation model loaded successfully on {self.device}!")
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            raise

    def generate_text(self, prompt: str, max_length: int = 512) -> str:
        try:
            with tqdm(total=3, desc="Generating text") as pbar:
                # Tokenization
                inputs = self.tokenizer(
                    prompt,
                    return_tensors="pt",
                    truncation=True,
                    max_length=max_length
                ).to(self.device)
                pbar.update(1)
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
                # Text generation
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=50,
                    num_return_sequences=1,
                    do_sample=True,
                    temperature=0.7,
                    top_k=50,
                    top_p=0.9,
                    pad_token_id=self.tokenizer.eos_token_id
                )
                pbar.update(1)
                outputs = outputs.cpu()
                # Decoding
                generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
                pbar.update(1)

            print("✓ Text generated successfully!")
            return generated_text

        except Exception as e:
            print(f"Error generating text: {str(e)}")
            return prompt  # Return original prompt if generation fails

from diffusers import StableDiffusionPipeline
import torch
import numpy as np
from huggingface_hub import snapshot_download
import cv2
from tqdm import tqdm

class ImageGenerator:
    def __init__(self, device, hf_token: str):
        self.device = device
        self._initialize_model(hf_token)

    def _initialize_model(self, hf_token: str):
        print("\nInitializing Stable Diffusion...")
        with tqdm(total=2, desc="Loading image generator") as pbar:
            model_id = "CompVis/stable-diffusion-v1-4"
            cache_dir = snapshot_download(
                repo_id=model_id,
                use_auth_token=hf_token,
                revision="main"
            )
            pbar.update(1)

            self.model = StableDiffusionPipeline.from_pretrained(
                cache_dir,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                safety_checker=None,
                local_files_only=True
            ).to(self.device)
            pbar.update(1)
        print("✓ Image generation model loaded successfully!")

    def generate_image(self, prompt: str, size: tuple = (640, 480)) -> np.ndarray:
        try:
            print("\nGenerating image...")
            enhanced_prompt = f"educational illustration of {prompt[:150]}"[:250]

            with tqdm(total=1, desc="Generating image") as pbar:  # Changed total to 1
                def progress_callback(step: int, timestep: int, latents: torch.FloatTensor) -> None:
                    # Remove step checking to avoid modulo operations
                    pass  # Simply pass instead of trying to calculate progress

                # Generate image without progress tracking first
                image = self.model(
                    enhanced_prompt,
                    num_inference_steps=30,
                    guidance_scale=7.5,
                    callback=None  # Temporarily disable callback
                ).images[0]
                pbar.update(1)

                resized_image = np.array(image.resize(size))

            print("✓ Image generated successfully!")
            return resized_image

        except Exception as e:
            print(f"Error generating image: {str(e)}")
            # Create a blank error image
            blank_image = np.ones((size[1], size[0], 3), dtype=np.uint8) * 255
            cv2.putText(
                blank_image,
                f"Image Generation Failed: {str(e)}",
                (50, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 0),
                2
            )
            return blank_image

from transformers import MusicgenForConditionalGeneration, AutoProcessor
import torch
import torchaudio
from tqdm import tqdm
from typing import Optional

class MusicGenerator:
    def __init__(self, device):
        self.device = device
        self._initialize_model()

    def _initialize_model(self):
        try:
            print("\nInitializing music generation...")
            with tqdm(total=2, desc="Loading MusicGen") as pbar:
                self.model = MusicgenForConditionalGeneration.from_pretrained(
                    "facebook/musicgen-small",
                    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
                ).to(self.device)
                pbar.update(1)

                self.processor = AutoProcessor.from_pretrained("facebook/musicgen-small")
                pbar.update(1)
            print("✓ Music generation model loaded successfully!")
        except Exception as e:
            print(f"Error loading music generation model: {str(e)}")
            raise

    def generate_music(self, prompt: str, duration: int = 10, temperature: float = 0.7) -> Optional[str]:
        try:
            with tqdm(total=3, desc="Generating music") as pbar:
                # Process input
                inputs = self.processor(
                    text=[prompt],
                    padding=True,
                    return_tensors="pt"
                ).to(self.device)
                pbar.update(1)

                # Generate audio
                print(f"\nGenerating {duration} seconds of music...")
                audio_values = self.model.generate(
                    **inputs,
                    do_sample=True,
                    guidance_scale=3,
                    max_new_tokens=duration * 50,
                    temperature=temperature
                )
                pbar.update(1)

                # Process output
                audio_output = audio_values.cpu().to(torch.float32)
                pbar.update(1)

            print("✓ Music generated successfully!")
            return audio_output

        except Exception as e:
            print(f"Error generating music: {str(e)}")
            return None

from transformers import SpeechT5Processor, SpeechT5ForTextToSpeech, SpeechT5HifiGan
from datasets import load_dataset
from tqdm import tqdm
import torch
import numpy as np
import librosa
import scipy.signal

class SpeechGenerator:
    def __init__(self, device, audio_config: AudioConfig):
        self.device = device
        self.audio_config = audio_config
        self._initialize_models()

    def _initialize_models(self):
        print("\nInitializing speech synthesis...")
        with tqdm(total=4, desc="Loading TTS models") as pbar:
            self.processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
            pbar.update(1)

            self.tts_model = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts").to(self.device)
            pbar.update(1)

            self.vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan").to(self.device)
            pbar.update(1)

            dataset = load_dataset("Matthijs/cmu-arctic-xvectors", split="validation")
            self.speaker_embeddings = torch.tensor(dataset[7306]["xvector"]).unsqueeze(0).to(self.device)
            pbar.update(1)
        print("✓ Speech synthesis models loaded successfully!")

    def generate_speech(self, text: str) -> np.ndarray:
        try:
            with tqdm(total=4, desc="Generating speech") as pbar:
                # Text preprocessing
                sentences = text.split('.')
                truncated_text = ''
                for sent in sentences:
                    if len(truncated_text) + len(sent) < 200:
                        truncated_text += sent + '.'
                    else:
                        break
                pbar.update(1)

                # Tokenization
                inputs = self.processor(
                    text=truncated_text,
                    return_tensors="pt",
                    padding="max_length",
                    max_length=600
                ).to(self.device)
                pbar.update(1)

                # Speech synthesis
                speech = self.tts_model.generate_speech(
                    inputs["input_ids"],
                    self.speaker_embeddings,
                    vocoder=self.vocoder
                )
                speech = speech.cpu().numpy()
                pbar.update(1)

                # Audio processing
                processed_audio = self._process_audio(speech)
                pbar.update(1)

            print("✓ Speech generated successfully!")
            return processed_audio

        except Exception as e:
            print(f"Error generating speech: {str(e)}")
            return np.zeros(0)

    def _process_audio(self, audio_data: np.ndarray) -> np.ndarray:
        with tqdm(total=3, desc="Processing audio") as pbar:
            if self.audio_config.noise_reduction:
                audio_data = self._reduce_noise(audio_data)
                pbar.update(1)

            if self.audio_config.audio_enhancer:
                audio_data = self._enhance_audio(audio_data)
                pbar.update(1)

            if self.audio_config.voice_speed != 1.0:
                audio_data = librosa.effects.time_stretch(audio_data, rate=self.audio_config.voice_speed)
                pbar.update(1)

        return audio_data

    def _reduce_noise(self, audio_data: np.ndarray) -> np.ndarray:
        noise_clip = audio_data[:int(len(audio_data) * 0.1)]
        noise_spectrum = np.mean(np.abs(librosa.stft(noise_clip)), axis=1)
        audio_spectrum = librosa.stft(audio_data)
        audio_spectrum_clean = audio_spectrum * (np.abs(audio_spectrum) > 2 * noise_spectrum[:, np.newaxis])
        return librosa.istft(audio_spectrum_clean)

    def _enhance_audio(self, audio_data: np.ndarray) -> np.ndarray:
        # Compression
        db = 20 * np.log10(np.abs(audio_data) + 1e-8)
        mask = db > -20
        compression = (db[mask] - (-20)) * (1 - 1/4)
        audio_data[mask] *= 10 ** (-compression/20)

        # EQ
        sos = scipy.signal.butter(2, [2000, 4000], 'bandpass', fs=16000, output='sos')
        filtered = scipy.signal.sosfilt(sos, audio_data)
        return audio_data + 0.3 * filtered

from moviepy.editor import ImageClip, CompositeVideoClip, AudioFileClip
# from moviepy.video.VideoClip import ImageClip
# from moviepy.video.compositing.CompositeVideoClip import CompositeVideoClip
# from moviepy.audio.io.AudioFileClip import AudioFileClip
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import textwrap
from tqdm import tqdm
from typing import Optional

class ClipGenerator:
    def __init__(self):
        pass

    def create_scene_clip(
        self,
        image: np.ndarray,
        text: str,
        audio_clip: Optional[AudioFileClip] = None,
        duration: float = 5.0
    ) -> Optional[CompositeVideoClip]:
        try:
            with tqdm(total=4, desc="Creating scene clip") as pbar:
                # Process image
                if image.shape[2] == 4:
                    image = image[..., :3]
                image_clip = ImageClip(image).set_duration(duration)
                pbar.update(1)

                # Create text overlay
                text_overlay = self._create_text_overlay(text)
                text_rgb = text_overlay[..., :3]
                text_alpha = text_overlay[..., 3]
                pbar.update(1)

                # Create text clip
                text_clip = (ImageClip(text_rgb)
                            .set_duration(duration)
                            .set_mask(ImageClip(text_alpha, ismask=True)))
                text_clip = text_clip.set_position(('center', 'bottom'))
                pbar.update(1)

                # Compose final clip
                clip = CompositeVideoClip([image_clip, text_clip])
                if audio_clip:
                    clip = clip.set_audio(audio_clip)
                pbar.update(1)

            print("✓ Scene clip created successfully!")
            return clip

        except Exception as e:
            print(f"Error creating scene clip: {str(e)}")
            return None

    def _create_text_overlay(
        self,
        text: str,
        width: int = 600,
        bg_color: tuple = (0, 0, 0, 180)
    ) -> np.ndarray:
        with tqdm(total=3, desc="Creating text overlay") as pbar:
            # Initialize image and font
            txt_img = Image.new('RGBA', (width, 480), (0, 0, 0, 0))
            draw = ImageDraw.Draw(txt_img)
            try:
                font = ImageFont.truetype("arial.ttf", 24)
            except:
                font = ImageFont.load_default()
            pbar.update(1)

            # Process text layout
            wrapper = textwrap.TextWrapper(width=40)
            text_lines = wrapper.wrap(text)
            line_height = 30
            text_height = len(text_lines) * line_height
            margin = 20
            pbar.update(1)

            # Create and draw text
            text_bg_height = text_height + 2 * margin
            text_bg = Image.new('RGBA', (width, text_bg_height), bg_color)
            txt_img.paste(text_bg, (0, 480 - text_bg_height))

            y = 480 - text_bg_height + margin
            for line in text_lines:
                line_width = draw.textlength(line, font=font)
                x = (width - line_width) // 2
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
                y += line_height
            pbar.update(1)

        return np.array(txt_img)


from pathlib import Path
import torch
import os
import yaml
import torchaudio
import soundfile as sf
from concurrent.futures import ThreadPoolExecutor
import multiprocessing
from typing import List, Dict, Optional
from pdf2image import convert_from_path
import pytesseract
from moviepy.editor import ImageClip, CompositeVideoClip, AudioFileClip,CompositeAudioClip
# from moviepy.video.VideoClip import ImageClip
# from moviepy.video.compositing.CompositeVideoClip import CompositeVideoClip
# from moviepy.audio.io.AudioFileClip import AudioFileClip
import json
from dataclasses import dataclass
from tqdm import tqdm

class PDFToAnimationPipeline:
    def __init__(self, hf_token: str, config_path: Optional[str] = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.audio_config = self._load_config(config_path)

        # Initialize components
        self.text_generator = TextGenerator(self.device)
        self.image_generator = ImageGenerator(self.device, hf_token)
        self.music_generator = MusicGenerator(self.device)
        self.speech_generator = SpeechGenerator(self.device, self.audio_config)
        self.clip_generator = ClipGenerator()

        # Setup directories
        self.audio_dir = Path("audio_files")
        self.output_dir = Path("output")
        self.audio_dir.mkdir(exist_ok=True)
        self.output_dir.mkdir(exist_ok=True)

        # Initialize thread pool
        self.thread_pool = ThreadPoolExecutor(max_workers=multiprocessing.cpu_count())

    def _load_config(self, config_path: Optional[str]) -> AudioConfig:
        if config_path and Path(config_path).exists():
            with open(config_path, 'r') as f:
                config_dict = yaml.safe_load(f)
                return AudioConfig(**config_dict)
        return AudioConfig()

    def generate_animation(
        self,
        pdf_path: str,
        duration: Optional[float] = None,
        force_regenerate: bool = False
    ) -> Optional[str]:
        try:
            print("\n========== Starting Animation Generation ==========")
            scene_descriptions = []
            if not force_regenerate:
                print("\nChecking for existing scene descriptions...")
                scene_descriptions = self._load_scene_descriptions()

            if not scene_descriptions:
                print("\nExtracting text from PDF...")
                text_content = self._extract_text_from_pdf(pdf_path)
                if not text_content:
                    raise ValueError("No text content extracted from PDF")
                print(f"✓ Successfully extracted {len(text_content.split())} words")

                print("\nGenerating scene descriptions from text...")
                scene_descriptions = self._generate_scene_descriptions(text_content, total_duration=duration or 300)
                print(f"✓ Generated {len(scene_descriptions)} scene descriptions")

            if not scene_descriptions:
                raise ValueError("No scene descriptions available")

            print("\nCalculating scene durations...")
            print("\nLength of scene_description : ",len(scene_descriptions))
            duration_per_scene =  duration/len(scene_descriptions) if duration else 5.0
            print(f"✓ Each scene will be approximately {duration_per_scene:.3f} seconds")

            return self._create_animation(scene_descriptions, duration_per_scene)

        except Exception as e:
            print(f"\n❌ Error in animation pipeline: {str(e)}")
            return None

    def _extract_text_from_pdf(self, pdf_path: str) -> str:
        images = convert_from_path(pdf_path)
        text_content = []

        for img in images:
            text = pytesseract.image_to_string(img)
            if text.strip():
                text_content.append(text)

        return "\n\n".join(text_content)

    def _generate_scene_descriptions(self, text_content: str, total_duration: float = 300) -> List[Dict[str, str]]:
        # Step 1: Clean up segments
        raw_segments = [seg.strip() for seg in text_content.split('\n\n') if seg.strip()]
        print(f"\n🧠 Extracted {len(raw_segments)} raw segments")

        # Step 2: Analyze total word count
        total_words = sum(len(seg.split()) for seg in raw_segments)
        words_per_scene = 90  # can vary this dynamically if needed
        estimated_scene_count = max(1, total_words // words_per_scene)
        average_scene_duration = total_duration / estimated_scene_count

        print(f"📚 Total words: {total_words}")
        print(f"🎯 Estimated scene count: {estimated_scene_count}")
        print(f"⏱️ Average scene duration: {average_scene_duration:.1f}s")

        # Step 3: Merge raw segments into scene-sized chunks
        merged_segments = []
        temp_chunk = ""

        for seg in raw_segments:
            if len((temp_chunk + " " + seg).split()) < words_per_scene:
                temp_chunk += " " + seg
            else:
                merged_segments.append(temp_chunk.strip())
                temp_chunk = seg

        if temp_chunk.strip():
            merged_segments.append(temp_chunk.strip())

        print(f"📦 Final number of merged segments: {len(merged_segments)}")

        # Step 4: Generate scene descriptions
        scene_descriptions = []

        print("\nGenerating scene descriptions...")
        for segment in tqdm(merged_segments, desc="Processing merged segments"):
            try:
                visual_prompt = f"Create a brief visual scene description: {segment[:200]}"

                visual_description = self.text_generator.generate_text(
                    visual_prompt,
                    max_length=77
                )

                scene_descriptions.append({
                    'text': segment,
                    'visual_description': visual_description.strip()
                })

            except Exception as e:
                print(f"Error generating scene description:{str(e)}")
                continue

        self._save_scene_descriptions(scene_descriptions)
        return scene_descriptions



    def _save_scene_descriptions(self, scene_descriptions: List[Dict[str, str]]) -> None:
        output_dir = Path("scene_descriptions")
        output_dir.mkdir(exist_ok=True)

        with open(output_dir / "all_scenes.json", 'w', encoding='utf-8') as f:
            json.dump(scene_descriptions, f, ensure_ascii=False, indent=2)

    def _load_scene_descriptions(self) -> List[Dict[str, str]]:
        try:
            with open(Path("scene_descriptions/all_scenes.json"), 'r', encoding='utf-8') as f:
                scenes = json.load(f)
            print("🟢Scene descriptions found and updated")
            return scenes
        except FileNotFoundError:
            print("No saved scene descriptions found.")
            return []
        except Exception as e:
            print(f"Error loading scene descriptions: {str(e)}")
            return []

    def _create_animation(
        self,
        scene_descriptions: List[Dict[str, str]],
        duration_per_scene: float = 5.0
    ) -> Optional[str]:
        clips = []

        try:
            # Generate initial background music
            print("\nGenerating background music...")
            music_audio = self.music_generator.generate_music(
                self.audio_config.music_prompt,
                duration=30
            )
            print("\nCreating scene clips...")
            pbar = tqdm(total=len(scene_descriptions),  desc="Generating scenes")

            for i, scene in enumerate(scene_descriptions):
                pbar.set_description(f"Scene {i+1}/{len(scene_descriptions)}")

                narrative_text = self.text_generator.generate_text(
                    f"Convert this educational content into an engaging narrative: {scene['text'][:500]}"
                )

                image = self.image_generator.generate_image(scene['visual_description'])
                speech_audio = self.speech_generator.generate_speech(narrative_text)


                # Create audio clip
                if len(speech_audio) > 0:
                    speech_path = self.audio_dir / f"speech_{i:03d}.wav"
                    sf.write(str(speech_path), speech_audio, samplerate=16000)
                    audio_clip = AudioFileClip(str(speech_path))

                    # Mix with background music if available
                    if music_audio is not None:
                        background_path = self.audio_dir / f"background_{i:03d}.wav"
                        torchaudio.save(
                            str(background_path),
                            music_audio.squeeze(0),
                            sample_rate=32000
                        )
                        music_clip = AudioFileClip(str(background_path))

                        # Adjust volumes and mix
                        speech_volume = audio_clip.volumex(self.audio_config.voice_volume)
                        music_volume = music_clip.volumex(self.audio_config.background_music_volume)
                        audio_clip = CompositeAudioClip([speech_volume, music_volume])
                else:
                    audio_clip = None

                # Create scene clip
                clip = self.clip_generator.create_scene_clip(
                    image=image,
                    text=narrative_text,
                    audio_clip=audio_clip,
                    duration=max(duration_per_scene, audio_clip.duration if audio_clip else duration_per_scene)
                )

                if clip is not None:
                    clips.append(clip)
                pbar.update(1)

            pbar.close()
            if not clips:
                raise ValueError("No clips were generated")

            # Concatenate clips and write final video
            print("\nConcatenating clips and rendering final video...")
            final_clip = concatenate_videoclips(clips, method="compose")
            output_path = str(self.output_dir / 'enhanced_narrated_output.mp4')

            final_clip = concatenate_videoclips(clips, method="compose")
            output_path = str(self.output_dir / 'enhanced_narrated_output.mp4')

            final_clip.write_videofile(
                output_path,
                fps=24,
                codec='h264_nvenc' if torch.cuda.is_available() else 'libx264', # Use GPU encoding if available
                audio_codec='aac',
                audio_bitrate='192k',
                threads=multiprocessing.cpu_count(), # Use all available CPU cores
                preset='fast', # Use faster encoding preset
            )

            print(f"\nVideo saved to: {output_path}")
            return output_path

        except Exception as e:
            print(f"Error creating animation: {str(e)}")
            return None
        finally:
            for clip in clips:
                try:
                    clip.close()
                except:
                    pass

import os

def main():
    try:
        print("\nInitializing Foster Animation Pipeline...")
        hf_token = os.getenv('HF_TOKEN')
        if not hf_token:
            hf_token = "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"

        pipeline = PDFToAnimationPipeline(hf_token, 'audio_config.yml')
        print("\nStarting animation generation...")

        video_path = pipeline.generate_animation(
            pdf_path="input.pdf",
            duration=300  # 5 minutes
        )

        if video_path:
            print(f"\nSuccess! Generated video saved to: {video_path}")
        else:
            print("\nFailed to generate video")

    except Exception as e:
        print(f"\nError in main: {str(e)}")

if __name__ == "__main__":
    main()