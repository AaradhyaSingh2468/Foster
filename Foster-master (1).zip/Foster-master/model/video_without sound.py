import torch
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
from pdf2image import convert_from_path
import pytesseract
import numpy as np
from moviepy.editor import ImageClip, TextClip, CompositeVideoClip, concatenate_videoclips
import cv2
from huggingface_hub import login, snapshot_download
from diffusers import StableDiffusionPipeline
import os
from typing import List, Dict, Optional
import subprocess
from PIL import Image, ImageDraw, ImageFont
import textwrap
from tqdm import tqdm
import json
from pathlib import Path

class PDFToAnimationPipeline:
    def __init__(self, hf_token: str):
        """
        Initialize the pipeline with Hugging Face token
        Args:
            hf_token (str): Hugging Face token for model access
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._check_imagemagick()
        login(hf_token)
        self.text_extractor = pytesseract
        self._initialize_image_generator(hf_token)
        self._initialize_text_generator()
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)

    def _check_imagemagick(self) -> None:
        """Check if ImageMagick is installed and accessible"""
        try:
            # Try to run convert -version (part of ImageMagick)
            subprocess.run(['convert', '-version'],
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         check=True)
        except (subprocess.SubprocessError, FileNotFoundError):
            raise RuntimeError(
                "ImageMagick is not installed or not found in PATH. "
                "Please install ImageMagick:\n"
                "- Ubuntu/Debian: sudo apt-get install imagemagick\n"
                "- macOS: brew install imagemagick\n"
                "- Windows: Download from https://imagemagick.org/script/download.php"
            )

    def _initialize_image_generator(self, hf_token: str) -> None:
        """Initialize the image generation model"""
        try:
            print("Downloading Stable Diffusion model files...")
            model_id = "CompVis/stable-diffusion-v1-4"
            cache_dir = snapshot_download(
                repo_id=model_id,
                use_auth_token=hf_token,
                revision="main"
            )

            self.image_generator = StableDiffusionPipeline.from_pretrained(
                cache_dir,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                safety_checker=None,
                local_files_only=True
            ).to(self.device)

            print(f"Using device: {self.device}")

        except Exception as e:
            print(f"Error loading Stable Diffusion: {str(e)}")
            raise


    def _initialize_text_generator(self) -> None:
        """Initialize the text generation model"""
        try:
            print("Loading text generation model...")
            self.scene_generator = AutoModelForCausalLM.from_pretrained(
                "EleutherAI/gpt-neo-125M",
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
            ).to(self.device)

            self.scene_tokenizer = AutoTokenizer.from_pretrained(
                "EleutherAI/gpt-neo-125M"
            )
            print("Text generation model loaded successfully!")

        except Exception as e:
            print(f"Error loading text generation model: {str(e)}")
            raise



    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """
        Extract text content from PDF
        Args:
            pdf_path (str): Path to the PDF file
        Returns:
            str: Extracted text content
        """
        try:
            images = convert_from_path(pdf_path)
            text_content = []

            for img in images:
                text = self.text_extractor.image_to_string(img)
                if text.strip():  # Only add non-empty text
                    text_content.append(text)

            return "\n\n".join(text_content)
        except Exception as e:
            print(f"Error extracting text from PDF: {str(e)}")
            return ""

    def generate_scene_image(self, visual_description: str) -> np.ndarray:
        """
        Generate image for a scene
        Args:
            visual_description (str): Visual description for image generation
        Returns:
            np.ndarray: Generated image as numpy array
        """
        try:
            # Truncate and enhance the prompt to fit within CLIP's 77 token limit
            # We'll keep it shorter to allow room for the additional context
            base_desc = visual_description[:150]  # Truncate base description
            enhanced_prompt = (
                f"educational illustration of {base_desc}"
            )[:250]  # Further ensure we're within limits

            image = self.image_generator(
                enhanced_prompt,
                num_inference_steps=30,
                guidance_scale=7.5
            ).images[0]

            # Convert to numpy array and ensure correct size
            image_np = np.array(image.resize((640, 480)))
            return image_np

        except Exception as e:
            print(f"Error generating image: {str(e)}")
            blank_image = np.ones((480, 640, 3), dtype=np.uint8) * 255
            cv2.putText(
                blank_image,
                "Image Generation Failed",
                (50, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 0, 0),
                2
            )
            return blank_image

    def generate_scene_descriptions(self, text_content: str) -> List[Dict[str, str]]:
        """
        Generate visual scene descriptions from text with progress tracking and save to disk
        Args:
            text_content (str): Input text content
        Returns:
            List[Dict[str, str]]: List of scene descriptions with text and visual descriptions
        """
        segments = [seg.strip() for seg in text_content.split('\n\n') if seg.strip()]
        scene_descriptions = []

        # Create output directory if it doesn't exist
        output_dir = Path("scene_descriptions")
        output_dir.mkdir(exist_ok=True)

        print(f"\nGenerating scene descriptions for {len(segments)} text segments...")

        progress_bar = tqdm(
            total=len(segments),
            desc="Generating descriptions",
            unit="scene"
        )

        for i, segment in enumerate(segments, 1):
            # Generate unique filename for each scene
            scene_file = output_dir / f"scene_{i:03d}.json"

            # Check if scene description already exists
            if scene_file.exists():
                with open(scene_file, 'r', encoding='utf-8') as f:
                    scene_data = json.load(f)
                    scene_descriptions.append(scene_data)
                progress_bar.update(1)
                continue

            truncated_segment = segment[:200]
            prompt = (
                "Create a brief visual scene description: "
                f"{truncated_segment}"
            )

            try:
                inputs = self.scene_tokenizer(
                    prompt,
                    return_tensors="pt",
                    truncation=True,
                    max_length=77
                )

                # Move inputs to the same device as the model
                inputs = {k: v.to(self.device) for k, v in inputs.items()}

                outputs = self.scene_generator.generate(
                    **inputs,
                    max_new_tokens=50,
                    num_return_sequences=1,
                    do_sample=True,
                    temperature=0.7,
                    top_k=50,
                    top_p=0.9,
                    pad_token_id=self.scene_tokenizer.eos_token_id
                )

                # Move outputs back to CPU for tokenizer decoding
                outputs = outputs.cpu()

                scene_desc = self.scene_tokenizer.decode(outputs[0], skip_special_tokens=True)
                scene_data = {
                    'text': segment,
                    'visual_description': scene_desc.strip()
                }

                # Save scene description to disk
                with open(scene_file, 'w', encoding='utf-8') as f:
                    json.dump(scene_data, f, ensure_ascii=False, indent=2)

                scene_descriptions.append(scene_data)

                progress_bar.set_postfix({
                    'current': f"Segment {i}/{len(segments)}",
                    'status': 'success'
                })

            except Exception as e:
                print(f"\nError generating scene description for segment {i}: {str(e)}")
                progress_bar.set_postfix({
                    'current': f"Segment {i}/{len(segments)}",
                    'status': 'failed'
                })
                continue
            finally:
                progress_bar.update(1)

        progress_bar.close()

        # Save complete collection of scene descriptions
        with open(output_dir / "all_scenes.json", 'w', encoding='utf-8') as f:
            json.dump(scene_descriptions, f, ensure_ascii=False, indent=2)

        successful = len(scene_descriptions)
        failed = len(segments) - successful
        print(f"\nScene description generation complete:")
        print(f"- Successfully generated: {successful}")
        print(f"- Failed: {failed}")
        print(f"- Saved to: {output_dir}")

        return scene_descriptions

    def create_scene_clip(
        self,
        image: np.ndarray,
        text: str,
        duration: float = 5.0
    ) -> Optional[CompositeVideoClip]:
        """
        Create a video clip with image and explanatory text
        """
        try:
            # Convert image to RGB if it's RGBA
            if image.shape[2] == 4:
                image = image[..., :3]

            # Create base clip
            image_clip = ImageClip(image).set_duration(duration)

            # Create text overlay
            text_overlay = self._create_text_overlay(text)

            # Convert RGBA overlay to RGB and create a separate mask
            text_rgb = text_overlay[..., :3]
            text_alpha = text_overlay[..., 3]

            # Create text clip with alpha channel as mask
            text_clip = (ImageClip(text_rgb)
                        .set_duration(duration)
                        .set_mask(ImageClip(text_alpha, ismask=True)))

            # Position text at the bottom
            text_clip = text_clip.set_position(('center', 'bottom'))

            # Combine clips
            return CompositeVideoClip([image_clip, text_clip])

        except Exception as e:
            print(f"Error creating scene clip: {str(e)}")
            # Fallback to just the image if compositing fails
            try:
                return ImageClip(image).set_duration(duration)
            except:
                return None

    def load_scene_descriptions(self) -> List[Dict[str, str]]:
        """
        Load previously generated scene descriptions from disk
        Returns:
            List[Dict[str, str]]: List of scene descriptions
        """
        try:
            with open(Path("scene_descriptions/all_scenes.json"), 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print("No saved scene descriptions found.")
            return []
        except Exception as e:
            print(f"Error loading scene descriptions: {str(e)}")
            return []

    def create_animation(
        self,
        scene_descriptions: List[Dict[str, str]],
        duration_per_scene: float = 5.0
    ) -> Optional[str]:
        """
        Create animation from scene descriptions with progress tracking
        Args:
            scene_descriptions (List[Dict[str, str]]): List of scene descriptions
            duration_per_scene (float): Duration for each scene in seconds
        Returns:
            Optional[str]: Path to output video file or None if creation fails
        """
        clips = []

        print(f"\nCreating animation for {len(scene_descriptions)} scenes...")

        # Create progress bar for scene generation
        progress_bar = tqdm(
            total=len(scene_descriptions),
            desc="Generating scenes",
            unit="scene"
        )

        try:
            for i, scene in enumerate(scene_descriptions, 1):
                progress_bar.set_postfix({'status': 'generating image'})
                image = self.generate_scene_image(scene['visual_description'])

                progress_bar.set_postfix({'status': 'creating clip'})
                clip = self.create_scene_clip(
                    image=image,
                    text=scene['text'],
                    duration=duration_per_scene
                )

                if clip is not None:
                    clips.append(clip)
                    progress_bar.set_postfix({
                        'current': f"Scene {i}/{len(scene_descriptions)}",
                        'status': 'success'
                    })
                else:
                    progress_bar.set_postfix({
                        'current': f"Scene {i}/{len(scene_descriptions)}",
                        'status': 'failed'
                    })

                progress_bar.update(1)

            progress_bar.close()

            if not clips:
                raise ValueError("No clips generated")

            print("\nConcatenating video clips...")
            final_clip = concatenate_videoclips(clips)
            output_path = 'output.mp4'

            print("\nWriting final video file...")
            final_clip.write_videofile(
                output_path,
                fps=24,
                codec='libx264',
                audio=False,
                threads=4
            )

            print(f"\nVideo creation complete:")
            print(f"- Total scenes processed: {len(scene_descriptions)}")
            print(f"- Successfully rendered: {len(clips)}")
            print(f"- Failed: {len(scene_descriptions) - len(clips)}")

            return output_path

        except Exception as e:
            print(f"\nError in animation creation: {str(e)}")
            return None
        finally:
            progress_bar.close()

    def generate_animation(
        self,
        pdf_path: str,
        duration: Optional[float] = None,
        force_regenerate: bool = False) -> Optional[str]:
        """
        Main pipeline to generate animation from PDF
        Args:
            pdf_path (str): Path to input PDF file
            duration (Optional[float]): Total desired duration in seconds
            force_regenerate (bool): If True, regenerate scenes even if they exist
        Returns:
            Optional[str]: Path to output video file or None if generation fails
        """
        try:
            # First try to load existing scene descriptions
            scene_descriptions = []
            if not force_regenerate:
                print("Checking for existing scene descriptions...")
                scene_descriptions = self.load_scene_descriptions()

            # If no existing scenes found or force_regenerate is True, generate new ones
            if not scene_descriptions:
                print("Generating new scene descriptions...")
                text_content = self.extract_text_from_pdf(pdf_path)
                if not text_content:
                    raise ValueError("No text content extracted from PDF")

                scene_descriptions = self.generate_scene_descriptions(text_content)
            else:
                print(f"Loaded {len(scene_descriptions)} existing scene descriptions")

            if not scene_descriptions:
                raise ValueError("No scene descriptions available")

            # Calculate duration per scene
            duration_per_scene = 5.0
            if duration:
                duration_per_scene = duration / len(scene_descriptions)

            # Create the animation
            print("\nCreating animation from scene descriptions...")
            video_path = self.create_animation(
                scene_descriptions,
                duration_per_scene
            )

            if not video_path:
                raise ValueError("Video creation failed")

            return video_path

        except Exception as e:
            print(f"Error in animation generation pipeline: {str(e)}")
            return None
    def _create_text_overlay(
        self,
        text: str,
        width: int = 600,
        bg_color: tuple = (0, 0, 0, 180)
    ) -> np.ndarray:
        """
        Create a text overlay image using PIL instead of ImageMagick
        """
        try:
            # Create a transparent image for text
            txt_img = Image.new('RGBA', (width, 480), (0, 0, 0, 0))
            draw = ImageDraw.Draw(txt_img)

            # Try to use Arial font, fall back to default if not available
            try:
                font = ImageFont.truetype("arial.ttf", 24)
            except:
                font = ImageFont.load_default()

            # Wrap text to fit width
            margin = 20
            wrapper = textwrap.TextWrapper(width=40)  # Approximate characters per line
            text_lines = wrapper.wrap(text)

            # Calculate text block height
            line_height = 30
            text_height = len(text_lines) * line_height

            # Create semi-transparent background for text
            text_bg_height = text_height + 2 * margin
            text_bg = Image.new('RGBA', (width, text_bg_height), bg_color)
            txt_img.paste(text_bg, (0, 480 - text_bg_height))

            # Draw text lines
            y = 480 - text_bg_height + margin
            for line in text_lines:
                # Get line width for centering
                line_width = draw.textlength(line, font=font)
                x = (width - line_width) // 2
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
                y += line_height

            return np.array(txt_img)

        except Exception as e:
            print(f"Error creating text overlay: {str(e)}")
            return np.zeros((480, width, 4), dtype=np.uint8)


def main():
    try:
        hf_token = os.getenv('HF_TOKEN')
        if not hf_token:
            print("Please provide your Hugging Face token:")
            hf_token = "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"

        os.makedirs(os.path.expanduser("~/.cache/huggingface/diffusers"), exist_ok=True)

        pipeline = PDFToAnimationPipeline(hf_token)

        # Example usage with different scenarios
        # 1. First run - generates and saves scenes
        video_path = pipeline.generate_animation(
            pdf_path="input.pdf",
            duration=300  # 5 minutes
        )

        if video_path:
            print(f"Generated video saved to: {video_path}")
        else:
            print("Failed to generate video")

        # 2. Second run - uses saved scenes
        # print("\nTrying to generate another video using saved scenes...")
        # video_path_2 = pipeline.generate_animation(
        #     pdf_path="input.pdf",
        #     duration=300
        # )

        # # 3. Force regenerate scenes
        # print("\nForce regenerating scenes...")
        # video_path_3 = pipeline.generate_animation(
        #     pdf_path="input.pdf",
        #     duration=300,
        #     force_regenerate=True
        # )

    except Exception as e:
        print(f"Error in main: {str(e)}")

if __name__ == "__main__":
    main()