import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiShare2, FiMessageCircle, FiPlus } from 'react-icons/fi';
import { Button } from '../ui/button';
import { SearchBar } from '../header/SearchBar';
import { UserProfileDropdown } from '../header/UserProfileDropdown';
import { ShareModal } from '../modals/ShareModal';
import { UpgradeModal } from '../modals/UpgradeModal';
import { FeedbackModal } from '../modals/FeedbackModal';
import { CreateSetModal } from '../modals/CreateSetModal';

const Header: React.FC = () => {
  // State for expanded search bar
  const [searchExpanded, setSearchExpanded] = useState(false);

  // State for modals
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);
  const [createSetModalOpen, setCreateSetModalOpen] = useState(false);

  // Button animations
  const buttonAnimation = {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.95 },
    transition: { duration: 0.2 }
  };

  return (
    <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-900">
      <div className="flex items-center space-x-4">
        <SearchBar
          expanded={searchExpanded}
          onToggleExpand={() => setSearchExpanded(!searchExpanded)}
        />
        <div className="flex items-center gap-2 ml-2">
          <span className="text-orange-500">🔥</span>
          <span className="text-white font-semibold">0</span>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="outline"
            className="rounded-full px-5 border-gray-700 text-gray-300 hover:bg-gray-800"
            onClick={() => setShareModalOpen(true)}
          >
            <FiShare2 className="mr-2" />
            Share
          </Button>
        </motion.div>

        <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="default"
            className="rounded-full px-5 bg-emerald-500 hover:bg-emerald-600 text-white"
            onClick={() => setUpgradeModalOpen(true)}
          >
            Upgrade
          </Button>
        </motion.div>

        <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="outline"
            className="rounded-full px-5 border-gray-700 text-gray-300 hover:bg-gray-800"
            onClick={() => setFeedbackModalOpen(true)}
          >
            <FiMessageCircle className="mr-2" />
            Feedback
          </Button>
        </motion.div>

        <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="default"
            className="rounded-full px-5 bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2"
            onClick={() => setCreateSetModalOpen(true)}
          >
            <FiPlus size={18} />
            Create a Set
          </Button>
        </motion.div>

        <UserProfileDropdown />
      </div>

      {/* Modals */}
      <ShareModal
        open={shareModalOpen}
        onOpenChange={setShareModalOpen}
      />

      <UpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
      />

      <FeedbackModal
        open={feedbackModalOpen}
        onOpenChange={setFeedbackModalOpen}
      />

      <CreateSetModal
        open={createSetModalOpen}
        onOpenChange={setCreateSetModalOpen}
      />
    </div>
  );
};

export default Header;
