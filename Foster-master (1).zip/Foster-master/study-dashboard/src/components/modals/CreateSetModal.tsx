import type React from 'react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Save, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { useToast } from '../../lib/useToast';
import { Separator } from '../ui/separator';

interface FlashcardItem {
  id: string;
  term: string;
  definition: string;
}

interface CreateSetModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateSetModal: React.FC<CreateSetModalProps> = ({ open, onOpenChange }) => {
  const { toast } = useToast();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [cards, setCards] = useState<FlashcardItem[]>([
    { id: '1', term: '', definition: '' },
    { id: '2', term: '', definition: '' }
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAddCard = () => {
    const newId = Date.now().toString();
    setCards([...cards, { id: newId, term: '', definition: '' }]);
  };

  const handleRemoveCard = (id: string) => {
    if (cards.length <= 2) {
      toast({
        title: "Cannot remove card",
        description: "You need at least 2 cards in a study set",
        variant: "destructive",
      });
      return;
    }

    setCards(cards.filter(card => card.id !== id));
  };

  const handleCardChange = (id: string, field: 'term' | 'definition', value: string) => {
    setCards(cards.map(card =>
      card.id === id ? { ...card, [field]: value } : card
    ));
  };

  const handleSubmit = () => {
    // Form validation
    if (!title.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter a title for your study set",
        variant: "destructive",
      });
      return;
    }

    const emptyCards = cards.filter(card => !card.term.trim() || !card.definition.trim());
    if (emptyCards.length > 0) {
      toast({
        title: "Incomplete cards",
        description: "Please fill out all term and definition fields",
        variant: "destructive",
      });
      return;
    }

    // Simulate form submission
    setIsSubmitting(true);

    setTimeout(() => {
      // In a real app, this would call an API to create the study set
      setIsSubmitting(false);

      toast({
        title: "Study set created",
        description: `Your study set "${title}" with ${cards.length} cards has been created!`,
        variant: "success",
      });

      // Reset form and close modal
      setTitle('');
      setDescription('');
      setCards([
        { id: '1', term: '', definition: '' },
        { id: '2', term: '', definition: '' }
      ]);
      onOpenChange(false);
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Create a New Study Set</DialogTitle>
          <DialogDescription className="text-gray-300">
            Create your study set with terms and definitions. Add as many cards as you need.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-white">Title</Label>
            <Input
              id="title"
              placeholder="Enter a title for your study set"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-white">Description (optional)</Label>
            <Textarea
              id="description"
              placeholder="Add a description for your study set"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <Separator className="my-4" />

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-white">Flashcards ({cards.length})</h3>
              <Button
                size="sm"
                variant="outline"
                onClick={handleAddCard}
                className="flex items-center gap-1"
              >
                <Plus size={16} /> Add Card
              </Button>
            </div>

            <div className="space-y-6">
              <AnimatePresence>
                {cards.map((card, index) => (
                  <motion.div
                    key={card.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0, overflow: 'hidden' }}
                    transition={{ duration: 0.2 }}
                    className="border border-gray-700 rounded-lg p-4 bg-gray-800/50"
                  >
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium text-sm text-gray-300">Card {index + 1}</h4>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleRemoveCard(card.id)}
                        className="h-8 w-8 p-0 text-gray-400 hover:text-red-500"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor={`term-${card.id}`} className="text-gray-200">Term</Label>
                        <Textarea
                          id={`term-${card.id}`}
                          placeholder="Enter term"
                          value={card.term}
                          onChange={(e) => handleCardChange(card.id, 'term', e.target.value)}
                          className="min-h-[80px]"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor={`definition-${card.id}`} className="text-gray-200">Definition</Label>
                        <Textarea
                          id={`definition-${card.id}`}
                          placeholder="Enter definition"
                          value={card.definition}
                          onChange={(e) => handleCardChange(card.id, 'definition', e.target.value)}
                          className="min-h-[80px]"
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="mt-4"
            >
              <Button
                variant="outline"
                className="w-full border-dashed border-gray-600 py-6 flex items-center justify-center gap-2"
                onClick={handleAddCard}
              >
                <Plus size={18} /> Add Another Card
              </Button>
            </motion.div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="gap-2"
          >
            {isSubmitting ? (
              'Creating...'
            ) : (
              <>
                <Save size={16} /> Create Study Set
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
