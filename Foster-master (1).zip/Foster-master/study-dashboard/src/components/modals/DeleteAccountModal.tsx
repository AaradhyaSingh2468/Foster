import type React from 'react';
import { useState } from 'react';
import { AlertTriangle, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useToast } from '../../lib/useToast';

interface DeleteAccountModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const DeleteAccountModal: React.FC<DeleteAccountModalProps> = ({
  open,
  onOpenChange,
}) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [password, setPassword] = useState('');

  const CONFIRM_TEXT = 'delete my account';
  const isValid = confirmText === CONFIRM_TEXT && password.length >= 6;

  const handleDeleteAccount = () => {
    if (!isValid) return;

    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      setLoading(false);

      toast({
        title: "Account deleted",
        description: "Your account has been permanently deleted",
        variant: "success",
        duration: 3000,
      });

      onOpenChange(false);

      // In a real app, this would redirect to the login page or home page
      setTimeout(() => {
        window.location.href = '/';
      }, 1500);
    }, 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl text-red-400 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Delete Account
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            This action cannot be undone. Your account will be permanently deleted.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-6">
          <div className="border border-red-500/30 rounded-lg p-4 bg-red-900/10 text-sm">
            <h4 className="text-red-400 font-medium mb-2">Warning</h4>
            <ul className="text-gray-300 space-y-2 list-disc pl-4">
              <li>All your study sets, flashcards, and notes will be deleted</li>
              <li>Your activity history and statistics will be lost</li>
              <li>You will lose access to any premium features</li>
              <li>This action is permanent and cannot be reversed</li>
            </ul>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm text-gray-300">
                Enter your password
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700/50 border-gray-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirm-text" className="text-sm text-gray-300">
                Type "{CONFIRM_TEXT}" to confirm
              </Label>
              <Input
                id="confirm-text"
                placeholder={CONFIRM_TEXT}
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="bg-gray-700/50 border-gray-600 text-white"
              />
              <p className="text-xs text-gray-400">
                This helps prevent accidental deletion
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDeleteAccount}
            disabled={!isValid || loading}
            className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                Deleting...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Trash2 size={16} />
                Delete Account
              </span>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
