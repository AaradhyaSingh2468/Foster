import type React from 'react';
import { motion } from 'framer-motion';
import { User, Settings, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { useToast } from '../../lib/useToast';

interface UserProfileDropdownProps {
  userInitial?: string;
  userImage?: string;
}

export const UserProfileDropdown: React.FC<UserProfileDropdownProps> = ({
  userInitial = 'F',
  userImage = 'https://github.com/shadcn.png'
}) => {
  const { toast } = useToast();

  const handleLogout = () => {
    // In a real app, this would call an API to log the user out
    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
      variant: "default",
      duration: 3000,
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="cursor-pointer"
        >
          <Avatar className="h-10 w-10 ring-2 ring-gray-700">
            <AvatarImage src={userImage} alt="User" />
            <AvatarFallback className="bg-purple-600 text-white">
              {userInitial}
            </AvatarFallback>
          </Avatar>
        </motion.div>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        <DropdownMenuSeparator />

        <Link to="/profile">
          <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
            <User size={16} />
            <span>View Profile</span>
          </DropdownMenuItem>
        </Link>

        <Link to="/account-settings">
          <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
            <Settings size={16} />
            <span>Account Settings</span>
          </DropdownMenuItem>
        </Link>

        <DropdownMenuSeparator />

        <DropdownMenuItem
          className="flex items-center gap-2 cursor-pointer text-red-400 focus:text-red-400"
          onClick={handleLogout}
        >
          <LogOut size={16} />
          <span>Logout</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
