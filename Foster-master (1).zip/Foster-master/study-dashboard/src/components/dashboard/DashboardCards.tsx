import type React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { motion } from 'framer-motion';
import { FiArrowRight, FiTarget, FiLock } from 'react-icons/fi';

// Upcoming Events Card
const UpcomingEventsCard: React.FC = () => {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Upcoming Events</CardTitle>
        <Button variant="ghost" size="sm" className="text-blue-600 font-medium">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center py-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="w-28 h-28 mb-4"
          >
            <img src="https://same-assets.com/iWJVPz1F4gjGI62tgZbp-IMG_8771.png" alt="Robot Illustration" className="w-full h-full" />
          </motion.div>
          <p className="text-gray-600 text-sm">No upcoming events</p>
        </div>
      </CardContent>
    </Card>
  );
};

// Study Set Progress Card
const StudySetProgressCard: React.FC = () => {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Study Set Progress</CardTitle>
        <Button variant="ghost" size="sm" className="text-blue-600 font-medium">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center flex-col py-6">
          <div className="w-full flex flex-col items-center">
            <div className="flex items-center justify-between w-full mb-2">
              <span className="text-sm font-medium text-gray-700">Mastered</span>
              <span className="text-sm font-medium text-gray-700">0%</span>
            </div>
            <motion.div
              className="w-full"
              initial={{ opacity: 0, scaleX: 0 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <Progress value={0} className="h-2" />
            </motion.div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Daily Objectives Card
const DailyObjectivesCard: React.FC = () => {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Daily Objectives</CardTitle>
        <Button variant="ghost" size="sm" className="text-blue-600 font-medium">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <motion.div
          className="flex items-center p-3 rounded-lg bg-gray-50 border border-gray-100 hover:bg-gray-100 transition-colors cursor-pointer mt-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="mr-4 bg-red-100 p-2 rounded-lg">
            <FiTarget className="text-red-600" size={20} />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-medium text-gray-800">Perfect Score on a Match Game</h4>
          </div>
          <div className="text-gray-600 text-sm font-medium">
            0 / 1
          </div>
        </motion.div>
      </CardContent>
    </Card>
  );
};

// Class Knowledge Card
const ClassKnowledgeCard: React.FC = () => {
  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Class Knowledge</CardTitle>
        <Button variant="ghost" size="sm" className="text-blue-600 font-medium">
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center py-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="w-24 h-24 mb-4 text-gray-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full">
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12" y2="16" />
            </svg>
          </motion.div>
          <p className="text-gray-700 text-sm font-medium">Enable Class Knowledge to unlock</p>
          <p className="text-gray-500 text-sm">collaborative insights</p>
        </div>
      </CardContent>
    </Card>
  );
};

// Main Dashboard Cards Container
const DashboardCards: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-10 staggered-animation">
      <UpcomingEventsCard />
      <StudySetProgressCard />
      <DailyObjectivesCard />
      <ClassKnowledgeCard />
    </div>
  );
};

export default DashboardCards;
