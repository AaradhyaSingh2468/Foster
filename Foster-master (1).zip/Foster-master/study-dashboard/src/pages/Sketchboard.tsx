import type React from 'react';
import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Brush, Eraser, Save, Trash2, Undo, Square, Circle, PenTool, Image, Download } from 'lucide-react';

interface Point {
  x: number;
  y: number;
}

interface DrawingElement {
  points: Point[];
  color: string;
  lineWidth: number;
  tool: 'pen' | 'eraser' | 'square' | 'circle';
}

const Sketchboard: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [context, setContext] = useState<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentTool, setCurrentTool] = useState<'pen' | 'eraser' | 'square' | 'circle'>('pen');
  const [currentColor, setCurrentColor] = useState('#ffffff');
  const [lineWidth, setLineWidth] = useState(3);
  const [elements, setElements] = useState<DrawingElement[]>([]);
  const [currentElement, setCurrentElement] = useState<DrawingElement | null>(null);
  const [history, setHistory] = useState<DrawingElement[][]>([]);

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    setContext(ctx);

    // Set canvas dimensions to match parent
    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.clientWidth;
        canvas.height = parent.clientHeight;
        redrawCanvas(ctx, elements);
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    return () => window.removeEventListener('resize', resizeCanvas);
  }, [elements]);

  // Redraw canvas with current elements
  const redrawCanvas = (ctx: CanvasRenderingContext2D, elements: DrawingElement[]) => {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    for (const element of elements) {
      ctx.strokeStyle = element.color;
      ctx.lineWidth = element.lineWidth;

      if (element.tool === 'pen' || element.tool === 'eraser') {
        if (element.points.length < 2) continue;

        ctx.beginPath();
        ctx.moveTo(element.points[0].x, element.points[0].y);

        for (let i = 1; i < element.points.length; i++) {
          ctx.lineTo(element.points[i].x, element.points[i].y);
        }

        if (element.tool === 'eraser') {
          ctx.globalCompositeOperation = 'destination-out';
          ctx.strokeStyle = 'rgba(0,0,0,1)';
        } else {
          ctx.globalCompositeOperation = 'source-over';
        }

        ctx.stroke();
        ctx.globalCompositeOperation = 'source-over';
      } else if (element.tool === 'square' && element.points.length === 2) {
        const [start, end] = element.points;
        const width = end.x - start.x;
        const height = end.y - start.y;

        ctx.strokeRect(start.x, start.y, width, height);
      } else if (element.tool === 'circle' && element.points.length === 2) {
        const [start, end] = element.points;
        const radius = Math.sqrt(
          (end.x - start.x) ** 2 + (end.y - start.y) ** 2
        );

        ctx.beginPath();
        ctx.arc(start.x, start.y, radius, 0, 2 * Math.PI);
        ctx.stroke();
      }
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!context) return;

    setIsDrawing(true);
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newElement: DrawingElement = {
      points: [{ x, y }],
      color: currentTool === 'eraser' ? '#000000' : currentColor,
      lineWidth,
      tool: currentTool,
    };

    setCurrentElement(newElement);
    setElements(prev => [...prev, newElement]);
    setHistory(prev => [...prev, elements]);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !context || !currentElement) return;

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (currentTool === 'pen' || currentTool === 'eraser') {
      const updatedElement = {
        ...currentElement,
        points: [...currentElement.points, { x, y }],
      };

      setCurrentElement(updatedElement);
      setElements(prev => [...prev.slice(0, -1), updatedElement]);

      context.strokeStyle = updatedElement.color;
      context.lineWidth = updatedElement.lineWidth;

      if (currentTool === 'eraser') {
        context.globalCompositeOperation = 'destination-out';
        context.strokeStyle = 'rgba(0,0,0,1)';
      } else {
        context.globalCompositeOperation = 'source-over';
      }

      context.beginPath();
      context.moveTo(updatedElement.points[updatedElement.points.length - 2].x, updatedElement.points[updatedElement.points.length - 2].y);
      context.lineTo(x, y);
      context.stroke();
      context.globalCompositeOperation = 'source-over';
    } else if (currentTool === 'square' || currentTool === 'circle') {
      const updatedElement = {
        ...currentElement,
        points: [currentElement.points[0], { x, y }],
      };

      setCurrentElement(updatedElement);
      setElements(prev => [...prev.slice(0, -1), updatedElement]);
      redrawCanvas(context, elements.slice(0, -1).concat(updatedElement));
    }
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
    setCurrentElement(null);
  };

  const handleUndo = () => {
    if (history.length === 0) return;

    const lastElements = history[history.length - 1];
    setElements(lastElements);
    setHistory(prev => prev.slice(0, -1));

    if (context) {
      redrawCanvas(context, lastElements);
    }
  };

  const handleClear = () => {
    setHistory(prev => [...prev, elements]);
    setElements([]);

    if (context) {
      context.clearRect(0, 0, context.canvas.width, context.canvas.height);
    }
  };

  const handleSave = () => {
    if (!canvasRef.current) return;

    const dataURL = canvasRef.current.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `sketchboard-${new Date().toISOString().slice(0, 10)}.png`;
    link.href = dataURL;
    link.click();
  };

  const colors = [
    '#ffffff', // White
    '#ff5555', // Red
    '#55ff55', // Green
    '#5555ff', // Blue
    '#ffff55', // Yellow
    '#ff55ff', // Magenta
    '#55ffff', // Cyan
    '#ff9955', // Orange
  ];

  return (
    <div className="flex flex-col h-full animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-6 text-purple-100">Sketchboard</h1>

      <div className="flex flex-col flex-1">
        <Card className="flex-1 bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm flex flex-col">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center">
              <span>Drawing Canvas</span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleUndo}
                  disabled={elements.length === 0 || history.length === 0}
                  className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                >
                  <Undo size={16} className="mr-1" /> Undo
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleClear}
                  className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                >
                  <Trash2 size={16} className="mr-1" /> Clear
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSave}
                  className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                >
                  <Download size={16} className="mr-1" /> Save
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-2 relative">
            <div className="absolute top-2 left-2 flex flex-col gap-2 p-2 bg-gray-900/80 rounded-lg backdrop-blur-sm z-10">
              <Button
                variant={currentTool === 'pen' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentTool('pen')}
                className={currentTool === 'pen' ? 'bg-purple-600' : 'bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700'}
              >
                <PenTool size={16} />
              </Button>
              <Button
                variant={currentTool === 'eraser' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentTool('eraser')}
                className={currentTool === 'eraser' ? 'bg-purple-600' : 'bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700'}
              >
                <Eraser size={16} />
              </Button>
              <Button
                variant={currentTool === 'square' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentTool('square')}
                className={currentTool === 'square' ? 'bg-purple-600' : 'bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700'}
              >
                <Square size={16} />
              </Button>
              <Button
                variant={currentTool === 'circle' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCurrentTool('circle')}
                className={currentTool === 'circle' ? 'bg-purple-600' : 'bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700'}
              >
                <Circle size={16} />
              </Button>
            </div>

            <div className="absolute top-2 right-2 flex flex-wrap gap-2 p-2 bg-gray-900/80 rounded-lg backdrop-blur-sm z-10 max-w-[150px]">
              {colors.map((color) => (
                <div
                  key={color}
                  className={`w-6 h-6 rounded-full cursor-pointer ${
                    currentColor === color ? 'ring-2 ring-white' : ''
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => setCurrentColor(color)}
                />
              ))}
              <div className="w-full mt-2">
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={lineWidth}
                  onChange={(e) => setLineWidth(Number.parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>

            <div className="w-full h-full bg-gray-900 rounded-lg overflow-hidden">
              <canvas
                ref={canvasRef}
                className="w-full h-full"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Sketchboard;
