import type React from 'react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { FileText, BookOpen, Settings, FileCheck, Plus } from 'lucide-react';

const ExamGeneration: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [examConfig, setExamConfig] = useState({
    subject: '',
    topic: '',
    difficultyLevel: 'moderate',
    questionsCount: 10,
    timeLimit: 30,
    examType: 'multiple-choice'
  });

  const handleInputChange = (field: string, value: string | number) => {
    setExamConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const steps = [
    {
      title: 'Select Subject',
      description: 'Choose the subject area for your exam',
      content: (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Subject</label>
            <Input
              value={examConfig.subject}
              onChange={(e) => handleInputChange('subject', e.target.value)}
              placeholder="E.g. Mathematics, Biology, History"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Topic</label>
            <Input
              value={examConfig.topic}
              onChange={(e) => handleInputChange('topic', e.target.value)}
              placeholder="E.g. Calculus, Cell Biology, World War II"
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
        </div>
      )
    },
    {
      title: 'Configure Exam',
      description: 'Set exam parameters',
      content: (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Difficulty Level</label>
            <div className="flex gap-2">
              {['beginner', 'moderate', 'advanced', 'expert'].map((level) => (
                <Button
                  key={level}
                  variant={examConfig.difficultyLevel === level ? "default" : "outline"}
                  className={examConfig.difficultyLevel === level
                    ? "bg-purple-600 text-white flex-1"
                    : "border-gray-700 text-white flex-1"}
                  onClick={() => handleInputChange('difficultyLevel', level)}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Number of Questions</label>
            <div className="flex gap-2">
              {[5, 10, 15, 20].map((count) => (
                <Button
                  key={count}
                  variant={examConfig.questionsCount === count ? "default" : "outline"}
                  className={examConfig.questionsCount === count
                    ? "bg-purple-600 text-white flex-1"
                    : "border-gray-700 text-white flex-1"}
                  onClick={() => handleInputChange('questionsCount', count)}
                >
                  {count}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Time Limit (minutes)</label>
            <div className="flex gap-2">
              {[15, 30, 45, 60].map((time) => (
                <Button
                  key={time}
                  variant={examConfig.timeLimit === time ? "default" : "outline"}
                  className={examConfig.timeLimit === time
                    ? "bg-purple-600 text-white flex-1"
                    : "border-gray-700 text-white flex-1"}
                  onClick={() => handleInputChange('timeLimit', time)}
                >
                  {time}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Exam Type',
      description: 'Choose the type of exam questions',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { id: 'multiple-choice', name: 'Multiple Choice', icon: <FileCheck className="h-8 w-8 mb-2 text-purple-400" /> },
              { id: 'true-false', name: 'True/False', icon: <FileCheck className="h-8 w-8 mb-2 text-indigo-400" /> },
              { id: 'short-answer', name: 'Short Answer', icon: <FileText className="h-8 w-8 mb-2 text-blue-400" /> },
              { id: 'essay', name: 'Essay Questions', icon: <FileText className="h-8 w-8 mb-2 text-teal-400" /> }
            ].map((type) => (
              <div
                key={type.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors flex flex-col items-center justify-center text-center ${
                  examConfig.examType === type.id
                    ? 'bg-purple-600/30 border-purple-600'
                    : 'bg-gray-700/30 border-gray-700 hover:bg-gray-700/50'
                }`}
                onClick={() => handleInputChange('examType', type.id)}
              >
                {type.icon}
                <h3 className="font-medium">{type.name}</h3>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      title: 'Review & Generate',
      description: 'Review your exam settings and generate',
      content: (
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-purple-300">Exam Summary</h3>
            <div className="rounded-lg bg-gray-700/30 p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-300">Subject:</span>
                <span className="font-medium">{examConfig.subject || 'Not specified'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Topic:</span>
                <span className="font-medium">{examConfig.topic || 'Not specified'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Difficulty:</span>
                <span className="font-medium">{examConfig.difficultyLevel.charAt(0).toUpperCase() + examConfig.difficultyLevel.slice(1)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Questions:</span>
                <span className="font-medium">{examConfig.questionsCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Time Limit:</span>
                <span className="font-medium">{examConfig.timeLimit} minutes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Exam Type:</span>
                <span className="font-medium">{examConfig.examType.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</span>
              </div>
            </div>
          </div>

          <Button className="w-full bg-purple-600 hover:bg-purple-700">
            Generate Exam
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Exam Generation</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="text-purple-400" size={18} />
                Exam Builder
              </CardTitle>
              <CardDescription className="text-gray-400">
                Follow the steps below
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <div
                    key={index}
                    className={`flex gap-3 cursor-pointer ${activeStep > index + 1 ? 'opacity-60' : ''}`}
                    onClick={() => setActiveStep(index + 1)}
                  >
                    <div className={`rounded-full h-6 w-6 flex items-center justify-center text-xs ${
                      activeStep === index + 1 ? 'bg-purple-600' : activeStep > index + 1 ? 'bg-green-600' : 'bg-gray-700'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className={`font-medium ${activeStep === index + 1 ? 'text-purple-300' : ''}`}>{step.title}</p>
                      <p className="text-xs text-gray-400">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle>
                {steps[activeStep - 1].title}
              </CardTitle>
              <CardDescription className="text-gray-400">
                {steps[activeStep - 1].description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {steps[activeStep - 1].content}

              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setActiveStep(prev => Math.max(prev - 1, 1))}
                  disabled={activeStep === 1}
                  className="border-gray-700 text-white"
                >
                  Previous
                </Button>
                <Button
                  onClick={() => setActiveStep(prev => Math.min(prev + 1, steps.length))}
                  disabled={activeStep === steps.length}
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="text-purple-400" size={18} />
                  Recent Exams
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { title: 'Mathematics Midterm', date: 'Apr 28, 2025', questions: 15, type: 'Multiple Choice' },
                    { title: 'Biology Quiz', date: 'Apr 25, 2025', questions: 10, type: 'True/False' },
                  ].map((exam, index) => (
                    <div key={index} className="p-4 border border-gray-700 rounded-lg flex justify-between items-center">
                      <div>
                        <h3 className="font-medium">{exam.title}</h3>
                        <div className="text-sm text-gray-400">{exam.date} • {exam.questions} questions</div>
                      </div>
                      <div className="text-sm text-gray-300">{exam.type}</div>
                    </div>
                  ))}

                  <Button variant="ghost" className="w-full border border-dashed border-gray-700 text-gray-400 py-6 hover:bg-gray-800/50">
                    <Plus size={16} className="mr-2" /> Create Custom Exam Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamGeneration;
