import type React from 'react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { PlusCircle, Edit2, Trash2, Check, X, RotateCw, ChevronLeft, ChevronRight } from 'lucide-react';

// Types
interface FlashCard {
  id: string;
  front: string;
  back: string;
}

interface Deck {
  id: string;
  title: string;
  description: string;
  cards: FlashCard[];
  stats: {
    totalCards: number;
    mastered: number;
    needReview: number;
    accuracy: number;
  };
}

// Sample decks
const sampleDecks: Deck[] = [
  {
    id: '1',
    title: 'React Fundamentals',
    description: 'Core concepts of React JS framework',
    cards: [
      { id: '101', front: 'What is React?', back: 'A JavaScript library for building user interfaces' },
      { id: '102', front: 'What is JSX?', back: 'A syntax extension for JavaScript that looks similar to HTML and makes it easier to write React elements' },
      { id: '103', front: 'What is a component?', back: 'A reusable piece of code that returns React elements describing what should appear on the screen' },
      { id: '104', front: 'What is state?', back: 'An object that determines how a component renders and behaves' },
      { id: '105', front: 'What are props?', back: 'Inputs to components that allow passing data from parent to child components' },
    ],
    stats: {
      totalCards: 5,
      mastered: 3,
      needReview: 2,
      accuracy: 80,
    },
  },
  {
    id: '2',
    title: 'JavaScript Array Methods',
    description: 'Common array methods and their usage',
    cards: [
      { id: '201', front: 'Array.map()', back: 'Creates a new array with the results of calling a function on every element in the array' },
      { id: '202', front: 'Array.filter()', back: 'Creates a new array with elements that pass the test implemented by the provided function' },
      { id: '203', front: 'Array.reduce()', back: 'Executes a reducer function on each element of the array, resulting in a single output value' },
    ],
    stats: {
      totalCards: 3,
      mastered: 1,
      needReview: 2,
      accuracy: 66,
    },
  },
];

const FlashCards: React.FC = () => {
  const [decks, setDecks] = useState<Deck[]>(sampleDecks);
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);
  const [mode, setMode] = useState<'browse' | 'learn' | 'quiz'>('browse');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [newDeckTitle, setNewDeckTitle] = useState('');
  const [newDeckDescription, setNewDeckDescription] = useState('');
  const [showNewDeckForm, setShowNewDeckForm] = useState(false);
  const [newCardFront, setNewCardFront] = useState('');
  const [newCardBack, setNewCardBack] = useState('');
  const [showNewCardForm, setShowNewCardForm] = useState(false);

  // Create new deck
  const handleCreateDeck = () => {
    if (!newDeckTitle) return;

    const newDeck: Deck = {
      id: `deck-${Date.now()}`,
      title: newDeckTitle,
      description: newDeckDescription,
      cards: [],
      stats: { totalCards: 0, mastered: 0, needReview: 0, accuracy: 0 },
    };

    setDecks([...decks, newDeck]);
    setNewDeckTitle('');
    setNewDeckDescription('');
    setShowNewDeckForm(false);
    setSelectedDeck(newDeck);
  };

  // Delete deck
  const handleDeleteDeck = (id: string) => {
    setDecks(decks.filter(deck => deck.id !== id));
    if (selectedDeck && selectedDeck.id === id) {
      setSelectedDeck(null);
      setMode('browse');
    }
  };

  // Add card to deck
  const handleAddCard = () => {
    if (!selectedDeck || !newCardFront || !newCardBack) return;

    const newCard: FlashCard = {
      id: `card-${Date.now()}`,
      front: newCardFront,
      back: newCardBack,
    };

    const updatedDeck = {
      ...selectedDeck,
      cards: [...selectedDeck.cards, newCard],
      stats: {
        ...selectedDeck.stats,
        totalCards: selectedDeck.stats.totalCards + 1,
        needReview: selectedDeck.stats.needReview + 1,
      },
    };

    setDecks(decks.map(deck => deck.id === selectedDeck.id ? updatedDeck : deck));
    setSelectedDeck(updatedDeck);
    setNewCardFront('');
    setNewCardBack('');
    setShowNewCardForm(false);
  };

  // Delete card from deck
  const handleDeleteCard = (cardId: string) => {
    if (!selectedDeck) return;

    const updatedCards = selectedDeck.cards.filter(card => card.id !== cardId);
    const updatedDeck = {
      ...selectedDeck,
      cards: updatedCards,
      stats: {
        ...selectedDeck.stats,
        totalCards: updatedCards.length,
        needReview: Math.max(0, selectedDeck.stats.needReview - 1),
      },
    };

    setDecks(decks.map(deck => deck.id === selectedDeck.id ? updatedDeck : deck));
    setSelectedDeck(updatedDeck);
  };

  // Select a deck
  const handleSelectDeck = (deck: Deck) => {
    setSelectedDeck(deck);
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };

  // Go to learning mode
  const handleStartLearning = () => {
    if (!selectedDeck || selectedDeck.cards.length === 0) return;
    setMode('learn');
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };

  // Handle card navigation
  const handleNextCard = () => {
    if (!selectedDeck) return;

    if (currentCardIndex < selectedDeck.cards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setShowAnswer(false);
    } else {
      // End of deck
      setMode('browse');
      setShowAnswer(false);
    }
  };

  const handlePrevCard = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1);
      setShowAnswer(false);
    }
  };

  // Mark card correct/incorrect
  const handleMarkCard = (correct: boolean) => {
    if (!selectedDeck) return;

    // In a real app, you would update mastery/accuracy in your database
    // Here we just move to the next card
    const updatedStats = { ...selectedDeck.stats };
    if (correct) {
      updatedStats.mastered += 1;
      updatedStats.needReview -= 1;
      updatedStats.accuracy = (updatedStats.mastered / updatedStats.totalCards) * 100;
    }

    const updatedDeck = {
      ...selectedDeck,
      stats: updatedStats,
    };

    setDecks(decks.map(deck => deck.id === selectedDeck.id ? updatedDeck : deck));
    setSelectedDeck(updatedDeck);

    handleNextCard();
  };

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Flashcards</h1>

      {mode === 'browse' && (
        <div className="space-y-6">
          {/* Deck Management Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-white">Your Flashcard Decks</h2>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowNewDeckForm(true)}
              className="bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-md flex items-center gap-2"
            >
              <PlusCircle size={18} />
              Create Deck
            </motion.button>
          </div>

          {/* New Deck Form */}
          <AnimatePresence>
            {showNewDeckForm && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-lg p-4 mb-6"
              >
                <h3 className="text-lg font-medium mb-4 text-white">Create New Deck</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-1">Deck Title</label>
                    <Input
                      value={newDeckTitle}
                      onChange={(e) => setNewDeckTitle(e.target.value)}
                      placeholder="Enter deck title"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-1">Description</label>
                    <Input
                      value={newDeckDescription}
                      onChange={(e) => setNewDeckDescription(e.target.value)}
                      placeholder="Enter deck description"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="flex space-x-3">
                    <Button variant="default" onClick={handleCreateDeck} className="bg-purple-600 hover:bg-purple-700">
                      Create
                    </Button>
                    <Button variant="outline" onClick={() => setShowNewDeckForm(false)} className="border-gray-600 text-white">
                      Cancel
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Deck Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {decks.map((deck) => (
              <motion.div
                key={deck.id}
                whileHover={{ scale: 1.02 }}
                className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-lg overflow-hidden"
              >
                <div
                  className="cursor-pointer"
                  onClick={() => handleSelectDeck(deck)}
                >
                  <div className="p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-white">{deck.title}</h3>
                    <p className="text-gray-400 text-sm mt-1">{deck.description}</p>
                  </div>
                  <div className="p-4">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-purple-400">{deck.stats.totalCards}</div>
                        <div className="text-xs text-gray-400">Total Cards</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-green-400">{deck.stats.mastered}</div>
                        <div className="text-xs text-gray-400">Mastered</div>
                      </div>
                    </div>
                    <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-500"
                        style={{ width: `${deck.stats.accuracy}%` }}
                      />
                    </div>
                    <div className="text-xs text-gray-400 mt-1 text-center">
                      {deck.stats.accuracy}% Accuracy
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-gray-800 border-t border-gray-700 flex justify-between">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteDeck(deck.id)}
                    className="text-gray-400 hover:text-white hover:bg-red-500/20"
                  >
                    <Trash2 size={16} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      handleSelectDeck(deck);
                      handleStartLearning();
                    }}
                    className="text-blue-400 hover:text-blue-300"
                  >
                    Study Now
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Deck Detail View */}
      {mode === 'browse' && selectedDeck && (
        <div className="mt-8 space-y-6">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              className="border-gray-700 text-white"
              onClick={() => setSelectedDeck(null)}
            >
              <ChevronLeft size={16} className="mr-2" /> Back to Decks
            </Button>
            <Button
              variant="default"
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleStartLearning}
              disabled={selectedDeck.cards.length === 0}
            >
              Start Learning
            </Button>
          </div>

          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{selectedDeck.title}</CardTitle>
                <Button
                  variant="outline"
                  className="border-gray-700 text-white"
                  onClick={() => setShowNewCardForm(true)}
                >
                  <PlusCircle size={16} className="mr-2" /> Add Card
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-6">{selectedDeck.description}</p>

              {/* New Card Form */}
              <AnimatePresence>
                {showNewCardForm && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-gray-700/50 rounded-lg p-4 mb-6"
                  >
                    <h3 className="text-lg font-medium mb-4">Add New Card</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-gray-300 block mb-1">Front</label>
                        <Input
                          value={newCardFront}
                          onChange={(e) => setNewCardFront(e.target.value)}
                          placeholder="Question or term"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-300 block mb-1">Back</label>
                        <Input
                          value={newCardBack}
                          onChange={(e) => setNewCardBack(e.target.value)}
                          placeholder="Answer or definition"
                          className="bg-gray-700 border-gray-600 text-white"
                        />
                      </div>
                      <div className="flex space-x-3">
                        <Button variant="default" onClick={handleAddCard} className="bg-purple-600 hover:bg-purple-700">
                          Add Card
                        </Button>
                        <Button variant="outline" onClick={() => setShowNewCardForm(false)} className="border-gray-600 text-white">
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Cards List */}
              {selectedDeck.cards.length > 0 ? (
                <div className="space-y-3">
                  {selectedDeck.cards.map((card, index) => (
                    <div
                      key={card.id}
                      className="p-4 bg-gray-700/50 rounded-lg flex justify-between"
                    >
                      <div>
                        <p className="font-medium">{card.front}</p>
                        <p className="text-gray-400 text-sm mt-1">{card.back}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteCard(card.id)}
                        className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-red-500/20"
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <p>No cards in this deck yet. Add some cards to start learning!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Learning Mode */}
      {mode === 'learn' && selectedDeck && selectedDeck.cards.length > 0 && (
        <div className="mt-4">
          <div className="flex justify-between items-center mb-6">
            <Button
              variant="outline"
              className="border-gray-700 text-white"
              onClick={() => setMode('browse')}
            >
              <ChevronLeft size={16} className="mr-2" /> Back to Deck
            </Button>
            <div className="text-gray-300">
              Card {currentCardIndex + 1} of {selectedDeck.cards.length}
            </div>
          </div>

          <div className="flex flex-col items-center">
            <motion.div
              key={`card-${currentCardIndex}-${showAnswer ? 'back' : 'front'}`}
              initial={{ rotateY: showAnswer ? -90 : 0 }}
              animate={{ rotateY: showAnswer ? 0 : 0 }}
              exit={{ rotateY: showAnswer ? 0 : 90 }}
              transition={{ duration: 0.4 }}
              className="w-full max-w-xl perspective-1000"
            >
              <div
                className="bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-lg p-8 h-64 flex flex-col items-center justify-center text-center cursor-pointer transform-style-3d"
                onClick={() => setShowAnswer(!showAnswer)}
              >
                <div className="absolute top-2 right-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 text-gray-400"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowAnswer(!showAnswer);
                    }}
                  >
                    <RotateCw size={16} />
                  </Button>
                </div>

                <div className="text-xs text-gray-400 uppercase tracking-wider mb-3">
                  {showAnswer ? 'ANSWER' : 'QUESTION'}
                </div>

                <h3 className="text-2xl font-semibold text-white mb-4">
                  {showAnswer ? selectedDeck.cards[currentCardIndex].back : selectedDeck.cards[currentCardIndex].front}
                </h3>

                <p className="text-gray-400 text-sm mt-auto">
                  {showAnswer ? 'Click to see question' : 'Click to see answer'}
                </p>
              </div>
            </motion.div>

            {/* Navigation and Rating Buttons */}
            <div className="mt-6 flex justify-between w-full max-w-xl">
              <Button
                variant="outline"
                className="border-gray-700 text-white"
                onClick={handlePrevCard}
                disabled={currentCardIndex === 0}
              >
                <ChevronLeft size={16} className="mr-2" /> Previous
              </Button>

              {showAnswer && (
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="border-red-700/50 text-red-400 hover:bg-red-700/20"
                    onClick={() => handleMarkCard(false)}
                  >
                    <X size={16} className="mr-2" /> Incorrect
                  </Button>
                  <Button
                    variant="outline"
                    className="border-green-700/50 text-green-400 hover:bg-green-700/20"
                    onClick={() => handleMarkCard(true)}
                  >
                    <Check size={16} className="mr-2" /> Correct
                  </Button>
                </div>
              )}

              <Button
                variant="outline"
                className="border-gray-700 text-white"
                onClick={handleNextCard}
                disabled={currentCardIndex === selectedDeck.cards.length - 1}
              >
                Next <ChevronRight size={16} className="ml-2" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FlashCards;
