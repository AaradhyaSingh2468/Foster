import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { SendHorizonal, Smile, Paperclip, Bot, User, Image } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const Chat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your AI study assistant. How can I help you today?',
      sender: 'ai',
      timestamp: new Date(Date.now() - 60000),
    },
  ]);

  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response after a short delay
    setTimeout(() => {
      const responses = [
        "I can help you with that! Let me find some resources for you.",
        "Great question! Here's what I know about that topic.",
        "Would you like me to create some flashcards for this subject?",
        "I've analyzed your study patterns. For better retention, try reviewing this material again tomorrow.",
        "Based on your progress, you might want to focus more on this topic before your upcoming test."
      ];

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: responses[Math.floor(Math.random() * responses.length)],
        sender: 'ai',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h1 className="text-3xl font-bold mb-6 text-purple-100">Chat with AI Assistant</h1>

      <div className="flex-1 flex gap-4">
        <div className="flex-1">
          <Card className="h-full flex flex-col bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader className="pb-3 border-b border-gray-700">
              <CardTitle className="flex items-center text-lg">
                <Bot className="mr-2 text-purple-400" size={20} />
                AI Study Assistant
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                      message.sender === 'user'
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-700 text-white'
                    }`}
                  >
                    <div className="flex items-center mb-1">
                      {message.sender === 'ai' ? (
                        <Bot size={16} className="mr-2 text-purple-400" />
                      ) : (
                        <User size={16} className="mr-2 text-white" />
                      )}
                      <span className="text-xs text-gray-300">
                        {message.sender === 'ai' ? 'AI Assistant' : 'You'} • {' '}
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                </motion.div>
              ))}
            </CardContent>

            <div className="p-4 border-t border-gray-700">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message here..."
                  className="bg-gray-700 border-gray-600 text-white"
                />
                <Button
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim()}
                >
                  <SendHorizonal size={18} />
                </Button>
              </div>
              <div className="flex justify-between mt-2">
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    <Paperclip size={16} />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    <Image size={16} />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
                    <Smile size={16} />
                  </Button>
                </div>
                <div className="text-xs text-gray-500">
                  Powered by AI
                </div>
              </div>
            </div>
          </Card>
        </div>

        <div className="w-72">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-sm font-medium">Chat Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">AI Knowledge</h3>
                  <div className="text-xs text-gray-400">
                    AI has access to your study materials, notes, and learning progress to provide personalized assistance.
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Question Suggestions</h3>
                  <div className="space-y-2">
                    {[
                      "Help me prepare for my upcoming test",
                      "Create flashcards from my notes",
                      "Explain this concept in simpler terms",
                      "What should I focus on studying today?",
                    ].map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start text-xs border-gray-700 text-gray-300 hover:bg-gray-700"
                        onClick={() => {
                          setInputValue(suggestion);
                        }}
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Chat;
