import type React from 'react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Video, Upload, Play, Settings, Clock, Film, Rocket, Download, Edit } from 'lucide-react';

const VideoGeneration: React.FC = () => {
  const [videoConfig, setVideoConfig] = useState({
    title: '',
    topic: '',
    duration: '2-5',
    style: 'educational',
    format: '16:9',
    quality: 'high',
  });

  const [generating, setGenerating] = useState(false);
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);

  const handleInputChange = (field: string, value: string) => {
    setVideoConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleGenerate = () => {
    if (!videoConfig.title || !videoConfig.topic) return;

    setGenerating(true);

    // Simulate video generation
    setTimeout(() => {
      setGenerating(false);
      setGeneratedVideo('https://ext.same-assets.com/2129740578/849522504.webp');
    }, 3000);
  };

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Video Generation</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="text-purple-400" size={20} />
                Video Generator
              </CardTitle>
              <CardDescription className="text-gray-400">
                Generate educational videos from your study materials
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Title</label>
                    <Input
                      value={videoConfig.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                      placeholder="Enter video title"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Topic/Subject</label>
                    <Input
                      value={videoConfig.topic}
                      onChange={(e) => handleInputChange('topic', e.target.value)}
                      placeholder="E.g. Photosynthesis, World War II, Algebra"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Duration</label>
                    <div className="flex flex-col gap-2">
                      {['1-2', '2-5', '5-10', '10+'].map((duration) => (
                        <Button
                          key={duration}
                          variant={videoConfig.duration === duration ? "default" : "outline"}
                          className={videoConfig.duration === duration
                            ? "bg-purple-600 text-white justify-start"
                            : "border-gray-700 text-white justify-start"}
                          onClick={() => handleInputChange('duration', duration)}
                        >
                          <Clock size={16} className="mr-2" />
                          {duration} minutes
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Style</label>
                    <div className="flex flex-col gap-2">
                      {[
                        { id: 'educational', label: 'Educational', icon: <Film size={16} /> },
                        { id: 'animated', label: 'Animated', icon: <Film size={16} /> },
                        { id: 'presentation', label: 'Presentation', icon: <Film size={16} /> },
                        { id: 'documentary', label: 'Documentary', icon: <Film size={16} /> },
                      ].map((style) => (
                        <Button
                          key={style.id}
                          variant={videoConfig.style === style.id ? "default" : "outline"}
                          className={videoConfig.style === style.id
                            ? "bg-purple-600 text-white justify-start"
                            : "border-gray-700 text-white justify-start"}
                          onClick={() => handleInputChange('style', style.id)}
                        >
                          {style.icon}
                          <span className="ml-2">{style.label}</span>
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Format & Quality</label>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        {['16:9', '4:3', '1:1', '9:16'].map((format) => (
                          <Button
                            key={format}
                            variant={videoConfig.format === format ? "default" : "outline"}
                            size="sm"
                            className={videoConfig.format === format
                              ? "bg-purple-600 text-white flex-1"
                              : "border-gray-700 text-white flex-1"}
                            onClick={() => handleInputChange('format', format)}
                          >
                            {format}
                          </Button>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        {[
                          { id: 'standard', label: 'Standard', quality: '720p' },
                          { id: 'high', label: 'High', quality: '1080p' },
                          { id: 'ultra', label: 'Ultra', quality: '4K' },
                        ].map((quality) => (
                          <Button
                            key={quality.id}
                            variant={videoConfig.quality === quality.id ? "default" : "outline"}
                            size="sm"
                            className={videoConfig.quality === quality.id
                              ? "bg-purple-600 text-white flex-1"
                              : "border-gray-700 text-white flex-1"}
                            onClick={() => handleInputChange('quality', quality.id)}
                          >
                            {quality.label} ({quality.quality})
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-700">
                  <Button
                    className="w-full bg-purple-600 hover:bg-purple-700 py-6 text-white"
                    onClick={handleGenerate}
                    disabled={generating || !videoConfig.title || !videoConfig.topic}
                  >
                    {generating ? (
                      <>
                        <div className="animate-spin mr-2">
                          <Settings size={18} />
                        </div>
                        Generating Video...
                      </>
                    ) : (
                      <>
                        <Rocket size={18} className="mr-2" />
                        Generate Video
                      </>
                    )}
                  </Button>
                </div>

                {generatedVideo && !generating && (
                  <div className="pt-4 space-y-4">
                    <div className="w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center relative">
                      <img
                        src={generatedVideo}
                        alt="Generated Video Thumbnail"
                        className="w-full h-full object-contain"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="rounded-full bg-black/50 w-16 h-16 flex items-center justify-center cursor-pointer hover:bg-black/70 transition-colors">
                          <Play size={30} className="text-white ml-1" />
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-gray-700 text-white hover:bg-gray-600">
                        <Edit size={16} className="mr-2" />
                        Edit Video
                      </Button>
                      <Button className="flex-1 bg-green-600 text-white hover:bg-green-700">
                        <Download size={16} className="mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="text-purple-400" size={18} />
                Advanced Options
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Upload Material</label>
                  <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:border-purple-500 transition-colors">
                    <Upload className="mb-2 text-gray-400" size={24} />
                    <p className="text-sm text-gray-400">Upload PDF, PowerPoint, or Notes</p>
                    <p className="text-xs text-gray-500 mt-1">Max. file size: 50MB</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Custom Voice</label>
                  <div className="space-y-2">
                    {[
                      { id: 'default', name: 'AI Default', desc: 'Standard AI voice' },
                      { id: 'professional', name: 'Professional', desc: 'Clear, authoritative tone' },
                      { id: 'friendly', name: 'Friendly Tutor', desc: 'Casual, approachable tone' },
                    ].map((voice) => (
                      <div key={voice.id} className="flex items-center p-2 border border-gray-700 rounded-lg">
                        <input
                          type="radio"
                          id={voice.id}
                          name="voice"
                          className="mr-3"
                          defaultChecked={voice.id === 'default'}
                        />
                        <label htmlFor={voice.id} className="flex-1 cursor-pointer">
                          <div className="font-medium text-sm">{voice.name}</div>
                          <div className="text-xs text-gray-400">{voice.desc}</div>
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Recent Videos</h3>
                  <div className="space-y-3">
                    {[
                      { title: 'Introduction to Biology', date: 'Apr 28, 2025', duration: '4:32' },
                      { title: 'Calculus Basics', date: 'Apr 26, 2025', duration: '7:15' },
                    ].map((video, index) => (
                      <div key={video.title} className="flex gap-3 p-2 hover:bg-gray-700/30 rounded-lg cursor-pointer">
                        <div className="w-16 h-10 bg-gray-700 rounded-md flex items-center justify-center">
                          <Play size={14} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{video.title}</h4>
                          <div className="flex text-xs text-gray-400 mt-1">
                            <span>{video.date}</span>
                            <span className="mx-1">•</span>
                            <span>{video.duration}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default VideoGeneration;
