import { format, parse, startOfWeek, getDay, addMinutes } from 'date-fns';
import { enUS } from 'date-fns/locale/en-US';
import { Calendar, dateFnsLocalizer, Views, type SlotInfo } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { PlusCircle, Edit2, Trash2, Bell, BellOff, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const locales = {
  'en-US': enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

type CalendarView = 'month' | 'week' | 'day' | 'agenda' | 'work_week';

interface Event {
  id: number;
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
  desc?: string;
  reminder?: boolean;
  reminderTime?: Date;
}

interface ReminderPopupProps {
  event: Event;
  onClose: () => void;
}

const ReminderPopup: React.FC<ReminderPopupProps> = ({ event, onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="fixed bottom-6 right-6 p-6 bg-purple-800/90 rounded-lg shadow-lg max-w-md text-white z-50 backdrop-blur-sm border border-purple-700"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2">
          <Bell className="text-yellow-300" size={20} />
          <h3 className="text-lg font-bold">Reminder</h3>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0 text-gray-300 hover:text-white hover:bg-purple-700/50"
          onClick={onClose}
        >
          <X size={18} />
        </Button>
      </div>
      <h4 className="text-xl font-semibold mb-2">{event.title}</h4>
      <p className="text-gray-200 mb-3">
        {format(event.start, 'PPPP')} at {format(event.start, 'p')}
      </p>
      {event.desc && (
        <p className="text-gray-200 mb-4 border-l-2 border-purple-500 pl-3 italic">
          {event.desc}
        </p>
      )}
      <div className="flex justify-end mt-4">
        <Button
          className="bg-purple-600 hover:bg-purple-700 text-white"
          onClick={onClose}
        >
          Dismiss
        </Button>
      </div>
    </motion.div>
  );
};

const CalendarPage = () => {
  const [myEvents, setMyEvents] = useState<Event[]>([
    {
      id: 0,
      title: 'Study Session',
      start: new Date(2025, 3, 28, 10, 0), // April 28, 2025 at 10:00 AM
      end: new Date(2025, 3, 28, 12, 0),   // April 28, 2025 at 12:00 PM
      desc: 'Prepare for the upcoming test on React fundamentals',
      reminder: true,
      reminderTime: new Date(2025, 3, 28, 9, 45),
    },
    {
      id: 1,
      title: 'Group Project Meeting',
      start: new Date(2025, 3, 30, 14, 0), // April 30, 2025 at 2:00 PM
      end: new Date(2025, 3, 30, 15, 30),  // April 30, 2025 at 3:30 PM
      desc: 'Discuss progress on the term project with the team',
      reminder: false,
    },
  ]);

  const [view, setView] = useState<CalendarView>('month');
  const [date, setDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showEventForm, setShowEventForm] = useState(false);
  const [eventFormMode, setEventFormMode] = useState<'add' | 'edit'>('add');
  const [newEvent, setNewEvent] = useState<Omit<Event, 'id'>>({
    title: '',
    start: new Date(),
    end: addMinutes(new Date(), 60),
    desc: '',
    reminder: false,
  });
  const [showReminder, setShowReminder] = useState<Event | null>(null);

  // Ensure reminders don't reappear once dismissed
  React.useEffect(() => {
    const now = new Date();
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');

    const currentReminder = myEvents.find(
      event =>
        event.reminder &&
        event.reminderTime &&
        Math.abs(event.reminderTime.getTime() - now.getTime()) < 5 * 60 * 1000 && // Within 5 minutes
        !dismissedReminders.includes(event.id.toString()) // Not previously dismissed
    );

    if (currentReminder && !showReminder) {
      setShowReminder(currentReminder);
    }

    // In a real app, you would set up a proper timer instead of this demo code
    const timer = setTimeout(() => {
      if (!showReminder && myEvents.some(e => e.reminder)) {
        // For demo purposes, just show a random reminder after 10 seconds
        const eventsWithReminders = myEvents.filter(e =>
          e.reminder && !dismissedReminders.includes(e.id.toString())
        );

        if (eventsWithReminders.length > 0) {
          setShowReminder(eventsWithReminders[0]);
        }
      }
    }, 10000);

    return () => clearTimeout(timer);
  }, [myEvents, showReminder]);

  // Function to dismiss a reminder and remember the dismissal
  const handleDismissReminder = (event: Event) => {
    // Get currently dismissed reminders
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');

    // Add this event ID to the list if not already present
    if (!dismissedReminders.includes(event.id.toString())) {
      dismissedReminders.push(event.id.toString());
    }

    // Save updated list
    localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));

    // Close the reminder
    setShowReminder(null);
  };

  const handleSelectEvent = (event: Event) => {
    setSelectedEvent(event);
    setShowEventForm(false);
  };

  const handleSelectSlot = (slotInfo: SlotInfo) => {
    setNewEvent({
      title: '',
      start: slotInfo.start,
      end: slotInfo.end,
      desc: '',
      reminder: false,
    });
    setEventFormMode('add');
    setShowEventForm(true);
    setSelectedEvent(null);
  };

  const handleAddEvent = () => {
    if (!newEvent.title) return;

    const eventToAdd: Event = {
      ...newEvent,
      id: myEvents.length ? Math.max(...myEvents.map(e => e.id)) + 1 : 0,
      reminderTime: newEvent.reminder ? new Date(newEvent.start.getTime() - 15 * 60 * 1000) : undefined, // 15 minutes before
    };

    setMyEvents([...myEvents, eventToAdd]);
    setShowEventForm(false);
    setNewEvent({
      title: '',
      start: new Date(),
      end: addMinutes(new Date(), 60),
      desc: '',
      reminder: false,
    });

    // Remove from dismissedReminders if the event was previously dismissed (edge case if re-adding)
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
    const idx = dismissedReminders.indexOf(eventToAdd.id.toString());
    if (idx !== -1) {
      dismissedReminders.splice(idx, 1);
      localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
    }
  };

  const handleUpdateEvent = () => {
    if (!selectedEvent || !newEvent.title) return;

    const updatedEvent: Event = {
      ...newEvent,
      id: selectedEvent.id,
      reminderTime: newEvent.reminder ? new Date(newEvent.start.getTime() - 15 * 60 * 1000) : undefined,
    };

    setMyEvents(myEvents.map(event => event.id === selectedEvent.id ? updatedEvent : event));
    setShowEventForm(false);
    setSelectedEvent(updatedEvent);

    // If reminder is re-enabled, remove from dismissedReminders so it can show again
    if (updatedEvent.reminder) {
      const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
      const idx = dismissedReminders.indexOf(updatedEvent.id.toString());
      if (idx !== -1) {
        dismissedReminders.splice(idx, 1);
        localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
      }
    } else {
      // If reminder is turned off, dismiss it
      handleDismissReminder(updatedEvent);
    }
  };

  const handleDeleteEvent = (id: number) => {
    setMyEvents(myEvents.filter(event => event.id !== id));
    setSelectedEvent(null);
    setShowEventForm(false);

    // Remove from dismissedReminders if deleted
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
    const idx = dismissedReminders.indexOf(id.toString());
    if (idx !== -1) {
      dismissedReminders.splice(idx, 1);
      localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
    }
  };

  const handleEditEvent = (event: Event) => {
    setSelectedEvent(event);
    setNewEvent({
      title: event.title,
      start: event.start,
      end: event.end,
      desc: event.desc || '',
      reminder: event.reminder || false,
    });
    setEventFormMode('edit');
    setShowEventForm(true);
  };

  const toggleEventReminder = (id: number) => {
    setMyEvents(myEvents.map(event => {
      if (event.id === id) {
        const updatedEvent = {
          ...event,
          reminder: !event.reminder,
          reminderTime: !event.reminder ? new Date(event.start.getTime() - 15 * 60 * 1000) : undefined,
        };
        if (selectedEvent && selectedEvent.id === id) {
          setSelectedEvent(updatedEvent);
        }
        // If enabling reminder, remove from dismissedReminders; if disabling, add to dismissedReminders
        const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
        if (updatedEvent.reminder) {
          const idx = dismissedReminders.indexOf(updatedEvent.id.toString());
          if (idx !== -1) {
            dismissedReminders.splice(idx, 1);
            localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
          }
        } else {
          if (!dismissedReminders.includes(updatedEvent.id.toString())) {
            dismissedReminders.push(updatedEvent.id.toString());
            localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
          }
        }
        return updatedEvent;
      }
      return event;
    }));
  };

  return (
    <div className="animate-fade-in p-2">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Calendar</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Calendar */}
        <Card className="lg:col-span-3 bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Schedule</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('month')}
              >
                Month
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('week')}
              >
                Week
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('day')}
              >
                Day
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('agenda')}
              >
                Agenda
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[600px] calendar-container">
              <style>{`
                .rbc-calendar {
                  background-color: rgba(31, 41, 55, 0.4);
                  border-radius: 0.5rem;
                  padding: 1rem;
                  color: white;
                }
                .rbc-toolbar button {
                  color: white;
                  background-color: rgba(31, 41, 55, 0.7);
                }
                .rbc-toolbar button:hover {
                  background-color: rgba(67, 56, 202, 0.7);
                }
                .rbc-toolbar button.rbc-active {
                  background-color: rgba(67, 56, 202, 0.9);
                }
                .rbc-header {
                  background-color: rgba(31, 41, 55, 0.7);
                  padding: 0.5rem;
                }
                .rbc-date-cell {
                  color: rgba(255, 255, 255, 0.8);
                }
                .rbc-off-range-bg {
                  background-color: rgba(31, 41, 55, 0.4);
                }
                .rbc-event {
                  background-color: rgba(79, 70, 229, 0.8);
                }
                .rbc-today {
                  background-color: rgba(79, 70, 229, 0.2);
                }
              `}</style>
              <Calendar
                localizer={localizer}
                events={myEvents}
                startAccessor="start"
                endAccessor="end"
                style={{ height: '100%' }}
                views={['month', 'week', 'day', 'agenda']}
                view={view}
                date={date}
                onNavigate={setDate}
                onView={setView}
                onSelectEvent={handleSelectEvent}
                onSelectSlot={handleSelectSlot}
                selectable
                eventPropGetter={(event) => ({
                  style: {
                    backgroundColor: event.reminder
                      ? 'rgba(139, 92, 246, 0.9)'
                      : 'rgba(67, 56, 202, 0.7)',
                    borderRadius: '4px',
                    border: event.reminder
                      ? '2px solid rgba(250, 204, 21, 0.7)'
                      : 'none',
                    color: 'white',
                  },
                })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sidebar with event details and controls */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium">{showEventForm ? (eventFormMode === 'add' ? 'Add Event' : 'Edit Event') : 'Event Details'}</CardTitle>
          </CardHeader>
          <CardContent>
            {showEventForm ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Title</label>
                  <Input
                    value={newEvent.title}
                    onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Event title"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Start Date & Time</label>
                  <Input
                    type="datetime-local"
                    value={format(newEvent.start, "yyyy-MM-dd'T'HH:mm")}
                    onChange={(e) => {
                      const start = new Date(e.target.value);
                      setNewEvent({
                        ...newEvent,
                        start,
                        end: new Date(Math.max(start.getTime(), newEvent.end.getTime()))
                      });
                    }}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">End Date & Time</label>
                  <Input
                    type="datetime-local"
                    value={format(newEvent.end, "yyyy-MM-dd'T'HH:mm")}
                    onChange={(e) => {
                      const end = new Date(e.target.value);
                      setNewEvent({
                        ...newEvent,
                        end
                      });
                    }}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Description</label>
                  <Input
                    value={newEvent.desc}
                    onChange={(e) => setNewEvent({...newEvent, desc: e.target.value})}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Event description"
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="reminder"
                    checked={newEvent.reminder}
                    onChange={(e) => setNewEvent({...newEvent, reminder: e.target.checked})}
                    className="mr-2"
                  />
                  <label htmlFor="reminder" className="text-sm text-gray-300">Set reminder (15 min before)</label>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={eventFormMode === 'add' ? handleAddEvent : handleUpdateEvent}
                    className="flex-1 bg-purple-600 text-white hover:bg-purple-700"
                  >
                    {eventFormMode === 'add' ? 'Add Event' : 'Update Event'}
                  </Button>
                  <Button
                    onClick={() => {
                      setShowEventForm(false);
                      if (eventFormMode === 'edit' && selectedEvent) {
                        setSelectedEvent(selectedEvent);
                      }
                    }}
                    variant="outline"
                    className="flex-1 bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : selectedEvent ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">{selectedEvent.title}</h3>

                <div className="space-y-1">
                  <p className="text-sm text-gray-300">Start:</p>
                  <p className="text-sm text-white">{format(selectedEvent.start, 'PPpp')}</p>
                </div>

                <div className="space-y-1">
                  <p className="text-sm text-gray-300">End:</p>
                  <p className="text-sm text-white">{format(selectedEvent.end, 'PPpp')}</p>
                </div>

                {selectedEvent.desc && (
                  <div className="space-y-1">
                    <p className="text-sm text-gray-300">Description:</p>
                    <p className="text-sm text-white">{selectedEvent.desc}</p>
                  </div>
                )}

                <div className="flex items-center justify-between px-2 py-3 bg-gray-700/30 rounded-md">
                  <span className="text-sm">Reminder</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleEventReminder(selectedEvent.id)}
                    className={`h-8 w-8 p-0 ${selectedEvent.reminder ? 'text-yellow-400' : 'text-gray-400'}`}
                  >
                    {selectedEvent.reminder ? <Bell size={16} /> : <BellOff size={16} />}
                  </Button>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={() => handleEditEvent(selectedEvent)}
                    variant="outline"
                    className="flex-1 bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                  >
                    <Edit2 size={16} className="mr-2" /> Edit
                  </Button>
                  <Button
                    onClick={() => handleDeleteEvent(selectedEvent.id)}
                    variant="destructive"
                    className="flex-1"
                  >
                    <Trash2 size={16} className="mr-2" /> Delete
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    setNewEvent({
                      title: '',
                      start: new Date(),
                      end: addMinutes(new Date(), 60),
                      desc: '',
                      reminder: false,
                    });
                    setEventFormMode('add');
                    setShowEventForm(true);
                  }}
                  className="w-full mb-6 py-2 bg-purple-600 text-white rounded-lg font-medium text-sm flex items-center justify-center gap-2"
                >
                  <PlusCircle size={18} />
                  <span>Add New Event</span>
                </motion.button>

                <div className="text-center py-8 text-gray-400">
                  <p>Select an event to view details</p>
                  <p className="mt-2 text-xs">or click on the calendar to create a new event</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Reminder Popup */}
      <AnimatePresence>
        {showReminder && (
          <ReminderPopup
            event={showReminder}
            onClose={() => handleDismissReminder(showReminder)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default CalendarPage;
