import type React from 'react';
import { useState } from 'react';
import {
  BarChart, Bar, PieChart, Pie, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, Cell, AreaChart, Area
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { motion, AnimatePresence } from 'framer-motion';

// Sample data for the charts
const studyTimeData = [
  { name: 'Monday', time: 2.5 },
  { name: 'Tuesday', time: 1.8 },
  { name: 'Wednesday', time: 3.2 },
  { name: 'Thursday', time: 1.5 },
  { name: 'Friday', time: 2.1 },
  { name: 'Saturday', time: 4.3 },
  { name: 'Sunday', time: 3.7 },
];

const subjectDistributionData = [
  { name: 'Mathematics', value: 35, color: '#8b5cf6' },
  { name: 'Biology', value: 25, color: '#2dd4bf' },
  { name: 'History', value: 15, color: '#f97316' },
  { name: 'Computer Science', value: 25, color: '#f43f5e' },
];

const progressData = [
  { name: 'Week 1', quizScore: 65, flashcardAccuracy: 60 },
  { name: 'Week 2', quizScore: 70, flashcardAccuracy: 65 },
  { name: 'Week 3', quizScore: 75, flashcardAccuracy: 72 },
  { name: 'Week 4', quizScore: 68, flashcardAccuracy: 75 },
  { name: 'Week 5', quizScore: 80, flashcardAccuracy: 78 },
  { name: 'Week 6', quizScore: 85, flashcardAccuracy: 82 },
  { name: 'Week 7', quizScore: 90, flashcardAccuracy: 88 },
];

// Study history data
const studyHistoryData = [
  { date: 'Apr 23', studySessions: 2, totalHours: 2.5, retention: 72 },
  { date: 'Apr 24', studySessions: 3, totalHours: 4.1, retention: 75 },
  { date: 'Apr 25', studySessions: 1, totalHours: 1.2, retention: 68 },
  { date: 'Apr 26', studySessions: 3, totalHours: 3.8, retention: 81 },
  { date: 'Apr 27', studySessions: 2, totalHours: 2.7, retention: 83 },
  { date: 'Apr 28', studySessions: 4, totalHours: 5.2, retention: 86 },
  { date: 'Apr 29', studySessions: 2, totalHours: 3.0, retention: 84 },
];

// Flashcard performance data
const flashcardPerformanceData = [
  { subject: 'Mathematics', correct: 42, incorrect: 8 },
  { subject: 'Biology', correct: 36, incorrect: 14 },
  { subject: 'History', correct: 28, incorrect: 12 },
  { subject: 'Computer Science', correct: 45, incorrect: 5 },
];

// Pomodoro sessions data
const pomodoroData = [
  { date: 'Apr 23', completed: 4, interrupted: 1 },
  { date: 'Apr 24', completed: 6, interrupted: 0 },
  { date: 'Apr 25', completed: 2, interrupted: 2 },
  { date: 'Apr 26', completed: 8, interrupted: 1 },
  { date: 'Apr 27', completed: 5, interrupted: 0 },
  { date: 'Apr 28', completed: 7, interrupted: 2 },
  { date: 'Apr 29', completed: 5, interrupted: 1 },
];

const COLORS = ['#8b5cf6', '#2dd4bf', '#f97316', '#f43f5e'];

interface TooltipProps {
  active?: boolean;
  payload?: Array<{
    name?: string;
    value?: number;
    color?: string;
    fill?: string;
  }>;
  label?: string;
}

// Custom tooltip component
const CustomTooltip: React.FC<TooltipProps> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-800 p-3 border border-gray-700 rounded-md shadow-md">
        <p className="text-gray-200 font-medium">{label}</p>
        {payload.map((entry, i) => (
          <p key={`tooltip-item-${entry.name}-${i}`} style={{ color: entry.color || entry.fill || '#fff' }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

interface DataItem {
  [key: string]: any;
}

const Insights = () => {
  const [dateRange, setDateRange] = useState('week');
  const [activeSubject, setActiveSubject] = useState('all');
  const [detailedView, setDetailedView] = useState(false);
  const [filterModalOpen, setFilterModalOpen] = useState(false);

  // Filter data based on selected options
  const getFilteredData = (data: DataItem[]) => {
    if (activeSubject === 'all') return data;
    return data.filter(item => item.subject === activeSubject || item.name === activeSubject);
  };

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-purple-100">Insights</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="border-gray-700 text-white"
            onClick={() => setFilterModalOpen(true)}
          >
            Filter Data
          </Button>
          <Button
            variant={detailedView ? "default" : "outline"}
            className={detailedView ? "bg-purple-600 text-white" : "border-gray-700 text-white"}
            onClick={() => setDetailedView(!detailedView)}
          >
            {detailedView ? "Simple View" : "Detailed View"}
          </Button>
        </div>
      </div>

      {/* Filter Modal */}
      <AnimatePresence>
        {filterModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
            onClick={() => setFilterModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-800 p-6 rounded-lg shadow-lg max-w-md w-full"
              onClick={e => e.stopPropagation()}
            >
              <h2 className="text-xl font-semibold text-white mb-4">Filter Options</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-300 block mb-2">Date Range</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['week', 'month', 'year'].map((range) => (
                      <Button
                        key={range}
                        variant={dateRange === range ? "default" : "outline"}
                        className={dateRange === range
                          ? "bg-purple-600 text-white"
                          : "border-gray-700 text-white"}
                        onClick={() => setDateRange(range)}
                      >
                        {range.charAt(0).toUpperCase() + range.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm text-gray-300 block mb-2">Subject</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant={activeSubject === 'all' ? "default" : "outline"}
                      className={activeSubject === 'all'
                        ? "bg-purple-600 text-white"
                        : "border-gray-700 text-white"}
                      onClick={() => setActiveSubject('all')}
                    >
                      All Subjects
                    </Button>
                    {subjectDistributionData.map((subject) => (
                      <Button
                        key={subject.name}
                        variant={activeSubject === subject.name ? "default" : "outline"}
                        className={activeSubject === subject.name
                          ? "bg-purple-600 text-white"
                          : "border-gray-700 text-white"}
                        onClick={() => setActiveSubject(subject.name)}
                      >
                        {subject.name}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end pt-4">
                  <Button
                    onClick={() => setFilterModalOpen(false)}
                    className="bg-purple-600 text-white"
                  >
                    Apply Filters
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="bg-gray-800/60 w-full justify-center mb-6">
          <TabsTrigger value="overview" className="data-[state=active]:bg-purple-700 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="study-time" className="data-[state=active]:bg-purple-700 data-[state=active]:text-white">
            Study Time
          </TabsTrigger>
          <TabsTrigger value="performance" className="data-[state=active]:bg-purple-700 data-[state=active]:text-white">
            Performance
          </TabsTrigger>
          <TabsTrigger value="retention" className="data-[state=active]:bg-purple-700 data-[state=active]:text-white">
            Retention
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Study Time Distribution Card */}
            <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Study Time Distribution</CardTitle>
                <CardDescription className="text-gray-400">Hours spent studying by day</CardDescription>
              </CardHeader>
              <CardContent>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={getFilteredData(studyTimeData)}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                      <XAxis dataKey="name" stroke="#aaa" />
                      <YAxis stroke="#aaa" label={{ value: 'Hours', angle: -90, position: 'insideLeft', fill: '#aaa' }} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="time" name="Study Hours" fill="#8b5cf6" />
                    </BarChart>
                  </ResponsiveContainer>
                </motion.div>
              </CardContent>
            </Card>

            {/* Subject Distribution Card */}
            <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Subject Distribution</CardTitle>
                <CardDescription className="text-gray-400">Time allocation by subject</CardDescription>
              </CardHeader>
              <CardContent>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getFilteredData(subjectDistributionData)}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={100}
                        fill="#8b5cf6"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {subjectDistributionData.map((entry) => (
                          <Cell key={entry.name} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </motion.div>
              </CardContent>
            </Card>
          </div>

          {/* Progress Over Time Card */}
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Progress Over Time</CardTitle>
              <CardDescription className="text-gray-400">Quiz scores and flashcard accuracy</CardDescription>
            </CardHeader>
            <CardContent>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="h-80"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getFilteredData(progressData)}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                    <XAxis dataKey="name" stroke="#aaa" />
                    <YAxis stroke="#aaa" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line type="monotone" dataKey="quizScore" name="Quiz Score %" stroke="#8b5cf6" strokeWidth={2} activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="flashcardAccuracy" name="Flashcard Accuracy %" stroke="#2dd4bf" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </motion.div>
            </CardContent>
          </Card>

          {/* Detailed Study Metrics */}
          {detailedView && (
            <>
              <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Pomodoro Sessions</CardTitle>
                  <CardDescription className="text-gray-400">Completed vs. interrupted study sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={pomodoroData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        barGap={0}
                        barCategoryGap={10}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                        <XAxis dataKey="date" stroke="#aaa" />
                        <YAxis stroke="#aaa" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar dataKey="completed" name="Completed Sessions" fill="#4ade80" />
                        <Bar dataKey="interrupted" name="Interrupted Sessions" fill="#f87171" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Flashcard Performance</CardTitle>
                  <CardDescription className="text-gray-400">Correct vs. incorrect answers by subject</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={getFilteredData(flashcardPerformanceData)}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        barGap={0}
                        barCategoryGap={20}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#444" horizontal={false} />
                        <XAxis type="number" stroke="#aaa" />
                        <YAxis dataKey="subject" type="category" stroke="#aaa" />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Bar dataKey="correct" name="Correct" fill="#4ade80" />
                        <Bar dataKey="incorrect" name="Incorrect" fill="#f87171" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="study-time" className="space-y-6">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Weekly Study Hours</CardTitle>
                  <CardDescription className="text-gray-400">Hours spent studying over time</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={studyHistoryData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <defs>
                      <linearGradient id="colorTotalHours" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                    <XAxis dataKey="date" stroke="#aaa" />
                    <YAxis stroke="#aaa" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Area type="monotone" dataKey="totalHours" name="Study Hours" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorTotalHours)" />
                    <Line type="monotone" dataKey="studySessions" name="Study Sessions" stroke="#f87171" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-6 space-y-4">
                <div className="flex justify-between items-center p-4 bg-gray-700/50 rounded-lg">
                  <span>Total Weekly Study Hours</span>
                  <span className="font-bold text-purple-400">
                    {studyHistoryData.reduce((sum, item) => sum + item.totalHours, 0).toFixed(1)} hours
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-700/50 rounded-lg">
                  <span>Average Daily Study Time</span>
                  <span className="font-bold text-purple-400">
                    {(studyHistoryData.reduce((sum, item) => sum + item.totalHours, 0) / studyHistoryData.length).toFixed(1)} hours
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-700/50 rounded-lg">
                  <span>Most Productive Day</span>
                  <span className="font-bold text-purple-400">
                    {studyHistoryData.reduce((max, item) => item.totalHours > max.totalHours ? item : max).date}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription className="text-gray-400">Quiz scores and flashcard accuracy over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={progressData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                    <XAxis dataKey="name" stroke="#aaa" />
                    <YAxis stroke="#aaa" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line type="monotone" dataKey="quizScore" name="Quiz Score %" stroke="#8b5cf6" strokeWidth={2} activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="flashcardAccuracy" name="Flashcard Accuracy %" stroke="#2dd4bf" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-gray-700/50 rounded-lg">
                  <h3 className="text-lg font-medium mb-2">Quiz Performance</h3>
                  <p className="text-gray-300">Your quiz scores have improved by</p>
                  <p className="text-2xl font-bold text-purple-400">
                    {progressData[progressData.length - 1].quizScore - progressData[0].quizScore}%
                  </p>
                  <p className="text-gray-400 text-sm">since you started</p>
                </div>
                <div className="p-4 bg-gray-700/50 rounded-lg">
                  <h3 className="text-lg font-medium mb-2">Flashcard Accuracy</h3>
                  <p className="text-gray-300">Your flashcard accuracy has improved by</p>
                  <p className="text-2xl font-bold text-teal-400">
                    {progressData[progressData.length - 1].flashcardAccuracy - progressData[0].flashcardAccuracy}%
                  </p>
                  <p className="text-gray-400 text-sm">since you started</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="retention" className="space-y-6">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Knowledge Retention</CardTitle>
              <CardDescription className="text-gray-400">Information retention over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={studyHistoryData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                    <XAxis dataKey="date" stroke="#aaa" />
                    <YAxis stroke="#aaa" />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line type="monotone" dataKey="retention" name="Retention %" stroke="#8b5cf6" strokeWidth={2} />
                    <Line type="monotone" dataKey="totalHours" name="Study Hours" stroke="#2dd4bf" strokeWidth={1} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-6 p-4 bg-gray-700/50 rounded-lg">
                <h3 className="text-lg font-medium mb-2">Memory Retention Analysis</h3>
                <p className="text-gray-300 mb-2">Your average retention rate is</p>
                <p className="text-2xl font-bold text-purple-400">
                  {(studyHistoryData.reduce((sum, item) => sum + item.retention, 0) / studyHistoryData.length).toFixed(1)}%
                </p>
                <div className="mt-4 text-sm text-gray-400">
                  <p>Based on the spaced repetition algorithm, optimal review intervals:</p>
                  <ul className="list-disc pl-5 mt-2">
                    <li>First review: 1 day after learning</li>
                    <li>Second review: 3 days after first review</li>
                    <li>Third review: 7 days after second review</li>
                    <li>Fourth review: 14 days after third review</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Insights;
