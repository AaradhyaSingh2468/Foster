import type React from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { FiSearch, FiPlus, FiEdit, FiFolder, FiShare2, FiCalendar, FiBarChart2, FiBookOpen } from 'react-icons/fi';

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('study-sets');

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Your Study Sets</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Upcoming Events Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Upcoming Events</CardTitle>
            <Button variant="link" size="sm" className="text-blue-400 font-medium">
              View All
            </Button>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="w-20 h-20 mb-4 rounded-full bg-blue-500/20 flex items-center justify-center"
              >
                <FiCalendar className="h-10 w-10 text-blue-400" />
              </motion.div>
              <p className="text-gray-400 text-sm">No upcoming events</p>
            </div>
          </CardContent>
        </Card>

        {/* Daily Objectives Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Daily Objectives</CardTitle>
            <Button variant="link" size="sm" className="text-blue-400 font-medium">
              View All
            </Button>
          </CardHeader>
          <CardContent>
            <motion.div
              className="flex items-center p-3 rounded-lg bg-gray-700 border border-gray-600 hover:bg-gray-600 transition-colors cursor-pointer mt-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="mr-4 bg-red-500/20 p-2 rounded-lg">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-red-500">
                  <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2"/>
                  <path d="M12 15V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M9 11L12 8L15 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-medium text-white">Complete a Quiz</h4>
              </div>
              <div className="text-gray-400 text-sm font-medium">
                0 / 1
              </div>
            </motion.div>
          </CardContent>
        </Card>

        {/* Your Streak Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Your Streak</CardTitle>
            <Button variant="link" size="sm" className="text-blue-400 font-medium">
              Leaderboard
            </Button>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-8">
              <div className="flex items-center gap-4">
                <span className="text-4xl font-bold">0 Days</span>
                <span className="text-3xl">🔥</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Section */}
      <Tabs defaultValue="study-sets" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="bg-transparent border-b border-gray-700 w-full justify-start h-auto p-0 space-x-6">
          <TabsTrigger
            value="study-sets"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Study Sets
          </TabsTrigger>
          <TabsTrigger
            value="materials"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Materials
          </TabsTrigger>
          <TabsTrigger
            value="flashcards"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Flashcards
          </TabsTrigger>
          <TabsTrigger
            value="quizfetch"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            QuizFetch
          </TabsTrigger>
          <TabsTrigger
            value="tests"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Tests
          </TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="relative w-full max-w-md">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search your study sets..."
                className="pl-10 bg-gray-800/50 border-gray-700 text-white focus-visible:ring-purple-500"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                Edit
              </Button>

              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                Sort
              </Button>

              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                <FiFolder size={18} />
              </Button>

              <Button
                variant="default"
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Create <FiPlus size={18} className="ml-1" />
              </Button>
            </div>
          </div>

          <TabsContent value="study-sets" className="mt-6">
            <Link to="/study-set/foster" className="block hover:bg-gray-800/70 rounded-lg transition-colors">
              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 flex items-center justify-between backdrop-blur-sm">
                <div className="flex items-center gap-4">
                  <div className="bg-gray-700 h-12 w-12 rounded-full flex items-center justify-center text-purple-400 font-bold overflow-hidden">
                    <FiBookOpen size={24} />
                  </div>
                  <div>
                    <h3 className="text-white font-medium">foster</h3>
                    <p className="text-gray-400 text-sm">No Description</p>
                    <p className="text-gray-500 text-xs">Created At: 29/4/2025</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="bg-gray-700 p-2 rounded-full">
                    <span className="text-green-400">•</span>
                    <span className="text-white ml-1">1</span>
                  </div>
                  <Button variant="ghost" className="text-gray-400 hover:text-white">
                    <FiShare2 size={18} />
                  </Button>
                  <Button variant="link" className="text-blue-400">
                    Share
                  </Button>
                </div>
              </div>
            </Link>
          </TabsContent>

          <TabsContent value="materials" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <FiBarChart2 className="h-10 w-10 text-gray-400" />
              </div>
              <p className="text-gray-400">No materials found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Add Material
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="flashcards" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <FiBookOpen className="h-10 w-10 text-gray-400" />
              </div>
              <p className="text-gray-400">No flashcards found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Create Flashcards
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="quizfetch" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-gray-400">
                  <path d="M9 11L12 14L15 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 14V6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M20 16.7428C21.2215 15.734 22 14.2079 22 12.5C22 9.46243 19.5376 7 16.5 7C16.2815 7 16.0771 7.01859 15.8767 7.04592C14.7983 4.16477 12.0895 2 9 2C4.58172 2 1 5.58172 1 10C1 12.2091 1.89821 14.2091 3.34317 15.6365" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9.93246 20.5193C9.6794 20.8175 9.36562 21 9 21C8.44772 21 8 20.5523 8 20V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M17 16C17 18.7614 14.7614 21 12 21C11.6447 21 11.298 20.9594 10.9644 20.8812" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-gray-400">No quizzes found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Generate Quiz
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="tests" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-gray-400">
                  <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 9H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 13H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 17H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 3L9 5L12 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-gray-400">No tests found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Create Test
              </Button>
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default Dashboard;
