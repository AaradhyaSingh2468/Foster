import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import {
  CalendarIcon,
  BarChart3Icon,
  BookOpenIcon,
  ClipboardCheckIcon,
  BookMarkedIcon,
  GraduationCapIcon,
  TrophyIcon,
  FileEditIcon,
  SettingsIcon,
} from 'lucide-react';
import { Separator } from '../components/ui/separator';

// Define a proper type for achievement that includes optional progress and total
interface Achievement {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  earned: boolean;
  date?: string;
  progress?: number;
  total?: number;
}

const achievements: Achievement[] = [
  {
    id: 1,
    title: "First Set Created",
    description: "Created your first study set",
    icon: <BookMarkedIcon className="h-5 w-5 text-blue-400" />,
    earned: true,
    date: "Apr 28, 2025"
  },
  {
    id: 2,
    title: "Quiz Master",
    description: "Score 100% on 5 quizzes",
    icon: <TrophyIcon className="h-5 w-5 text-yellow-400" />,
    earned: false,
    progress: 0,
    total: 5
  },
  {
    id: 3,
    title: "Study Streak",
    description: "Study for 7 days in a row",
    icon: <CalendarIcon className="h-5 w-5 text-green-400" />,
    earned: false,
    progress: 0,
    total: 7
  },
  {
    id: 4,
    title: "Content Creator",
    description: "Create 10 study sets",
    icon: <FileEditIcon className="h-5 w-5 text-purple-400" />,
    earned: false,
    progress: 1,
    total: 10
  },
  {
    id: 5,
    title: "Scholar",
    description: "Spend 50 hours studying",
    icon: <GraduationCapIcon className="h-5 w-5 text-red-400" />,
    earned: false,
    progress: 0,
    total: 50
  }
];

const recentActivity = [
  {
    id: 1,
    type: "set_created",
    title: "Created a study set",
    detail: "foster",
    date: "Apr 29, 2025",
    icon: <BookMarkedIcon className="h-5 w-5 text-blue-400" />
  }
];

const stats = [
  {
    id: 1,
    name: "Study Sets",
    value: 1,
    icon: <BookOpenIcon className="h-5 w-5 text-purple-400" />
  },
  {
    id: 2,
    name: "Quiz Score Avg",
    value: "0%",
    icon: <ClipboardCheckIcon className="h-5 w-5 text-green-400" />
  },
  {
    id: 3,
    name: "Study Time",
    value: "0h",
    icon: <CalendarIcon className="h-5 w-5 text-blue-400" />
  },
  {
    id: 4,
    name: "Achievements",
    value: "1/5",
    icon: <TrophyIcon className="h-5 w-5 text-yellow-400" />
  }
];

const Profile: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'achievements' | 'activity'>('overview');
  const navigate = useNavigate();

  // Function to set the active tab and sync with the Tabs component
  const handleTabChange = (value: string) => {
    setActiveTab(value as 'overview' | 'achievements' | 'activity');
  };

  // Function to view all achievements
  const handleViewAllAchievements = () => {
    setActiveTab('achievements');
    setTimeout(() => {
      const achievementsSection = document.querySelector('[data-value="achievements"]');
      if (achievementsSection) {
        achievementsSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <div className="flex flex-col md:flex-row items-start gap-8 mb-8">
        {/* Profile Banner and Info */}
        <div className="w-full md:w-1/3">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm overflow-hidden">
            <div className="h-24 bg-gradient-to-r from-purple-600 to-blue-600" />
            <div className="px-6 pb-6 -mt-12">
              <Avatar className="h-24 w-24 border-4 border-gray-800 bg-gray-800">
                <AvatarImage src="https://github.com/shadcn.png" alt="User" />
                <AvatarFallback className="text-2xl font-bold bg-purple-600 text-white">F</AvatarFallback>
              </Avatar>
              <h2 className="text-2xl font-bold mt-4">Foster</h2>
              <p className="text-gray-400 text-sm">Member since April 2025</p>

              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-3">
                  <CalendarIcon className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-300">Current streak: 0 days</span>
                </div>
                <div className="flex items-center gap-3">
                  <BookOpenIcon className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-300">1 study set</span>
                </div>
                <div className="flex items-center gap-3">
                  <BarChart3Icon className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-300">0 hours study time</span>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={() => navigate('/account-settings')}
                >
                  Edit Profile
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-gray-700 text-gray-300 hover:bg-gray-700"
                  onClick={() => navigate('/account-settings')}
                >
                  <SettingsIcon size={16} className="mr-2" />
                  Account Settings
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="w-full md:w-2/3">
          <Tabs value={activeTab} className="w-full" onValueChange={handleTabChange}>
            <TabsList className="bg-gray-800/60 border border-gray-700 rounded-lg w-full grid grid-cols-3 p-1">
              <TabsTrigger
                value="overview"
                className="rounded-md data-[state=active]:bg-gray-700 data-[state=active]:text-white"
                data-value="overview"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="achievements"
                className="rounded-md data-[state=active]:bg-gray-700 data-[state=active]:text-white"
                data-value="achievements"
              >
                Achievements
              </TabsTrigger>
              <TabsTrigger
                value="activity"
                className="rounded-md data-[state=active]:bg-gray-700 data-[state=active]:text-white"
                data-value="activity"
              >
                Activity
              </TabsTrigger>
            </TabsList>

            <div className="mt-6">
              <TabsContent value="overview" className="mt-0">
                <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm mb-6">
                  <CardHeader>
                    <CardTitle>Stats Overview</CardTitle>
                    <CardDescription className="text-gray-400">
                      Your study statistics at a glance
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {stats.map((stat) => (
                        <div
                          key={stat.id}
                          className="bg-gray-700/50 rounded-lg p-4 border border-gray-700 flex flex-col items-center"
                        >
                          <div className="p-2 rounded-full bg-gray-800 mb-2">
                            {stat.icon}
                          </div>
                          <span className="text-2xl font-bold">{stat.value}</span>
                          <span className="text-sm text-gray-400">{stat.name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm mb-6">
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription className="text-gray-400">
                      Your most recent study activities
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {recentActivity.length > 0 ? (
                      <div className="space-y-4">
                        {recentActivity.map((activity) => (
                          <div
                            key={activity.id}
                            className="flex items-start gap-3 bg-gray-700/30 p-3 rounded-lg border border-gray-700"
                          >
                            <div className="p-2 rounded-full bg-gray-700 mt-1">
                              {activity.icon}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{activity.title}</p>
                              <p className="text-xs text-gray-400">{activity.detail}</p>
                              <p className="text-xs text-gray-500 mt-1">{activity.date}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-400">
                        No recent activity found.
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Recent Achievements</CardTitle>
                    <CardDescription className="text-gray-400">
                      Your most recent unlocked achievements
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {achievements.filter(a => a.earned).length > 0 ? (
                        achievements.filter(a => a.earned).map((achievement) => (
                          <div
                            key={achievement.id}
                            className="flex items-start gap-3 bg-gray-700/30 p-3 rounded-lg border border-gray-700"
                          >
                            <div className="p-2 rounded-full bg-gray-700 mt-1">
                              {achievement.icon}
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{achievement.title}</p>
                              <p className="text-xs text-gray-400">{achievement.description}</p>
                              <p className="text-xs text-gray-500 mt-1">Earned on {achievement.date}</p>
                            </div>
                            <div className="bg-green-500/20 px-2 py-1 rounded text-xs text-green-400">
                              Unlocked
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-8 text-gray-400">
                          No achievements unlocked yet.
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="justify-center border-t border-gray-700 pt-4">
                    <Button
                      variant="outline"
                      className="bg-transparent border-gray-700 text-gray-300 hover:bg-gray-700"
                      onClick={handleViewAllAchievements}
                    >
                      <TrophyIcon size={16} className="mr-2" />
                      View All Achievements
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="achievements" className="mt-0" data-value="achievements">
                <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                    <CardDescription className="text-gray-400">
                      Track your progress and unlock achievements
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {achievements.map((achievement) => (
                        <motion.div
                          key={achievement.id}
                          className={`flex items-start gap-3 p-4 rounded-lg border ${
                            achievement.earned
                              ? 'bg-green-900/20 border-green-700'
                              : 'bg-gray-700/30 border-gray-700'
                          }`}
                          whileHover={{ scale: 1.01 }}
                          transition={{ duration: 0.2 }}
                        >
                          <div className={`p-2 rounded-full ${
                            achievement.earned ? 'bg-green-900' : 'bg-gray-700'
                          } mt-1`}>
                            {achievement.icon}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{achievement.title}</p>
                            <p className="text-xs text-gray-400">{achievement.description}</p>
                            {achievement.earned ? (
                              <p className="text-xs text-gray-500 mt-1">Earned on {achievement.date}</p>
                            ) : (
                              <div className="mt-2">
                                <div className="flex items-center gap-2">
                                  <div className="bg-gray-700 h-2 rounded-full flex-1">
                                    <div
                                      className="bg-blue-500 h-2 rounded-full"
                                      style={{
                                        width: `${achievement.progress !== undefined && achievement.total !== undefined && achievement.total > 0
                                          ? (achievement.progress / achievement.total) * 100
                                          : 0}%`
                                      }}
                                    />
                                  </div>
                                  <span className="text-xs text-gray-400">
                                    {achievement.progress ?? 0}/{achievement.total ?? 0}
                                  </span>
                                </div>
                              </div>
                            )}
                          </div>
                          <div className={`px-2 py-1 rounded text-xs ${
                            achievement.earned
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-gray-700 text-gray-400'
                          }`}>
                            {achievement.earned ? 'Unlocked' : 'In Progress'}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="activity" className="mt-0">
                <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Activity History</CardTitle>
                    <CardDescription className="text-gray-400">
                      Your study activity timeline
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {recentActivity.length > 0 ? (
                      <div className="relative space-y-6 py-4">
                        {/* Timeline line */}
                        <div className="absolute left-4 top-10 bottom-10 w-0.5 bg-gray-700" />

                        {recentActivity.map((activity) => (
                          <div key={activity.id} className="relative flex items-start gap-4 pl-9">
                            <div className="absolute left-0 w-9 flex items-center justify-center">
                              <div className="h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center z-10">
                                {activity.icon}
                              </div>
                            </div>
                            <div className="flex-1 bg-gray-700/30 p-3 rounded-lg border border-gray-700">
                              <p className="text-sm font-medium">{activity.title}</p>
                              <p className="text-xs text-gray-400">{activity.detail}</p>
                              <p className="text-xs text-gray-500 mt-1">{activity.date}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-16 text-gray-400">
                        No activity recorded yet. Start studying to see your activity here!
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;
