import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Lock,
  Bell,
  Settings,
  ChevronLeft,
  Edit2,
  Camera,
  Save,
  Mail,
  UserCheck,
  Moon,
  Sun,
  Languages,
  X,
  LogOut,
  KeyRound,
  Shield,
  Smartphone,
  AlertCircle
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Switch } from '../components/ui/switch';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { useToast } from '../lib/useToast';
import { TwoFactorAuthModal } from '../components/modals/TwoFactorAuthModal';
import { SessionLogoutModal } from '../components/modals/SessionLogoutModal';
import { DeleteAccountModal } from '../components/modals/DeleteAccountModal';

const AccountSettings: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Form state
  const [name, setName] = useState('Foster');
  const [email, setEmail] = useState('foster@example.com');
  const [bio, setBio] = useState('');
  const [theme, setTheme] = useState('dark');
  const [language, setLanguage] = useState('en');
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    studyReminders: true,
    marketingEmails: false,
    newFeatures: true,
    achievementAlerts: true
  });
  const [loading, setLoading] = useState(false);

  // Modal states
  const [twoFactorAuthModalOpen, setTwoFactorAuthModalOpen] = useState(false);
  const [sessionLogoutModalOpen, setSessionLogoutModalOpen] = useState(false);
  const [deleteAccountModalOpen, setDeleteAccountModalOpen] = useState(false);

  // Tab state for navigation
  const [activeTab, setActiveTab] = useState<'profile' | 'notifications' | 'security' | 'preferences'>('profile');

  // Function to safely set the active tab
  const handleTabChange = (value: string) => {
    setActiveTab(value as 'profile' | 'notifications' | 'security' | 'preferences');
  };

  const handleSaveProfile = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Profile updated",
        description: "Your profile information has been saved successfully.",
        variant: "success",
        duration: 3000,
      });
    }, 1000);
  };

  const handleSaveNotifications = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Notification settings saved",
        description: "Your notification preferences have been updated.",
        variant: "success",
        duration: 3000,
      });
    }, 1000);
  }

  const handleUpdatePassword = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
        variant: "success",
        duration: 3000,
      });
    }, 1000);
  }

  const handleSavePreferences = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Preferences saved",
        description: "Your application preferences have been updated.",
        variant: "success",
        duration: 3000,
      });
    }, 1000);
  }

  return (
    <div className="max-w-5xl mx-auto animate-fade-in pb-12">
      {/* Header with back button */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          className="p-2 rounded-full"
          onClick={() => navigate(-1)}
        >
          <ChevronLeft size={24} />
        </Button>
        <h1 className="text-2xl font-bold text-purple-100">Account Settings</h1>
      </div>

      {/* Main content */}
      <div className="flex flex-col md:flex-row gap-8">
        {/* Settings navigation sidebar */}
        <div className="w-full md:w-1/4">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm sticky top-4">
            <CardContent className="p-4">
              <ul className="flex flex-col space-y-2">
                <li>
                  <Button
                    variant={activeTab === "profile" ? "default" : "ghost"}
                    className={`w-full flex items-center gap-2 justify-start text-left font-medium px-3 py-2 rounded-lg transition-colors whitespace-nowrap overflow-hidden ${
                      activeTab === "profile"
                        ? "bg-gray-700 text-white shadow-md"
                        : "text-gray-300 hover:bg-gray-700/50"
                    }`}
                    onClick={() => setActiveTab("profile")}
                  >
                    <User size={16} className="flex-shrink-0" />
                    <span className="truncate">Profile</span>
                  </Button>
                </li>
                <li>
                  <Button
                    variant={activeTab === "notifications" ? "default" : "ghost"}
                    className={`w-full flex items-center gap-2 justify-start text-left font-medium px-3 py-2 rounded-lg transition-colors whitespace-nowrap overflow-hidden ${
                      activeTab === "notifications"
                        ? "bg-gray-700 text-white shadow-md"
                        : "text-gray-300 hover:bg-gray-700/50"
                    }`}
                    onClick={() => setActiveTab("notifications")}
                  >
                    <Bell size={16} className="flex-shrink-0" />
                    <span className="truncate">Notifications</span>
                  </Button>
                </li>
                <li>
                  <Button
                    variant={activeTab === "security" ? "default" : "ghost"}
                    className={`w-full flex items-center gap-2 justify-start text-left font-medium px-3 py-2 rounded-lg transition-colors whitespace-nowrap overflow-hidden ${
                      activeTab === "security"
                        ? "bg-gray-700 text-white shadow-md"
                        : "text-gray-300 hover:bg-gray-700/50"
                    }`}
                    onClick={() => setActiveTab("security")}
                  >
                    <Lock size={16} className="flex-shrink-0" />
                    <span className="truncate">Security</span>
                  </Button>
                </li>
                <li>
                  <Button
                    variant={activeTab === "preferences" ? "default" : "ghost"}
                    className={`w-full flex items-center gap-2 justify-start text-left font-medium px-3 py-2 rounded-lg transition-colors whitespace-nowrap overflow-hidden ${
                      activeTab === "preferences"
                        ? "bg-gray-700 text-white shadow-md"
                        : "text-gray-300 hover:bg-gray-700/50"
                    }`}
                    onClick={() => setActiveTab("preferences")}
                  >
                    <Settings size={16} className="flex-shrink-0" />
                    <span className="truncate">Preferences</span>
                  </Button>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Settings content area */}
        <div className="w-full md:w-3/4">
          <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardContent className="p-4 md:p-6">
              <Tabs value={activeTab} onValueChange={handleTabChange}>
                {/* Profile Settings */}
                <TabsContent value="profile" className="space-y-6">
                  <div className="flex flex-col items-center sm:flex-row sm:items-start gap-6">
                    <div className="relative">
                      <Avatar className="h-24 w-24 border-4 border-gray-700">
                        <AvatarImage src="https://github.com/shadcn.png" alt="Profile" />
                        <AvatarFallback className="text-3xl bg-purple-600">F</AvatarFallback>
                      </Avatar>
                      <Button
                        size="sm"
                        className="absolute bottom-0 right-0 rounded-full h-8 w-8 p-0 bg-purple-600"
                        onClick={() => {
                          toast({
                            title: "Profile picture",
                            description: "This feature will be available soon",
                            variant: "default",
                            duration: 3000,
                          });
                        }}
                      >
                        <Camera size={14} />
                      </Button>
                    </div>
                    <div className="flex-1 space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Display Name</Label>
                        <Input
                          id="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="bg-gray-700/50 border-gray-600"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="bg-gray-700/50 border-gray-600"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator className="my-6 bg-gray-700" />

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        placeholder="Tell us about yourself"
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        className="min-h-[120px] bg-gray-700/50 border-gray-600"
                      />
                    </div>

                    <div className="flex flex-col sm:flex-row justify-between gap-3 mt-5">
                      <Button
                        variant="outline"
                        className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        onClick={() => navigate('/profile')}
                      >
                        View Public Profile
                      </Button>
                      <Button
                        onClick={handleSaveProfile}
                        disabled={loading}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {loading ? 'Saving...' : (
                          <>
                            <Save size={16} className="mr-2" />
                            Save Changes
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                {/* Notification Settings */}
                <TabsContent value="notifications" className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Email Notifications</h3>
                    <div className="space-y-3">
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                        <div className="space-y-0.5">
                          <Label htmlFor="email-notifications">Email Notifications</Label>
                          <p className="text-sm text-gray-400">
                            Receive notifications about your account via email
                          </p>
                        </div>
                        <Switch
                          id="email-notifications"
                          checked={notifications.emailNotifications}
                          onCheckedChange={(checked) =>
                            setNotifications({...notifications, emailNotifications: checked})
                          }
                        />
                      </div>

                      <Separator className="my-4 bg-gray-700" />

                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                        <div className="space-y-0.5">
                          <Label htmlFor="study-reminders">Study Reminders</Label>
                          <p className="text-sm text-gray-400">
                            Get reminders about your scheduled study sessions
                          </p>
                        </div>
                        <Switch
                          id="study-reminders"
                          checked={notifications.studyReminders}
                          onCheckedChange={(checked) =>
                            setNotifications({...notifications, studyReminders: checked})
                          }
                        />
                      </div>

                      <Separator className="my-4 bg-gray-700" />

                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                        <div className="space-y-0.5">
                          <Label htmlFor="marketing-emails">Marketing Emails</Label>
                          <p className="text-sm text-gray-400">
                            Receive special offers, promotions, and newsletter
                          </p>
                        </div>
                        <Switch
                          id="marketing-emails"
                          checked={notifications.marketingEmails}
                          onCheckedChange={(checked) =>
                            setNotifications({...notifications, marketingEmails: checked})
                          }
                        />
                      </div>

                      <Separator className="my-4 bg-gray-700" />

                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                        <div className="space-y-0.5">
                          <Label htmlFor="new-features">New Feature Announcements</Label>
                          <p className="text-sm text-gray-400">
                            Learn about new features as they're released
                          </p>
                        </div>
                        <Switch
                          id="new-features"
                          checked={notifications.newFeatures}
                          onCheckedChange={(checked) =>
                            setNotifications({...notifications, newFeatures: checked})
                          }
                        />
                      </div>

                      <Separator className="my-4 bg-gray-700" />

                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                        <div className="space-y-0.5">
                          <Label htmlFor="achievement-alerts">Achievement Alerts</Label>
                          <p className="text-sm text-gray-400">
                            Get notified when you unlock achievements
                          </p>
                        </div>
                        <Switch
                          id="achievement-alerts"
                          checked={notifications.achievementAlerts}
                          onCheckedChange={(checked) =>
                            setNotifications({...notifications, achievementAlerts: checked})
                          }
                        />
                      </div>
                    </div>

                    <div className="flex justify-end mt-6">
                      <Button
                        onClick={handleSaveNotifications}
                        disabled={loading}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {loading ? 'Saving...' : (
                          <>
                            <Save size={16} className="mr-2" />
                            Save Preferences
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </TabsContent>

                {/* Security Settings */}
                <TabsContent value="security" className="space-y-6">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Change Password</h3>
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label htmlFor="current-password">Current Password</Label>
                          <Input
                            id="current-password"
                            type="password"
                            placeholder="••••••••"
                            className="bg-gray-700/50 border-gray-600"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="new-password">New Password</Label>
                          <Input
                            id="new-password"
                            type="password"
                            placeholder="••••••••"
                            className="bg-gray-700/50 border-gray-600"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="confirm-password">Confirm New Password</Label>
                          <Input
                            id="confirm-password"
                            type="password"
                            placeholder="••••••••"
                            className="bg-gray-700/50 border-gray-600"
                          />
                        </div>
                      </div>
                      <Button
                        onClick={handleUpdatePassword}
                        disabled={loading}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {loading ? 'Updating...' : (
                          <>
                            <KeyRound size={16} className="mr-2" />
                            Update Password
                          </>
                        )}
                      </Button>
                    </div>

                    <Separator className="my-6 bg-gray-700" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
                      <div className="flex flex-col sm:flex-row justify-between gap-4 p-4 border border-gray-700 rounded-lg bg-gray-700/30">
                        <div className="space-y-1">
                          <p className="font-medium">Protect your account with 2FA</p>
                          <p className="text-sm text-gray-400">
                            Add an extra layer of security to your account by requiring both a password and verification code
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          className="border-gray-600 hover:bg-gray-700 mt-2 sm:mt-0 whitespace-nowrap"
                          onClick={() => setTwoFactorAuthModalOpen(true)}
                        >
                          <Shield size={16} className="mr-2" />
                          Setup 2FA
                        </Button>
                      </div>
                    </div>

                    <Separator className="my-6 bg-gray-700" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Sessions</h3>
                      <div className="p-4 border border-gray-700 rounded-lg bg-gray-700/30">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4">
                          <div className="flex items-center gap-3">
                            <div className="bg-green-500/20 p-2 rounded-full">
                              <Smartphone size={18} className="text-green-400" />
                            </div>
                            <div>
                              <p className="font-medium">Current Session</p>
                              <p className="text-sm text-gray-400">
                                Web Browser • Last active just now
                              </p>
                            </div>
                          </div>
                          <div className="bg-green-500/20 px-2 py-1 text-xs text-green-400 rounded-full">
                            Active
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700 text-sm"
                          onClick={() => setSessionLogoutModalOpen(true)}
                        >
                          <LogOut size={14} className="mr-2" />
                          Sign Out of All Other Sessions
                        </Button>
                      </div>
                    </div>

                    <Separator className="my-6 bg-gray-700" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium text-red-400">Danger Zone</h3>
                      <div className="p-4 border border-red-800/30 rounded-lg bg-red-900/10">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                          <div className="space-y-1">
                            <p className="font-medium">Delete Account</p>
                            <p className="text-sm text-gray-400">
                              Permanently delete your account and all your data
                            </p>
                          </div>
                          <Button
                            variant="outline"
                            onClick={() => setDeleteAccountModalOpen(true)}
                            className="bg-transparent border-red-500 text-red-400 hover:bg-red-500/10 mt-2 sm:mt-0"
                          >
                            <AlertCircle size={16} className="mr-2" />
                            Delete Account
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                {/* Preferences Settings */}
                <TabsContent value="preferences" className="space-y-6">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Theme</h3>
                      <RadioGroup
                        value={theme}
                        onValueChange={setTheme}
                        className="grid grid-cols-1 sm:grid-cols-3 gap-4"
                      >
                        <div>
                          <RadioGroupItem
                            value="light"
                            id="theme-light"
                            className="peer sr-only"
                          />
                          <Label
                            htmlFor="theme-light"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-gray-700 bg-gray-800 p-4 hover:bg-gray-700/50 hover:border-gray-600 peer-data-[state=checked]:border-purple-500 cursor-pointer"
                          >
                            <Sun size={22} className="mb-3 text-yellow-400" />
                            <div className="font-medium">Light</div>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem
                            value="dark"
                            id="theme-dark"
                            className="peer sr-only"
                          />
                          <Label
                            htmlFor="theme-dark"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-gray-700 bg-gray-800 p-4 hover:bg-gray-700/50 hover:border-gray-600 peer-data-[state=checked]:border-purple-500 cursor-pointer"
                          >
                            <Moon size={22} className="mb-3 text-blue-400" />
                            <div className="font-medium">Dark</div>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem
                            value="system"
                            id="theme-system"
                            className="peer sr-only"
                          />
                          <Label
                            htmlFor="theme-system"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-gray-700 bg-gray-800 p-4 hover:bg-gray-700/50 hover:border-gray-600 peer-data-[state=checked]:border-purple-500 cursor-pointer"
                          >
                            <Settings size={22} className="mb-3 text-gray-400" />
                            <div className="font-medium">System</div>
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <Separator className="my-6 bg-gray-700" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Language</h3>
                      <div className="space-y-2">
                        <Label htmlFor="language">Select Language</Label>
                        <div className="flex items-center">
                          <div className="relative flex-1">
                            <Languages className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                            <select
                              id="language"
                              value={language}
                              onChange={(e) => setLanguage(e.target.value)}
                              className="w-full pl-10 py-2 bg-gray-700/50 border-gray-600 rounded-md text-white focus:border-purple-500 focus:ring-purple-500"
                            >
                              <option value="en">English (US)</option>
                              <option value="es">Español</option>
                              <option value="fr">Français</option>
                              <option value="de">Deutsch</option>
                              <option value="ja">日本語</option>
                              <option value="zh">中文</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>

                    <Separator className="my-6 bg-gray-700" />

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Accessibility</h3>
                      <div className="space-y-3">
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                          <div className="space-y-0.5">
                            <Label htmlFor="reduce-motion">Reduce Motion</Label>
                            <p className="text-sm text-gray-400">
                              Minimize animations across the interface
                            </p>
                          </div>
                          <Switch id="reduce-motion" />
                        </div>

                        <Separator className="my-4 bg-gray-700" />

                        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                          <div className="space-y-0.5">
                            <Label htmlFor="high-contrast">High Contrast</Label>
                            <p className="text-sm text-gray-400">
                              Increase contrast between elements
                            </p>
                          </div>
                          <Switch id="high-contrast" />
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-end mt-6">
                      <Button
                        onClick={handleSavePreferences}
                        disabled={loading}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {loading ? 'Saving...' : (
                          <>
                            <Save size={16} className="mr-2" />
                            Save Preferences
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modals */}
      <TwoFactorAuthModal
        open={twoFactorAuthModalOpen}
        onOpenChange={setTwoFactorAuthModalOpen}
      />

      <SessionLogoutModal
        open={sessionLogoutModalOpen}
        onOpenChange={setSessionLogoutModalOpen}
      />

      <DeleteAccountModal
        open={deleteAccountModalOpen}
        onOpenChange={setDeleteAccountModalOpen}
      />
    </div>
  );
};

export default AccountSettings;
