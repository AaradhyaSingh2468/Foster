import React, { lazy, Suspense, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import Sidebar from "./components/layouts/Sidebar";
import Header from "./components/layouts/Header";
import NotificationPrompt from "./components/dashboard/NotificationPrompt";
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";

// Type definition for component importing functions
type ImportFn = () => Promise<{ default: React.ComponentType<any> }>;

// Prefetch function to load components in the background
const prefetchComponent = (componentImport: ImportFn): void => {
  componentImport().catch(() => {});
};

// Lazy load all page components with dynamic imports
const Chat = lazy(() => import("./pages/Chat"));
const Calendar = lazy(() => import("./pages/Calendar"));
const Insights = lazy(() => import("./pages/Insights"));
const FlashCards = lazy(() => import("./pages/FlashCards"));
const Tests = lazy(() => import("./pages/Tests"));
const Sketchboard = lazy(() => import("./pages/Sketchboard"));
const ExamGeneration = lazy(() => import("./pages/ExamGeneration"));
const VideoGeneration = lazy(() => import("./pages/VideoGeneration"));
const StudySet = lazy(() => import("./pages/StudySet"));
const Profile = lazy(() => import("./pages/Profile"));
const AccountSettings = lazy(() => import("./pages/AccountSettings"));

// Optimized loading state component
const PageLoader = () => (
  <div className="flex h-full w-full items-center justify-center">
    <div className="flex flex-col items-center">
      <div className="h-16 w-16 animate-spin rounded-full border-b-2 border-t-2 border-purple-500" />
      <p className="mt-4 text-lg text-gray-300">Loading...</p>
    </div>
  </div>
);

// Component to handle prefetching
const PrefetchNextRoutes = () => {
  const location = useLocation();

  useEffect(() => {
    // Based on current route, prefetch likely next pages
    const path = location.pathname;

    // Start prefetching after a small delay to prioritize current page
    const timer = setTimeout(() => {
      if (path === "/") {
        prefetchComponent(() => import("./pages/Chat"));
        prefetchComponent(() => import("./pages/Calendar"));
      } else if (path === "/chat") {
        prefetchComponent(() => import("./pages/Insights"));
        prefetchComponent(() => import("./pages/FlashCards"));
      } else if (path === "/calendar") {
        prefetchComponent(() => import("./pages/Insights"));
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [location]);

  return null;
};

function App() {
  // Background with subtle pattern/gradient - optimized by caching
  const appBgStyle = React.useMemo(
    () => ({
      backgroundImage: `
      linear-gradient(to bottom right, rgba(17, 24, 39, 0.97), rgba(30, 27, 75, 0.97)),
      url("https://static.vecteezy.com/system/resources/previews/054/238/446/non_2x/abstract-dark-black-textured-background-with-subtle-wavy-lines-perfect-for-website-banners-presentations-or-design-projects-vector.jpg")
    `,
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundAttachment: "fixed",
    }),
    []
  );

  return (
    <TooltipProvider>
      <Router>
        <div className="flex h-screen text-white" style={appBgStyle}>
          {/* Sidebar */}
          <Sidebar />

          {/* Main Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Header */}
            <Header />

            {/* Prefetch logic */}
            <PrefetchNextRoutes />

            {/* Main Content */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <Suspense fallback={<PageLoader />}>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/chat" element={<Chat />} />
                  <Route path="/calendar" element={<Calendar />} />
                  <Route path="/insights" element={<Insights />} />
                  <Route path="/flashcards" element={<FlashCards />} />
                  <Route path="/tests" element={<Tests />} />
                  <Route path="/sketchboard" element={<Sketchboard />} />
                  <Route path="/exam-generation" element={<ExamGeneration />} />
                  <Route
                    path="/video-generation"
                    element={<VideoGeneration />}
                  />
                  <Route path="/study-set/:id" element={<StudySet />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route
                    path="/account-settings"
                    element={<AccountSettings />}
                  />
                </Routes>
              </Suspense>

              {/* Notification Prompt */}
              <NotificationPrompt />
            </div>
          </div>
        </div>
        <Toaster />
      </Router>
    </TooltipProvider>
  );
}

export default App;
