const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  // Proxy API requests directly to the Django backend
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:8000',
      changeOrigin: true,
      pathRewrite: function(path, req) {
        // Keep the /api prefix when forwarding to Django
        return path;
      }
    })
  );
}; 