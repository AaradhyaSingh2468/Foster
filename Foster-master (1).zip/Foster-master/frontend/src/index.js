import React from "react";
// import ReactDOM from "react-dom";

import App from "./App";
//import reportWebVitals from "./reportWebVitals";''

import { createRoot } from 'react-dom/client';

// Determine if we're in development mode
const isDevelopment = process.env.NODE_ENV === 'development';

// Get the root DOM node
const domNode = document.getElementById('root');
const root = createRoot(domNode);

// In development, temporarily disable StrictMode to avoid double-mounting issues
// This helps prevent infinite API calls when there are issues with effect dependencies
if (isDevelopment) {
  console.log('Development mode - StrictMode disabled to prevent double fetching');
  root.render(<App />);
} else {
  // In production, we can use StrictMode for extra checks
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById("root")
// );

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
// reportWebVitals();
