import React, { createContext, useCallback, useContext, useEffect } from 'react';
import { useToast, clearAllToasts } from './study-dashboard/lib/useToast';

// Create context for toast management
const ToastManagerContext = createContext(null);

/**
 * Toast Manager Provider component
 * Provides toast functions to the entire app
 */
export const ToastManagerProvider = ({ children }) => {
  const { toast } = useToast();
  
  // Function to show a logout toast
  const showLogoutToast = useCallback(() => {
    // Clear any existing toasts first
    clearAllToasts();
    
    // Show the toast
    toast({
      title: "Logged out successfully",
      description: "You have been securely logged out of your account",
      variant: "success",
      duration: 5000,
    });
    
    // Mark toast as shown
    localStorage.setItem('logout_toast_shown', 'true');
    localStorage.removeItem('show_logout_message');
    sessionStorage.removeItem('just_logged_out');
  }, [toast]);
  
  // Initialize and expose methods globally
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Create global methods
      window.showLogoutToast = showLogoutToast;
      window.clearAllToasts = clearAllToasts;
      
      // Check if we need to show a logout toast right away
      const showLogoutMessage = localStorage.getItem('show_logout_message');
      const justLoggedOut = sessionStorage.getItem('just_logged_out');
      
      if (showLogoutMessage || justLoggedOut) {
        // Show with a slight delay to ensure rendering is complete
        setTimeout(showLogoutToast, 300);
      }
    }
    
    // Event listener for logout events
    const handleLogoutEvent = () => {
      showLogoutToast();
    };
    
    // Listen for logout events from various sources
    document.addEventListener('userLogout', handleLogoutEvent);
    document.addEventListener('userLoggedOut', handleLogoutEvent);
    
    return () => {
      // Clean up event listeners on unmount
      document.removeEventListener('userLogout', handleLogoutEvent);
      document.removeEventListener('userLoggedOut', handleLogoutEvent);
    };
  }, [showLogoutToast]);
  
  // Expose methods through context
  const contextValue = {
    showLogoutToast,
    showToast: toast,
    clearToasts: clearAllToasts
  };
  
  return (
    <ToastManagerContext.Provider value={contextValue}>
      {children}
    </ToastManagerContext.Provider>
  );
};

// Custom hook to use toast manager
export const useToastManager = () => {
  const context = useContext(ToastManagerContext);
  if (!context) {
    throw new Error('useToastManager must be used within a ToastManagerProvider');
  }
  return context;
};

// Convenience function for showing logout toast from anywhere
export const showGlobalLogoutToast = () => {
  if (typeof window !== 'undefined') {
    if (typeof window.showLogoutToast === 'function') {
      window.showLogoutToast();
    } else if (window.dispatchToastAction) {
      clearAllToasts();
      window.dispatchToastAction({
        type: "ADD_TOAST",
        toast: {
          id: "logout-" + Date.now(),
          title: "Logged out successfully",
          description: "You have been securely logged out of your account",
          variant: "success",
          duration: 5000,
          open: true
        }
      });
    }
  }
};

export default ToastManagerProvider; 