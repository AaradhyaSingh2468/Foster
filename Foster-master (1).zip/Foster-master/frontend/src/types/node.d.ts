// Fix compatibility issues with Node.js setTimeout in browser
declare namespace NodeJS {
  interface Timeout {}
  interface Global {
    gc?: () => void;
  }
} 