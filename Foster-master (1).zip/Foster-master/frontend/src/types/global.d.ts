// Global type declarations
declare interface Window {
  gc?: () => void;
}

// Make setTimeout return a number type to fix TypeScript errors
declare function setTimeout(callback: Function, ms: number): number;
declare function clearTimeout(id: number): void; 