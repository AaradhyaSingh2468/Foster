/**
 * Type declarations for Firebase to prevent TypeScript errors
 */

// If you're getting TypeScript errors about missing Firebase types,
// this declaration ensures the TypeScript compiler doesn't complain
declare module 'firebase/auth' {
  // Reexport all types from the installed @firebase packages
  export * from '@firebase/auth-types';
}

declare module 'firebase/app' {
  export * from '@firebase/app-types';
}

// Firebase App
declare module 'firebase/app' {
  export interface FirebaseApp {
    name: string;
    options: object;
    automaticDataCollectionEnabled: boolean;
  }
  
  export function initializeApp(options: object, name?: string): FirebaseApp;
  export function getApp(name?: string): FirebaseApp;
  export function deleteApp(app: FirebaseApp): Promise<void>;
}

// Firebase Auth
declare module 'firebase/auth' {
  import { FirebaseApp } from 'firebase/app';
  
  export interface User {
    uid: string;
    email: string | null;
    emailVerified: boolean;
    displayName: string | null;
    photoURL: string | null;
    phoneNumber: string | null;
    getIdToken(forceRefresh?: boolean): Promise<string>;
    [key: string]: any;
  }
  
  export interface Auth {
    app: FirebaseApp;
    currentUser: User | null;
    languageCode: string | null;
    [key: string]: any;
  }
  
  export interface UserCredential {
    user: User;
    credential: any;
    operationType?: string;
    additionalUserInfo?: {
      providerId: string;
      isNewUser: boolean;
      profile?: object;
      username?: string;
    };
  }
  
  export type NextOrObserver<T> = ((value: T) => void) | object;
  export type ErrorFn = (error: Error) => void;
  
  export function getAuth(app?: FirebaseApp): Auth;
  export function signInWithEmailAndPassword(auth: Auth, email: string, password: string): Promise<UserCredential>;
  export function createUserWithEmailAndPassword(auth: Auth, email: string, password: string): Promise<UserCredential>;
  export function signOut(auth: Auth): Promise<void>;
  export function onAuthStateChanged(auth: Auth, nextOrObserver: NextOrObserver<User | null>, error?: ErrorFn): () => void;
  
  // Auth providers
  export class GoogleAuthProvider {
    static PROVIDER_ID: string;
    static credentialFromResult(result: any): any;
    static credentialFromError(error: any): any;
  }
  
  export class GithubAuthProvider {
    static PROVIDER_ID: string;
    static credentialFromResult(result: any): any;
    static credentialFromError(error: any): any;
  }
  
  export function signInWithPopup(auth: Auth, provider: any): Promise<UserCredential>;
  export function signInWithRedirect(auth: Auth, provider: any): Promise<never>;
  export function getRedirectResult(auth: Auth): Promise<UserCredential | null>;
  export function fetchSignInMethodsForEmail(auth: Auth, email: string): Promise<string[]>;
  export function linkWithCredential(user: User, credential: any): Promise<UserCredential>;
}

// Firebase Firestore
declare module 'firebase/firestore' {
  export function getFirestore(app?: any): any;
} 