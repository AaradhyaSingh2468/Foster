declare module '../../services/studyService' {
  import { StudySet, StudyCard, DeleteStudySetOptions, FlashCard } from '../services/types';

  export function getStudySets(): Promise<StudySet[]>;
  export function getStudySet(id: string): Promise<StudySet | null>;
  export function createStudySet(studySetData: Partial<StudySet>): Promise<StudySet>;
  export function updateStudySet(id: string, studySetData: Partial<StudySet>): Promise<StudySet>;
  export function deleteStudySet(id: string, options?: DeleteStudySetOptions): Promise<any>;
  export function getFlashcards(studySetId: string): Promise<FlashCard[]>;
  export function createFlashcard(studySetId: string, flashcardData: Partial<FlashCard>): Promise<FlashCard>;
  export function updateFlashcard(studySetId: string, flashcardId: string, flashcardData: Partial<FlashCard>): Promise<FlashCard>;
  export function deleteFlashcard(studySetId: string, flashcardId: string): Promise<any>;
  export function generateQuiz(studySetId: string, options: any): Promise<any>;
  export function submitQuizResults(studySetId: string, quizId: string, results: any): Promise<any>;
  export function getStudyStatistics(): Promise<any>;
  export function updateStudyProgress(studySetId: string, progressData: any): Promise<any>;
  export function createStudySetFromPdf(pdfId: string, title: string): Promise<StudySet>;
  export function refreshStudySets(): Promise<StudySet[]>;
} 