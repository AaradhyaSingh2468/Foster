declare module '@radix-ui/react-select';
declare module '@radix-ui/react-slider'; 

// Global window interface extensions
interface Window {
  showLogoutToast?: boolean | (() => void);
  showAppToast?: any;
  toast?: any;
  clearAllToasts?: () => void;
  dispatchToastAction?: (action: any) => void;
  
  // Fix the globalToast interface to ensure it's recognized by TypeScript
  globalToast?: {
    show: (options: { 
      title: string; 
      message?: string; 
      description?: string;
      type?: string;
      variant?: string;
      duration?: number;
    }) => void;
    clear: () => void;
  };
}

// Export the window interface to make it globally available
export {}; 