import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import styled, { keyframes } from "styled-components";

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const shimmer = keyframes`
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

const bounceIn = keyframes`
  0% { opacity: 0; transform: translateX(-25px); }
  60% { transform: translateX(10px); }
  80% { transform: translateX(-5px); }
  100% { opacity: 1; transform: translateX(0); }
`;

const staggeredFadeIn = keyframes`
  0% { opacity: 0; transform: translateY(20px); }
  100% { opacity: 1; transform: translateY(0); }
`;

const BlogPostContainer = styled.div`
  width: 100%;
  color: white;
  animation: ${fadeIn} 0.6s ease-out;
`;

const BackLink = styled(Link)`
  display: inline-flex;
  align-items: center;
  color: var(--purple);
  font-weight: 600;
  padding: 0.5rem 0.9rem;
  border: 1.5px solid var(--purple);
  border-radius: 20px;
  background: rgba(155, 70, 255, 0.05);
  margin-bottom: 0;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  z-index: 1;
  animation: ${bounceIn} 0.7s ease forwards;
  font-size: 0.9rem;
  vertical-align: middle;
  transform: translateY(2px);
  
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 0%;
    height: 100%;
    background: linear-gradient(90deg, var(--purple) 0%, var(--pink) 100%);
    transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
    z-index: -1;
  }
  
  &:hover {
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 6px 15px -8px rgba(155, 70, 255, 0.5);
    border-color: transparent;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    
    &::before {
      width: 100%;
    }
    
    svg {
      transform: translateX(-3px);
      stroke: white;
    }
  }
  
  &:focus {
    outline: none;
    box-shadow: 0 0 0 2px rgba(155, 70, 255, 0.4);
    border-color: var(--purple);
  }
  
  &:active {
    transform: translateY(-1px);
  }
  
  svg {
    margin-right: 0.5rem;
    transition: all 0.3s ease;
    stroke: var(--purple);
    width: 16px;
    height: 16px;
  }
`;

const CategoryTag = styled.span`
  background: rgba(155, 70, 255, 0.15);
  color: var(--purple);
  padding: 0.4rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  display: inline-block;
  margin-bottom: 1rem;
  margin-right: 1rem;
  font-weight: 600;
  border: 1px solid rgba(155, 70, 255, 0.2);
`;

const BlogTitle = styled.h1`
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
  background: linear-gradient(90deg, var(--purple) 0%, var(--pink) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  line-height: 1.2;
  background-size: 200% auto;
  animation: ${shimmer} 3s linear infinite;
  
  @media (max-width: 768px) {
    font-size: 2.2rem;
  }
`;

const BlogMeta = styled.div`
  display: flex;
  align-items: center;
  color: rgba(255, 255, 255, 0.6);
  margin-bottom: 2.5rem;
  
  span:not(:last-child) {
    margin-right: 0.5rem;
  }
`;

const BlogImage = styled.div`
  width: 100%;
  height: 450px;
  overflow: hidden;
  border-radius: 16px;
  margin-bottom: 3rem;
  position: relative;
  box-shadow: 0 10px 30px -15px rgba(0, 0, 0, 0.5);
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(0deg, rgba(10,11,16,0.2) 0%, rgba(10,11,16,0) 50%);
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 10s ease;
  }
  
  &:hover img {
    transform: scale(1.05);
  }
  
  @media (max-width: 768px) {
    height: 300px;
  }
`;

const BlogContent = styled.div`
  line-height: 1.8;
  font-size: 1.1rem;
  color: rgba(255, 255, 255, 0.85);
  max-width: 800px;
  margin: 0 auto;
  
  p {
    margin-bottom: 1.8rem;
  }
  
  h2 {
    font-size: 2rem;
    font-weight: bold;
    color: var(--purple);
    margin: 3rem 0 1.5rem;
    position: relative;
    padding-bottom: 0.5rem;
    
    &::after {
      content: "";
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100px;
      height: 4px;
      background: linear-gradient(90deg, var(--purple) 0%, rgba(155, 70, 255, 0.1) 100%);
      border-radius: 2px;
    }
  }
  
  h3 {
    font-size: 1.5rem;
    font-weight: bold;
    color: var(--pink);
    margin: 2rem 0 1rem;
  }
  
  ul, ol {
    margin-left: 2rem;
    margin-bottom: 1.8rem;
  }
  
  li {
    margin-bottom: 0.8rem;
    position: relative;
  }
  
  ul li::before {
    content: "";
    position: absolute;
    left: -1.5rem;
    top: 0.6rem;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: var(--purple);
  }
  
  blockquote {
    border-left: 4px solid var(--purple);
    padding: 1rem 0 1rem 2rem;
    font-style: italic;
    margin: 2.5rem 0;
    background: rgba(155, 70, 255, 0.05);
    border-radius: 0 8px 8px 0;
  }
  
  a {
    color: var(--purple);
    text-decoration: none;
    border-bottom: 1px dashed rgba(155, 70, 255, 0.5);
    transition: all 0.3s ease;
    
    &:hover {
      color: var(--pink);
      border-bottom-color: var(--pink);
    }
  }
  
  img {
    max-width: 100%;
    border-radius: 8px;
    margin: 2rem 0;
  }
  
  code {
    background: rgba(155, 70, 255, 0.1);
    padding: 2px 6px;
    border-radius: 4px;
    font-family: 'Courier New', monospace;
    font-size: 0.9em;
  }
  
  pre {
    background: rgba(0, 0, 0, 0.2);
    padding: 1.5rem;
    border-radius: 8px;
    overflow-x: auto;
    margin: 2rem 0;
    
    code {
      background: transparent;
      padding: 0;
    }
  }
`;

const RelatedPosts = styled.div`
  margin-top: 5rem;
  padding-top: 3rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  animation: ${fadeIn} 0.6s ease-out;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
`;

const RelatedPostTitle = styled.h3`
  font-size: 1.8rem;
  font-weight: bold;
  margin-bottom: 2rem;
  color: white;
`;

const RelatedPostGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 2rem;
`;

const RelatedPostCard = styled.div`
  background: rgba(255, 255, 255, 0.03);
  border-radius: 16px;
  padding: 1.75rem;
  transition: all 0.4s ease;
  border: 1px solid rgba(255, 255, 255, 0.05);
  height: 100%;
  animation: ${staggeredFadeIn} 0.5s ease forwards;
  animation-delay: ${props => 0.4 + props.index * 0.1}s;
  opacity: 0;
  transform: translateY(20px);
  
  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 25px -15px rgba(155, 70, 255, 0.4);
    border-color: rgba(155, 70, 255, 0.3);
  }
`;

const RelatedPostTitle2 = styled.h4`
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1rem;
  color: white;
  line-height: 1.3;
`;

const RelatedPostExcerpt = styled.p`
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.95rem;
  line-height: 1.6;
`;

// Expanded blog data (in a real implementation, this would come from an API or data file)
const blogPosts = [
  {
    id: 1,
    title: "Getting Started with AI-Powered Learning",
    category: "AI Learning",
    excerpt: "Learn how to leverage AI to enhance your learning experience and achieve better results with personalized education paths.",
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "May 15, 2023",
    author: "Sarah Johnson",
    readTime: "6 min read",
    content: `
      <p>Artificial Intelligence is revolutionizing the way we learn. By personalizing content and adapting to individual learning styles, AI-powered platforms like Foster are making education more effective and engaging than ever before.</p>
      
      <h2>Understanding AI-Powered Learning</h2>
      
      <p>AI-powered learning uses algorithms and machine learning models to analyze your learning patterns, strengths, and weaknesses. This allows the system to create a personalized learning path that adapts to your needs in real-time.</p>
      
      <p>Here are some key benefits of AI-powered learning:</p>
      
      <ul>
        <li>Personalized learning experiences tailored to your unique needs</li>
        <li>Immediate feedback that helps you correct mistakes and reinforce knowledge</li>
        <li>Adaptive content that adjusts to your skill level as you progress</li>
        <li>Engagement techniques that keep you motivated and on track</li>
        <li>Data-driven insights that help you understand your learning patterns</li>
      </ul>
      
      <h2>Getting Started with Foster</h2>
      
      <p>Foster makes it easy to begin your AI-powered learning journey. Here's how to get started:</p>
      
      <h3>1. Create Your Profile</h3>
      
      <p>Sign up for a Foster account and complete your learning profile. This helps our AI understand your starting point, goals, and preferences.</p>
      
      <h3>2. Set Your Learning Goals</h3>
      
      <p>Define what you want to achieve. Whether it's mastering a new skill, preparing for an exam, or expanding your knowledge in a specific area, clear goals help our AI create an effective learning path.</p>
      
      <h3>3. Engage with the Content</h3>
      
      <p>Start working through the personalized content. As you interact with lessons, quizzes, and exercises, Foster's AI will adapt to your responses, providing additional support where needed and advancing you when you're ready.</p>
      
      <blockquote>
        "The Foster platform transformed my learning experience. The personalized approach helped me master concepts I had struggled with for years." - Alex, Foster User
      </blockquote>
      
      <h2>Tips for Success</h2>
      
      <p>To get the most out of your AI-powered learning experience:</p>
      
      <ul>
        <li>Maintain a regular schedule to build learning momentum</li>
        <li>Embrace the adaptive process, even when it challenges you</li>
        <li>Provide feedback to help the AI better understand your needs</li>
        <li>Use the analytics to identify patterns in your learning</li>
        <li>Join the Foster community to connect with other learners</li>
      </ul>
      
      <p>Ready to transform your learning experience? Foster's AI-powered platform is here to guide you every step of the way.</p>
    `
  },
  {
    id: 2,
    title: "The Future of Education with Foster",
    category: "Education",
    excerpt: "Discover how Foster is transforming education with adaptive learning technologies and what this means for the future of learning.",
    image: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "April 28, 2023",
    author: "Michael Chen",
    readTime: "8 min read",
    content: `
      <p>Education is undergoing a profound transformation, and Foster is at the forefront of this revolution. By integrating cutting-edge AI technology with evidence-based learning principles, we're creating educational experiences that are more personalized, engaging, and effective than traditional approaches.</p>
      
      <h2>The Limitations of Traditional Education</h2>
      
      <p>Traditional education has long followed a one-size-fits-all model, where students are expected to learn the same content at the same pace, regardless of their individual abilities, interests, or learning styles. This approach has several limitations:</p>
      
      <ul>
        <li>Students who learn at different paces are either left behind or held back</li>
        <li>Generic content fails to engage students with diverse interests</li>
        <li>Feedback is often delayed and generalized</li>
        <li>Assessment focuses on memorization rather than understanding</li>
        <li>Limited resources make individual attention difficult</li>
      </ul>
      
      <h2>Foster's Vision for the Future</h2>
      
      <p>At Foster, we're building a new educational paradigm that addresses these limitations through adaptive learning technologies.</p>
      
      <h3>Personalization at Scale</h3>
      
      <p>Our AI analyzes learning patterns to create truly personalized experiences for each student, adjusting content, pace, and teaching methods to match individual needs. This brings the benefits of one-on-one tutoring to every learner.</p>
      
      <h3>Real-time Adaptation</h3>
      
      <p>Foster's platform continuously adjusts to each learner's progress, identifying knowledge gaps and strengths to provide the right content at the right time. This ensures students are always working in their optimal challenge zone.</p>
      
      <blockquote>
        "Education must not simply teach work—it must teach life." - W.E.B. Du Bois
      </blockquote>
      
      <h2>The Impact of Foster's Approach</h2>
      
      <p>Early results from Foster implementations show promising outcomes:</p>
      
      <ul>
        <li>35% improvement in knowledge retention compared to traditional methods</li>
        <li>42% increase in student engagement and motivation</li>
        <li>28% reduction in time needed to master new concepts</li>
        <li>Significant improvements in student confidence and self-efficacy</li>
      </ul>
      
      <p>As we continue to refine our AI and expand our content offerings, these benefits will only grow, making high-quality, personalized education accessible to learners everywhere.</p>
    `
  },
  {
    id: 3,
    title: "Personalized Learning Paths: A Case Study",
    category: "Case Study",
    excerpt: "How personalized learning paths helped students improve their performance by 40%. See the data and results from our latest study.",
    image: "https://images.unsplash.com/photo-1515378960530-7c0da6231fb1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "March 12, 2023",
    author: "David Williams",
    readTime: "10 min read",
    content: `
      <p>In early 2022, Foster partnered with Westlake High School to implement our personalized learning platform in their mathematics department. The results were remarkable, with students showing significant improvements in both performance and engagement.</p>
      
      <h2>The Challenge</h2>
      
      <p>Westlake High School, like many educational institutions, faced several challenges in their mathematics education:</p>
      
      <ul>
        <li>A wide range of student abilities within the same classroom</li>
        <li>Limited resources for providing individualized instruction</li>
        <li>Declining student engagement with traditional teaching methods</li>
        <li>Achievement gaps between different student demographics</li>
        <li>Difficulty in identifying and addressing individual learning gaps</li>
      </ul>
      
      <h2>The Implementation</h2>
      
      <p>Foster worked closely with Westlake's mathematics department to implement our personalized learning platform. The implementation process included:</p>
      
      <h3>Initial Assessment Phase</h3>
      
      <p>Students completed a comprehensive diagnostic assessment to identify their current knowledge level, strengths, weaknesses, and learning preferences.</p>
      
      <h3>Personalized Curriculum Development</h3>
      
      <p>Based on assessment results, the Foster AI created individualized learning paths for each student, with custom content sequences and adaptive difficulty levels.</p>
      
      <h3>Teacher Training and Integration</h3>
      
      <p>Teachers received training on how to use the platform's analytics to inform their classroom instruction and provide targeted support to students.</p>
      
      <h3>Continuous Adaptation</h3>
      
      <p>As students progressed through the curriculum, the Foster platform continuously adjusted based on their performance, ensuring they were always working at the optimal challenge level.</p>
      
      <blockquote>
        "The Foster platform allowed me to finally reach every student at their level. I could see in real-time who was struggling and exactly what concepts they needed help with." - Maria Chen, Math Department Chair
      </blockquote>
      
      <h2>The Results</h2>
      
      <p>After one semester of implementation, the results exceeded expectations:</p>
      
      <ul>
        <li>40% improvement in average test scores compared to the previous year</li>
        <li>62% reduction in the number of students receiving failing grades</li>
        <li>35% increase in self-reported student engagement</li>
        <li>Significant narrowing of achievement gaps between different student demographics</li>
        <li>89% of students reported feeling more confident in their mathematical abilities</li>
      </ul>
      
      <p>The success at Westlake High School demonstrates the transformative potential of personalized learning paths. By adapting to each student's unique needs and providing targeted support exactly when it's needed, Foster is helping to create more equitable and effective educational experiences.</p>
    `
  },
  {
    id: 4,
    title: "AI Ethics in Educational Technology",
    category: "AI Ethics",
    excerpt: "Exploring the ethical considerations of using AI in educational settings. What developers and educators need to consider.",
    image: "https://images.unsplash.com/photo-1520333789090-1afc82db536a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "February 5, 2023",
    author: "Elena Rodriguez",
    readTime: "7 min read",
    content: `
      <p>As artificial intelligence becomes increasingly prevalent in educational settings, it's crucial to consider the ethical implications of these technologies. At Foster, ethical considerations are at the core of our development process, ensuring that our AI-powered learning platform enhances education while respecting privacy, promoting fairness, and maintaining human connection.</p>
      
      <h2>Privacy and Data Protection</h2>
      
      <p>Educational AI systems collect and analyze vast amounts of student data to provide personalized learning experiences. This raises important questions about privacy and data protection:</p>
      
      <ul>
        <li>What student data is being collected, and how is it being used?</li>
        <li>How is sensitive data stored and protected from breaches?</li>
        <li>Do students and parents have visibility into what data is collected?</li>
        <li>Are there clear options for consenting to data collection?</li>
        <li>How long is data retained, and what are the protocols for deletion?</li>
      </ul>
      
      <p>At Foster, we implement strict data protection measures and maintain transparency about our data practices. We collect only the information necessary to improve learning outcomes, store it securely, and give users control over their data.</p>
      
      <h2>Algorithmic Bias and Fairness</h2>
      
      <h3>The Challenge of Bias</h3>
      
      <p>AI systems can inadvertently perpetuate or amplify existing biases if not carefully designed and monitored. This is particularly concerning in educational contexts, where algorithmic bias could affect student opportunities and outcomes.</p>
      
      <blockquote>
        "The challenge isn't just creating accurate algorithms, but creating fair ones that serve all students equally well." - Dr. Aisha Johnson, AI Ethics Researcher
      </blockquote>
      
      <h3>Foster's Approach to Fairness</h3>
      
      <p>Our approach to addressing algorithmic bias includes:</p>
      
      <ul>
        <li>Diverse training data that represents various demographics, learning styles, and cultural contexts</li>
        <li>Regular bias audits conducted by internal teams and independent experts</li>
        <li>Continuous monitoring of outcomes across different student populations</li>
        <li>Transparent disclosure of how algorithms make recommendations</li>
        <li>Human oversight of algorithmic decisions, particularly high-stakes ones</li>
      </ul>
      
      <h2>Maintaining Human Connection</h2>
      
      <p>While AI can enhance education in many ways, it's essential to preserve the human elements of learning. Technology should support, not replace, the crucial role of teachers, mentors, and peer interactions in education.</p>
      
      <p>Foster's platform is designed to strengthen the teacher-student relationship by providing educators with insights that help them deliver more effective and personalized instruction. Our goal is to give teachers more time for meaningful interactions by handling routine tasks and providing data-driven insights.</p>
      
      <h2>The Path Forward</h2>
      
      <p>As educational AI continues to evolve, ongoing dialogue about ethics and responsible development is crucial. At Foster, we're committed to being part of this conversation and continuously improving our practices to ensure our technology serves all learners equitably and ethically.</p>
    `
  },
  {
    id: 5,
    title: "Building Effective Learning Habits",
    category: "Learning Tips",
    excerpt: "Discover the science-backed methods to develop strong learning habits that will help you retain information better and learn faster.",
    image: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "January 18, 2023",
    author: "Marcus Feng",
    readTime: "5 min read",
    content: `<p>Building effective learning habits is essential for long-term educational success. This article explores science-backed methods to develop strong habits that enhance learning efficiency and retention.</p>`
  },
  {
    id: 6,
    title: "How Machine Learning Is Reshaping Content Delivery",
    category: "Technology",
    excerpt: "The revolutionary impact of machine learning algorithms on educational content delivery and why it matters for learners.",
    image: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "December 7, 2022",
    author: "Priya Sharma",
    readTime: "9 min read",
    content: `<p>Machine learning is fundamentally changing how educational content is delivered to students. This article examines the technologies behind this revolution and their impact on learning outcomes.</p>`
  },
  {
    id: 7,
    title: "Bridging Educational Gaps with Technology",
    category: "Education",
    excerpt: "How Foster and similar platforms are working to make quality education accessible to everyone, regardless of location or background.",
    image: "https://images.unsplash.com/photo-1588702547923-7093a6c3ba33?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "November 14, 2022",
    author: "James Wilson",
    readTime: "6 min read",
    content: `<p>Educational technology is helping to bridge gaps in access to quality education. This article examines how Foster and similar platforms are democratizing learning opportunities worldwide.</p>`
  },
  {
    id: 8,
    title: "The Science of Memory: Optimizing Learning",
    category: "Learning Tips",
    excerpt: "Understanding how memory works and practical techniques to improve retention when studying with AI-assisted tools.",
    image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "October 29, 2022",
    author: "Sophia Martinez",
    readTime: "11 min read",
    content: `<p>Understanding the science of memory can significantly improve learning outcomes. This article explores memory formation processes and practical techniques to enhance retention when using AI-assisted learning tools.</p>`
  }
];

const BlogPost = () => {
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [relatedPosts, setRelatedPosts] = useState([]);
  
  useEffect(() => {
    // In a real implementation, you would fetch the post from an API
    const currentPost = blogPosts.find(post => post.id === parseInt(id));
    setPost(currentPost);
    
    if (currentPost) {
      // Find related posts in the same category
      const related = blogPosts.filter(p => 
        p.id !== currentPost.id && p.category === currentPost.category
      ).slice(0, 2);
      setRelatedPosts(related);
    }
    
    // Scroll to top when post changes
    window.scrollTo(0, 0);
  }, [id]);
  
  if (!post) {
    return (
      <div style={{ textAlign: 'center', padding: '5rem 0' }}>
        <h1 style={{ marginBottom: '1.5rem' }}>Post not found</h1>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <BackLink to="/blog">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Back to Blog
          </BackLink>
        </div>
      </div>
    );
  }
  
  return (
    <BlogPostContainer>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem' }}>
        <BackLink to="/blog">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.3"/>
          </svg>
          Back to Blog
        </BackLink>
      </div>
      
      <CategoryTag>{post.category}</CategoryTag>
      <span style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '0.9rem' }}>
        {post.readTime}
      </span>
      
      <BlogTitle>{post.title}</BlogTitle>
      
      <BlogMeta>
        <span>By {post.author}</span>
        <span>•</span>
        <span>{post.date}</span>
      </BlogMeta>
      
      <BlogImage>
        <img src={post.image} alt={post.title} />
      </BlogImage>
      
      <BlogContent dangerouslySetInnerHTML={{ __html: post.content }} />
      
      {relatedPosts.length > 0 && (
        <RelatedPosts>
          <RelatedPostTitle>Continue Reading</RelatedPostTitle>
          <RelatedPostGrid>
            {relatedPosts.map((related, index) => (
              <Link to={`/blog/${related.id}`} key={related.id}>
                <RelatedPostCard index={index}>
                  <RelatedPostTitle2>{related.title}</RelatedPostTitle2>
                  <RelatedPostExcerpt>
                    {related.excerpt.length > 100 
                      ? `${related.excerpt.substring(0, 100)}...` 
                      : related.excerpt
                    }
                  </RelatedPostExcerpt>
                </RelatedPostCard>
              </Link>
            ))}
          </RelatedPostGrid>
        </RelatedPosts>
      )}
    </BlogPostContainer>
  );
};

export default BlogPost; 