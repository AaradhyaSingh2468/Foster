import React from 'react';
import { Link } from 'react-router-dom';
import styled, { keyframes } from "styled-components";

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const float = keyframes`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-15px); }
`;

const shimmer = keyframes`
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

const NotFoundContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 8rem 1rem;
  text-align: center;
  color: white;
  animation: ${fadeIn} 0.6s ease-out;
  position: relative;
  
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(155, 70, 255, 0.1) 0%, rgba(0, 0, 0, 0) 70%);
    z-index: -1;
    opacity: 0.7;
  }
`;

const ErrorCode = styled.div`
  font-size: 8rem;
  font-weight: 900;
  line-height: 1;
  margin-bottom: 2rem;
  animation: ${float} 3s ease-in-out infinite;
  background: linear-gradient(90deg, var(--purple) 0%, var(--pink) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-size: 200% auto;
  animation: ${shimmer} 3s linear infinite, ${float} 3s ease-in-out infinite;
  
  @media (max-width: 768px) {
    font-size: 6rem;
  }
`;

const Title = styled.h1`
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
  background: linear-gradient(90deg, var(--purple) 0%, var(--pink) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  
  @media (max-width: 768px) {
    font-size: 2rem;
  }
`;

const Subtitle = styled.p`
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 3rem;
  max-width: 500px;
  line-height: 1.6;
`;

const StyledLink = styled(Link)`
  display: inline-flex;
  align-items: center;
  color: var(--purple);
  font-weight: 600;
  padding: 0.8rem 1.5rem;
  border: 2px solid var(--purple);
  border-radius: 30px;
  transition: all 0.3s ease;
  
  &:hover {
    background: var(--purple);
    color: white;
    transform: translateY(-3px);
    box-shadow: 0 10px 20px -10px rgba(155, 70, 255, 0.5);
    
    svg {
      transform: translateX(-3px);
    }
  }
  
  svg {
    margin-right: 0.8rem;
    transition: transform 0.3s ease;
  }
`;

const NotFound = () => {
  return (
    <NotFoundContainer>
      <ErrorCode>404</ErrorCode>
      <Title>Page Not Found</Title>
      <Subtitle>
        Oops! It seems the page you're looking for has vanished into the digital ether.
        Let's get you back to familiar territory.
      </Subtitle>
      <StyledLink to="/blog">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        Return to Blog
      </StyledLink>
    </NotFoundContainer>
  );
};

export default NotFound; 