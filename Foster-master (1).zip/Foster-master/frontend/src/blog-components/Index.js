import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import styled, { keyframes } from "styled-components";

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const staggeredFadeIn = keyframes`
  0% { opacity: 0; transform: translateY(20px); }
  100% { opacity: 1; transform: translateY(0); }
`;

const shimmer = keyframes`
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
`;

const BlogContainer = styled.div`
  width: 100%;
  color: white;
  animation: ${fadeIn} 0.5s ease-out;
`;

const Header = styled.div`
  margin-bottom: 3rem;
  text-align: center;
`;

const Title = styled.h1`
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
  background: linear-gradient(90deg, var(--purple) 0%, var(--pink) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-size: 200% auto;
  animation: ${shimmer} 3s linear infinite;
  
  @media (max-width: 768px) {
    font-size: 2.2rem;
  }
`;

const Subtitle = styled.p`
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.7);
  max-width: 640px;
  line-height: 1.6;
  margin: 0 auto;
`;

const CategoryContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 2rem;
`;

const CategoryButton = styled.button`
  background: ${props => props.active ? 'var(--purple)' : 'rgba(155, 70, 255, 0.1)'};
  color: ${props => props.active ? 'white' : 'rgba(255, 255, 255, 0.7)'};
  border: 1px solid ${props => props.active ? 'var(--purple)' : 'transparent'};
  border-radius: 20px;
  padding: 0.5rem 1.25rem;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${props => props.active ? 'var(--purple)' : 'rgba(155, 70, 255, 0.2)'};
    transform: translateY(-2px);
  }
  
  &:active {
    transform: translateY(0);
  }
`;

const SearchInput = styled.input`
  width: 100%;
  max-width: 300px;
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: white;
  padding: 0.8rem 1.2rem;
  border-radius: 10px;
  margin-bottom: 3rem;
  font-size: 1rem;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: var(--purple);
    box-shadow: 0 0 0 2px rgba(155, 70, 255, 0.2);
  }
  
  &::placeholder {
    color: rgba(255, 255, 255, 0.4);
  }
`;

const BlogGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 2.5rem;
`;

const BlogCard = styled.div`
  background: rgba(255, 255, 255, 0.03);
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.05);
  transition: all 0.4s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
  animation: ${staggeredFadeIn} 0.5s ease forwards;
  animation-delay: ${props => props.index * 0.1}s;
  opacity: 0;
  transform: translateY(20px);
  
  &:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 25px -15px rgba(155, 70, 255, 0.4);
    border-color: rgba(155, 70, 255, 0.3);
  }
`;

const BlogImage = styled.div`
  height: 200px;
  overflow: hidden;
  position: relative;
  
  &::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(0deg, rgba(10,11,16,0.2) 0%, rgba(10,11,16,0) 50%);
  }
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s ease;
  }
  
  ${BlogCard}:hover & img {
    transform: scale(1.08);
  }
`;

const BlogContent = styled.div`
  padding: 1.75rem;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
`;

const BlogCategory = styled.span`
  background: rgba(155, 70, 255, 0.15);
  color: var(--purple);
  padding: 0.4rem 1rem;
  border-radius: 20px;
  font-size: 0.8rem;
  display: inline-block;
  margin-bottom: 1rem;
  font-weight: 600;
  border: 1px solid rgba(155, 70, 255, 0.2);
`;

const BlogTitle = styled.h3`
  font-size: 1.4rem;
  font-weight: bold;
  margin-bottom: 1rem;
  line-height: 1.3;
  color: white;
`;

const BlogExcerpt = styled.p`
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 1.5rem;
  line-height: 1.6;
  flex-grow: 1;
`;

const BlogMeta = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.85rem;
  margin-bottom: 1rem;
  padding-top: 0.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
`;

const ReadMore = styled.span`
  color: var(--purple);
  font-weight: 500;
  font-size: 0.875rem;
  transition: all 0.3s ease;
  
  &:hover {
    color: var(--pink);
    text-decoration: underline;
  }
`;

const NoResults = styled.div`
  text-align: center;
  padding: 5rem 0;
  animation: ${fadeIn} 0.5s ease-out;
  
  h3 {
    font-size: 1.5rem;
    color: rgba(255, 255, 255, 0.7);
    margin-bottom: 1rem;
  }
  
  p {
    color: rgba(255, 255, 255, 0.5);
    max-width: 400px;
    margin: 0 auto;
  }
`;

// Expanded blog data
const blogPosts = [
  {
    id: 1,
    title: "Getting Started with AI-Powered Learning",
    category: "AI Learning",
    excerpt: "Learn how to leverage AI to enhance your learning experience and achieve better results with personalized education paths.",
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "May 15, 2023",
    author: "Sarah Johnson",
    readTime: "6 min read"
  },
  {
    id: 2,
    title: "The Future of Education with Foster",
    category: "Education",
    excerpt: "Discover how Foster is transforming education with adaptive learning technologies and what this means for the future of learning.",
    image: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "April 28, 2023",
    author: "Michael Chen",
    readTime: "8 min read"
  },
  {
    id: 3,
    title: "Personalized Learning Paths: A Case Study",
    category: "Case Study",
    excerpt: "How personalized learning paths helped students improve their performance by 40%. See the data and results from our latest study.",
    image: "https://images.unsplash.com/photo-1515378960530-7c0da6231fb1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "March 12, 2023",
    author: "David Williams",
    readTime: "10 min read"
  },
  {
    id: 4,
    title: "AI Ethics in Educational Technology",
    category: "AI Ethics",
    excerpt: "Exploring the ethical considerations of using AI in educational settings. What developers and educators need to consider.",
    image: "https://images.unsplash.com/photo-1520333789090-1afc82db536a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "February 5, 2023",
    author: "Elena Rodriguez",
    readTime: "7 min read"
  },
  {
    id: 5,
    title: "Building Effective Learning Habits",
    category: "Learning Tips",
    excerpt: "Discover the science-backed methods to develop strong learning habits that will help you retain information better and learn faster.",
    image: "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "January 18, 2023",
    author: "Marcus Feng",
    readTime: "5 min read"
  },
  {
    id: 6,
    title: "How Machine Learning Is Reshaping Content Delivery",
    category: "Technology",
    excerpt: "The revolutionary impact of machine learning algorithms on educational content delivery and why it matters for learners.",
    image: "https://images.unsplash.com/photo-1591696205602-2f950c417cb9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "December 7, 2022",
    author: "Priya Sharma",
    readTime: "9 min read"
  },
  {
    id: 7,
    title: "Bridging Educational Gaps with Technology",
    category: "Education",
    excerpt: "How Foster and similar platforms are working to make quality education accessible to everyone, regardless of location or background.",
    image: "https://images.unsplash.com/photo-1588702547923-7093a6c3ba33?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "November 14, 2022",
    author: "James Wilson",
    readTime: "6 min read"
  },
  {
    id: 8,
    title: "The Science of Memory: Optimizing Learning",
    category: "Learning Tips",
    excerpt: "Understanding how memory works and practical techniques to improve retention when studying with AI-assisted tools.",
    image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80",
    date: "October 29, 2022",
    author: "Sophia Martinez",
    readTime: "11 min read"
  }
];

const categories = ["All", "AI Learning", "Education", "Case Study", "AI Ethics", "Learning Tips", "Technology"];

const Index = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [filteredPosts, setFilteredPosts] = useState(blogPosts);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    filterPosts();
  }, [activeCategory, searchQuery]);

  const filterPosts = () => {
    let filtered = [...blogPosts];
    setIsSearching(!!searchQuery);
    
    // Filter by category
    if (activeCategory !== "All") {
      filtered = filtered.filter(post => post.category === activeCategory);
    }
    
    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(post => 
        post.title.toLowerCase().includes(query) || 
        post.excerpt.toLowerCase().includes(query) ||
        post.category.toLowerCase().includes(query) ||
        post.author.toLowerCase().includes(query)
      );
    }
    
    setFilteredPosts(filtered);
  };

  const clearSearch = () => {
    setSearchQuery("");
    setIsSearching(false);
  };

  return (
    <BlogContainer>
      <Header>
        <Title>Foster Blog</Title>
        <Subtitle>Insights, tips, and resources to enhance your AI-powered learning journey. Explore our latest articles about education, technology, and more.</Subtitle>
      </Header>
      
      <CategoryContainer>
        {categories.map(category => (
          <CategoryButton 
            key={category}
            active={activeCategory === category}
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </CategoryButton>
        ))}
      </CategoryContainer>
      
      <div style={{ position: 'relative', marginBottom: '3rem' }}>
        <SearchInput 
          type="text"
          placeholder="Search articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        {isSearching && (
          <button 
            onClick={clearSearch}
            style={{ 
              position: 'absolute', 
              right: '310px', 
              top: '50%', 
              transform: 'translateY(-50%)',
              background: 'none',
              border: 'none',
              color: 'var(--purple)',
              cursor: 'pointer',
              fontSize: '0.9rem'
            }}
          >
            Clear
          </button>
        )}
      </div>
      
      {isSearching && (
        <div style={{ marginBottom: '2rem', color: 'rgba(255, 255, 255, 0.6)' }}>
          Found {filteredPosts.length} {filteredPosts.length === 1 ? 'result' : 'results'} 
          {searchQuery ? ` for "${searchQuery}"` : ''}
        </div>
      )}
      
      {filteredPosts.length > 0 ? (
        <BlogGrid>
          {filteredPosts.map((post, index) => (
            <BlogCard key={post.id} index={index}>
              <BlogImage>
                <img src={post.image} alt={post.title} />
              </BlogImage>
              <BlogContent>
                <BlogCategory>{post.category}</BlogCategory>
                <BlogTitle>{post.title}</BlogTitle>
                <BlogExcerpt>{post.excerpt}</BlogExcerpt>
                <BlogMeta>
                  <span>{post.date}</span>
                  <Link to={`/blog/${post.id}`}>
                    <ReadMore>
                      Read more
                    </ReadMore>
                  </Link>
                </BlogMeta>
              </BlogContent>
            </BlogCard>
          ))}
        </BlogGrid>
      ) : (
        <NoResults>
          <h3>No articles found</h3>
          <p>
            {searchQuery 
              ? `No results found for "${searchQuery}". Try a different search term or category.` 
              : "Try adjusting your search or category filters"}
          </p>
        </NoResults>
      )}
    </BlogContainer>
  );
};

export default Index; 