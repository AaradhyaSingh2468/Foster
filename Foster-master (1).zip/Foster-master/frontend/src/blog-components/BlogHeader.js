import { useEffect, useRef, useState } from "react";
import styled from "styled-components";
import logo from "../assets/logo.svg";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Headers = styled.header`
  height: 3rem;
  background-color: #0a0b10;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 calc(3rem + 3vw);
  position: sticky;
  top: 0;
  z-index: 60;
  @media only Screen and (max-width: 48em) {
    padding: 0 calc(2rem + 2vw);
  }
  @media only Screen and (max-width: 30em) {
    padding: 0 calc(1.5rem + 1.5vw);
  }
`;

const Logo = styled(Link)`
  display: flex;
  align-items: center;
  width: 3rem;
  height: auto;
  cursor: pointer;
  img {
    margin-right: 0.5rem;
    width: 3rem;
    height: 3rem;
  }
  h3 {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--pink);
  }
`;

const Nav = styled.nav`
  width: auto;
  min-width: 28rem;
  max-width: 60rem;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: nowrap;
  transition: all 0.3s;
  @media only Screen and (max-width: 48em) {
    display: none;
  }
  a {
    font-weight: 600;
    line-height: 1.5;
    color: var(--white);
    margin-right: 1.8rem;
    white-space: nowrap;
    &::after {
      content: "";
      display: block;
      height: 3px;
      width: 0;
      background: transparent;
      transition: width 0.5s;
    }
    &:not(:last-child):hover::after {
      width: 100%;
      background: var(--purple);
    }
  }
  & > *:last-child {
    margin-right: 0;
    margin-left: auto;
  }
`;

const Button = styled.button`
  background-color: var(--purple);
  padding: 0.5rem 1rem;
  border-radius: 20px;
  color: var(--white);
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  &:hover {
    transform: scale(1.1);
  }
  &:focus {
    transform: scale(0.9);
  }
  @media only Screen and (max-width: 40em) {
    font-size: 1.2rem;
    &:hover {
      transform: none;
    }
    &:focus {
      transform: none;
    }
  }
`;

const HamburgerBtn = styled.button`
  display: none;
  @media only Screen and (max-width: 48em) {
    display: inline-block;
  }
  position: relative;
  background-color: transparent;
  width: 2rem;
  height: 2px;
  margin-top: 0rem;
  transition: all 0.3s;
  cursor: pointer;
  &::before,
  &::after {
    content: "";
    background-color: var(--white);
    width: 2rem;
    height: 2px;
    display: inline-block;
    position: absolute;
    left: 0;
    cursor: pointer;

    transition: all 0.3s;
  }
  &::before {
    top: ${(props) => (props.clicked ? "0" : "-0.5rem")};
    transform: ${(props) => (props.clicked ? "rotate(135deg)" : "rotate(0)")};
  }
  &::after {
    top: ${(props) => (props.clicked ? "0" : "0.5rem")};
    transform: ${(props) => (props.clicked ? "rotate(-135deg)" : "rotate(0)")};
  }
`;

const MobileMenu = styled.nav`
  display: none;
  @media only Screen and (max-width: 48em) {
    display: flex;
  }
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem 0;
  overflow-x: hidden;
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  opacity: ${(props) => (props.clicked ? "1" : 0)};
  visibility: ${(props) => (props.clicked ? "visible" : "hidden")};
  transition: all 0.5s;
  z-index: -10;
  background-color: rgb(53 53 63 / 95%);
  border-radius: 20px;
  margin: 0.5rem;
  a {
    color: var(--white);
    font-weight: 600;
    font-size: 1.5rem;
    margin: 1.5rem;
    cursor: pointer;
  }
`;

const BlogHeader = () => {
  const [click, setClick] = useState(false);
  const ref = useRef(null);
  const { currentUser } = useAuth();

  return (
    <Headers ref={ref}>
      <Logo to="/">
        <img src={logo} alt="Foster" />
        <h3>Foster</h3>
      </Logo>
      <Nav>
        <Link to="/">Home</Link>
        <Link to="/#about">About Us</Link>
        <Link to="/#services">Services</Link>
        <Link to="/#contact">Contact Us</Link>
        <Link to="/blog">Blog</Link>
        {currentUser ? (
          <Link to="/study-dashboard">
            <Button>Dashboard</Button>
          </Link>
        ) : (
          <Link to="/auth">
            <Button>Sign In</Button>
          </Link>
        )}
      </Nav>
      <HamburgerBtn clicked={+click} onClick={() => setClick(!click)}>
        <span></span>
      </HamburgerBtn>
      <MobileMenu clicked={+click}>
        <Link to="/">Home</Link>
        <Link to="/#about">About Us</Link>
        <Link to="/#services">Services</Link>
        <Link to="/#contact">Contact Us</Link>
        <Link to="/blog">Blog</Link>
        {currentUser ? (
          <Link to="/study-dashboard">
            <Button>Dashboard</Button>
          </Link>
        ) : (
          <Link to="/auth">
            <Button>Sign In</Button>
          </Link>
        )}
      </MobileMenu>
    </Headers>
  );
};

export default BlogHeader; 