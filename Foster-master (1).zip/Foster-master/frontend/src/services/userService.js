import api from '../config/api';

// User Authentication
export const loginWithEmail = async (email, password) => {
  const response = await api.post('/auth/login', { email, password });
  
  // Store tokens in localStorage
  if (response.data.access && response.data.refresh) {
    localStorage.setItem('accessToken', response.data.access);
    localStorage.setItem('refreshToken', response.data.refresh);
    localStorage.setItem('user', JSON.stringify(response.data.user));
    
    // Store session ID if present
    if (response.data.session_id) {
      localStorage.setItem('sessionId', response.data.session_id);
    }
  }
  
  return response.data;
};

export const registerWithEmail = async (userData) => {
  const response = await api.post('/auth/register', userData);
  
  // Store tokens in localStorage
  if (response.data.access && response.data.refresh) {
    localStorage.setItem('accessToken', response.data.access);
    localStorage.setItem('refreshToken', response.data.refresh);
    localStorage.setItem('user', JSON.stringify(response.data.user));
    
    // Store session ID if present
    if (response.data.session_id) {
      localStorage.setItem('sessionId', response.data.session_id);
    }
  }
  
  return response.data;
};

export const authenticateWithGoogle = async (tokenId) => {
  const response = await api.post('/auth/google', { tokenId });
  
  // Store tokens in localStorage
  if (response.data.access && response.data.refresh) {
    localStorage.setItem('accessToken', response.data.access);
    localStorage.setItem('refreshToken', response.data.refresh);
    
    // Store user data and preserve is_new_user flag
    const userData = {
      ...response.data.user,
      is_new_user: response.data.is_new_user || false
    };
    localStorage.setItem('user', JSON.stringify(userData));
    
    // Store session ID if present
    if (response.data.session_id) {
      localStorage.setItem('sessionId', response.data.session_id);
    }
  }
  
  return response.data;
};

export const authenticateWithGithub = async (token) => {
  const response = await api.post('/auth/github', { token });
  
  // Store tokens in localStorage
  if (response.data.access && response.data.refresh) {
    localStorage.setItem('accessToken', response.data.access);
    localStorage.setItem('refreshToken', response.data.refresh);
    
    // Store user data and preserve is_new_user flag
    const userData = {
      ...response.data.user,
      is_new_user: response.data.is_new_user || false
    };
    localStorage.setItem('user', JSON.stringify(userData));
    
    // Store session ID if present
    if (response.data.session_id) {
      localStorage.setItem('sessionId', response.data.session_id);
    }
  }
  
  return response.data;
};

export const refreshToken = async () => {
  const refreshToken = localStorage.getItem('refreshToken');
  if (!refreshToken) {
    throw new Error('No refresh token available');
  }
  
  const response = await api.post('/auth/token/refresh', { refresh: refreshToken });
  
  if (response.data.access) {
    localStorage.setItem('accessToken', response.data.access);
  }
  
  return response.data;
};

export const resetPassword = async (email) => {
  const response = await api.post('/auth/reset-password', { email });
  return response.data;
};

export const verifyResetToken = async (token) => {
  const response = await api.get(`/auth/verify-reset/${token}`);
  return response.data;
};

export const setNewPassword = async (token, password) => {
  const response = await api.post('/auth/reset-password/confirm', { token, password });
  
  // If response includes tokens, store them
  if (response.data.access && response.data.refresh) {
    localStorage.setItem('accessToken', response.data.access);
    localStorage.setItem('refreshToken', response.data.refresh);
  }
  
  return response.data;
};

export const logout = async () => {
  try {
    const response = await api.post('/auth/logout');
    return response.data;
  } catch (error) {
    throw error;
  }
};

// User Profile
export const getUserProfile = async () => {
  try {
    const response = await api.get('/users/profile/');
    console.log('Profile API response:', response.status, response.data);
    
    // Add more detailed logging about onboarding_completed type
    if (response.data && 'onboarding_completed' in response.data) {
      console.log(
        `Onboarding completed value: ${response.data.onboarding_completed}, ` +
        `Type: ${typeof response.data.onboarding_completed}, ` +
        `JSON value: ${JSON.stringify(response.data.onboarding_completed)}`
      );
    }
    
    return response.data;
  } catch (error) {
    console.error('Error getting user profile:', error.response?.status, error.response?.data || error.message);
    throw error;
  }
};

export const updateUserProfile = async (profileData) => {
  try {
    // Remove the _id field to avoid MongoDB immutable field error
    const { _id, ...profileDataWithoutId } = profileData;
    
    const response = await api.put('/users/profile/', profileDataWithoutId);
    return response.data;
  } catch (error) {
    console.error('Error updating user profile:', error.response?.status, error.response?.data || error.message);
    throw error;
  }
};

export const updateUserAvatar = async (imageFile) => {
  try {
    const formData = new FormData();
    formData.append('avatar', imageFile);
    
    const response = await api.post('/users/avatar/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    // If successful, update the local user data with the new avatar URL
    if (response.data && response.data.avatar_url) {
      const userData = JSON.parse(localStorage.getItem('user') || '{}');
      userData.avatar = response.data.avatar_url;
      localStorage.setItem('user', JSON.stringify(userData));
    }
    
    return response.data;
  } catch (error) {
    console.error('Error updating avatar:', error);
    throw error;
  }
};

// Set avatar from URL (for OAuth providers)
export const setAvatarFromOAuth = async (avatarUrl) => {
  try {
    // Save the avatar URL to the backend
    const response = await api.post('/users/avatar-url/', { avatarUrl });
    
    // Update local storage
    if (response.data && response.data.avatar_url) {
      const userData = JSON.parse(localStorage.getItem('user') || '{}');
      userData.avatar = response.data.avatar_url;
      localStorage.setItem('user', JSON.stringify(userData));
    }
    
    return response.data;
  } catch (error) {
    console.error('Error setting avatar from OAuth:', error);
    // We'll still update the local storage even if the API call fails
    // This ensures the user sees their avatar immediately after login
    const userData = JSON.parse(localStorage.getItem('user') || '{}');
    userData.avatar = avatarUrl;
    localStorage.setItem('user', JSON.stringify(userData));
    
    throw error;
  }
};

// User Preferences
export const getUserPreferences = async () => {
  const response = await api.get('/users/preferences');
  return response.data;
};

export const updateUserPreferences = async (preferences) => {
  const response = await api.put('/users/preferences', preferences);
  return response.data;
};

// Onboarding
export const updateOnboardingStatus = async (onboardingData) => {
  const response = await api.post('/users/onboarding', onboardingData);
  return response.data;
};

// Get all user sessions
export const getUserSessions = async () => {
  try {
    const response = await api.get('/auth/sessions');
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Terminate a specific session
export const terminateSession = async (sessionId) => {
  try {
    const response = await api.delete(`/auth/sessions/${sessionId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Logout from all sessions
export const logoutAll = async (keepCurrent = false) => {
  try {
    const response = await api.post('/auth/logout-all', { keep_current: keepCurrent });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Force refresh user profile (bypassing any cache)
export const refreshUserProfile = async () => {
  try {
    // Add cache-busting parameter to force a fresh request
    const response = await api.get('/users/profile/?_t=' + Date.now());
    console.log('Forced profile refresh response:', response.status, response.data);
    
    if (response.data && 'onboarding_completed' in response.data) {
      console.log(
        `Refreshed onboarding status: ${response.data.onboarding_completed}, ` +
        `Type: ${typeof response.data.onboarding_completed}`
      );
    }
    
    return response.data;
  } catch (error) {
    console.error('Error refreshing profile:', error.response?.status, error.response?.data || error.message);
    throw error;
  }
};

// Delete user account (both Firebase and MongoDB)
export const deleteUserAccount = async () => {
  try {
    const response = await api.delete('/users/delete');
    
    // Clear all auth data from localStorage
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    localStorage.removeItem('sessionId');
    
    return response.data;
  } catch (error) {
    console.error('Error deleting user account:', error);
    throw error;
  }
};

// A helper function to check if a user has completed onboarding
export const hasCompletedOnboarding = async () => {
  try {
    const response = await api.get('/users/profile/');
    return response.data && response.data.onboarding_completed === true;
  } catch (error) {
    console.error('Error checking onboarding status:', error);
    return false;
  }
};

// Debug helpers
export const checkAuthStatus = async () => {
  try {
    console.log('Checking auth status...');
    const response = await api.get('/debug-auth/');
    console.log('Auth check successful:', response.data);
    return response.data;
  } catch (error) {
    console.error('Auth check failed:', error.response?.status, error.response?.data);
    throw error;
  }
};

export const checkAndFixProfilePicture = async () => {
  try {
    // First get current user profile
    const profileData = await getUserProfile();
    
    // Check if profile exists and has no avatar
    if (!profileData || !profileData.avatar) {
      console.log("Profile missing or has no avatar, checking for OAuth picture");
      
      // Get user data from localStorage
      const userData = JSON.parse(localStorage.getItem('user') || '{}');
      
      // Check if we have a photoURL from Firebase
      if (userData.photoURL) {
        console.log("Found photoURL in user data, setting as avatar");
        await setAvatarFromOAuth(userData.photoURL);
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error('Error checking/fixing profile picture:', error);
    return false;
  }
}; 