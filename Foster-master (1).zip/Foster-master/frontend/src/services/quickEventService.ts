import api from '../config/api';
import type { CalendarEvent } from './types';

/**
 * Helper function for quick event creation
 * @param title The event title
 * @param startTime Local date object that will be converted to UTC for storage
 * @param durationMinutes Duration in minutes
 */
export const createQuickEvent = async (title: string, startTime?: Date, durationMinutes = 60): Promise<CalendarEvent> => {
  try {
    // Prepare request data
    const requestData: any = { title, duration_minutes: durationMinutes };
    
    // Add start time if provided - ensure proper ISO format (UTC)
    if (startTime) {
      console.log('Creating quick event with:');
      console.log('  - Title:', title);
      console.log('  - Local time object:', startTime.toString());
      console.log('  - Local timezone:', Intl.DateTimeFormat().resolvedOptions().timeZone);
      console.log('  - UTC ISO string:', startTime.toISOString());
      console.log('  - Duration (minutes):', durationMinutes);
      
      // When a Date object is converted to ISO string, it's automatically in UTC
      requestData.start_time = startTime.toISOString();
    }
    
    console.log('Sending request data to backend:', requestData);
    
    // Use the calendar quick-event endpoint for simplified event creation
    const response = await api.post('/calendar/quick-event/', requestData);
    console.log('Quick event created:', response.data);
    
    // Map response back to frontend format
    const event = {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description,
      startTime: response.data.start_time, // This is in UTC from the server
      endTime: response.data.end_time, // This is in UTC from the server
      eventType: response.data.event_type,
      location: response.data.location,
      reminder: response.data.reminder,
      reminderTime: response.data.reminder_time,
      createdAt: response.data.created_at
    };
    
    console.log('Parsed event timings:',  {
      startTimeFromServer: event.startTime,
      endTimeFromServer: event.endTime,
      parsedStartLocal: new Date(event.startTime).toLocaleString(),
      parsedEndLocal: new Date(event.endTime).toLocaleString()
    });
    
    return event;
  } catch (error) {
    console.error('Error creating quick event:', error);
    throw error;
  }
}; 