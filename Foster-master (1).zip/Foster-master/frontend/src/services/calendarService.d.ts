// Type definitions for calendarService

import type { CalendarEvent, RecurringEvent, Reminder, CalendarSettings } from './types';

interface CalendarEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  description?: string;
  eventType?: string;
  location?: string;
  reminder?: boolean;
  reminderTime?: number;
  createdAt?: string;
}

interface RecurringEventData {
  title: string;
  startTime: string;
  endTime: string;
  description?: string;
  reminder?: boolean;
  reminderTime?: number;
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  interval?: number;
  endDate?: string;
  occurrences?: number;
}

interface ReminderData {
  eventId: string;
  time: string;
  message?: string;
  notificationType?: 'email' | 'push' | 'sms' | 'in-app';
}

interface CalendarSettings {
  defaultView: 'day' | 'week' | 'month' | 'agenda';
  weekStartsOn: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  defaultReminderTime: number; // minutes before event
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
  };
}

// Calendar Events
export function getEvents(startDate: string, endDate: string): Promise<CalendarEvent[]>;
export function getEvent(eventId: string): Promise<CalendarEvent>;
export function createEvent(eventData: Omit<CalendarEvent, 'id'>): Promise<CalendarEvent>;
export function updateEvent(eventId: string, eventData: Partial<CalendarEvent>): Promise<CalendarEvent>;
export function deleteEvent(eventId: string): Promise<void>;

// Recurring Events
export function createRecurringEvent(recurringEventData: Omit<RecurringEvent, 'id'>): Promise<RecurringEvent>;
export function updateRecurringEvent(eventId: string, updateData: Partial<RecurringEvent>): Promise<RecurringEvent>;
export function deleteRecurringEvent(eventId: string, deleteOptions: { deleteAll?: boolean }): Promise<void>;

// Reminders
export function getReminders(): Promise<Reminder[]>;
export function createReminder(reminderData: Omit<Reminder, 'id'>): Promise<Reminder>;
export function updateReminder(reminderId: string, reminderData: Partial<Reminder>): Promise<Reminder>;
export function deleteReminder(reminderId: string): Promise<void>;

// Calendar Settings
export function getCalendarSettings(): Promise<CalendarSettings>;
export function updateCalendarSettings(settingsData: Partial<CalendarSettings>): Promise<CalendarSettings>; 