import api from '../config/api';
import type { CalendarEvent, RecurringEvent, Reminder, CalendarSettings } from './types';

// Cache for calendar events - disable caching to ensure events are always fetched fresh
let cachedEvents: CalendarEvent[] | null = null;
let lastEventsFetchTime = 0;
const EVENTS_CACHE_TTL = 0; // Disable caching to ensure fresh data

// Calendar Events
export const getEvents = async (startDate: string, endDate: string): Promise<CalendarEvent[]> => {
  try {
    // Always fetch fresh data to avoid stale events
    cachedEvents = null;
    
    // Format query parameters
    const params = new URLSearchParams();
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);
    
    console.log(`Fetching calendar events from ${startDate} to ${endDate}`);
    const endpoint = `/calendar/events/?${params.toString()}`;
    const response = await api.get(endpoint);
    
    console.log("Raw API response:", response.data);
    
    // Map backend data to frontend format
    const events = response.data.map((event: any) => {
      // UTC dates from the backend - handle snake_case field names
      const rawStartTime = event.start_time || event.startTime;
      const rawEndTime = event.end_time || event.endTime;
      
      let startTime, endTime;
      
      // Parse the ISO string from backend (UTC) into a JavaScript Date
      try {
        // This creates a local Date object from the UTC string
        startTime = new Date(rawStartTime);
        console.log(`Event "${event.title}" - UTC start time: ${rawStartTime}, parsed as local: ${startTime.toLocaleString()}`);
        
        if (isNaN(startTime.getTime())) {
          console.warn(`Invalid start_time format: ${rawStartTime}`);
          startTime = new Date();
        }
      } catch (e) {
        console.error(`Error parsing start_time: ${rawStartTime}`, e);
        startTime = new Date();
      }
      
      try {
        // This creates a local Date object from the UTC string
        endTime = new Date(rawEndTime);
        console.log(`Event "${event.title}" - UTC end time: ${rawEndTime}, parsed as local: ${endTime.toLocaleString()}`);
        
        if (isNaN(endTime.getTime())) {
          console.warn(`Invalid end_time format: ${rawEndTime}`);
          endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // Default to 1 hour later
        }
      } catch (e) {
        console.error(`Error parsing end_time: ${rawEndTime}`, e);
        endTime = new Date(startTime.getTime() + 60 * 60 * 1000);
      }
      
      // Store the original UTC strings and the local Date objects
      return {
        id: event.id,
        title: event.title,
        description: event.description || '',
        startTime: rawStartTime, // Keep the original UTC ISO string exactly as received
        endTime: rawEndTime, // Keep the original UTC ISO string exactly as received
        startTimeLocal: startTime, // The parsed local Date object (not used currently)
        endTimeLocal: endTime, // The parsed local Date object (not used currently)
        eventType: event.event_type || event.eventType || 'study_session',
        location: event.location || '',
        reminder: event.reminder !== undefined ? event.reminder : true,
        reminderTime: event.reminder_time || event.reminderTime || 15
      };
    });
    
    console.log(`Fetched ${events.length} calendar events`);
    console.log("First event after mapping:", events.length > 0 ? events[0] : "No events");
    return events;
  } catch (error: any) {
    console.error('Error fetching events:', error);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
    return [];
  }
};

export const getEvent = async (eventId: string): Promise<CalendarEvent> => {
  try {
    console.log(`Fetching event with ID: ${eventId}`);
    const response = await api.get(`/calendar/events/${eventId}/`);
    
    console.log("Raw event data:", response.data);
    
    // Map backend data to frontend format (handle both snake_case and camelCase)
    return {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description || response.data.desc || '',
      startTime: response.data.start_time || response.data.startTime,
      endTime: response.data.end_time || response.data.endTime,
      eventType: response.data.event_type || response.data.eventType || 'study_session',
      location: response.data.location || '',
      reminder: response.data.reminder !== undefined ? response.data.reminder : true,
      reminderTime: response.data.reminder_time || response.data.reminderTime || 15,
      createdAt: response.data.created_at || response.data.createdAt
    };
  } catch (error) {
    console.error(`Error fetching event ${eventId}:`, error);
    throw error;
  }
};

export const createEvent = async (eventData: Omit<CalendarEvent, 'id'>): Promise<CalendarEvent> => {
  try {
    console.log('Creating event with data:', eventData);
    // Map frontend data to backend format (use snake_case for API)
    const backendData = {
      title: eventData.title,
      description: eventData.description || '',
      start_time: eventData.startTime,
      end_time: eventData.endTime,
      event_type: eventData.eventType || 'custom',
      location: eventData.location || '',
      reminder: eventData.reminder !== undefined ? eventData.reminder : true,
      reminder_time: eventData.reminderTime || 15
    };
    
    const response = await api.post('/calendar/events/', backendData);
    console.log('Event created successfully, raw response:', response.data);
    
    // Map response back to frontend format (handle both snake_case and camelCase)
    const createdEvent = {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description || response.data.desc || '',
      startTime: response.data.start_time || response.data.startTime,
      endTime: response.data.end_time || response.data.endTime,
      eventType: response.data.event_type || response.data.eventType || 'study_session',
      location: response.data.location || '',
      reminder: response.data.reminder !== undefined ? response.data.reminder : true,
      reminderTime: response.data.reminder_time || response.data.reminderTime || 15,
      createdAt: response.data.created_at || response.data.createdAt
    };
    
    // Invalidate cache
    cachedEvents = null;
    
    return createdEvent;
  } catch (error) {
    console.error('Error creating event:', error);
    throw error;
  }
};

export const updateEvent = async (eventId: string, eventData: Partial<CalendarEvent>): Promise<CalendarEvent> => {
  try {
    console.log(`Updating event ${eventId} with data:`, eventData);
    // Map frontend data to backend format (use snake_case for API)
    const backendData: any = {};
    
    if (eventData.title !== undefined) backendData.title = eventData.title;
    if (eventData.description !== undefined) backendData.description = eventData.description;
    if (eventData.startTime !== undefined) backendData.start_time = eventData.startTime;
    if (eventData.endTime !== undefined) backendData.end_time = eventData.endTime;
    if (eventData.eventType !== undefined) backendData.event_type = eventData.eventType;
    if (eventData.location !== undefined) backendData.location = eventData.location;
    if (eventData.reminder !== undefined) backendData.reminder = eventData.reminder;
    if (eventData.reminderTime !== undefined) backendData.reminder_time = eventData.reminderTime;
    
    const response = await api.put(`/calendar/events/${eventId}/`, backendData);
    console.log('Event updated successfully, raw response:', response.data);
    
    // Map response back to frontend format (handle both snake_case and camelCase)
    const updatedEvent = {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description || response.data.desc || '',
      startTime: response.data.start_time || response.data.startTime,
      endTime: response.data.end_time || response.data.endTime,
      eventType: response.data.event_type || response.data.eventType || 'study_session',
      location: response.data.location || '',
      reminder: response.data.reminder !== undefined ? response.data.reminder : true,
      reminderTime: response.data.reminder_time || response.data.reminderTime || 15,
      createdAt: response.data.created_at || response.data.createdAt
    };
    
    // Invalidate cache
    cachedEvents = null;
    
    return updatedEvent;
  } catch (error) {
    console.error(`Error updating event ${eventId}:`, error);
    throw error;
  }
};

export const deleteEvent = async (eventId: string): Promise<void> => {
  try {
    console.log(`Attempting to delete event with ID: ${eventId}`);
    const response = await api.delete(`/calendar/events/${eventId}/`);
    console.log(`Delete event response:`, response);
    
    // Invalidate cache
    cachedEvents = null;
  } catch (error: any) {
    console.error(`Error deleting calendar event ${eventId}:`, error);
    // Log detailed error information
    if (error.response) {
      console.error(`Status: ${error.response.status}, Data:`, error.response.data);
    }
    throw error;
  }
};



// Recurring Events - can be implemented later if needed
export const createRecurringEvent = async (recurringEventData: Omit<RecurringEvent, 'id'>): Promise<RecurringEvent> => {
  throw new Error('Not implemented yet');
};

export const updateRecurringEvent = async (eventId: string, updateData: Partial<RecurringEvent>): Promise<RecurringEvent> => {
  throw new Error('Not implemented yet');
};

export const deleteRecurringEvent = async (eventId: string, deleteOptions: { deleteAll?: boolean }): Promise<void> => {
  throw new Error('Not implemented yet');
};

// Reminders - can be implemented later if needed
export const getReminders = async (): Promise<Reminder[]> => {
  throw new Error('Not implemented yet');
};

export const createReminder = async (reminderData: Omit<Reminder, 'id'>): Promise<Reminder> => {
  throw new Error('Not implemented yet');
};

export const updateReminder = async (reminderId: string, reminderData: Partial<Reminder>): Promise<Reminder> => {
  throw new Error('Not implemented yet');
};

export const deleteReminder = async (reminderId: string): Promise<void> => {
  throw new Error('Not implemented yet');
};

// Calendar Settings - can be implemented later if needed
export const getCalendarSettings = async (): Promise<CalendarSettings> => {
  return {
    defaultView: 'week',
    weekStartsOn: 0, // Sunday
    defaultReminderTime: 15,
    notifications: {
      email: true,
      push: true,
      sms: false
    }
  };
};

export const updateCalendarSettings = async (settingsData: Partial<CalendarSettings>): Promise<CalendarSettings> => {
  throw new Error('Not implemented yet');
}; 