import { auth } from "../config/firebase";
import { refreshStudySets } from "./studyBuddyService";

// Add global variable to store notifications
if (typeof window !== 'undefined') {
  window.websocketNotifications = window.websocketNotifications || [];
}

export interface WebSocketListener {
  onMessage: (data: any) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Event) => void;
}

type MessageHandlers = {
  [key: string]: (data: any) => void;
};

class WebSocketService {
  private socket: WebSocket | null = null;
  private listeners: Map<string, WebSocketListener> = new Map();
  private messageHandlers: MessageHandlers = {};
  private reconnectTimer: NodeJS.Timeout | null = null;
  private reconnectAttempt: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectDelay: number = 2000; // Start with 2 seconds
  private connected: boolean = false;
  private connecting: boolean = false;
  private baseUrl: string;
  private pingIntervalId: NodeJS.Timeout | null = null;
  private pingIntervalMs: number = 30000; // Send ping every 30 seconds
  private connectionAttemptTimestamp: number = 0; // Add timestamp tracking

  // Add a notification buffer to store important notifications until they can be processed
  private notificationBuffer: {[key: string]: any[]} = {};

  constructor() {
    // Determine WebSocket URL based on current environment
    const isSecure = window.location.protocol === 'https:';
    const wsProtocol = isSecure ? 'wss://' : 'ws://';
    const hostname = window.location.hostname;
    const port = hostname === 'localhost' ? ':8000' : (window.location.port ? `:${window.location.port}` : '');
    this.baseUrl = `${wsProtocol}${hostname}${port}`;
    
    console.log(`WebSocket base URL configured as: ${this.baseUrl}`);
    
    // Setup handlers for window events
    window.addEventListener('online', this.handleOnline);
    window.addEventListener('offline', this.handleOffline);
    document.addEventListener('visibilitychange', this.handleVisibilityChange);
  }

  private handleOnline = () => {
    console.log('Network connection restored, attempting to reconnect WebSocket');
    if (this.socket) {
      // We can't just reconnect the same socket after network loss
      // Need to create a new connection
      this.socket.close();
      this.socket = null;
      this.connected = false;
      
      // Try to reconnect immediately when network is back
      this.reconnectAttempt = 0;
      if (this.listeners.size > 0) {
        // Get the first endpoint we were connected to
        const endpoint = this.listeners.keys().next().value;
        if (endpoint) {
          this.connect(endpoint, {} as WebSocketListener, 'reconnect');
        }
      }
    }
  };

  private handleOffline = () => {
    console.log('Network connection lost, WebSocket will disconnect');
    // No need to manually disconnect - the browser will do that
    // Just update our state
    this.connected = false;
  };

  private handleVisibilityChange = () => {
    if (!document.hidden && !this.connected && this.listeners.size > 0) {
      console.log('Tab became visible, checking WebSocket connection');
      // If page became visible and we're not connected, try to reconnect
      const endpoint = this.listeners.keys().next().value;
      if (endpoint) {
        this.connect(endpoint, {} as WebSocketListener, 'reconnect');
      }
    }
  };

  // New method to update a listener without reconnecting
  public updateListener(listenerKey: string, listener: WebSocketListener) {
    // Add or update the listener in our map
    if (this.listeners.has(listenerKey)) {
      console.log(`Updating existing WebSocket listener: ${listenerKey}`);
    } else {
      console.log(`Adding new WebSocket listener: ${listenerKey}`);
    }
    
    this.listeners.set(listenerKey, listener);
    
    // If we're already connected, notify the listener
    if (this.connected && this.socket) {
      console.log(`Notifying updated listener ${listenerKey} of existing connection`);
      listener.onConnect?.();
    }
    
    return true;
  }

  public async connect(endpoint: string, listener: WebSocketListener, listenerKey: string) {
    // Don't attempt a new connection if we're in the process already unless it's been more than 5 seconds
    const now = Date.now();
    if (this.connecting) {
      // Allow new connection attempt if previous one has been stuck for more than 5 seconds
      if (now - this.connectionAttemptTimestamp < 5000) {
      console.log('Already attempting to connect. Waiting...');
      return;
      } else {
        console.log('Previous connection attempt seems stuck. Trying again...');
      }
    }
    
    this.connecting = true;
    this.connectionAttemptTimestamp = now;
    console.log(`Attempting to connect to WebSocket endpoint: ${endpoint}`);
    
    try {
      // Add the listener to our map
      this.listeners.set(listenerKey, listener);
      
      // If already connected, just notify the listener
      if (this.connected && this.socket) {
        console.log('Already connected to WebSocket, notifying listener');
        listener.onConnect?.();
        
        // If the listener sends a subscribe message in onConnect, we need to handle it here too
        // since onConnect won't be called again if we're already connected
        if (endpoint === 'flashcards') {
          console.log('Already connected - sending subscribe message with delay');
          // Add a short delay to ensure connection is fully established
          setTimeout(() => {
            this.send({
              type: 'subscribe',
              channel: 'flashcards'
            });
          }, 100);
        }
        return;
      }
      
      // Get authentication token for secure connection
      const user = auth.currentUser;
      let token = '';
      
      if (user) {
        try {
          token = await user.getIdToken();
          console.log(`Authentication token obtained: Yes (length: ${token.length})`);
        } catch (error) {
          console.error('Failed to get authentication token:', error);
        }
      } else {
        console.log('No authenticated user, connecting without token');
      }
      
      // Ensure endpoint has trailing slash for consistent URL pattern matching
      if (!endpoint.endsWith('/')) {
        endpoint = `${endpoint}/`;
      }
      
      // Construct WebSocket URL
      const wsUrl = token 
        ? `${this.baseUrl}/ws/${endpoint}?token=${token}`
        : `${this.baseUrl}/ws/${endpoint}`;
      
      console.log(`Connecting to WebSocket URL: ${wsUrl}`);
      
      // Create a new WebSocket connection
      this.socket = new WebSocket(wsUrl);
      
      // Setup event handlers
      this.socket.onopen = () => {
        console.log(`WebSocket connection established to ${endpoint}`);
        this.connected = true;
        this.connecting = false;
        this.reconnectAttempt = 0;
        
        // Notify all listeners about the connection
        this.listeners.forEach(l => {
          if (typeof l.onConnect === 'function') {
            l.onConnect();
          }
        });
        
        // Start ping interval to keep the connection alive
        this.startPingInterval();
      };
      
      this.socket.onclose = (event) => {
        console.log(`WebSocket disconnected from ${endpoint} with code: ${event.code}`);
        console.log(`WebSocket close reason: ${event.reason || 'No reason provided'}`);
        this.connected = false;
        this.connecting = false;
        
        // Notify all listeners about the disconnection
        this.listeners.forEach(l => {
          if (typeof l.onDisconnect === 'function') {
            l.onDisconnect();
          }
        });
        
        // Always attempt to reconnect unless it was closed by the client intentionally
        // Code 1000 is normal closure, but we'll reconnect anyway if we have active listeners
        // as frontend components might still need the connection
        if (event.code !== 1000 || this.listeners.size > 0) {
          console.log(`Scheduling reconnection after disconnect with code ${event.code}`);
          this.scheduleReconnect(endpoint);
        } else {
          console.log(`Normal closure (${event.code}) with no active listeners, not reconnecting`);
        }
      };
      
      this.socket.onmessage = (event) => {
        let data: any;
        try {
          // First check for special plain text messages
          if (event.data === 'ping' || event.data === 'pong') {
            // Just log for debug and don't process further
            console.log(`Received plain text ${event.data} message`);
            return;
          }
          
          // Then try parsing as JSON
          try {
            data = JSON.parse(event.data);
            this.debugLog(`WebSocket message (${endpoint})`, data, 'color: #2196F3');
            
            // Special handling for ping/pong messages - just log and don't process further
            if (data.type === 'ping' || data.type === 'pong') {
              console.log(`Received ${data.type} message with timestamp ${data.timestamp}`);
              return;
            }

            // Enhanced debug logging for job_completed notifications
            if (data && 
                (data.notification_type === 'job_completed' || 
                 data.type === 'job_completed')) {
              
              // SUPER VISIBLE LOG - Make this extremely obvious in the console
              console.log('%c🚨🚨🚨 JOB COMPLETED NOTIFICATION RECEIVED 🚨🚨🚨', 
                'background: #FF0000; color: white; padding: 10px; font-size: 24px; font-weight: bold; border-radius: 4px;');
              console.log('Full notification data:', JSON.stringify(data, null, 2));
              console.log('Flashcards array length:', data.flashcards ? data.flashcards.length : 'none');
              console.log('Study set ID:', data.study_set_id);
              
              // Immediately try to force a UI update via multiple channels
              try {
                window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
                  detail: {
                    deckId: data.study_set_id,
                    timestamp: Date.now(),
                    source: 'websocket_critical',
                    flashcards: data.flashcards || []
                  }
                }));
                console.log("Dispatched CRITICAL flashcardsRefreshNeeded event");
                
                // Also add DOM trigger with forced visibility
                const triggerEl = document.createElement('div');
                triggerEl.id = 'websocket-update-trigger-critical';
                triggerEl.style.position = 'fixed';
                triggerEl.style.bottom = '0';
                triggerEl.style.right = '0';
                triggerEl.style.width = '10px';
                triggerEl.style.height = '10px';
                triggerEl.style.background = 'red';
                triggerEl.style.zIndex = '9999';
                triggerEl.dataset.timestamp = Date.now().toString();
                triggerEl.dataset.type = 'job_completed_critical';
                triggerEl.dataset.deckId = data.study_set_id || '';
                document.body.appendChild(triggerEl);
                
                // Try localStorage as another backup
                localStorage.setItem('lastFlashcardUpdate', JSON.stringify({
                  timestamp: Date.now(),
                  study_set_id: data.study_set_id,
                  notification_type: 'job_completed',
                  hasFlashcards: !!(data.flashcards && data.flashcards.length > 0)
                }));
              } catch (e) {
                console.error('Error in critical notification handling:', e);
              }
              
              // Direct log to console to ensure visibility
              const notificationElement = document.createElement('div');
              notificationElement.style.position = 'fixed';
              notificationElement.style.top = '20px';
              notificationElement.style.right = '20px';
              notificationElement.style.padding = '15px 20px';
              notificationElement.style.background = 'rgba(139, 92, 246, 0.9)';
              notificationElement.style.color = 'white';
              notificationElement.style.borderRadius = '8px';
              notificationElement.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.2)';
              notificationElement.style.zIndex = '9999';
              notificationElement.style.transition = 'all 0.3s ease';
              notificationElement.style.fontWeight = 'bold';
              notificationElement.innerHTML = `
                <div style="display: flex; align-items: center; gap: 10px;">
                  <span>✅</span>
                  <div>
                    <div>Flashcards Ready!</div>
                    <div style="font-size: 0.8em; font-weight: normal;">${data.flashcards ? data.flashcards.length : '0'} cards generated</div>
                  </div>
                </div>
              `;
              
              document.body.appendChild(notificationElement);
              
              // Remove after 5 seconds
              setTimeout(() => {
                if (notificationElement.parentNode) {
                  notificationElement.style.opacity = '0';
                  setTimeout(() => {
                    if (notificationElement.parentNode) {
                      notificationElement.parentNode.removeChild(notificationElement);
                    }
                  }, 300);
                }
              }, 5000);
              
              // Store in global variable for recovery
              if (typeof window !== 'undefined') {
                window.websocketNotifications = window.websocketNotifications || [];
                window.websocketNotifications.push(data);
                console.log('Stored notification in global variable. Total stored:', window.websocketNotifications.length);
                
                // Also try saving to session storage
                try {
                  sessionStorage.setItem('lastFlashcardWebSocketUpdate', JSON.stringify({
                    timestamp: Date.now(),
                    data: data
                  }));
                  console.log('Saved notification to sessionStorage');
                  
                  // Trigger a DOM event as a fallback mechanism
                  const triggerEl = document.createElement('div');
                  triggerEl.id = 'websocket-update-trigger';
                  triggerEl.style.display = 'none';
                  triggerEl.dataset.timestamp = Date.now().toString();
                  triggerEl.dataset.type = 'job_completed';
                  document.body.appendChild(triggerEl);
                  
                  // Remove it after a short delay
                  setTimeout(() => {
                    if (triggerEl.parentNode) {
                      triggerEl.parentNode.removeChild(triggerEl);
                    }
                  }, 1000);
                } catch (e) {
                  console.error('Error saving to sessionStorage:', e);
                }
                
                // Dispatch a custom event
                try {
                  window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
                    detail: {
                      deckId: data.study_set_id,
                      timestamp: Date.now(),
                      source: 'websocket',
                      flashcards: data.flashcards || []
                    }
                  }));
                  console.log('Dispatched flashcardsRefreshNeeded event');
                } catch (e) {
                  console.error('Error dispatching event:', e);
                }
              }
            }
          } catch (error) {
            // If not JSON, use the raw data
            data = event.data;
            this.debugLog(`WebSocket raw message (${endpoint})`, data, 'color: #FFA000');
          }

          // Special handling for job completion notifications
          // Check if this is a job_completed notification
          if (data && 
              (data.notification_type === 'job_completed' || 
               data.type === 'job_completed')) {
            
            this.debugLog('🔥 FLASHCARD JOB COMPLETED 🔥', data, 'background: #9C27B0; color: white; padding: 3px; border-radius: 3px;');
            
            // Debug log the data structure to help diagnose issues
            console.log("Flashcard job completed notification data structure:", {
              notification_type: data.notification_type || data.type,
              study_set_id: data.study_set_id,
              flashcards: data.flashcards ? `${data.flashcards.length} cards` : 'none',
              hasFlashcards: !!(data.flashcards && data.flashcards.length > 0),
              firstCard: data.flashcards && data.flashcards.length > 0 ? data.flashcards[0] : null
            });
            
            // Ensure we have flashcards data before proceeding
            if (!data.flashcards || data.flashcards.length === 0) {
              console.warn("Job completed notification received without flashcards data");
              
              // Still store the notification to allow polling for results
              try {
                sessionStorage.setItem('lastFlashcardWebSocketUpdate', JSON.stringify({
                  timestamp: Date.now(),
                  data: data,
                  missingFlashcards: true
                }));
              } catch (e) {
                console.error('Error saving to sessionStorage:', e);
              }
              
              // Don't try to update UI without cards
              return;
            }
            
            // Broadcast through multiple channels to ensure it's received
            // 1. Window event
            try {
              window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
                detail: {
                  deckId: data.study_set_id,
                  timestamp: Date.now(),
                  source: 'websocket',
                  flashcards: data.flashcards || [],
                  notification: data
                }
              }));
              console.log("Successfully dispatched flashcardsRefreshNeeded event with", 
                data.flashcards ? data.flashcards.length : 0, "cards");
            } catch (e) {
              console.error('Error dispatching CustomEvent:', e);
            }
            
            // 2. Session Storage (persists across component mounts)
            try {
              sessionStorage.setItem('lastFlashcardWebSocketUpdate', JSON.stringify({
                timestamp: Date.now(),
                data: data
              }));
              console.log("Successfully saved flashcard data to sessionStorage");
            } catch (e) {
              console.error('Error saving to sessionStorage:', e);
            }
            
            // 3. Direct UI update via DOM
            try {
              // Create a hidden div to trigger React's MutationObserver
              const triggerEl = document.createElement('div');
              triggerEl.id = 'websocket-update-trigger';
              triggerEl.style.display = 'none';
              triggerEl.dataset.timestamp = Date.now().toString();
              triggerEl.dataset.type = 'job_completed';
              triggerEl.dataset.deckId = data.study_set_id || '';
              triggerEl.dataset.hasFlashcards = (data.flashcards && data.flashcards.length > 0).toString();
              document.body.appendChild(triggerEl);
              
              console.log("Added DOM trigger element for MutationObserver");
              
              // Remove after a short delay
              setTimeout(() => {
                if (triggerEl.parentNode) {
                  triggerEl.parentNode.removeChild(triggerEl);
                  console.log("Removed DOM trigger element");
                }
              }, 1000); // Increase timeout to ensure it's observed
            } catch (e) {
              console.error('Error with DOM manipulation:', e);
            }
          }
          
          // Notify all listeners about the message
          this.listeners.forEach((listener, key) => {
            if (listener && listener.onMessage) {
              try {
                  listener.onMessage(data);
              } catch (error) {
                console.error(`Error in listener ${key} processing message:`, error);
              }
            }
          });
          
        } catch (error) {
          console.error('Error processing WebSocket message:', error);
        }
      };
      
      this.socket.onerror = (error) => {
        console.error(`WebSocket error:`, error);
        
        // Check if we're in the CONNECTING state (0)
        if (this.socket && this.socket.readyState === 0) {
          console.error(`WebSocket connection failed - endpoint may not exist: ${wsUrl}`);
        } else {
          console.error(`WebSocket error while connected: ${error}`);
        }
        
        // Notify all listeners about the error
        this.listeners.forEach(l => {
          if (typeof l.onError === 'function') {
            l.onError(error);
          }
        });
      };
      
    } catch (error) {
      console.error(`Error connecting to WebSocket: ${error}`);
      this.connecting = false;
      
      // Notify all listeners about the connection error
      this.listeners.forEach(l => {
        if (typeof l.onError === 'function') {
          l.onError(error as Event);
        }
      });
      
      // Try to reconnect
      this.scheduleReconnect(endpoint);
    }
  }

  public addMessageHandler(type: string, handler: (data: any) => void) {
    this.messageHandlers[type] = handler;
  }

  public removeMessageHandler(type: string) {
    delete this.messageHandlers[type];
  }

  // Start sending periodic pings to keep the connection alive
  private startPingInterval() {
    // Clear any existing interval
    this.stopPingInterval();
    
    // Create new ping interval
    this.pingIntervalId = setInterval(() => {
      if (this.connected && this.socket) {
        console.log('Sending WebSocket ping to keep connection alive');
        try {
          this.send({ type: 'ping' });
        } catch (error) {
          console.error('Error sending ping:', error);
        }
      } else {
        console.log('Cannot send ping: WebSocket not connected');
        this.stopPingInterval();
      }
    }, this.pingIntervalMs);
    
    console.log(`Started WebSocket ping interval (every ${this.pingIntervalMs/1000}s)`);
  }
  
  // Stop sending pings
  private stopPingInterval() {
    if (this.pingIntervalId) {
      clearInterval(this.pingIntervalId);
      this.pingIntervalId = null;
      console.log('Stopped WebSocket ping interval');
    }
  }

  public disconnect() {
    // Stop sending pings
    this.stopPingInterval();
    
    if (this.socket) {
      console.log('Intentionally closing WebSocket connection');
      this.socket.close(1000, 'Intentional disconnect');
      this.socket = null;
    }
    
    this.connected = false;
    this.connecting = false;
    
    // Clear any pending reconnection
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    
    // Clear all listeners
    this.listeners.clear();
  }

  // Check if a message is an important notification that should be retained
  private isImportantNotification(data: any): boolean {
    return data && 
           (data.notification_type === 'job_completed' || 
            data.type === 'job_completed' ||
            data.notification_type === 'flashcard_created' ||
            data.notification_type === 'study_set_updated');
  }

  // Add buffered notifications to this method
  private notifyListeners(endpoint: string, data: any): void {
    console.log(`WebSocket message received from ${endpoint}/: ${JSON.stringify(data)}`);
    
    // Check if this is an important notification we should buffer
    const isImportant = this.isImportantNotification(data);
    
    // Initialize buffer for this endpoint if it doesn't exist
    if (isImportant && !this.notificationBuffer[endpoint]) {
      this.notificationBuffer[endpoint] = [];
    }
    
    // Add to buffer if it's an important notification
    if (isImportant) {
      this.notificationBuffer[endpoint].push(data);
      console.log(`Buffered important notification: ${JSON.stringify(data)}`);
    }
    
    // Get the listener from the map
    const listener = this.listeners.get(endpoint);
    
    // Call the listener if it exists
    if (listener && typeof listener.onMessage === 'function') {
      try {
        listener.onMessage(data);
        
        // If a listener successfully processed a notification, remove it from buffer
        if (isImportant && this.notificationBuffer[endpoint]) {
          const index = this.notificationBuffer[endpoint].indexOf(data);
          if (index > -1) {
            this.notificationBuffer[endpoint].splice(index, 1);
            console.log(`Notification processed and removed from buffer`);
          }
        }
      } catch (e) {
        console.error(`Error in WebSocket listener for ${endpoint}:`, e);
      }
    }
  }

  // Modify the removeListener method to handle buffered notifications
  public removeListener(id: string): void {
    let endpointToRemove: string | null = null;
    
    // Find the endpoint with this listener
    this.listeners.forEach((listener, endpoint) => {
      if (endpoint === id) {
        endpointToRemove = endpoint;
      }
    });
    
    // Remove the listener
    if (endpointToRemove) {
      this.listeners.delete(endpointToRemove);
      console.log(`Removed WebSocket listener: ${id}`);
      
      // Check if there are other listeners for this endpoint
      const hasOtherListeners = Array.from(this.listeners.keys()).some(key => key.startsWith(endpointToRemove!));
      
      // Report remaining listeners for debugging
      console.log(`Remaining listeners: ${this.listeners.size}`);
      
      // If we still have other listeners and there are buffered notifications,
      // deliver them to the remaining listeners
      if (hasOtherListeners && 
          endpointToRemove && 
          this.notificationBuffer[endpointToRemove] && 
          this.notificationBuffer[endpointToRemove].length > 0) {
        
        console.log(`Re-delivering ${this.notificationBuffer[endpointToRemove].length} buffered notifications to remaining listeners`);
        
        // Use setTimeout to avoid call stack issues
        setTimeout(() => {
          // Make a copy to avoid modification during iteration
          if (endpointToRemove && this.notificationBuffer[endpointToRemove]) {
            const notifications = [...this.notificationBuffer[endpointToRemove]];
            notifications.forEach(notification => {
              this.notifyListeners(endpointToRemove!, notification);
            });
          }
        }, 0);
      }
    }
  }

  private scheduleReconnect(endpoint: string) {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    
    if (this.reconnectAttempt >= this.maxReconnectAttempts) {
      console.log(`Maximum reconnect attempts (${this.maxReconnectAttempts}) reached. Giving up.`);
      return;
    }
    
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempt);
    console.log(`Scheduling WebSocket reconnect in ${delay}ms (attempt ${this.reconnectAttempt + 1}/${this.maxReconnectAttempts})`);
    
    this.reconnectTimer = setTimeout(() => {
      this.reconnectAttempt++;
      this.connect(endpoint, {} as WebSocketListener, 'reconnect');
    }, delay);
  }

  public isConnected(): boolean {
    return this.connected;
  }

  public send(data: any) {
    if (this.socket && this.connected) {
      // Special case: always send 'subscribe' and 'ping' as plain text
      // This is what the backend expects based on the logs
      if (data === 'subscribe' || (typeof data === 'object' && data?.type === 'subscribe')) {
        console.log('Sending simple subscribe message');
        this.socket.send('subscribe');
        return true;
      }
      
      // Also send ping as plain text for consistency with backend
      if (data === 'ping' || (typeof data === 'object' && data?.type === 'ping')) {
        console.log('Sending ping message');
        this.socket.send('ping');
        return true;
      }
      
      // Handle simple string messages
      if (typeof data === 'string') {
        console.log(`Sending string message: ${data}`);
        this.socket.send(data);
        return true;
      }
      
      // For objects, convert to JSON
      try {
        console.log('Sending JSON message:', data);
        this.socket.send(JSON.stringify(data));
        return true;
      } catch (error) {
        console.error('Error serializing WebSocket message:', error);
        return false;
      }
    } else {
      console.error('Cannot send message: WebSocket not connected');
      return false;
    }
  }

  // Add this as a method to WebSocketService class
  private debugLog(title: string, message?: any, style: string = '') {
    console.log(`%c${title}`, `font-weight: bold; ${style}`, message || '');
  }

  // Process WebSocket message
  private processMessage(event: MessageEvent): void {
    try {
      // Handle special ping/pong messages and text messages differently
      if (event.data === 'ping') {
        console.log('Received ping message (text)');
        // Send a pong response
        this.send({ type: 'pong', timestamp: new Date().toISOString() });
        return;
      } else if (event.data === 'pong') {
        console.log('Received pong message (text)');
        return;
      }

      // Parse JSON messages
      let message: any;
      try {
        message = JSON.parse(event.data);
        console.log(`WebSocket message received:`, message);
      } catch (error) {
        console.warn('Failed to parse WebSocket message as JSON:', event.data);
        message = { type: 'unknown', raw: event.data };
      }

      // Handle ping messages
      if (message.type === 'ping') {
        console.log(`Received ping message with timestamp ${message.timestamp}`);
        // Send pong response
        this.send({ type: 'pong', timestamp: new Date().toISOString() });
        return;
      }

      // Handle pong messages
      if (message.type === 'pong') {
        console.log(`Received pong message with timestamp ${message.timestamp}`);
        return;
      }
      
      // Special handling for job_completed notifications to ensure they're never missed
      if (message.notification_type === 'job_completed' || message.type === 'job_completed') {
        console.log('Received job_completed notification:', message);
        
        // Check if we should show UI notifications
        // First see if there's already a recent notification for this job
        let shouldShowNotification = true;
        
        try {
          // Check session storage for recent notifications
          const lastNotification = sessionStorage.getItem('lastWebSocketNotification');
          if (lastNotification) {
            const parsedNotification = JSON.parse(lastNotification);
            const currentTime = Date.now();
            // If we've shown a notification for this job in the last 5 seconds, don't show another
            if (parsedNotification.data?.job_id === message.job_id && 
                parsedNotification.timestamp > currentTime - 5000) {
              console.log('Suppressing duplicate notification for job', message.job_id);
              shouldShowNotification = false;
            }
          }
        } catch (e) {
          console.error('Error checking for recent notifications:', e);
        }
        
        // Store in global notification array
        if (typeof window !== 'undefined') {
          if (!window.websocketNotifications) {
            window.websocketNotifications = [];
          }
          // Avoid duplicate notifications in the array
          const isDuplicate = window.websocketNotifications.some(
            n => n.job_id === message.job_id
          );
          if (!isDuplicate) {
            window.websocketNotifications.push(message);
            console.log('Added job_completed notification to websocketNotifications array');
          }
        }
        
        // Store in session storage
        try {
          sessionStorage.setItem('lastWebSocketNotification', JSON.stringify({
            timestamp: Date.now(),
            data: message
          }));
        } catch (e) {
          console.error('Error saving to sessionStorage:', e);
        }
        
        // Refresh study sets to ensure we have the latest data
        console.log('Refreshing study sets after receiving job_completed notification');
        refreshStudySets().catch(error => {
          console.error('Error refreshing study sets:', error);
        });
        
        // Broadcast an event for all components
        window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
          detail: {
            deckId: message.study_set_id || message.document_id,
            timestamp: Date.now(),
            source: 'websocket',
            flashcards: message.flashcards || [],
            forceUpdate: true
          }
        }));
        
        // Only show visual notification if not a duplicate
        if (shouldShowNotification) {
          // Create a visual notification
          const notificationElement = document.createElement('div');
          notificationElement.style.position = 'fixed';
          notificationElement.style.top = '20px';
          notificationElement.style.right = '20px';
          notificationElement.style.padding = '15px 20px';
          notificationElement.style.background = 'rgba(139, 92, 246, 0.9)';
          notificationElement.style.color = 'white';
          notificationElement.style.borderRadius = '8px';
          notificationElement.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.2)';
          notificationElement.style.zIndex = '9999';
          notificationElement.style.transition = 'all 0.3s ease';
          notificationElement.style.fontWeight = 'bold';
          notificationElement.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
              <span>✅</span>
              <div>
                <div>Flashcards Ready!</div>
                <div style="font-size: 0.8em; font-weight: normal;">${message.flashcards?.length || 0} cards generated</div>
              </div>
            </div>
          `;
          
          document.body.appendChild(notificationElement);
          
          // Remove after 5 seconds
          setTimeout(() => {
            if (notificationElement.parentNode) {
              notificationElement.style.opacity = '0';
              setTimeout(() => {
                if (notificationElement.parentNode) {
                  notificationElement.parentNode.removeChild(notificationElement);
                }
              }, 300);
            }
          }, 5000);
        }
      }

      // Iterate through all listeners and notify them
      this.listeners.forEach((listener, key) => {
        if (listener && listener.onMessage) {
          try {
            listener.onMessage(message);
          } catch (error) {
            console.error(`Error in listener ${key} processing message:`, error);
          }
        }
      });
      
      // If there are no active listeners, log this
      if (this.listeners.size === 0) {
        console.log(`No active listeners for WebSocket message`);
      }
    } catch (error) {
      console.error('Error processing WebSocket message:', error);
    }
  }
}

// Create singleton instance
const websocketService = new WebSocketService();

export default websocketService; 