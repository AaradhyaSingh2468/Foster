// Re-export all functions from the TypeScript version
export * from './studyService.ts'; 