import api from '../config/api';
import { auth } from '../config/firebase';
import type { StudyBuddyResponse, StudySet, ExamConfig, CreateStudySetData } from './types';
import syncService from './syncService';
import websocketService from './websocketService';
import axios from 'axios';

// Define the WebSocketListener interface
interface WebSocketListener {
  onMessage: (data: any) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Event) => void;
}

// Document Upload and Processing
export const uploadDocument = async (file: File): Promise<StudyBuddyResponse> => {
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        // Ensure user is authenticated first
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const token = await getFirebaseToken();
        // Continue even if token is null - the API interceptor will handle it
        
        // Add timeout and retry logic for upload
        const MAX_RETRIES = 3;
        let retries = 0;
        let lastError: any = null;
        
        while (retries < MAX_RETRIES) {
            try {
                console.log(`Upload attempt ${retries + 1} for file: ${file.name}`);
                
                const response = await api.post('/study-buddy/upload', formData, {
                    timeout: 30000,
                });
                
                console.log('Upload successful:', response.data);
                
                // Clear document cache to ensure new upload is shown in the list
                try {
                    localStorage.removeItem('cachedDocuments');
                    localStorage.removeItem('cachedDocumentsTimestamp');
                    localStorage.removeItem('cachedStudySets');
                    localStorage.removeItem('cachedStudySetsTimestamp');
                    console.log('Cleared document and study set caches for fresh data after upload');
                } catch (e) {
                    console.warn('Failed to clear caches after upload:', e);
                }
                
                return response.data;
            } catch (error: any) {
                lastError = error;
                console.error(`Attempt ${retries + 1} failed:`, error);
                
                if (error.response?.status === 401 || error.response?.status === 403) {
                    console.warn('Authentication error during upload, returning empty response');
                    return {
                        message: 'Please sign in to upload documents',
                        error: 'Authentication required',
                        job_id: ''
                    };
                }
                
                retries++;
                if (retries < MAX_RETRIES) {
                    const delay = Math.pow(2, retries) * 1000;
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError;
    } catch (error: unknown) {
        console.error('Error uploading document:', error);
        if (error instanceof Error) {
            return {
                message: error.message,
                error: 'Upload failed',
                job_id: ''
            };
        }
        return {
            message: 'Failed to upload document',
            error: 'Unknown error',
            job_id: ''
        };
    }
};

// Helper function to get Firebase token
async function getFirebaseToken(): Promise<string | null> {
    try {
        if (!auth.currentUser) {
            console.log('No authenticated user found, returning null token');
            return null;
        }
        return await auth.currentUser.getIdToken(true);
    } catch (e) {
        console.warn('Error getting Firebase token:', e);
        return null; // Return null instead of throwing to allow graceful fallback
    }
}

// Q&A Functionality
export const askQuestion = async (question: string, documentId?: string | null): Promise<StudyBuddyResponse> => {
    try {
        // Get the current document ID from the URL if not provided
        if (!documentId) {
            const pathname = window.location.pathname;
            // eslint-disable-next-line no-useless-escape
            const match = pathname.match(/\/study-sets\/([^/]+)/);
            documentId = match ? match[1] : null;
        }

        if (!documentId) {
            throw new Error('Document ID is required');
        }

        const currentUser = auth.currentUser;
        if (!currentUser) {
            throw new Error('Please sign in to continue');
        }

        console.log(`Asking question with documentId: ${documentId}`);
        const response = await api.post('/study-buddy/ask', {
            question,
            document_id: documentId,
            user_id: currentUser.uid
        });
        
        if (!response.data) {
            throw new Error('No response data received');
        }
        
        console.log('StudyBuddy response:', response.data);
        return response.data;
    } catch (error: unknown) {
        console.error('Error asking question:', error);
        
        if (error instanceof Error) {
            if (error.message === 'Authentication required') {
                throw new Error('Please sign in to ask questions');
            }
        }
        
        // Add more detailed error information
        if (error && typeof error === 'object' && 'response' in error) {
            const axiosError = error as { response?: { data: any; status: number } };
            if (axiosError.response) {
                console.error('Response error:', axiosError.response.data);
                console.error('Status code:', axiosError.response.status);
                
                // Handle specific error cases
                if (axiosError.response.status === 401 || axiosError.response.status === 403) {
                    throw new Error('Please sign in to continue');
                }
                if (axiosError.response.status === 404) {
                    throw new Error('Document not found or service unavailable');
                }
            }
        }
        throw error;
    }
};

// Study Set Management
export const createStudySet = async (data: CreateStudySetData): Promise<StudySet> => {
    try {
        const response = await api.post('/study-sets/', data);
        return response.data;
    } catch (error) {
        console.error('Error creating study set:', error);
        throw error;
    }
};

export const getStudySets = async (source?: string): Promise<StudySet[]> => {
    try {
        const params = source ? { source } : {};
        const response = await api.get('/study-sets', { params });
        
        // Map backend field names to frontend field names
        const studySets = response.data.map((set: any) => ({
            ...set,
            createdAt: set.created_at,
            createdBy: set.owner,
            cards: set.cards || []
        }));
        
        // For each study set, check if it has cards, and if not, fetch them separately
        const studySetsWithCards = await Promise.all(studySets.map(async (set: StudySet) => {
            // If the set already has cards, no need to fetch them again
            if (set.cards && set.cards.length > 0) {
                return set;
            }
            
            // Otherwise, fetch cards for this study set
            try {
                const flashcardsResponse = await api.get(`/study-sets/${set.id}/flashcards`);
                if (flashcardsResponse.data && Array.isArray(flashcardsResponse.data)) {
                    console.log(`Loaded ${flashcardsResponse.data.length} flashcards for study set ${set.id}`);
                    return {
                        ...set,
                        cards: flashcardsResponse.data
                    };
                }
            } catch (flashcardsError) {
                console.error(`Error fetching flashcards for study set ${set.id}:`, flashcardsError);
            }
            
            return set;
        }));
        
        return studySetsWithCards;
    } catch (error) {
        console.error('Error fetching study sets:', error);
        throw error;
    }
};

export const getStudySetById = async (id: string): Promise<StudySet> => {
    try {
        // First get the study set data
        const response = await api.get(`/study-sets/${id}`);
        const studySet = response.data;

        // Then explicitly fetch the flashcards for this study set
        try {
            const flashcardsResponse = await api.get(`/study-sets/${id}/flashcards`);
            if (flashcardsResponse.data && Array.isArray(flashcardsResponse.data)) {
                console.log(`Loaded ${flashcardsResponse.data.length} flashcards for study set ${id}`);
                studySet.cards = flashcardsResponse.data;
            }
        } catch (flashcardsError) {
            console.error(`Error fetching flashcards for study set ${id}:`, flashcardsError);
        }
        
        return studySet;
    } catch (error) {
        console.error(`Error fetching study set ${id}:`, error);
        throw error;
    }
};

export const updateStudySet = async (id: string, data: Partial<StudySet>): Promise<StudySet> => {
    try {
        const response = await api.put(`/study-sets/${id}`, data);
        return response.data;
    } catch (error) {
        console.error(`Error updating study set ${id}:`, error);
        throw error;
    }
};

export const deleteStudySet = async (id: string, options?: { preservePdf?: boolean }): Promise<void> => {
    try {
        console.log(`Deleting study set ${id} with options:`, options);
        
        // Include preservePdf option in query parameters if specified
        const preservePdf = options?.preservePdf !== undefined ? options.preservePdf : false;
        const queryParams = `?preservePdf=${preservePdf}`;
        
        // Make the delete request
        await api.delete(`/study-sets/${id}${queryParams}`);
        
        // Double check that associated flashcards are deleted by making an additional call
        // to ensure the backend has fully processed the deletion
        if (!preservePdf) {
            try {
                // Make an additional call to ensure flashcards are deleted
                await api.post('/cleanup-associated-data/', {
                    id: id,
                    type: 'study_set',
                    include_flashcards: true,
                    include_pdf: !preservePdf
                }).catch(e => {
                    // If endpoint doesn't exist, that's fine - this is just an extra safety measure
                    console.log('Additional cleanup request failed (may be normal):', e);
                });
                
                // Clear any cached data that might include the deleted items
                try {
                    localStorage.removeItem('cachedStudySets');
                    localStorage.removeItem('cachedStudySetsTimestamp');
                    localStorage.removeItem('cachedDocuments');
                    localStorage.removeItem('cachedDocumentsTimestamp');
                    console.log('Cleared cached data after deletion');
                } catch (cacheError) {
                    console.warn('Failed to clear cache after deletion:', cacheError);
                }
            } catch (cleanupError) {
                console.warn('Failed to perform additional cleanup:', cleanupError);
                // Continue despite cleanup errors - the main delete operation succeeded
            }
        }
        
        // Notify other components about the deletion
        try {
            // First use our sync service
            syncService.publish('pdf-deleted', {
                id: id,
                preservePdf: preservePdf,
                timestamp: Date.now()
            });
            
            // Set timestamp for cross-tab communication
            localStorage.setItem('syncTimestamp', Date.now().toString());
            localStorage.setItem('lastSyncEvent', 'pdf-deleted');
            localStorage.setItem('lastSyncData', JSON.stringify({
                id: id,
                preservePdf: preservePdf
            }));
        } catch (e) {
            console.warn('Failed to notify about deletion:', e);
        }
    } catch (error) {
        console.error(`Error deleting study set ${id}:`, error);
        throw error;
    }
};

// Exam Generation
export const generateExam = async (documentId: string, config: ExamConfig): Promise<StudyBuddyResponse> => {
    try {
        const response = await api.post('/study-buddy/generate-exam', {
            documentId,
            ...config,
        });
        return response.data;
    } catch (error) {
        console.error('Error generating exam:', error);
        throw error;
    }
};

// Flashcard Generation
export const generateFlashcards = async (documentId: string, topic: string, numCards: number = 10, callbacks?: {
    onCompleted?: (data: any) => void;
    onError?: (error: string) => void;
}): Promise<StudyBuddyResponse> => {
    console.log("generateFlashcards called with:", { documentId, topic, numCards });
    
    // Set up a delayed message timer to give user feedback
    let progressTimer: NodeJS.Timeout | undefined;
    const progressCallbacks: {onProgress?: (message: string, progress: number) => void} = {};
    
    // Track WebSocket connection
    let wsConnected = false;
    let listenerKey = `flashcards_${Date.now()}`;
    let jobCompleted = false;
    
    try {
        console.log("Making API POST request to /study-buddy/generate-flashcards");
        
        // Start progress updates
        let progress = 0;
        progressTimer = setInterval(() => {
            if (progressCallbacks.onProgress && !jobCompleted) {
                progress += 3; // Increment by 3% each time (slower than before)
                if (progress > 95) progress = 95; // Cap at 95% until we get actual results
                const messages = [
                    "Analyzing document content...",
                    "Extracting relevant information about the topic...",
                    "Formulating flashcard questions...",
                    "Generating comprehensive answers...",
                    "Almost there! Finalizing your flashcards..."
                ];
                const messageIndex = Math.min(Math.floor(progress / 20), messages.length - 1);
                progressCallbacks.onProgress(messages[messageIndex], progress);
            }
        }, 3000);
        
        // Make the initial request to start the generation process
        const response = await api.post('/study-buddy/generate-flashcards', {
            documentId,
            topic,
            numCards
        });
        
        console.log("Initial API response received:", response.data);
        
        // Check if we received a job ID for async processing
        const jobId = response.data?.job_id;
        
        if (!jobId) {
            // No job ID received, use old synchronous flow
            if (progressTimer) {
                clearInterval(progressTimer);
                progressTimer = undefined;
            }
            
            // Add progress callback support for backward compatibility
            const registerProgressCallback = (callback: (message: string, progress: number) => void) => {
                // Call once with completed status
                setTimeout(() => callback("Flashcards ready!", 100), 0);
                return () => {}; // Empty cleanup function
            };
            
            return {
                ...response.data,
                registerProgressCallback,
                job_id: jobId || ''
            };
        }
        
        // Add job to active jobs list for background checking
        try {
            const activeJobs = localStorage.getItem('activeFlashcardJobs');
            const jobIds = activeJobs ? JSON.parse(activeJobs) as string[] : [];
            if (!jobIds.includes(jobId)) {
                jobIds.push(jobId);
                localStorage.setItem('activeFlashcardJobs', JSON.stringify(jobIds));
                console.log(`Added job ${jobId} to active jobs list for background checking`);
            }
            
            // Set up a periodic job checker (runs every 10 seconds)
            const jobCheckerId = setInterval(() => {
                checkForCompletedJobs();
            }, 10000);
            
            // Auto-clear after 5 minutes
            setTimeout(() => {
                clearInterval(jobCheckerId);
                console.log(`Stopped background job checker for ${jobId}`);
            }, 300000);
        } catch (e) {
            console.error('Error managing active jobs list:', e);
        }
        
        // Check if response indicates to use WebSocket
        const useWebSocket = response.data?.useWebSocket === true;
        
        if (!useWebSocket) {
            // Fall back to polling approach if WebSockets not supported or not requested
            console.log("Using polling approach for job status checks");
            
            // Implement polling similar to before
            const checkJobStatus = async (pollCount = 0): Promise<StudyBuddyResponse> => {
                // Set a maximum number of polls
                const MAX_POLLS = 60; // About 3 minutes with 3-second intervals
                
                if (pollCount >= MAX_POLLS) {
                    if (progressTimer) {
                        clearInterval(progressTimer);
                        progressTimer = undefined;
                    }
                    
                    if (progressCallbacks.onProgress) {
                        progressCallbacks.onProgress("Generation is taking too long. Please try again later.", 100);
                    }
                    
                    // Call the error callback if provided
                    if (callbacks?.onError) {
                        callbacks.onError("Flashcard generation timed out after 3 minutes of polling.");
                    }
                    
                    return {
                        status: 'error',
                        error: 'Flashcard generation timed out after 3 minutes of polling.',
                        isApiError: true,
                        job_id: jobId || ''
                    };
                }
                
                try {
                    const statusResponse = await api.get(`/study-buddy/flashcard-job/${jobId}`);
                    const jobData = statusResponse.data;
                    
                    if (progressCallbacks.onProgress) {
                        const progressPercent = jobData.progress_percent || Math.min(90, (pollCount / MAX_POLLS) * 100);
                        
                        if (jobData.status === 'processing') {
                            progressCallbacks.onProgress(jobData.message || "Generating flashcards...", progressPercent);
                            
                            return new Promise((resolve) => {
                                setTimeout(() => {
                                    checkJobStatus(pollCount + 1).then(resolve);
                                }, 3000);
                            });
                        } else if (jobData.status === 'completed') {
                            jobCompleted = true;
                            progressCallbacks.onProgress("Flashcards ready!", 100);
                            
                            if (progressTimer) {
                                clearInterval(progressTimer);
                                progressTimer = undefined;
                            }
                            
                            // Call completion callback if provided
                            if (callbacks?.onCompleted && jobData.flashcards) {
                                callbacks.onCompleted({
                                    ...jobData,
                                    notification_type: 'job_completed',
                                    job_id: jobId
                                });
                            }
                            
                            return {
                                status: 'success',
                                flashcards: jobData.flashcards,
                                message: jobData.message,
                                job_id: jobId || ''
                            };
                        } else if (jobData.status === 'failed') {
                            jobCompleted = true;
                            progressCallbacks.onProgress(`Error: ${jobData.error || "Flashcard generation failed"}`, 100);
                            
                            if (progressTimer) {
                                clearInterval(progressTimer);
                                progressTimer = undefined;
                            }
                            
                            // Call error callback if provided
                            if (callbacks?.onError) {
                                callbacks.onError(jobData.error || "Flashcard generation failed");
                            }
                            
                            return {
                                status: 'error',
                                error: jobData.error || 'Flashcard generation failed',
                                details: jobData.error_details || '',
                                isApiError: true,
                                job_id: jobId || ''
                            };
                        }
                    }
                    
                    return new Promise((resolve) => {
                        setTimeout(() => {
                            checkJobStatus(pollCount + 1).then(resolve);
                        }, 3000);
                    });
                } catch (pollError: any) {
                    console.error('Error polling job status:', pollError);
                    
                    if (progressTimer) {
                        clearInterval(progressTimer);
                        progressTimer = undefined;
                    }
                    
                    // Call error callback if provided
                    if (callbacks?.onError) {
                        callbacks.onError(pollError.response?.data?.error || 'Lost connection to the server during flashcard generation');
                    }
                    
                    return {
                        status: 'error',
                        error: pollError.response?.data?.error || 'Lost connection to the server during flashcard generation',
                        isApiError: true,
                        job_id: jobId || ''
                    };
                }
            };
            
            // Create a function to register progress callbacks (polling approach)
            const registerProgressCallback = (callback: (message: string, progress: number) => void) => {
                progressCallbacks.onProgress = callback;
                return () => {
                    delete progressCallbacks.onProgress;
                    if (progressTimer) {
                        clearInterval(progressTimer);
                        progressTimer = undefined;
                    }
                };
            };
            
            // Start polling and return enhanced response object
            const pollingResult = checkJobStatus();
            
            return {
                ...await pollingResult,
                registerProgressCallback,
                job_id: jobId || ''
            };
        }
        
        // WebSocket approach
        console.log("Using WebSocket approach for job status updates");
        
        return new Promise((resolve) => {
            // Result data that will be populated by WebSocket
            let resultData: StudyBuddyResponse = {
                status: 'processing',
                job_id: jobId || '',
                message: 'Waiting for flashcard generation to complete...',
                registerProgressCallback: () => () => {}  // Will be overridden below
            };
            
            // Create a WebSocket listener for flashcard generation updates
            const wsListener: WebSocketListener = {
                onMessage: (data: any) => {
                    console.log('WebSocket message received:', data);
                    
                    // Handle different notification types
                    if (data.notification_type === 'job_completed') {
                        console.log('WebSocket received job_completed notification:', data);
                        jobCompleted = true;
                        
                        // Update progress indicator
                        if (progressCallbacks.onProgress) {
                            progressCallbacks.onProgress("Flashcards ready!", 100);
                        }
                        
                        // Clear the progress timer
                        if (progressTimer) {
                            clearInterval(progressTimer);
                            progressTimer = undefined;
                        }
                        
                        // Get flashcards from the message
                        const jobData = {
                            ...data,
                            flashcards: data.flashcards || []
                        };
                        
                        // Update result data
                        resultData = {
                            ...resultData,
                            status: 'success',
                            flashcards: jobData.flashcards,
                            message: jobData.message,
                            job_id: jobId || '',
                            study_set_id: jobData.study_set_id || ''
                        };
                        
                        // Ensure we're working with the correct data format
                        console.log('Preparing to call onCompleted callback with data:', {
                            flashcardsLength: jobData.flashcards ? jobData.flashcards.length : 0,
                            hasStudySetId: !!jobData.study_set_id,
                            notification_type: 'job_completed'
                        });
                        
                        // Call completion callback if provided with full job data
                        if (callbacks?.onCompleted) {
                            console.log('Calling onCompleted callback with WebSocket data');
                            
                            // Create a comprehensive data object for the callback
                            const callbackData = {
                                ...jobData,
                                notification_type: 'job_completed',
                                job_id: jobId,
                                document_id: documentId,
                                topic: topic,
                                num_cards: numCards,
                                timestamp: Date.now()
                            };
                            
                            // Add small delay to ensure React state updates properly
                            setTimeout(() => {
                                if (callbacks?.onCompleted) {
                                    callbacks.onCompleted(callbackData);
                                }
                            }, 10);
                        }
                        
                        // Resolve the promise with the result
                        resolve(resultData);
                    }
                    else if (data.notification_type === 'job_failed') {
                        jobCompleted = true;
                        
                        if (progressCallbacks.onProgress) {
                            progressCallbacks.onProgress(`Error: ${data.error || "Flashcard generation failed"}`, 100);
                        }
                        
                        if (progressTimer) {
                            clearInterval(progressTimer);
                            progressTimer = undefined;
                        }
                        
                        // Update result data
                        resultData = {
                            ...resultData,
                            status: 'error',
                            error: data.error || 'Flashcard generation failed',
                            details: data.error_details || '',
                            isApiError: true,
                            job_id: jobId || ''
                        };
                        
                        // Call error callback if provided
                        if (callbacks?.onError) {
                            callbacks.onError(data.error || "Flashcard generation failed");
                        }
                        
                        // Resolve the promise with the result
                        resolve(resultData);
                    }
                    else if (data.notification_type === 'job_progress') {
                        // Update progress if we get progress updates
                        if (progressCallbacks.onProgress && data.progress && data.message) {
                            progressCallbacks.onProgress(data.message, data.progress);
                        }
                    }
                    else if (data.type === 'connection_established') {
                        console.log('WebSocket connection established notification received');
                    }
                    else if (data.type === 'job_status') {
                        console.log('Job status update received:', data);
                        
                        // Process job status updates
                        if (data.status?.status === 'completed' || data.status?.completed === true) {
                            jobCompleted = true;
                            
                            if (progressCallbacks.onProgress) {
                                progressCallbacks.onProgress("Flashcards ready!", 100);
                            }
                            
                            if (progressTimer) {
                                clearInterval(progressTimer);
                                progressTimer = undefined;
                            }
                            
                            // Update result data
                            resultData = {
                                ...resultData,
                                status: 'success',
                                flashcards: data.status.flashcards,
                                message: data.status.message || 'Flashcards generated successfully',
                                job_id: jobId || ''
                            };
                            
                            // Call completion callback if provided with full data
                            if (callbacks?.onCompleted) {
                                callbacks.onCompleted({
                                    ...data,
                                    flashcards: data.status.flashcards,
                                    notification_type: 'job_completed'
                                });
                            }
                            
                            // Resolve the promise with the result
                            resolve(resultData);
                        }
                        
                        // Also log job status information for debugging
                        console.log('Job status details:', {
                            completed: data.status?.completed,
                            status: data.status?.status,
                            flashcards: data.status?.flashcards ? `${data.status.flashcards.length} flashcards` : 'none'
                        });
                    }
                },
                onConnect: () => {
                    console.log('WebSocket connected for flashcard generation');
                    wsConnected = true;
                    
                    // First subscribe to notifications
                    websocketService.send({
                        type: 'subscribe',
                        channel: 'flashcards'
                    });
                    
                    // Then send a message to request updates for this specific job
                    websocketService.send({
                        type: 'check_job',
                        job_id: jobId
                    });
                    
                    if (progressCallbacks.onProgress) {
                        progressCallbacks.onProgress("Connected to server for real-time updates...", 15);
                    }
                },
                onDisconnect: () => {
                    console.log('WebSocket disconnected for flashcard generation');
                    wsConnected = false;
                    
                    // If the job is not completed when the connection drops, 
                    // check the status manually one more time
                    if (!jobCompleted) {
                        console.log('Job not completed before WebSocket disconnected, checking status manually');
                        
                        // Check job status once using REST API
                        api.get(`/study-buddy/flashcard-job/${jobId}`)
                            .then(response => {
                                const jobData = response.data;
                                console.log(`Manual job status check after WebSocket disconnect:`, jobData);
                                
                                // Process the job status
                                if (jobData.status === 'completed') {
                                    jobCompleted = true;
                                    
                                    if (progressCallbacks.onProgress) {
                                        progressCallbacks.onProgress("Flashcards ready!", 100);
                                    }
                                    
                                    if (progressTimer) {
                                        clearInterval(progressTimer);
                                        progressTimer = undefined;
                                    }
                                    
                                    // Update result data
                                    resultData = {
                                        ...resultData,
                                        status: 'success',
                                        flashcards: jobData.flashcards,
                                        message: jobData.message,
                                        job_id: jobId || ''
                                    };
                                    
                                    // Call completion callback if provided with full job data
                                    if (callbacks?.onCompleted && jobData.flashcards) {
                                        callbacks.onCompleted({
                                            ...jobData,
                                            notification_type: 'job_completed',
                                            job_id: jobId
                                        });
                                    }
                                    
                                    // Resolve the promise with the result
                                    resolve(resultData);
                                }
                                else if (jobData.status === 'failed') {
                                    jobCompleted = true;
                                    
                                    if (progressCallbacks.onProgress) {
                                        progressCallbacks.onProgress(`Error: ${jobData.error || "Flashcard generation failed"}`, 100);
                                    }
                                    
                                    if (progressTimer) {
                                        clearInterval(progressTimer);
                                        progressTimer = undefined;
                                    }
                                    
                                    // Update result data
                                    resultData = {
                                        ...resultData,
                                        status: 'error',
                                        error: jobData.error || 'Flashcard generation failed',
                                        details: jobData.error_details || '',
                                        isApiError: true,
                                        job_id: jobId || ''
                                    };
                                    
                                    // Call error callback if provided
                                    if (callbacks?.onError) {
                                        callbacks.onError(jobData.error || "Flashcard generation failed");
                                    }
                                    
                                    // Resolve the promise with the result
                                    resolve(resultData);
                                }
                            })
                            .catch(error => {
                                console.error('Error checking job status after WebSocket disconnect:', error);
                            });
                    }
                },
                onError: (error: Event) => {
                    console.error('WebSocket error for flashcard generation:', error);
                }
            };
            
            // Connect to WebSocket
            websocketService.connect('flashcards', wsListener, listenerKey);
            
            // Create a function to register progress callbacks (WebSocket approach)
            const registerProgressCallback = (callback: (message: string, progress: number) => void) => {
                progressCallbacks.onProgress = callback;
                
                // Call it once with initial state
                callback("Connecting to server for flashcard generation...", 5);
                
                // Return cleanup function
                return () => {
                    delete progressCallbacks.onProgress;
                    
                    if (progressTimer) {
                        clearInterval(progressTimer);
                        progressTimer = undefined;
                    }
                    
                    // Close WebSocket if job is completed
                    if (jobCompleted && wsConnected) {
                        websocketService.removeListener(listenerKey);
                    }
                };
            };
            
            // Set the callback registration function on the result data
            resultData.registerProgressCallback = registerProgressCallback;
            
            // Add a timeout to detect WebSocket connection issues
            const wsConnectionTimeout = setTimeout(() => {
                console.log("WebSocket connection not established after 5 seconds, falling back to polling");
                    
                // If the WebSocket hasn't connected after 5 seconds, fall back to polling
                if (!wsConnected) {
                    // Start polling as a fallback
                    api.get(`/study-buddy/flashcard-job/${jobId}`)
                        .then(statusResponse => {
                            console.log("Fallback polling response:", statusResponse.data);
                            
                            // If job is already completed, notify callbacks
                            if (statusResponse.data.status === 'completed' && callbacks?.onCompleted) {
                                console.log("Job already completed when checking status, calling completion callback directly");
                                callbacks.onCompleted({
                                    ...statusResponse.data,
                                    notification_type: 'job_completed',
                                    job_id: jobId,
                                    document_id: documentId
                                });
                                
                                // Add a more robust handling for completed jobs
                                if (statusResponse.data.flashcards && statusResponse.data.flashcards.length > 0) {
                                    console.log(`Found ${statusResponse.data.flashcards.length} flashcards, broadcasting completion`);
                                    
                                    // Broadcast through multiple channels
                                    // 1. CustomEvent
                                    try {
                                        window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
                                            detail: {
                                                deckId: statusResponse.data.study_set_id || statusResponse.data.document_id,
                                                timestamp: Date.now(),
                                                source: 'polling_fallback',
                                                flashcards: statusResponse.data.flashcards || []
                                            }
                                        }));
                                        console.log("Dispatched polling fallback event");
                                    } catch (e) {
                                        console.error('Error dispatching event:', e);
                                    }
                                    
                                    // 2. Session storage
                                    try {
                                        sessionStorage.setItem('lastFlashcardPollingUpdate', JSON.stringify({
                                            timestamp: Date.now(),
                                            data: statusResponse.data
                                        }));
                                    } catch (e) {
                                        console.error('Error saving to sessionStorage:', e);
                                }
                                
                                    // 3. Add visual indicator for user
                                    const notificationElement = document.createElement('div');
                                    notificationElement.style.position = 'fixed';
                                    notificationElement.style.top = '20px';
                                    notificationElement.style.right = '20px';
                                    notificationElement.style.padding = '15px 20px';
                                    notificationElement.style.background = 'rgba(139, 92, 246, 0.9)';
                                    notificationElement.style.color = 'white';
                                    notificationElement.style.borderRadius = '8px';
                                    notificationElement.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.2)';
                                    notificationElement.style.zIndex = '9999';
                                    notificationElement.style.transition = 'all 0.3s ease';
                                    notificationElement.style.fontWeight = 'bold';
                                    notificationElement.innerHTML = `
                                      <div style="display: flex; align-items: center; gap: 10px;">
                                        <span>✅</span>
                                        <div>
                                          <div>Flashcards Ready!</div>
                                          <div style="font-size: 0.8em; font-weight: normal;">${statusResponse.data.flashcards.length} cards generated</div>
                                        </div>
                                      </div>
                                    `;
                                    
                                    document.body.appendChild(notificationElement);
                                    
                                    // Remove after 5 seconds
                                    setTimeout(() => {
                                        if (notificationElement.parentNode) {
                                            notificationElement.style.opacity = '0';
                                            setTimeout(() => {
                                                if (notificationElement.parentNode) {
                                                    notificationElement.parentNode.removeChild(notificationElement);
                                                }
                                            }, 300);
                                        }
                                    }, 5000);
                                }
                            } else if (statusResponse.data.status === 'processing') {
                                // Set up polling interval for processing jobs
                                console.log("Setting up polling interval for job:", jobId);
                                const pollInterval = setInterval(() => {
                                    api.get(`/study-buddy/flashcard-job/${jobId}`)
                                        .then(pollResponse => {
                                            const pollData = pollResponse.data;
                                            console.log("Poll update for job:", pollData);
                                            
                                            if (pollData.status === 'completed') {
                                                clearInterval(pollInterval);
                                                console.log("Job completed during polling, calling completion callback");
                                                
                                                if (callbacks?.onCompleted) {
                                    callbacks.onCompleted({
                                                        ...pollData,
                                        notification_type: 'job_completed',
                                                        job_id: jobId,
                                                        document_id: documentId
                                    });
                                }
                                
                                                // Trigger UI update
                                                try {
                                                    window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
                                                        detail: {
                                                            deckId: pollData.study_set_id || pollData.document_id,
                                                            timestamp: Date.now(),
                                                            source: 'polling_interval',
                                                            flashcards: pollData.flashcards || []
                                                        }
                                                    }));
                                                } catch (e) {
                                                    console.error('Error dispatching event:', e);
                                }
                                            } else if (pollData.status === 'failed') {
                                                clearInterval(pollInterval);
                                                console.log("Job failed during polling");
                                                
                                if (callbacks?.onError) {
                                                    callbacks.onError(pollData.error || "Flashcard generation failed");
                                }
                                            }
                                        })
                                        .catch(err => {
                                            console.error("Error polling job status:", err);
                                            // Don't clear interval - keep trying
                                        });
                                }, 5000); // Check every 5 seconds
                                
                                // Auto-clear after 3 minutes to prevent infinite polling
                                setTimeout(() => {
                                    clearInterval(pollInterval);
                                    console.log("Stopping polling after timeout");
                                }, 180000);
                            }
                        })
                        .catch(err => console.error("Error in fallback polling:", err));
                }
            }, 5000);
        });
    } catch (error: any) {
        console.error('Error generating flashcards:', error);
        
        // Clear the progress timer
        if (progressTimer) {
            clearInterval(progressTimer);
            progressTimer = undefined;
        }
        
        // Call error callback if provided
        if (callbacks?.onError) {
            const errorMessage = error.isApiError ? error.error : 
                            error.response?.data?.error ? error.response.data.error :
                            error.message || "An unknown error occurred";
            callbacks.onError(errorMessage);
        }
        
        if (error.code === 'ECONNABORTED') {
            // Timeout error
            return {
                error: 'The flashcard generation is taking longer than expected. The server might be processing a lot of requests or the document is very large. Please try again later or with a smaller number of cards.',
                status: 'timeout',
                isApiError: true,
                job_id: ''
            };
        } else if (error.response) {
            // The request was made and the server responded with an error status
            const errorMessage = error.response.data?.error || 'Failed to generate flashcards';
            const errorDetails = error.response.data?.details || '';
            const errorStatus = error.response.data?.status || 'error';
            
            return {
                error: errorMessage,
                details: errorDetails,
                status: errorStatus,
                isApiError: true,
                job_id: ''
            };
        } else if (error.request) {
            // The request was made but no response was received
            return {
                error: 'No response from server. Please check your connection.',
                isApiError: true,
                job_id: ''
            };
        } else {
            // Something happened in setting up the request
            return {
                error: error.message || 'An unknown error occurred',
                isApiError: true,
                job_id: ''
            };
        }
    }
};

export const createStudySetFromPdf = async (pdfId: string): Promise<any> => {
    try {
        console.log(`Creating study set from PDF ${pdfId}`);
        const response = await api.post('/create-study-set-from-pdf/', {
            pdf_id: pdfId
        });
        
        // Use multiple synchronization methods for maximum reliability
        console.log(`Broadcasting new flashcard creation from PDF ${pdfId}`);
        
        // 1. Use syncService - primary synchronization mechanism
        syncService.publish('flashcards-created', {
            pdfId,
            timestamp: Date.now(),
            responseData: response.data
        });
        
        // 2. Set localStorage flags - backup sync mechanism
        try {
            // Clear study set cache to force refresh
            localStorage.removeItem('cachedStudySets');
            localStorage.removeItem('cachedStudySetsTimestamp');
            
            // Set flashcard refresh flags
            localStorage.setItem('flashcardsNeedsRefresh', 'true');
            localStorage.setItem('flashcardsRefreshTimestamp', Date.now().toString());
        } catch (cacheError) {
            console.warn('Failed to update localStorage after creating study set:', cacheError);
        }
        
        // 3. Direct DOM event - most immediate in current window
        try {
            window.dispatchEvent(new Event('flashcardsRefreshNeeded'));
        } catch (eventError) {
            console.warn('Failed to dispatch direct refresh event:', eventError);
        }
        
        return response.data;
    } catch (error) {
        console.error('Error creating study set from PDF:', error);
        throw error;
    }
};

// Force deck refresh when a job completes
const forceDeckRefresh = (jobData: any) => {
  console.log("Forcing deck refresh for completed job:", jobData);
  
  // 1. Create a flashcard notification overlay that disappears automatically
  const notificationElement = document.createElement('div');
  notificationElement.style.position = 'fixed';
  notificationElement.style.top = '20px';
  notificationElement.style.right = '20px';
  notificationElement.style.padding = '15px 20px';
  notificationElement.style.background = 'rgba(139, 92, 246, 0.9)';
  notificationElement.style.color = 'white';
  notificationElement.style.borderRadius = '8px';
  notificationElement.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.2)';
  notificationElement.style.zIndex = '9999';
  notificationElement.style.transition = 'all 0.3s ease';
  notificationElement.style.fontWeight = 'bold';
  notificationElement.style.cursor = 'pointer';
  notificationElement.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px;">
      <span>✅</span>
      <div>
        <div>Flashcards Ready!</div>
        <div style="font-size: 0.8em; font-weight: normal;">${jobData.flashcards.length} cards generated</div>
      </div>
    </div>
  `;
  
  // Make notification clickable
  notificationElement.onclick = () => {
    if (notificationElement.parentNode) {
      notificationElement.parentNode.removeChild(notificationElement);
    }
  };
  
  document.body.appendChild(notificationElement);
  
  // Remove after 5 seconds
  setTimeout(() => {
    if (notificationElement.parentNode) {
      notificationElement.style.opacity = '0';
      setTimeout(() => {
        if (notificationElement.parentNode) {
          notificationElement.parentNode.removeChild(notificationElement);
        }
      }, 300);
    }
  }, 5000);
  
  // 2. Broadcast an event for any listening components
  window.dispatchEvent(new CustomEvent('flashcardsRefreshNeeded', {
    detail: {
      deckId: jobData.study_set_id || jobData.document_id,
      timestamp: Date.now(),
      source: 'job_checker',
      flashcards: jobData.flashcards,
      forceUpdate: true
    }
  }));
  
  // 3. Store data in sessionStorage
  try {
    sessionStorage.setItem('lastCompletedFlashcardJob', JSON.stringify({
      timestamp: Date.now(),
      jobData: jobData
    }));
  } catch (e) {
    console.error("Error saving to sessionStorage:", e);
  }
};

// Add a dedicated refresh function for study sets
export const refreshStudySets = async (): Promise<StudySet[]> => {
    try {
        // Clear any cached study sets first
        try {
            localStorage.removeItem('cachedStudySets');
            localStorage.removeItem('cachedStudySetsTimestamp');
        } catch (e) {
            console.warn('Failed to clear cached study sets:', e);
        }
        
        // Get fresh data
        console.log('Refreshing study sets from server...');
        return await getStudySets();
    } catch (error) {
        console.error('Error refreshing study sets:', error);
        throw error;
    }
};

// Update checkForCompletedJobs to call refreshStudySets
export const checkForCompletedJobs = async (): Promise<void> => {
  try {
    // Get active jobs from localStorage
    const activeJobs = localStorage.getItem('activeFlashcardJobs');
    if (!activeJobs) return;
    
    const jobIds = JSON.parse(activeJobs) as string[];
    if (!jobIds.length) return;
    
    console.log(`Checking ${jobIds.length} active flashcard jobs for completion`);
    
    let anyJobsCompleted = false;
    
    // Check each job
    for (const jobId of jobIds) {
      try {
        // First check if we already have this job's results in session storage
        const alreadyProcessed = sessionStorage.getItem(`processed_job_${jobId}`);
        if (alreadyProcessed) {
          console.log(`Job ${jobId} was already processed, skipping check`);
          
          // Remove from active jobs
          const updatedJobs = jobIds.filter(id => id !== jobId);
          localStorage.setItem('activeFlashcardJobs', JSON.stringify(updatedJobs));
          
          continue;
        }
        
        const response = await api.get(`/study-buddy/flashcard-job/${jobId}`);
        const jobData = response.data;
        
        if (jobData.status === 'completed' && jobData.flashcards && jobData.flashcards.length > 0) {
          console.log(`Found completed job ${jobId} with ${jobData.flashcards.length} flashcards`);
          anyJobsCompleted = true;
          
          // Remove from active jobs
          const updatedJobs = jobIds.filter(id => id !== jobId);
          localStorage.setItem('activeFlashcardJobs', JSON.stringify(updatedJobs));
          
          // Mark as processed to avoid duplicate processing
          sessionStorage.setItem(`processed_job_${jobId}`, 'true');
          
          // Check if we already have content rendered for this deck
          const studySetId = jobData.study_set_id;
          const deckAlreadyRendered = document.querySelector(`[data-deck-id="${studySetId}"]`);
          
          if (deckAlreadyRendered) {
            console.log(`Deck ${studySetId} is already rendered, skipping UI update`);
            
            // Just show a subtle notification without forcing a refresh
            const quietNotification = document.createElement('div');
            quietNotification.style.position = 'fixed';
            quietNotification.style.top = '20px';
            quietNotification.style.right = '20px';
            quietNotification.style.padding = '10px 15px';
            quietNotification.style.background = 'rgba(139, 92, 246, 0.7)';
            quietNotification.style.color = 'white';
            quietNotification.style.borderRadius = '8px';
            quietNotification.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
            quietNotification.style.zIndex = '9999';
            quietNotification.style.transition = 'all 0.3s ease';
            quietNotification.style.fontSize = '14px';
            quietNotification.innerHTML = `Flashcards ready - ${jobData.flashcards.length} cards available`;
            
            document.body.appendChild(quietNotification);
            
            // Remove after 3 seconds
            setTimeout(() => {
              if (quietNotification.parentNode) {
                quietNotification.style.opacity = '0';
                setTimeout(() => {
                  if (quietNotification.parentNode) {
                    quietNotification.parentNode.removeChild(quietNotification);
                  }
                }, 300);
              }
            }, 3000);
            
            continue;
          }
          
          // Use the forceDeckRefresh function to handle UI updates
          forceDeckRefresh(jobData);
        }
      } catch (error) {
        console.error(`Error checking job ${jobId}:`, error);
      }
    }
    
    // If any jobs were completed, refresh study sets
    if (anyJobsCompleted) {
      console.log('Refreshing study sets after job completion...');
      try {
        await refreshStudySets();
      } catch (e) {
        console.error('Error refreshing study sets after job completion:', e);
      }
    }
  } catch (error) {
    console.error('Error checking for completed jobs:', error);
    }
};

const studyBuddyService = {
    uploadDocument,
    askQuestion,
    generateFlashcards,
    generateExam,
    createStudySet,
    getStudySets,
    getStudySetById,
    updateStudySet,
    deleteStudySet,
    createStudySetFromPdf,
    checkForCompletedJobs,
};

// Set up a background job checker to automatically check for completed jobs periodically
if (typeof window !== 'undefined') {
    // Run the job checker every 30 seconds
    setInterval(() => {
        console.log("Running automatic job checker for completed flashcards");
        checkForCompletedJobs().catch(err => {
            console.error("Error in automatic job checker:", err);
        });
    }, 30000);
    
    // Also check on visibility change
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            console.log("Document became visible, checking for completed jobs");
            checkForCompletedJobs().catch(err => {
                console.error("Error checking for completed jobs on visibility change:", err);
            });
        }
    });
    
    // Check for completed jobs on page load
    setTimeout(() => {
        checkForCompletedJobs().catch(err => {
            console.error("Error checking for completed jobs on page load:", err);
        });
    }, 2000);
}

// eslint-disable-next-line import/no-anonymous-default-export
export default studyBuddyService; 