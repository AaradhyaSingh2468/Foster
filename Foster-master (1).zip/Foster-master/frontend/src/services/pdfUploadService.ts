import api from '../config/api';
import syncService from './syncService';

/**
 * Upload a PDF file to the server
 * @param file PDF file to upload
 * @returns Promise with upload result
 */
export const uploadPdf = async (file: File): Promise<any> => {
  try {
    console.log("NEW UPLOAD SERVICE: Uploading PDF", file.name);
    
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await api.post('/study-buddy/upload', formData);
    
    // Clear all caches to ensure fresh data
    try {
      localStorage.removeItem('cachedDocuments');
      localStorage.removeItem('cachedDocumentsTimestamp');
      localStorage.removeItem('cachedStudySets');
      localStorage.removeItem('cachedStudySetsTimestamp');
      
      // Use the new syncService to notify all components
      syncService.publish('pdf-uploaded', {
        filename: file.name,
        timestamp: Date.now(),
        responseData: response.data
      });
      
      console.log('Cleared all caches and triggered sync events after PDF upload');
    } catch (e) {
      console.error('Failed to clear caches or publish sync event:', e);
    }
    
    return response.data;
  } catch (error) {
    console.error("Error uploading PDF:", error);
    throw error;
  }
};

export default {
  uploadPdf
}; 