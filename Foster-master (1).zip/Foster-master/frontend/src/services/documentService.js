import api from '../config/api';

// Get the documents for the current user
export const getUserDocuments = async () => {
  try {
    const response = await api.get('/documents/');
    
    // Log response for debugging
    console.log('Retrieved documents:', response.data.length);
    
    // Check if any documents are marked as persistent (preserved PDFs)
    const persistentPdfs = response.data.filter(doc => doc.isPersistent);
    if (persistentPdfs.length > 0) {
      console.log(`Found ${persistentPdfs.length} preserved PDFs that can be reused for flashcards`);
    }
    
    return response.data;
  } catch (error) {
    console.error('Error fetching documents:', error);
    throw error;
  }
};