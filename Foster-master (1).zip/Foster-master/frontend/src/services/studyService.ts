import api from '../config/api';
import { StudySet, StudyCard, DeleteStudySetOptions, FlashCard } from './types';

// Cache for study sets
let cachedStudySets: StudySet[] | null = null;
let isLoadingStudySets = false;
let lastFetchedTimestamp = 0;
const CACHE_TTL = 60000; // 1 minute cache TTL

// Cache for flashcards by study set ID
let flashcardsCache: Record<string, FlashCard[]> = {};
let isLoadingFlashcards: Record<string, boolean> = {};
let flashcardsCacheTTL: Record<string, number> = {};
const FLASHCARDS_CACHE_TTL = 300000; // 5 minutes TTL for flashcards

// Try to load cached study sets from localStorage on module initialization
try {
  const storedStudySets = localStorage.getItem('cachedStudySets');
  if (storedStudySets) {
    cachedStudySets = JSON.parse(storedStudySets);
    console.log('Loaded study sets from localStorage:', cachedStudySets?.length || 0);
    
    // Also load the timestamp if available
    const timestamp = localStorage.getItem('cachedStudySetsTimestamp');
    if (timestamp) {
      lastFetchedTimestamp = parseInt(timestamp, 10);
    }
  }
  
  // Load flashcards cache
  const storedFlashcardsCache = localStorage.getItem('flashcardsCache');
  if (storedFlashcardsCache) {
    flashcardsCache = JSON.parse(storedFlashcardsCache);
    console.log('Loaded flashcards cache from localStorage');
    
    const storedFlashcardsTTL = localStorage.getItem('flashcardsCacheTTL');
    if (storedFlashcardsTTL) {
      flashcardsCacheTTL = JSON.parse(storedFlashcardsTTL);
    }
  }
} catch (e) {
  console.warn('Failed to load caches from localStorage:', e);
}

// Study Set Services
export const getStudySets = async (): Promise<StudySet[]> => {
  try {
    // Prevent duplicate requests if already in progress
    if (isLoadingStudySets) {
      console.log('Study sets already being fetched, returning cached data');
      return cachedStudySets || [];
    }
    
    // If we have cached study sets and they're not stale, return them
    const now = Date.now();
    if (cachedStudySets && lastFetchedTimestamp > 0 && (now - lastFetchedTimestamp) < CACHE_TTL) {
      console.log('Returning cached study sets (not stale):', cachedStudySets.length);
      return cachedStudySets;
    }
    
    // If we have cached study sets but they might be stale, return them first
    // and then refresh them in the background with lower priority
    if (cachedStudySets) {
      console.log('Returning cached study sets while refreshing:', cachedStudySets.length);
      
      // Use setTimeout to reduce priority of this refresh
      setTimeout(() => {
        refreshStudySetsCache().catch(e => console.error('Background refresh failed:', e));
      }, 100);
      
      return cachedStudySets;
    }
    
    // No cached study sets, we need to fetch them (blocking call)
    return await refreshStudySetsCache();
  } catch (error) {
    console.error('Error fetching study sets:', error);
    return cachedStudySets || []; // Always fall back to cached study sets
  }
};

// Helper function to refresh the study sets cache
const refreshStudySetsCache = async (): Promise<StudySet[]> => {
  // If already loading, wait for the current request
  if (isLoadingStudySets) {
    console.log('Already refreshing study sets cache');
    return cachedStudySets || [];
  }
  
  isLoadingStudySets = true;
  
  try {
    console.log('Refreshing study sets cache from API');
    const response = await api.get('/study-sets/');
    
    if (response.data && Array.isArray(response.data)) {
      // Update the timestamp
      lastFetchedTimestamp = Date.now();
      
      // Cache successful responses
      cachedStudySets = response.data;
      
      // Save to localStorage for persistence across reloads
      try {
        localStorage.setItem('cachedStudySets', JSON.stringify(response.data));
        localStorage.setItem('cachedStudySetsTimestamp', lastFetchedTimestamp.toString());
        console.log('Saved study sets to localStorage:', response.data.length);
      } catch (e) {
        console.warn('Failed to save study sets to localStorage:', e);
      }
      
      return response.data;
    }
    
    console.warn('Unexpected response format from study sets API');
    return cachedStudySets || [];
  } catch (error: any) {
    // If unauthorized or forbidden, return cached study sets or empty array
    if (error.response && (error.response.status === 403 || error.response.status === 401)) {
      console.warn(`Study sets endpoint returned ${error.response.status}, returning cached sets or empty array`);
    } else {
      console.error('Error refreshing study sets cache:', error);
    }
    return cachedStudySets || [];
  } finally {
    isLoadingStudySets = false;
  }
};

export const getStudySet = async (id: string): Promise<StudySet | null> => {
  try {
    // Check if study set is already in cache
    if (cachedStudySets) {
      const cachedSet = cachedStudySets.find(set => set.id === id);
      if (cachedSet) {
        return cachedSet;
      }
    }
    
    const response = await api.get(`/study-sets/${id}/`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching study set ${id}:`, error);
    return null;
  }
};

export const createStudySet = async (studySetData: Partial<StudySet>): Promise<StudySet> => {
  try {
    const response = await api.post('/study-sets/', studySetData);
    
    // Update the cache with the new study set
    if (cachedStudySets) {
      cachedStudySets = [...cachedStudySets, response.data];
      
      // Update localStorage
      try {
        localStorage.setItem('cachedStudySets', JSON.stringify(cachedStudySets));
        console.log('Updated cached study sets in localStorage after creation');
      } catch (e) {
        console.warn('Failed to update study sets in localStorage:', e);
      }
    }
    
    return response.data;
  } catch (error) {
    console.error("Error creating study set:", error);
    throw error;
  }
};

export const updateStudySet = async (id: string, studySetData: Partial<StudySet>): Promise<StudySet> => {
  try {
    const response = await api.put(`/study-sets/${id}/`, studySetData);
    
    // Update cache if it exists
    if (cachedStudySets) {
      cachedStudySets = cachedStudySets.map(set => 
        set.id === id ? {...set, ...response.data} : set
      );
      
      // Update localStorage
      try {
        localStorage.setItem('cachedStudySets', JSON.stringify(cachedStudySets));
      } catch (e) {
        console.warn('Failed to update study sets in localStorage:', e);
      }
    }
    
    return response.data;
  } catch (error) {
    console.error(`Error updating study set ${id}:`, error);
    throw error;
  }
};

export const deleteStudySet = async (id: string, options: DeleteStudySetOptions = {}): Promise<any> => {
  try {
    // Include preservePdf option in query parameters if specified
    const queryParams = options.preservePdf !== undefined ? `?preservePdf=${options.preservePdf}` : '';
    
    const response = await api.delete(`/study-sets/${id}${queryParams}`);
    
    // Update cache if it exists
    if (cachedStudySets) {
      cachedStudySets = cachedStudySets.filter(set => set.id !== id);
      
      // Update localStorage
      try {
        localStorage.setItem('cachedStudySets', JSON.stringify(cachedStudySets));
      } catch (e) {
        console.warn('Failed to update study sets in localStorage:', e);
      }
    }
    
    // Also clean up flashcards cache for this study set
    if (flashcardsCache[id]) {
      delete flashcardsCache[id];
      delete flashcardsCacheTTL[id];
      try {
        localStorage.setItem('flashcardsCache', JSON.stringify(flashcardsCache));
        localStorage.setItem('flashcardsCacheTTL', JSON.stringify(flashcardsCacheTTL));
      } catch (e) {
        console.warn('Failed to update flashcards cache in localStorage:', e);
      }
    }
    
    // IMPORTANT: Also invalidate documents cache to make PDFs list refresh
    try {
      localStorage.removeItem('cachedDocuments');
      localStorage.removeItem('cachedDocumentsTimestamp');
      console.log('Cleared documents cache after study set deletion');
    } catch (e) {
      console.warn('Failed to clear documents cache in localStorage:', e);
    }
    
    return response.data;
  } catch (error) {
    console.error(`Error deleting study set ${id}:`, error);
    throw error;
  }
};

// Flashcard Services with improved caching
export const getFlashcards = async (studySetId: string): Promise<FlashCard[]> => {
  if (!studySetId) {
    console.error("No study set ID provided to getFlashcards");
    return [];
  }

  try {
    // Prevent duplicate requests
    if (isLoadingFlashcards[studySetId]) {
      console.log(`Already fetching flashcards for study set ${studySetId}, returning cached data`);
      return flashcardsCache[studySetId] || [];
    }
    
    // Check cache validity
    const now = Date.now();
    if (flashcardsCache[studySetId] && 
        flashcardsCacheTTL[studySetId] && 
        now - flashcardsCacheTTL[studySetId] < FLASHCARDS_CACHE_TTL) {
      
      // When using cache, check if it's an empty array and not just because of a failed API call
      if (Array.isArray(flashcardsCache[studySetId])) {
        console.log(`Using cached flashcards for study set ${studySetId}`);
        
        // Only log this once, not on every render
        console.log(`Cache contains ${flashcardsCache[studySetId].length} flashcards`);
        
        return flashcardsCache[studySetId];
      }
    }
    
    // Mark as loading to prevent duplicate requests
    isLoadingFlashcards[studySetId] = true;
    
    // Add a timeout promise to prevent infinite hanging
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout after 10 seconds')), 10000);
    });

    try {
      // Race between the actual request and the timeout
      const response = await Promise.race([
        api.get(`/study-sets/${studySetId}/flashcards/`),
        timeoutPromise
      ]);
      
      // Validate response data structure
      let flashcardsData: any[] = [];
      
      if (!response.data) {
        console.warn(`Invalid response data for studySetId ${studySetId}`);
      } else if (!Array.isArray(response.data)) {
        console.warn(`Expected array for studySetId ${studySetId}, got:`, typeof response.data);
        flashcardsData = Array.isArray(response.data.flashcards) ? response.data.flashcards : [];
      } else {
        flashcardsData = response.data;
      }
      
      // Map backend field names (question/answer) to frontend field names (front/back)
      flashcardsData = flashcardsData.map(card => ({
        id: card.id,
        front: card.question || '', // Map 'question' to 'front'
        back: card.answer || '',    // Map 'answer' to 'back'
        difficulty: card.difficulty,
        // Preserve any other fields
        ...Object.fromEntries(
          Object.entries(card).filter(([key]) => 
            !['id', 'question', 'answer', 'difficulty'].includes(key)
          )
        )
      }));
      
      console.log(`Mapped ${flashcardsData.length} flashcards from backend format to frontend format`);
      
      // Cache the result
      flashcardsCache[studySetId] = flashcardsData;
      flashcardsCacheTTL[studySetId] = now;
      
      // Save to localStorage
      try {
        localStorage.setItem('flashcardsCache', JSON.stringify(flashcardsCache));
        localStorage.setItem('flashcardsCacheTTL', JSON.stringify(flashcardsCacheTTL));
        console.log(`Cached ${flashcardsData.length} flashcards for study set ${studySetId}`);
      } catch (e) {
        console.warn('Failed to cache flashcards in localStorage:', e);
      }
      
      return flashcardsData;
    } catch (error) {
      console.error(`Error fetching flashcards for study set ${studySetId}:`, error);
      // Return cached data as fallback
      return flashcardsCache[studySetId] || [];
    } finally {
      // Clear loading flag
      isLoadingFlashcards[studySetId] = false;
    }
  } catch (outerError) {
    // Handle any unexpected errors in the outer try/catch
    console.error(`Unexpected error in getFlashcards for study set ${studySetId}:`, outerError);
    return flashcardsCache[studySetId] || [];
  }
};

export const createFlashcard = async (studySetId: string, flashcardData: Partial<FlashCard>): Promise<FlashCard> => {
  try {
    // Map frontend field names (front/back) to backend field names (question/answer)
    const mappedData = {
      question: flashcardData.front || '',  // Map 'front' to 'question'
      answer: flashcardData.back || '',     // Map 'back' to 'answer'
      difficulty: flashcardData.difficulty || 'Medium',
      // Preserve any other fields
      ...Object.fromEntries(
        Object.entries(flashcardData).filter(([key]) => 
          !['front', 'back', 'difficulty'].includes(key)
        )
      )
    };

    console.log(`Mapping frontend flashcard data to backend format for study set ${studySetId}`);
    
    const response = await api.post(`/study-sets/${studySetId}/flashcards/`, mappedData);
    
    // Convert response back to frontend format
    const frontendFormat = {
      id: response.data.id,
      front: response.data.question || '',
      back: response.data.answer || '',
      difficulty: response.data.difficulty || 'Medium',
      // Preserve any other fields
      ...Object.fromEntries(
        Object.entries(response.data).filter(([key]) => 
          !['id', 'question', 'answer', 'difficulty'].includes(key)
        )
      )
    };
    
    // Update cache if exists
    if (flashcardsCache[studySetId]) {
      flashcardsCache[studySetId] = [...flashcardsCache[studySetId], frontendFormat];
      flashcardsCacheTTL[studySetId] = Date.now();
      
      // Update localStorage
      try {
        localStorage.setItem('flashcardsCache', JSON.stringify(flashcardsCache));
        localStorage.setItem('flashcardsCacheTTL', JSON.stringify(flashcardsCacheTTL));
      } catch (e) {
        console.warn('Failed to update flashcards cache in localStorage:', e);
      }
    }
    
    return frontendFormat;
  } catch (error) {
    console.error(`Error creating flashcard for study set ${studySetId}:`, error);
    throw error;
  }
};

export const updateFlashcard = async (studySetId: string, flashcardId: string, flashcardData: Partial<FlashCard>): Promise<FlashCard> => {
  try {
    // Map frontend field names (front/back) to backend field names (question/answer)
    const mappedData = {
      question: flashcardData.front || '',  // Map 'front' to 'question'
      answer: flashcardData.back || '',     // Map 'back' to 'answer'
      difficulty: flashcardData.difficulty || 'Medium',
      // Preserve any other fields
      ...Object.fromEntries(
        Object.entries(flashcardData).filter(([key]) => 
          !['front', 'back', 'difficulty'].includes(key)
        )
      )
    };
    
    const response = await api.put(`/study-sets/${studySetId}/flashcards/${flashcardId}/`, mappedData);
    
    // Convert response back to frontend format
    const frontendFormat = {
      id: response.data.id,
      front: response.data.question || '',
      back: response.data.answer || '',
      difficulty: response.data.difficulty || 'Medium',
      // Preserve any other fields
      ...Object.fromEntries(
        Object.entries(response.data).filter(([key]) => 
          !['id', 'question', 'answer', 'difficulty'].includes(key)
        )
      )
    };
    
    // Update cache if exists
    if (flashcardsCache[studySetId]) {
      flashcardsCache[studySetId] = flashcardsCache[studySetId].map(card => 
        card.id === flashcardId ? frontendFormat : card
      );
      flashcardsCacheTTL[studySetId] = Date.now();
      
      // Update localStorage
      try {
        localStorage.setItem('flashcardsCache', JSON.stringify(flashcardsCache));
        localStorage.setItem('flashcardsCacheTTL', JSON.stringify(flashcardsCacheTTL));
      } catch (e) {
        console.warn('Failed to update flashcards cache in localStorage:', e);
      }
    }
    
    return frontendFormat;
  } catch (error) {
    console.error(`Error updating flashcard ${flashcardId}:`, error);
    throw error;
  }
};

export const deleteFlashcard = async (studySetId: string, flashcardId: string): Promise<any> => {
  try {
    const response = await api.delete(`/study-sets/${studySetId}/flashcards/${flashcardId}/`);
    
    // Update cache if exists
    if (flashcardsCache[studySetId]) {
      flashcardsCache[studySetId] = flashcardsCache[studySetId].filter(card => card.id !== flashcardId);
      flashcardsCacheTTL[studySetId] = Date.now();
      
      // Update localStorage
      try {
        localStorage.setItem('flashcardsCache', JSON.stringify(flashcardsCache));
        localStorage.setItem('flashcardsCacheTTL', JSON.stringify(flashcardsCacheTTL));
      } catch (e) {
        console.warn('Failed to update flashcards cache in localStorage:', e);
      }
    }
    
    return response.data;
  } catch (error) {
    console.error(`Error deleting flashcard ${flashcardId}:`, error);
    throw error;
  }
};

// Quiz and Test Services
export const generateQuiz = async (studySetId: string, options: any): Promise<any> => {
  try {
    const response = await api.post(`/study-sets/${studySetId}/generate-quiz/`, options);
    return response.data;
  } catch (error) {
    console.error(`Error generating quiz for study set ${studySetId}:`, error);
    throw error;
  }
};

export const submitQuizResults = async (studySetId: string, quizId: string, results: any): Promise<any> => {
  try {
    const response = await api.post(`/study-sets/${studySetId}/quizzes/${quizId}/results/`, results);
    return response.data;
  } catch (error) {
    console.error(`Error submitting quiz results for quiz ${quizId}:`, error);
    throw error;
  }
};

// Statistics and Progress Services
export const getStudyStatistics = async (): Promise<any> => {
  try {
    const response = await api.get('/users/statistics/');
    return response.data;
  } catch (error) {
    console.error('Error fetching study statistics:', error);
    throw error;
  }
};

export const updateStudyProgress = async (studySetId: string, progressData: any): Promise<any> => {
  try {
    const response = await api.post(`/study-sets/${studySetId}/progress/`, progressData);
    return response.data;
  } catch (error) {
    console.error(`Error updating study progress for set ${studySetId}:`, error);
    throw error;
  }
};

export const createStudySetFromPdf = async (pdfId: string, title: string): Promise<StudySet> => {
  try {
    const response = await api.post('/create-study-set-from-pdf/', { 
      pdf_id: pdfId,
      title: title 
    });
    
    // Update cache if exists
    if (cachedStudySets) {
      cachedStudySets.push(response.data);
      
      // Update localStorage
      try {
        localStorage.setItem('cachedStudySets', JSON.stringify(cachedStudySets));
      } catch (e) {
        console.warn('Failed to update study sets in localStorage:', e);
      }
    }
    
    return response.data;
  } catch (error) {
    console.error('Error creating study set from PDF:', error);
    throw error;
  }
}; 