# API Services for Foster Application

This directory contains service modules for interacting with the Foster backend API.

## Available Services

- `userService.js` - Authentication and user profile management
- `studyService.js` - Study sets, flashcards, and study progress
- `calendarService.js` - Calendar events and reminders
- `aiService.js` - AI features (chat, exam generation, video generation)

## How to Use

Import the specific functions you need in your components:

```javascript
// For auth-related functions
import { loginWithEmail, registerWithEmail, updateUserProfile } from '../services/userService';

// For study-related functions
import { getStudySets, getFlashcards, createStudySet } from '../services/studyService';

// For calendar-related functions
import { getCalendarEvents, createCalendarEvent } from '../services/calendarService';

// For AI-related functions
import { sendChatMessage, generateExam } from '../services/aiService';
```

## Error Handling

All service functions are designed to be used with async/await. Use try/catch blocks for error handling:

```javascript
const fetchData = async () => {
  try {
    setLoading(true);
    const data = await getStudySets();
    setStudySets(data);
  } catch (error) {
    console.error('Error fetching study sets:', error);
    setError('Failed to load study sets');
  } finally {
    setLoading(false);
  }
};
```

## Authentication

Authentication is handled through the `AuthContext` which uses the `userService` module. The token is automatically attached to all API requests via the axios interceptor in `config/api.js`.

## Example Component Using API Services

```jsx
import React, { useState, useEffect } from 'react';
import { getStudySets, createStudySet } from '../services/studyService';

const StudySetsComponent = () => {
  const [studySets, setStudySets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newSetTitle, setNewSetTitle] = useState('');

  useEffect(() => {
    const fetchStudySets = async () => {
      try {
        setLoading(true);
        const data = await getStudySets();
        setStudySets(data);
      } catch (err) {
        setError('Failed to load study sets');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchStudySets();
  }, []);

  const handleCreateSet = async () => {
    try {
      setLoading(true);
      const newSet = await createStudySet({
        title: newSetTitle,
        description: '',
      });
      setStudySets([...studySets, newSet]);
      setNewSetTitle('');
    } catch (err) {
      setError('Failed to create new study set');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h1>Your Study Sets</h1>
      <div>
        <input
          value={newSetTitle}
          onChange={(e) => setNewSetTitle(e.target.value)}
          placeholder="Enter new set title"
        />
        <button onClick={handleCreateSet}>Create New Set</button>
      </div>
      <ul>
        {studySets.map((set) => (
          <li key={set.id}>{set.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default StudySetsComponent;
```

## API Base URL Configuration

The API base URL can be configured in your `.env` file:

```
REACT_APP_API_URL=http://localhost:5000/api
```

For production deployments, you should set the appropriate production URL.

## Service Layer Documentation

This directory contains service modules that handle all API communication and data transformation for the application.

### Structure

```
services/
  ├── aiService.ts       # AI-related functionality (chat, exam generation, etc.)
  ├── calendarService.ts # Calendar event management
  ├── studyService.ts    # Study sets and flashcards management
  ├── userService.ts     # User authentication and profile management
  └── types.ts          # TypeScript type definitions
```

### Usage Example

```typescript
import { getEvents, createEvent } from '../services/calendarService';

// Fetch calendar events
const events = await getEvents(startDate, endDate);

// Create a new event
const newEvent = await createEvent({
  title: 'Study Session',
  startTime: '2025-04-28T10:00:00Z',
  endTime: '2025-04-28T12:00:00Z',
  description: 'Prepare for the upcoming test',
  reminder: true
});
```

### Error Handling

All service functions use try-catch blocks and will throw errors that should be handled by the components:

```typescript
try {
  const events = await getEvents(startDate, endDate);
  // Handle success
} catch (error) {
  // Handle error (show toast, update error state, etc.)
}
```

### Authentication

The services automatically handle:
- Adding auth tokens to requests
- Token refresh on 401 errors
- Redirecting to login on auth failures
- Managing user sessions

### Type Safety

All services are fully typed with TypeScript:

```typescript
interface Event {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  description?: string;
  reminder?: boolean;
}

async function getEvents(startDate: string, endDate: string): Promise<Event[]>
``` 