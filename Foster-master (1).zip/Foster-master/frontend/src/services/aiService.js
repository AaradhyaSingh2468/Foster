import api from '../config/api';

// AI Chat
export const sendChatMessage = async (message, conversationId = null) => {
  try {
    const response = await api.post('/ai/chat', {
      message,
      conversation_id: conversationId,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getChatHistory = async (conversationId) => {
  try {
    const response = await api.get(`/ai/chat/${conversationId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createConversation = async (title) => {
  try {
    const response = await api.post('/ai/chat/conversations', { title });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getConversations = async () => {
  try {
    const response = await api.get('/ai/chat/conversations');
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deleteConversation = async (conversationId) => {
  try {
    const response = await api.delete(`/ai/chat/conversations/${conversationId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Exam Generation
export const generateExam = async (options) => {
  try {
    const response = await api.post('/ai/exam-generation', options);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getExamStatus = async (examId) => {
  try {
    const response = await api.get(`/ai/exam-generation/${examId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const saveExam = async (examId, examData) => {
  try {
    const response = await api.post(`/ai/exam-generation/${examId}/save`, examData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Video Generation
export const generateVideo = async (options) => {
  try {
    const response = await api.post('/ai/video-generation', options);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getVideoGenerationStatus = async (generationId) => {
  try {
    const response = await api.get(`/ai/video-generation/${generationId}/status`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getGeneratedVideo = async (generationId) => {
  try {
    const response = await api.get(`/ai/video-generation/${generationId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Sketchboard AI Features
export const enhanceSketch = async (drawingData) => {
  try {
    const response = await api.post('/ai/sketchboard/enhance', drawingData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const generateSketch = async (description) => {
  try {
    const response = await api.post('/ai/sketchboard/generate', { description });
    return response.data;
  } catch (error) {
    throw error;
  }
};

// AI Study Insights
export const getStudyInsights = async (studyData) => {
  try {
    const response = await api.post('/ai/insights', studyData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// AI Learning Recommendations
export const getStudyRecommendations = async () => {
  try {
    const response = await api.get('/ai/recommendations');
    return response.data;
  } catch (error) {
    throw error;
  }
}; 