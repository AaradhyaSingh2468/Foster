/**
 * SyncService - Centralized event system to keep components in sync
 * This ensures that when PDFs are uploaded, created, or deleted,
 * all relevant components are notified immediately.
 */

// Define event types for type safety
export type SyncEventType = 
  | 'pdf-uploaded'
  | 'pdf-deleted'
  | 'flashcards-created'
  | 'study-set-updated';

// Interface for listener functions
export interface SyncListener {
  (data?: any): void;
}

// Main service class
class SyncService {
  private listeners: Record<SyncEventType, SyncListener[]> = {
    'pdf-uploaded': [],
    'pdf-deleted': [],
    'flashcards-created': [],
    'study-set-updated': []
  };

  // Register a listener for a specific event type
  public subscribe(eventType: SyncEventType, listener: SyncListener): () => void {
    this.listeners[eventType].push(listener);
    
    // Return unsubscribe function
    return () => {
      const index = this.listeners[eventType].indexOf(listener);
      if (index !== -1) {
        this.listeners[eventType].splice(index, 1);
      }
    };
  }

  // Trigger an event with optional data
  public publish(eventType: SyncEventType, data?: any): void {
    console.log(`SyncService: Publishing ${eventType} event`, data);
    
    // Call all listeners for this event type
    this.listeners[eventType].forEach(listener => {
      try {
        listener(data);
      } catch (error) {
        console.error(`Error in sync listener for ${eventType}:`, error);
      }
    });
    
    // Also dispatch DOM event for cross-component communication
    this.dispatchDomEvent(eventType, data);
    
    // Set localStorage flag for cross-tab communication
    this.setLocalStorageFlag(eventType, data);
  }

  // Helper to dispatch DOM events
  private dispatchDomEvent(eventType: SyncEventType, data?: any): void {
    try {
      // Create a custom event with the data
      const event = new CustomEvent(`foster-${eventType}`, { 
        detail: data,
        bubbles: true,
        cancelable: true
      });
      
      // Dispatch on window
      window.dispatchEvent(event);
      
      // Also dispatch the legacy event for backward compatibility
      window.dispatchEvent(new Event('flashcardsRefreshNeeded'));
    } catch (error) {
      console.warn('Error dispatching DOM event:', error);
    }
  }

  // Helper to set localStorage flags
  private setLocalStorageFlag(eventType: SyncEventType, data?: any): void {
    try {
      // Set specific flag based on event type
      localStorage.setItem('flashcardsNeedsRefresh', 'true');
      
      // Add timestamp to trigger storage events
      localStorage.setItem('syncTimestamp', Date.now().toString());
      
      // Store event type for more specific handling
      localStorage.setItem('lastSyncEvent', eventType);
      
      // Store data if needed (as JSON)
      if (data) {
        try {
          localStorage.setItem('lastSyncData', JSON.stringify(data));
        } catch (e) {
          console.warn('Could not stringify sync data:', e);
        }
      }
    } catch (error) {
      console.warn('Error setting localStorage flags:', error);
    }
  }
}

// Export a singleton instance
const syncService = new SyncService();
export default syncService; 