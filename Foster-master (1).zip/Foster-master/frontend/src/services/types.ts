export type QuestionType = 'multiple_choice' | 'true_false' | 'short_answer' | 'essay';

export interface ExamConfig {
  startPage: number;
  endPage: number;
  numQuestions: number;
  questionTypes: QuestionType[];
}

export interface StudySetStats {
  mastered: number;
  needReview: number;
  accuracy: number;
}

export interface StudyCard {
  id?: string;
  question: string;
  answer: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
  metadata?: Array<{
    source: string;
    page: number;
  }>;
  // Frontend-specific properties
  front?: string;
  back?: string;
}

export interface StudySet {
  id: string;
  title: string;
  description?: string | null;
  createdAt: string;
  createdBy: string;
  source?: 'pdf' | 'manual' | 'ai';
  stats?: StudySetStats;
  cards: StudyCard[];
  cardCount?: number;
}

export type StudySetType = 'flashcards' | 'notes' | 'quiz';

export interface CreateStudySetData {
  title: string;
  description?: string;
  documentId?: string;
  source: 'pdf' | 'manual' | 'ai';
  cards?: StudyCard[];
  type?: StudySetType;
}

export interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isProcessing?: boolean;
  sources?: Array<string | {
    content: string;
    metadata?: {
      page?: number;
      source?: string;
    };
  }>;
}

export interface StudyBuddyResponse {
  documentId?: string;
  answer?: string;
  message?: string;
  sources?: Array<{
    content: string;
    metadata?: {
      page?: number;
      source?: string;
    };
  }>;
  error?: string;
  details?: string;
  flashcards?: StudyCard[];
  status?: string;
  isApiError?: boolean;
  job_id?: string;
  study_set_id?: string;
  // Progress tracking callback registration
  registerProgressCallback?: (callback: (message: string, progress: number) => void) => (() => void);
}

export interface FlashcardResponse extends StudyBuddyResponse {
  flashcards: StudyCard[];
}

export interface DeleteStudySetOptions {
  preservePdf?: boolean;
}

export interface PDFDocument {
  id: string;
  title: string;
  filename?: string;
  description?: string;
  uploadDate?: string;
  fileType: string;
  userId?: string;
  processingStatus?: string;
  isPersistent?: boolean;
  isPreserved?: boolean;
  stats?: {
    mastered?: number;
    needReview?: number;
    accuracy?: number;
  };
  file_path?: string;
}

export interface CreatePDFDeckOptions {
  pdf_id: string;
  title?: string;
}

export interface StudyBuddyService {
  uploadDocument: (file: File) => Promise<StudyBuddyResponse>;
  generateFlashcards: (documentId: string) => Promise<StudyBuddyResponse>;
  askQuestion: (documentId: string, question: string) => Promise<StudyBuddyResponse>;
  createStudySet: (data: CreateStudySetData) => Promise<StudySet>;
  generateExam: (documentId: string, config: ExamConfig) => Promise<StudyBuddyResponse>;
  getStudySets: (source?: string) => Promise<StudySet[]>;
  getStudySetById: (id: string) => Promise<StudySet>;
  updateStudySet: (id: string, data: Partial<StudySet>) => Promise<StudySet>;
  deleteStudySet: (id: string, options?: DeleteStudySetOptions) => Promise<void>;
}

export interface FlashCard {
  id: string;
  front: string;
  back: string;
  question?: string;
  answer?: string;
  difficulty?: 'Easy' | 'Medium' | 'Hard';
} 

// Calendar Event Types
export interface CalendarEvent {
  id: string;
  title: string;
  startTime: string;
  endTime: string;
  description?: string;
  eventType?: string;
  location?: string;
  reminder?: boolean;
  reminderTime?: number;
  createdAt?: string;
}

// Recurring Event Types
export interface RecurringEvent extends Omit<CalendarEvent, 'id'> {
  id: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  interval?: number;
  endDate?: string;
  occurrences?: number;
}

// Reminder Types
export interface Reminder {
  id: string;
  eventId: string;
  time: string;
  message?: string;
  notificationType?: 'email' | 'push' | 'sms' | 'in-app';
}

// Calendar Settings
export interface CalendarSettings {
  defaultView: 'day' | 'week' | 'month' | 'agenda';
  weekStartsOn: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  defaultReminderTime: number; // minutes before event
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
  };
} 