import api from '../config/api';

export interface Objective {
  id: string;
  title: string;
  description?: string;
  objectiveType?: string;
  completed: boolean;
  dueDate?: string;
  createdAt: string;
  completedAt?: string;
}

// Cache for objectives
let cachedObjectives: Objective[] | null = null;
let lastObjectivesFetchTime = 0;
const OBJECTIVES_CACHE_TTL = 60000; // 1 minute

// Get all objectives or filtered by completed status
export const getObjectives = async (completed?: boolean): Promise<Objective[]> => {
  try {
    // Check if we have a valid cache
    const now = Date.now();
    if (cachedObjectives && (now - lastObjectivesFetchTime < OBJECTIVES_CACHE_TTL)) {
      console.log('Using cached objectives data');
      // If we have completed filter, apply it to the cached data
      if (completed !== undefined) {
        return cachedObjectives.filter(obj => obj.completed === completed);
      }
      return cachedObjectives;
    }
    
    // Format query parameters
    const params = new URLSearchParams();
    if (completed !== undefined) {
      params.append('completed', completed.toString());
    }
    
    const response = await api.get(`/users/objectives/?${params.toString()}`);
    
    // Map backend data to frontend format
    const objectives = response.data.map((obj: any) => ({
      id: obj.id,
      title: obj.title,
      description: obj.description,
      objectiveType: obj.objective_type,
      completed: obj.completed,
      dueDate: obj.due_date,
      createdAt: obj.created_at,
      completedAt: obj.completed_at
    }));
    
    // Update cache if we're not filtering
    if (completed === undefined) {
      cachedObjectives = objectives;
      lastObjectivesFetchTime = now;
    }
    
    return objectives;
  } catch (error) {
    console.error('Error fetching objectives:', error);
    return [];
  }
};

// Get a specific objective by ID
export const getObjective = async (objectiveId: string): Promise<Objective | null> => {
  try {
    const response = await api.get(`/users/objectives/${objectiveId}/`);
    
    // Map backend data to frontend format
    return {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description,
      objectiveType: response.data.objective_type,
      completed: response.data.completed,
      dueDate: response.data.due_date,
      createdAt: response.data.created_at,
      completedAt: response.data.completed_at
    };
  } catch (error) {
    console.error(`Error fetching objective ${objectiveId}:`, error);
    return null;
  }
};

// Create a new objective
export const createObjective = async (objectiveData: Omit<Objective, 'id' | 'createdAt' | 'completedAt'>): Promise<Objective> => {
  try {
    console.log('Creating new objective:', objectiveData);
    
    // Map frontend data to backend format
    const backendData = {
      title: objectiveData.title,
      description: objectiveData.description || '',
      objective_type: objectiveData.objectiveType || 'custom',
      completed: objectiveData.completed || false,
      due_date: objectiveData.dueDate || null
    };
    
    console.log('Sending objective data to API:', backendData);
    const response = await api.post('/users/objectives/', backendData);
    console.log('Received API response for objective creation:', response.data);
    
    // Map response back to frontend format
    const createdObjective = {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description,
      objectiveType: response.data.objective_type,
      completed: response.data.completed,
      dueDate: response.data.due_date,
      createdAt: response.data.created_at,
      completedAt: response.data.completed_at
    };
    
    // Invalidate cache BEFORE returning
    cachedObjectives = null;
    console.log('Objectives cache invalidated after creation');
    
    return createdObjective;
  } catch (error) {
    console.error('Error creating objective:', error);
    throw error;
  }
};

// Update an existing objective
export const updateObjective = async (objectiveId: string, objectiveData: Partial<Objective>): Promise<Objective> => {
  try {
    // Map frontend data to backend format
    const backendData: any = {};
    
    if (objectiveData.title !== undefined) backendData.title = objectiveData.title;
    if (objectiveData.description !== undefined) backendData.description = objectiveData.description;
    if (objectiveData.objectiveType !== undefined) backendData.objective_type = objectiveData.objectiveType;
    if (objectiveData.completed !== undefined) backendData.completed = objectiveData.completed;
    if (objectiveData.dueDate !== undefined) backendData.due_date = objectiveData.dueDate;
    
    const response = await api.put(`/users/objectives/${objectiveId}/`, backendData);
    
    // Map response back to frontend format
    const updatedObjective = {
      id: response.data.id,
      title: response.data.title,
      description: response.data.description,
      objectiveType: response.data.objective_type,
      completed: response.data.completed,
      dueDate: response.data.due_date,
      createdAt: response.data.created_at,
      completedAt: response.data.completed_at
    };
    
    // Invalidate cache
    cachedObjectives = null;
    
    return updatedObjective;
  } catch (error) {
    console.error(`Error updating objective ${objectiveId}:`, error);
    throw error;
  }
};

// Delete an objective
export const deleteObjective = async (objectiveId: string): Promise<void> => {
  try {
    await api.delete(`/users/objectives/${objectiveId}/`);
    
    // Invalidate cache
    cachedObjectives = null;
  } catch (error) {
    console.error(`Error deleting objective ${objectiveId}:`, error);
    throw error;
  }
};

// Helper function to create AI content learning objectives
export const createAIVideoObjective = async (title: string, dueDate?: string): Promise<Objective> => {
  return createObjective({
    title,
    description: 'Watch and understand AI-generated video content',
    objectiveType: 'video',
    completed: false,
    dueDate
  });
};

// Helper function to create flashcard review objectives
export const createFlashcardObjective = async (title: string, dueDate?: string): Promise<Objective> => {
  return createObjective({
    title,
    description: 'Review flashcards to improve retention',
    objectiveType: 'flashcard',
    completed: false,
    dueDate
  });
};

// Helper function to create PDF study objectives
export const createPdfObjective = async (title: string, dueDate?: string): Promise<Objective> => {
  return createObjective({
    title,
    description: 'Study and interact with PDF content',
    objectiveType: 'pdf',
    completed: false,
    dueDate
  });
};

// Helper function to create quiz objectives
export const createQuizObjective = async (title: string, dueDate?: string): Promise<Objective> => {
  return createObjective({
    title,
    description: 'Complete quiz to test knowledge',
    objectiveType: 'quiz',
    completed: false,
    dueDate
  });
};

// Helper function to mark an objective as complete
export const completeObjective = async (objectiveId: string): Promise<Objective> => {
  return updateObjective(objectiveId, { completed: true });
};

// Helper function for quick objective creation
export const quickCreateObjective = async (title: string, objectiveType: string = 'custom'): Promise<Objective> => {
  try {
    // Create today's date as a string in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Create a basic objective with sensible defaults
    return createObjective({
      title,
      description: '',
      objectiveType,
      completed: false,
      dueDate: today
    });
  } catch (error) {
    console.error('Error creating quick objective:', error);
    throw error;
  }
}; 