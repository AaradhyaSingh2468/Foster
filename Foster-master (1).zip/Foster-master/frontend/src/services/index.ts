// Re-export all services, avoiding conflicts by using specific imports
export * from './studyService';
export * from './calendarService';
export * from './websocketService';

// Import individual functions from studyBuddyService
import {
  uploadDocument,
  askQuestion,
  createStudySet,
  getStudySets,
  getStudySetById,
  updateStudySet,
  deleteStudySet,
  generateExam,
  generateFlashcards,
  refreshStudySets,
  createStudySetFromPdf,
  checkForCompletedJobs
} from './studyBuddyService';

// Re-export them
export {
  uploadDocument,
  askQuestion,
  createStudySet,
  getStudySets,
  getStudySetById,
  updateStudySet,
  deleteStudySet,
  generateExam,
  generateFlashcards,
  refreshStudySets,
  createStudySetFromPdf,
  checkForCompletedJobs
};

export * from './documentService';
export * from './syncService'; 