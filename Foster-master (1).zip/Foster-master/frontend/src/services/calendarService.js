import api from '../config/api';

// Calendar Events
export const getEvents = async (startDate, endDate) => {
  try {
    const response = await api.get('/calendar/events/', {
      params: { start_date: startDate, end_date: endDate },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching calendar events:', error);
    return [];
  }
};

export const getEvent = async (eventId) => {
  try {
    const response = await api.get(`/calendar/events/${eventId}/`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching calendar event ${eventId}:`, error);
    return null;
  }
};

export const createEvent = async (eventData) => {
  try {
    const response = await api.post('/calendar/events/', eventData);
    return response.data;
  } catch (error) {
    console.error('Error creating calendar event:', error);
    throw error;
  }
};

export const updateEvent = async (eventId, eventData) => {
  try {
    const response = await api.put(`/calendar/events/${eventId}/`, eventData);
    return response.data;
  } catch (error) {
    console.error(`Error updating calendar event ${eventId}:`, error);
    throw error;
  }
};

export const deleteEvent = async (eventId) => {
  try {
    const response = await api.delete(`/calendar/events/${eventId}/`);
    return response.data;
  } catch (error) {
    console.error(`Error deleting calendar event ${eventId}:`, error);
    throw error;
  }
};

// Recurring Events
export const createRecurringEvent = async (recurringEventData) => {
  try {
    const response = await api.post('/calendar/recurring-events/', recurringEventData);
    return response.data;
  } catch (error) {
    console.error('Error creating recurring event:', error);
    throw error;
  }
};

export const updateRecurringEvent = async (eventId, updateData) => {
  try {
    const response = await api.put(`/calendar/recurring-events/${eventId}/`, {
      ...updateData,
    });
    return response.data;
  } catch (error) {
    console.error(`Error updating recurring event ${eventId}:`, error);
    throw error;
  }
};

export const deleteRecurringEvent = async (eventId, deleteOptions) => {
  try {
    const response = await api.delete(`/calendar/recurring-events/${eventId}/`, {
      data: deleteOptions,
    });
    return response.data;
  } catch (error) {
    console.error(`Error deleting recurring event ${eventId}:`, error);
    throw error;
  }
};

// Reminders
export const getReminders = async () => {
  try {
    const response = await api.get('/calendar/reminders/');
    return response.data;
  } catch (error) {
    console.error('Error fetching reminders:', error);
    return [];
  }
};

export const createReminder = async (reminderData) => {
  try {
    const response = await api.post('/calendar/reminders/', reminderData);
    return response.data;
  } catch (error) {
    console.error('Error creating reminder:', error);
    throw error;
  }
};

export const updateReminder = async (reminderId, reminderData) => {
  try {
    const response = await api.put(`/calendar/reminders/${reminderId}/`, reminderData);
    return response.data;
  } catch (error) {
    console.error(`Error updating reminder ${reminderId}:`, error);
    throw error;
  }
};

export const deleteReminder = async (reminderId) => {
  try {
    const response = await api.delete(`/calendar/reminders/${reminderId}/`);
    return response.data;
  } catch (error) {
    console.error(`Error deleting reminder ${reminderId}:`, error);
    throw error;
  }
};

// Calendar Settings
export const getCalendarSettings = async () => {
  try {
    const response = await api.get('/calendar/settings/');
    return response.data;
  } catch (error) {
    console.error('Error fetching calendar settings:', error);
    return {};
  }
};

export const updateCalendarSettings = async (settingsData) => {
  try {
    const response = await api.put('/calendar/settings/', settingsData);
    return response.data;
  } catch (error) {
    console.error('Error updating calendar settings:', error);
    throw error;
  }
}; 