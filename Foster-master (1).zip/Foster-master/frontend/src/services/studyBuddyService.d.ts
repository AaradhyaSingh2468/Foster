export type QuestionType = 'multiple_choice' | 'true_false' | 'short_answer';

export interface StudyBuddyResponse {
  success: boolean;
  message?: string;
  data?: any;
  error?: string;
}

export interface ExamConfig {
  questionCount: number;
  questionTypes: QuestionType[];
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Card {
  id: number;
  term: string;
  definition: string;
}

export interface StudySet {
  id: string;
  title: string;
  description?: string;
  source?: 'manual' | 'pdf' | 'ai';
  createdAt: string;
  createdBy?: string;
  avatar?: string;
  cards: Card[];
  stats?: {
    mastered: number;
    needReview: number;
    accuracy: number;
  };
}

export interface CreateStudySetData {
  title: string;
  description?: string;
  cards: Card[];
  source: 'manual' | 'pdf' | 'ai';
}

export interface StudyBuddyService {
  uploadDocument: (file: File) => Promise<StudyBuddyResponse>;
  askQuestion: (question: string, documentId?: string | null) => Promise<StudyBuddyResponse>;
  generateFlashcards: (documentId: string) => Promise<StudyBuddyResponse>;
  generateExam: (documentId: string, config: ExamConfig) => Promise<StudyBuddyResponse>;
  createStudySet: (data: CreateStudySetData) => Promise<StudySet>;
  getStudySets: () => Promise<StudySet[]>;
  getStudySetById: (id: string) => Promise<StudySet>;
  updateStudySet: (id: string, data: Partial<StudySet>) => Promise<StudySet>;
  deleteStudySet: (id: string) => Promise<void>;
}

declare const studyBuddyService: StudyBuddyService;

export default studyBuddyService; 