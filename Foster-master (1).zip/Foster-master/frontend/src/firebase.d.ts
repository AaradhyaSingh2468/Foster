// This file provides TypeScript declarations for custom modules

declare module '../context/AuthContext' {
  import { ReactNode } from 'react';
  import { User } from 'firebase/auth';

  export interface AuthContextType {
    currentUser: User | null;
    loading: boolean;
    error: string | null;
    signInWithEmail: (email: string, password: string) => Promise<any>;
    signUpWithEmail: (email: string, password: string) => Promise<any>;
    signInWithGoogle: () => Promise<any>;
    signInWithGithub: () => Promise<any>;
    linkAccounts: (credential: any) => Promise<any>;
    logout: () => Promise<void>;
    clearError: () => void;
  }

  export const AuthProvider: React.FC<{ children: ReactNode }>;
  export const useAuth: () => AuthContextType;
} 