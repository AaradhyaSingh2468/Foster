import React from 'react';
import './index.css';

// Re-export all the components that need to be accessed from outside
export { default as Chat } from './pages/Chat';
export { default as Calendar } from './pages/Calendar';
export { default as Insights } from './pages/Insights';
export { default as FlashCards } from './pages/FlashCards';
export { default as Tests } from './pages/Tests';
export { default as Sketchboard } from './pages/Sketchboard';
export { default as ExamGeneration } from './pages/ExamGeneration';
export { default as VideoGeneration } from './pages/VideoGeneration';
export { default as StudySet } from './pages/StudySet';
export { default as Profile } from './pages/Profile';
export { default as AccountSettings } from './pages/AccountSettings'; 
export { default as Dashboard } from './pages/Dashboard';