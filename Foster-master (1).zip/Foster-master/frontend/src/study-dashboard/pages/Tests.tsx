import type React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { FileText, Check, Clock, Award, BookOpen } from 'lucide-react';

const Tests: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Tests & QuizFetch</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="text-purple-400" />
              Available Tests
            </CardTitle>
            <CardDescription className="text-gray-400">
              Tests ready for you to take
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: 'Midterm Practice Exam', subject: 'Computer Science', questions: 25, timeLimit: '45 minutes' },
                { name: 'Chapter 7 Quiz', subject: 'Biology', questions: 15, timeLimit: '20 minutes' },
                { name: 'Historical Analysis Test', subject: 'History', questions: 10, timeLimit: '30 minutes' },
              ].map((test, index) => (
                <div key={test.name} className="p-4 bg-gray-700/50 rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{test.name}</h3>
                    <div className="text-sm text-gray-400 mt-1">{test.subject} • {test.questions} questions</div>
                    <div className="text-xs text-gray-500 mt-1 flex items-center">
                      <Clock size={12} className="mr-1" /> {test.timeLimit}
                    </div>
                  </div>
                  <Button className="bg-purple-600 hover:bg-purple-700">
                    Start
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Check className="text-green-400" />
              Completed Tests
            </CardTitle>
            <CardDescription className="text-gray-400">
              Your previous test results
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: 'Chapter 5 Quiz', subject: 'Mathematics', score: '92%', date: 'Apr 23, 2025' },
                { name: 'Molecular Biology Quiz', subject: 'Biology', score: '85%', date: 'Apr 21, 2025' },
              ].map((test) => (
                <div key={test.name} className="p-4 bg-gray-700/50 rounded-lg flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">{test.name}</h3>
                    <div className="text-sm text-gray-400 mt-1">{test.subject}</div>
                    <div className="text-xs text-gray-500 mt-1">{test.date}</div>
                  </div>
                  <div className="text-xl font-bold text-green-400">{test.score}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="text-yellow-400" />
            Test Performance
          </CardTitle>
          <CardDescription className="text-gray-400">
            Your performance over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-60 flex items-center justify-center text-gray-400">
            <p>Performance chart will appear after taking more tests</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="text-blue-400" />
              Create a New Test
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-6">
              <p className="text-gray-400 mb-4">Generate custom tests from your study materials</p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Create Test
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Tips for Test Success</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-gray-300 text-sm">
              <p>• Review your notes and flashcards before starting a test</p>
              <p>• Read each question carefully before answering</p>
              <p>• Manage your time effectively during timed tests</p>
              <p>• Review your answers if time permits</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Tests;
