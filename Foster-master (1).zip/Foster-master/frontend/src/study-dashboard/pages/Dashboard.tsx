import type React from 'react';
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { FiSearch, FiPlus, FiFolder, FiShare2, FiCalendar, FiBookOpen } from 'react-icons/fi';
import { getStudySets, getStudyStatistics } from '../../services/studyService';
import { getEvents } from '../../services/calendarService';
import { createQuickEvent } from '../../services/quickEventService';
import { quickCreateObjective, updateObjective } from '../../services/objectiveService';
import UploadPDFButton from '../components/UploadPDFButton';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { CreateSetModal } from '../components/modals/CreateSetModal';
import { QuickEventModal } from '../components/modals/QuickEventModal';
import ObjectiveFormModal from '../components/modals/ObjectiveFormModal';
import { showErrorToast, showSuccessToast } from '../../utils/toastUtils';
import type { CalendarEvent, RecurringEvent, Reminder, CalendarSettings } from '../../services/types';

interface StudySet {
  id: string;
  title: string;
  description: string | null;
  createdAt: string;
  cardCount: number;
}

interface Statistics {
  streak: number;
  objectives: {
    completed: number;
    total: number;
    items: Array<{
      id: string;
      title: string;
      completed: boolean;
    }>;
  };
}

const Dashboard: React.FC = () => {
  const [studySets, setStudySets] = useState<StudySet[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<CalendarEvent[]>([]);
  const [statistics, setStatistics] = useState<Statistics | null>(null);
  const [loadingObjectives, setLoadingObjectives] = useState<{[key: string]: boolean}>({});
  const navigate = useNavigate();
  const [loading, setLoading] = useState({
    studySets: true,
    events: true,
    statistics: true
  });
  const [error, setError] = useState<{
    studySets: string | null,
    events: string | null,
    statistics: string | null
  }>({
    studySets: null,
    events: null,
    statistics: null
  });
  
  // Add state for the event modal
  const [showEventModal, setShowEventModal] = useState(false);
  const [showObjectiveModal, setShowObjectiveModal] = useState(false);

  // Helper function to safely get event time field (handles both camelCase and snake_case)
  const getEventTimeField = (event: any, field: 'start' | 'end'): string => {
    if (!event) return '';
    return event[`${field}Time`] || event[`${field}_time`] || '';
  };

  // Helper function to format dates consistently
  const formatDisplayDateTime = (dateString: string): string => {
    try {
      // If dateString is not provided or invalid, return a default message
      if (!dateString || typeof dateString !== 'string') {
        console.warn("Invalid date input:", dateString);
        return "Scheduled Session";
      }
      
      // Try to parse the date
      const date = new Date(dateString);
      
      // Check if the date is valid
      if (isNaN(date.getTime())) {
        console.warn("Invalid date format:", dateString);
        return "Scheduled Session";
      }
      
      // Format date as "DD/MM/YYYY"
      const day = date.getDate();
      const month = date.getMonth() + 1; // JavaScript months are 0-indexed
      const year = date.getFullYear();
      const dateDisplay = `${day}/${month}/${year}`;
      
      // Format time as "HH:mm AM/PM"
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const ampm = hours >= 12 ? 'pm' : 'am';
      const hoursDisplay = hours % 12 || 12; // Convert 0 to 12 for 12 AM
      const minutesDisplay = minutes < 10 ? `0${minutes}` : minutes;
      const timeDisplay = `${hoursDisplay}:${minutesDisplay} ${ampm}`;
      
      return `${dateDisplay} · ${timeDisplay}`;
    } catch (e) {
      console.error("Error formatting date:", e, "for input:", dateString);
      return "Scheduled Session";
    }
  };

  // Fetch study sets
  const fetchStudySets = async () => {
    try {
      const data = await getStudySets();
      // Map the API response to the local StudySet type
      const mappedData = data.map(set => ({
        id: set.id,
        title: set.title,
        description: set.description || null,
        createdAt: set.createdAt,
        cardCount: set.cardCount || set.cards?.length || 0
      }));
      setStudySets(mappedData);
    } catch (err) {
      console.error('Error fetching study sets:', err);
      setError(prev => ({ ...prev, studySets: 'Failed to load study sets' }));
      showErrorToast("Data Error", "Unable to load your study sets");
    } finally {
      setLoading(prev => ({ ...prev, studySets: false }));
    }
  };

  // Fetch events
  const fetchEvents = async () => {
    try {
      setLoading(prev => ({ ...prev, events: true }));
      setError(prev => ({ ...prev, events: null }));
      
      // Get upcoming events for next 7 days
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 7);
      
      // Get events from API
      const data = await getEvents(startDate.toISOString(), endDate.toISOString());
      console.log('Fetched events:', data);
      
      // Set the events without modifying the original date format strings
      // This ensures consistent display between components
      setUpcomingEvents(data);
    } catch (err) {
      console.error('Error fetching events:', err);
      setError(prev => ({ ...prev, events: 'Failed to load events' }));
      showErrorToast("Event Error", "Unable to load your upcoming events");
    } finally {
      setLoading(prev => ({ ...prev, events: false }));
    }
  };

  // Fetch statistics
  const fetchStatistics = async () => {
    try {
      const data = await getStudyStatistics();
      
      // Ensure that the statistics data has the expected structure
      const validatedData = {
        streak: data.streak || 0,
        objectives: {
          completed: data.objectives?.completed || 0,
          total: data.objectives?.total || 0,
          items: Array.isArray(data.objectives?.items) ? data.objectives.items : []
        }
      };
      
      setStatistics(validatedData);
    } catch (err) {
      console.error('Error fetching statistics:', err);
      setError(prev => ({ ...prev, statistics: 'Failed to load statistics' }));
      showErrorToast("Statistics Error", "Unable to load your study statistics");
      
      // Set default empty statistics structure in case of error
      setStatistics({
        streak: 0,
        objectives: {
          completed: 0,
          total: 0,
          items: []
        }
      });
    } finally {
      setLoading(prev => ({ ...prev, statistics: false }));
    }
  };

  useEffect(() => {
    fetchStudySets();
    fetchEvents();
    fetchStatistics();
  }, []);

  // Handle quick objective creation
  const handleAddQuickObjective = async () => {
    try {
      // Create a default study objective
      const objective = await quickCreateObjective("Complete a learning module", "custom");
      showSuccessToast("Objective Created", "New learning objective has been added");
      
      // Refresh statistics by calling fetchStatistics
      await fetchStatistics();

      // Also manually update the statistics state with the new objective
      setStatistics(prev => {
        if (!prev) return {
          streak: 0,
          objectives: {
            completed: 0,
            total: 1,
            items: [{
              id: objective.id,
              title: objective.title,
              completed: objective.completed
            }]
          }
        };

        return {
          ...prev,
          objectives: {
            completed: prev.objectives.completed,
            total: prev.objectives.total + 1,
            items: [
              ...prev.objectives.items,
              {
                id: objective.id,
                title: objective.title,
                completed: objective.completed
              }
            ]
          }
        };
      });
    } catch (error) {
      console.error("Error creating quick objective:", error);
      showErrorToast("Objective Error", "Failed to create a learning objective");
    }
  };

  // Handle opening the objective form modal
  const handleAddObjective = () => {
    setShowObjectiveModal(true);
  };

  // Refresh all data
  const refreshData = async () => {
    await Promise.all([
      fetchEvents(),
      fetchStatistics(),
      fetchStudySets()
    ]);
  };

  // Handle toggling objective completion
  const handleToggleObjective = async (objectiveId: string, completed: boolean) => {
    try {
      // Set loading state for this specific objective
      setLoadingObjectives(prev => ({ ...prev, [objectiveId]: true }));
      
      // Update the objective completion status
      await updateObjective(objectiveId, { completed });
      
      showSuccessToast("Objective Updated", `Objective marked as ${completed ? 'completed' : 'incomplete'}`);
      
      // Refresh statistics by calling fetchStatistics
      await fetchStatistics();
    } catch (error) {
      console.error("Error updating objective:", error);
      showErrorToast("Objective Error", "Failed to update objective completion status");
    } finally {
      // Clear loading state
      setLoadingObjectives(prev => ({ ...prev, [objectiveId]: false }));
    }
  };

  return (
    <div className="animate-fade-in">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Your Study Sets</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Upcoming Events Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Upcoming Events</CardTitle>
            <Button variant="link" size="sm" className="text-blue-400 font-medium">
              <Link to="/study-dashboard/calendar">View All</Link>
            </Button>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-xs mb-3">Scheduled study sessions and deadlines</p>
            {loading.events ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-400"></div>
              </div>
            ) : upcomingEvents.length > 0 ? (
              <div className="space-y-4">
                {upcomingEvents.slice(0, 3).map((event) => (
                  <div
                    key={event.id}
                    className="bg-gray-700/50 rounded-lg p-3 flex items-center justify-between"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{event.title}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {formatDisplayDateTime(getEventTimeField(event, 'start'))}
                      </p>
                    </div>
                    {event.reminder && (
                      <div className="flex-shrink-0 ml-2 bg-amber-500/20 text-amber-300 text-xs px-2 py-1 rounded">
                        Reminder
                      </div>
                    )}
                  </div>
                ))}
                
                {upcomingEvents.length > 3 && (
                  <div className="text-center mt-2">
                    <Link to="/study-dashboard/calendar" className="text-xs text-blue-400 hover:underline">
                      +{upcomingEvents.length - 3} more events
                    </Link>
                  </div>
                )}
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-2 border-gray-700 text-purple-300 hover:bg-gray-700 flex items-center justify-center gap-2"
                  onClick={() => setShowEventModal(true)}
                >
                  <FiPlus className="h-4 w-4" /> Add Event
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                  className="w-20 h-20 mb-4 rounded-full bg-blue-500/20 flex items-center justify-center"
                >
                  <FiCalendar className="h-10 w-10 text-blue-400" />
                </motion.div>
                <p className="text-gray-400 text-sm">No upcoming events</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
                  onClick={() => setShowEventModal(true)}
                >
                  Add Event
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Daily Objectives Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Daily Objectives</CardTitle>
            {/* <Button variant="link" size="sm" className="text-blue-400 font-medium">
              <Link to="/study-dashboard/insights">View All</Link>
            </Button> */}
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 text-xs mb-3">Tasks to complete for your learning goals</p>
            {loading.statistics ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-400"></div>
              </div>
            ) : error.statistics ? (
              <div className="text-center py-8 text-red-400">{error.statistics}</div>
            ) : statistics && statistics.objectives && statistics.objectives.items && statistics.objectives.items.length > 0 ? (
              <div className="space-y-2">
                {statistics.objectives.items.map(objective => (
                  <motion.div
                    key={objective.id}
                    className="flex items-center p-3 rounded-lg bg-gray-700 border border-gray-600 hover:bg-gray-600 transition-colors cursor-pointer mt-2"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleToggleObjective(objective.id, !objective.completed)}
                  >
                    <div className="mr-4 bg-red-500/20 p-2 rounded-lg">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-red-500">
                        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2"/>
                        <path d="M12 15V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                        <path d="M9 11L12 8L15 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-white">{objective.title}</h4>
                    </div>
                    <div 
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors 
                        ${objective.completed ? 'border-green-500 bg-green-500/20 hover:bg-green-500/30' : 'border-gray-400 hover:border-green-400 hover:bg-green-500/10'}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleObjective(objective.id, !objective.completed);
                      }}
                      title={objective.completed ? "Mark as incomplete" : "Mark as complete"}
                    >
                      {loadingObjectives[objective.id] ? (
                        <div className="w-3 h-3 border-t-2 border-green-400 rounded-full animate-spin"></div>
                      ) : (
                        objective.completed && <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M2 6L5 9L10 3" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                  className="w-20 h-20 mb-4 rounded-full bg-red-500/20 flex items-center justify-center"
                >
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-red-500">
                    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2"/>
                    <path d="M12 15V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M9 11L12 8L15 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </motion.div>
                <p className="text-gray-400 text-sm">No objectives for today</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
                  onClick={handleAddObjective}
                >
                  Add Objective
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Your Streak Card */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Your Streak</CardTitle>
            <Button variant="link" size="sm" className="text-blue-400 font-medium">
              <Link to="/study-dashboard/insights">Leaderboard</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {loading.statistics ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-400"></div>
              </div>
            ) : error.statistics ? (
              <div className="text-center py-8 text-red-400">{error.statistics}</div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="flex items-center gap-4">
                  <span className="text-4xl font-bold">{statistics?.streak || 0} Days</span>
                  <span className="text-3xl">🔥</span>
                </div>
                {(statistics?.streak || 0) === 0 && (
                  <p className="text-gray-400 text-sm mt-2 text-center">Complete objectives to start your streak!</p>
                )}
                {(statistics?.streak || 0) > 0 && (
                  <p className="text-gray-400 text-sm mt-2 text-center">Keep your streak alive by studying daily!</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tabs Section */}
      <Tabs defaultValue="study-sets" className="w-full">
        <TabsList className="bg-transparent border-b border-gray-700 w-full justify-start h-auto p-0 space-x-6">
          <TabsTrigger
            value="study-sets"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none font-medium text-sm"
          >
            Study Sets
          </TabsTrigger>
          <Link 
            to="/study-dashboard/chat" 
            className="pb-2 px-1 text-gray-400 hover:text-purple-300 border-b border-transparent hover:border-purple-500 transition-colors h-10 flex items-center font-medium text-sm"
          >
            Chat
          </Link>
          <Link
            to="/study-dashboard/chat"
            className="pb-2 px-1 text-gray-400 hover:text-purple-300 border-b border-transparent hover:border-purple-500 transition-colors h-10 flex items-center font-medium text-sm"
          >
            Flashcards
          </Link>
          {/* QuizFetch tab trigger - commented out */}
          {/* 
          <TabsTrigger
            value="quizfetch"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            QuizFetch
          </TabsTrigger>
          */}
          {/* Tests tab trigger - commented out */}
          {/*
          <TabsTrigger
            value="tests"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Tests
          </TabsTrigger>
          */}
        </TabsList>

        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="relative w-full max-w-md">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search your study sets..."
                className="pl-10 bg-gray-800/50 border-gray-700 text-white focus-visible:ring-purple-500"
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                Edit
              </Button>

              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                Sort
              </Button>

              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700 backdrop-blur-sm"
              >
                <FiFolder size={18} />
              </Button>

              <UploadPDFButton />

              <Button
                variant="default"
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Create <FiPlus size={18} className="ml-1" />
              </Button>
            </div>
          </div>

          <TabsContent value="study-sets" className="mt-6">
            {loading.studySets ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-400"></div>
              </div>
            ) : error.studySets ? (
              <div className="text-center py-12 text-red-400">{error.studySets}</div>
            ) : studySets.length > 0 ? (
              <div className="space-y-3">
                {studySets.map(studySet => (
                  <Link key={studySet.id} to={`/study-dashboard/study-set/${studySet.id}`} className="block hover:bg-gray-800/70 rounded-lg transition-colors">
                    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 flex items-center justify-between backdrop-blur-sm">
                      <div className="flex items-center gap-4">
                        <div className="bg-gray-700 h-12 w-12 rounded-full flex items-center justify-center text-purple-400 font-bold overflow-hidden">
                          <FiBookOpen size={24} />
                        </div>
                        <div>
                          <h3 className="text-white font-medium">{studySet.title}</h3>
                          <p className="text-gray-400 text-sm">{studySet.description || 'No Description'}</p>
                          <p className="text-gray-500 text-xs">Created At: {new Date(studySet.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="bg-gray-700 p-2 rounded-full">
                          <span className="text-green-400">•</span>
                          <span className="text-white ml-1">{studySet.cardCount}</span>
                        </div>
                        <Button variant="ghost" className="text-gray-400 hover:text-white">
                          <FiShare2 size={18} />
                        </Button>
                        <Button variant="link" className="text-blue-400">
                          Share
                        </Button>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
                <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                  <FiBookOpen size={32} className="text-purple-400" />
                </div>
                <h3 className="text-xl font-medium text-white mb-2">No Study Sets Yet</h3>
                <p className="text-gray-400 text-center max-w-md mb-6">Create your first study set to start organizing your learning materials</p>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Create New Study Set <FiPlus size={18} className="ml-1" />
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="flashcards" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <FiBookOpen className="h-10 w-10 text-gray-400" />
              </div>
              <p className="text-gray-400">No flashcards found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Create Flashcards
              </Button>
            </div>
          </TabsContent>

          {/* QuizFetch TabContent - Commented out */}
          {/* 
          <TabsContent value="quizfetch" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-gray-400">
                  <path d="M9 11L12 14L15 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 14V6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M20 16.7428C21.2215 15.734 22 14.2079 22 12.5C22 9.46243 19.5376 7 16.5 7C16.2815 7 16.0771 7.01859 15.8767 7.04592C14.7983 4.16477 12.0895 2 9 2C4.58172 2 1 5.58172 1 10C1 12.2091 1.89821 14.2091 3.34317 15.6365" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9.93246 20.5193C9.6794 20.8175 9.36562 21 9 21C8.44772 21 8 20.5523 8 20V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M17 16C17 18.7614 14.7614 21 12 21C11.6447 21 11.298 20.9594 10.9644 20.8812" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-gray-400">No quizzes found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Generate Quiz
              </Button>
            </div>
          </TabsContent>
          */}

          {/* Tests TabContent - Commented out */}
          {/* 
          <TabsContent value="tests" className="mt-6">
            <div className="flex flex-col items-center justify-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <div className="bg-gray-700/50 h-20 w-20 rounded-full flex items-center justify-center mb-4">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-gray-400">
                  <path d="M9 5H7C5.89543 5 5 5.89543 5 7V19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19V7C19 5.89543 18.1046 5 17 5H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 9H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 13H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 17H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M12 3L9 5L12 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <p className="text-gray-400">No tests found.</p>
              <Button
                variant="outline"
                className="mt-4 border-gray-700 text-purple-300 hover:bg-gray-700"
              >
                <FiPlus className="mr-2" /> Create Test
              </Button>
            </div>
          </TabsContent>
          */}
        </div>
      </Tabs>
      
      {/* Add the QuickEventModal */}
      <QuickEventModal
        isOpen={showEventModal}
        onClose={() => setShowEventModal(false)}
        onEventCreated={() => {
          fetchEvents(); // Refresh events after creation
        }}
      />
      
      {/* Add the ObjectiveFormModal */}
      <ObjectiveFormModal
        isOpen={showObjectiveModal}
        onClose={() => setShowObjectiveModal(false)}
        onObjectiveCreated={() => {
          fetchStatistics(); // Refresh statistics after objective creation
        }}
      />
    </div>
  );
};

export default Dashboard;
