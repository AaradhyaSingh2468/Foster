import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  Loader2,
  FileText,
  PlusCircle,
  Search,
  XCircle,
  ListFilter,
  Check,
  Star,
  RefreshCw,
  Trash2,
  MoreHorizontal,
  ChevronDown,
  BookOpen,
  Clock,
  AlertTriangle,
  Plus,
  Filter,
  LayoutGrid,
  LayoutList,
  Menu,
  X,
  RotateCw,
  ArrowLeft,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  InfoIcon,
  Minus,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "../lib/useToast";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import { Checkbox } from "../components/ui/checkbox";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import { Label } from "../components/ui/label";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import FlashCardSet from "../components/FlashCardSet";
import AutoRecovery from "../components/AutoRecovery";
import {
  getStudySets,
  getFlashcards,
  createStudySet,
  createFlashcard,
  deleteFlashcard,
  updateStudyProgress,
  deleteStudySet,
} from "../../services/studyService";
import studyBuddyService, {
  generateFlashcards,
} from "../../services/studyBuddyService";
import websocketService from "../../services/websocketService";
import { Textarea } from "../components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "../components/ui/select";
import {
  getUserDocuments,
  type Document,
} from "../../services/documentService";
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import {
  CreateStudySetData,
  PDFDocument,
  StudySet,
} from "../../services/types";
import { TooltipProvider } from "../components/ui/tooltip";
import {
  showSuccessToast,
  showInfoToast,
  showErrorToast,
} from "../../utils/toastUtils";
import syncService from "../../services/syncService";
import type { SyncEventType } from "../../services/syncService";
import { Slider } from "../components/ui/slider";
import { flushSync } from "react-dom";

// Add at the top of the file, right after imports
console.log(
  "WebSocket flashcard update fix v2 loaded with flushSync - " +
    new Date().toISOString(),
);

// Add global typing to fix TypeScript errors with our global notifications
// Add this before the FlashCards component declaration
declare global {
  interface Window {
    websocketNotifications?: any[];
  }
}

// Types
interface FlashCard {
  id: string;
  front: string;
  back: string;
}

interface Deck {
  id: string;
  title: string;
  description: string;
  cards: FlashCard[];
  source?: "manual" | "pdf" | "ai";
  stats: {
    totalCards: number;
    mastered: number;
    needReview: number;
    accuracy: number;
    streak: number;
  };
}

const FlashCards: React.FC = () => {
  const [decks, setDecks] = useState<Deck[]>([]);
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);
  const [mode, setMode] = useState<"browse" | "learn" | "quiz">("browse");
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [newDeckTitle, setNewDeckTitle] = useState("");
  const [newDeckDescription, setNewDeckDescription] = useState("");
  // Always set to false since we only support PDF-based flashcards
  const [showNewDeckForm, setShowNewDeckForm] = useState(false);
  const [newCardFront, setNewCardFront] = useState("");
  const [newCardBack, setNewCardBack] = useState("");
  const [showNewCardForm, setShowNewCardForm] = useState(false);
  const [loading, setLoading] = useState({
    decks: true,
    cards: false,
    creating: false,
    documents: false, // Add loading state for documents
  });
  const [error, setError] = useState<{
    decks: string | null;
    cards: string | null;
    creating: string | null;
    documents: string | null;
  }>({
    decks: null,
    cards: null,
    creating: null,
    documents: null,
  });
  const [aiGenerateMode, setAiGenerateMode] = useState(false);
  const [generatingCards, setGeneratingCards] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationMessage, setGenerationMessage] = useState("");
  const [topicToGenerate, setTopicToGenerate] = useState("");
  const [numCardsToGenerate, setNumCardsToGenerate] = useState(2);
  const [documentIdToGenerate, setDocumentIdToGenerate] = useState("");
  const [documents, setDocuments] = useState<PDFDocument[]>([]);
  const [isDocumentsAvailable, setIsDocumentsAvailable] =
    useState<boolean>(false);
  const [selectedDocument, setSelectedDocument] = useState<PDFDocument | null>(
    null,
  );
  const fetchedDocsRef = useRef(false);
  const isMountedRef = useRef(true);
  const timeoutsRef = useRef<NodeJS.Timeout[]>([]);
  // Track deck IDs we've already fetched to prevent infinite loops
  const fetchedDeckIdsRef = useRef<Set<string>>(new Set());
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);
  const [deckToDelete, setDeckToDelete] = useState<string | null>(null);
  const [preservePdf, setPreservePdf] = useState<boolean>(true);

  const { toast } = useToast();

  // Add a ref to track if we're currently fetching cards
  const fetchingCardsRef = useRef<boolean>(false);

  // Define the fetchDecks function first to avoid dependency issues
  const fetchDecks = useCallback(async () => {
    try {
      setLoading((prev) => ({ ...prev, decks: true }));
      setError((prev) => ({ ...prev, decks: null }));

      const studySets = await getStudySets();

      // Transform to match our Deck interface
      const transformedDecks = studySets.map((set: any) => ({
        id: set.id,
        title: set.title,
        description: set.description || "",
        cards: [], // Will load cards when deck is selected
        source: set.source as "manual" | "pdf" | "ai",
        stats: {
          totalCards: set.cardCount || 0,
          mastered: set.stats?.mastered || 0,
          needReview: set.stats?.needReview || 0,
          accuracy: set.stats?.accuracy || 0,
          streak: set.stats?.streak || 0,
        },
      }));

      if (isMountedRef.current) {
        setDecks(transformedDecks);
        setLoading((prev) => ({ ...prev, decks: false }));
      }
    } catch (err) {
      if (isMountedRef.current) {
        console.error("Error fetching study sets:", err);
        setError((prev) => ({
          ...prev,
          decks: "Failed to load flashcard decks",
        }));
        setLoading((prev) => ({ ...prev, decks: false }));
      }
    }
  }, [isMountedRef]);

  // Add WebSocket connection state
  const [wsConnected, setWsConnected] = useState(false);
  const websocketRef = useRef<string | null>(null);

  // Add a new state variable to track flashcard updates
  const [lastFlashcardUpdate, setLastFlashcardUpdate] = useState<number>(0);

  // Add session storage check for notifications at component startup - run once after decks are loaded
  useEffect(() => {
    // Only run this once after decks are loaded (not on every render)
    if (!loading.decks && decks.length > 0) {
      console.log(
        "Checking sessionStorage for unprocessed WebSocket notifications",
      );

      try {
        const storedNotifications = sessionStorage.getItem(
          "websocketNotifications",
        );
        if (storedNotifications) {
          const notifications = JSON.parse(storedNotifications);
          if (notifications && notifications.length > 0) {
            console.log(
              `Found ${notifications.length} stored notifications:`,
              notifications,
            );

            // Process job completion notifications
            const jobCompletions = notifications.filter(
              (n: any) =>
                n.type === "job_completed" && n.data && n.data.flashcards,
            );

            if (jobCompletions.length > 0) {
              console.log(
                `Processing ${jobCompletions.length} stored job completion notifications`,
              );

              // Process the most recent one
              const latestNotification =
                jobCompletions[jobCompletions.length - 1];

              // Use flushSync to ensure immediate UI update
              flushSync(() => {
                setLastFlashcardUpdate(Date.now());
              });

              // Fetch decks to get the latest data
              fetchDecks();
            }
          }
        }
      } catch (err) {
        console.error("Error processing stored WebSocket notifications:", err);
      }
    }
  }, [loading.decks, decks.length, fetchDecks]);

  // Cleanup effect on unmount
  useEffect(() => {
    // Store reference to current timeouts for cleanup
    const currentTimeoutsRef = timeoutsRef;

    return () => {
      // Mark component as unmounted
      isMountedRef.current = false;

      // Clear all timeouts using stored reference
      currentTimeoutsRef.current.forEach((id) => clearTimeout(id));
      currentTimeoutsRef.current = [];
    };
  }, []);

  // Memoize document fetching function to prevent recreation on each render
  const fetchDocuments = useCallback(
    async (forceFresh = false) => {
      // Only prevent fetches if we have documents already or if component is unmounted
      if (!isMountedRef.current) return;

      // Set loading state
      console.log("Setting documents loading state to TRUE", {
        docsLength: documents.length,
        forceFresh,
      });
      setLoading((prev) => ({ ...prev, documents: true }));

      // Reset error state first
      setError((prev) => ({ ...prev, documents: null }));

      try {
        // Clear localStorage cache if we're explicitly re-fetching
        if (forceFresh) {
          console.log("Forcing refresh of documents cache");
          try {
            localStorage.removeItem("cachedDocuments");
            localStorage.removeItem("cachedDocumentsTimestamp");
            // Reset the fetch flag to allow refetching
            fetchedDocsRef.current = false;
          } catch (e) {
            console.warn("Failed to clear localStorage cache:", e);
          }
        }

        const docs = await getUserDocuments(forceFresh);
        console.log("Raw documents from getUserDocuments():", docs);

        // Check if component is still mounted
        if (!isMountedRef.current) return;

        // If we have documents, update the state
        if (docs && docs.length > 0) {
          console.log(`Found ${docs.length} documents for AI generation`);

          // Filter for PDF documents and map to PDFDocument type
          const pdfDocs = docs
            .filter((doc: Document) => {
              // Enhanced PDF detection - any hint of PDF is good enough
              return (
                doc.fileType === "pdf" ||
                doc.fileType === "application/pdf" ||
                (doc.filename &&
                  typeof doc.filename === "string" &&
                  doc.filename.toLowerCase().includes(".pdf")) ||
                (doc.title &&
                  typeof doc.title === "string" &&
                  doc.title.toLowerCase().includes("pdf")) ||
                (doc.description &&
                  typeof doc.description === "string" &&
                  doc.description.toLowerCase().includes("pdf")) ||
                (doc.id &&
                  typeof doc.id === "string" &&
                  (doc.id.includes("emergency-doc") || doc.id.includes("pdf")))
              ); // Include emergency docs
            })
            .map((doc: Document) => ({
              id: doc.id,
              title: doc.title || doc.filename || `Document ${doc.id}`,
              description: doc.description || "",
              fileType: "pdf", // Force fileType to be pdf
              isPersistent: doc.isPersistent || false,
              isPreserved: doc.isPreserved || false,
            })) as PDFDocument[];

          console.log(`Filtered ${pdfDocs.length} PDF documents:`, pdfDocs);

          if (isMountedRef.current) {
            console.log(
              `Setting ${pdfDocs.length} PDF documents and turning loading OFF`,
            );

            // Update isDocumentsAvailable if we have at least one PDF
            if (pdfDocs.length > 0) {
              console.log(
                `Found ${pdfDocs.length} PDF documents, setting isDocumentsAvailable to true`,
              );
              setIsDocumentsAvailable(true);
            }

            // Force the React state update by creating a new array
            setDocuments((prevDocs) => {
              // Create a new array to ensure React detects the change
              const newDocs = [...pdfDocs];
              console.log("New documents state:", newDocs);
              return newDocs;
            });

            // If there's no document selected yet but we have documents, select the first one
            if (!documentIdToGenerate && pdfDocs.length > 0) {
              console.log(
                `Setting first document: ${pdfDocs[0].id} - ${pdfDocs[0].title}`,
              );
              setDocumentIdToGenerate(pdfDocs[0].id);
            }

            // Turn off loading state
            setLoading((prev) => ({ ...prev, documents: false }));
          }
        } else {
          console.log(
            "No documents found for AI generation, turning loading OFF",
          );
          if (isMountedRef.current) {
            setDocuments([]);
            setLoading((prev) => ({ ...prev, documents: false }));
          }
        }
      } catch (err) {
        // Check if component is still mounted
        if (!isMountedRef.current) return;

        console.error("Error fetching documents:", err);
        // Only show error toast for actual errors, not for empty results
        toast({
          title: "Error",
          description: "Failed to load documents for AI generation",
          variant: "destructive",
        });

        // Try to use localStorage directly as a fallback
        try {
          const storedDocuments = localStorage.getItem("cachedDocuments");
          if (storedDocuments) {
            const parsedDocs = JSON.parse(storedDocuments);
            console.log(
              "Recovered documents from localStorage fallback:",
              parsedDocs.length,
            );

            if (isMountedRef.current) {
              const pdfDocs = parsedDocs
                .filter((doc: any) => doc.fileType === "pdf")
                .map((doc: any) => ({
                  id: doc.id,
                  title: doc.title || doc.filename || `Document ${doc.id}`,
                  description: doc.description,
                  fileType: doc.fileType || "pdf",
                  isPersistent: doc.isPersistent,
                  isPreserved: doc.isPreserved,
                })) as PDFDocument[];

              setDocuments(pdfDocs);

              // Set first document as selected if needed
              if (!documentIdToGenerate && pdfDocs.length > 0) {
                setDocumentIdToGenerate(pdfDocs[0].id);
              }
            }
          }
        } catch (e) {
          console.warn("Failed to use localStorage fallback for documents:", e);
        }

        // Always turn off loading state regardless of outcome
        console.log("Error recovery complete, turning loading OFF");
        setLoading((prev) => ({ ...prev, documents: false }));
      }
    },
    [documentIdToGenerate, toast, documents.length],
  );

  // Fetch all decks/study sets on component mount
  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      if (!isMounted || !isMountedRef.current) return;

      try {
        console.log("FlashCards fetchData: Setting loading state to true");
        // Only set loading state once at the beginning
        setLoading((prev) => ({ ...prev, decks: true }));
        setError((prev) => ({ ...prev, decks: null }));

        // Reset the fetched decks tracking to ensure we get fresh data
        fetchedDeckIdsRef.current.clear();

        console.log("FlashCards fetchData: Fetching study sets");

        // Fetch study sets
        const studySets = await getStudySets();

        console.log(
          `FlashCards fetchData: Received ${studySets.length} study sets`,
        );

        // Transform to match our Deck interface
        const transformedDecks = studySets.map((set: any) => ({
          id: set.id,
          title: set.title,
          description: set.description || "",
          cards: [], // Will load cards when deck is selected
          source: set.source as "manual" | "pdf" | "ai",
          stats: {
            totalCards: set.cardCount || 0,
            mastered: set.stats?.mastered || 0,
            needReview: set.stats?.needReview || 0,
            accuracy: set.stats?.accuracy || 0,
            streak: set.stats?.streak || 0,
          },
        }));

        // Check mounted state before updating
        if (isMounted && isMountedRef.current) {
          console.log(
            "FlashCards fetchData: Setting decks and loading state to false",
          );
          setDecks(transformedDecks);
          setLoading((prev) => ({ ...prev, decks: false }));
        }
      } catch (err) {
        console.error("Error fetching study sets:", err);
        if (isMounted && isMountedRef.current) {
          console.log(
            "FlashCards fetchData: Error fetching study sets, setting error state",
          );
          setError((prev) => ({
            ...prev,
            decks: "Failed to load flashcard decks",
          }));
          setLoading((prev) => ({ ...prev, decks: false }));
        }
      }

      // Set a safety timeout to ensure loading state is cleared after 5 seconds
      // in case something goes wrong with the API calls
      const safetyTimeout = setTimeout(() => {
        if (isMounted && isMountedRef.current && loading.decks) {
          console.log(
            "Safety timeout triggered: Forcing loading state to false",
          );
          setLoading((prev) => ({ ...prev, decks: false }));
        }
      }, 5000);

      // Add to timeouts to be cleared on unmount
      timeoutsRef.current.push(safetyTimeout);

      // Fetch documents at startup even if not in AI mode to preload them
      // This helps ensure they're ready when user clicks AI Generate
      try {
        console.log(
          "FlashCards: Initial document fetch for AI generation starting",
        );

        // Set loading state for documents
        setLoading((prev) => ({ ...prev, documents: true }));

        const docs = await getUserDocuments();

        // Check mounted state before processing
        if (!isMounted || !isMountedRef.current) return;

        // If we have documents, update the state
        if (docs && docs.length > 0) {
          console.log(
            `Found ${docs.length} documents for AI generation during initial load`,
          );

          // Filter for PDF documents and map to PDFDocument type
          const pdfDocs = docs
            .filter((doc: Document) => {
              // Enhanced PDF detection to match our document service
              return (
                doc.fileType === "pdf" ||
                doc.fileType === "application/pdf" ||
                (doc.filename && doc.filename.toLowerCase().endsWith(".pdf")) ||
                (doc.title && doc.title?.toLowerCase().includes("pdf")) ||
                (doc.description &&
                  doc.description?.toLowerCase().includes("pdf"))
              );
            })
            .map((doc: Document) => ({
              id: doc.id,
              title: doc.title || doc.filename || `Document ${doc.id}`,
              description: doc.description || "",
              fileType: "pdf", // Force fileType to be pdf
              isPersistent: doc.isPersistent,
              isPreserved: doc.isPreserved,
            })) as PDFDocument[];

          // Set a short timeout to trigger another document fetch if no PDFs were found
          // But the server logs indicate there should be PDFs
          if (pdfDocs.length === 0) {
            console.log(
              "No PDF docs found during initial load, but server logs show PDFs exist",
            );
            console.log("Will force refresh documents in 1 second");

            // Add a short delay then force refresh
            const refreshTimeout = setTimeout(() => {
              if (isMountedRef.current) {
                console.log("Triggering forced document refresh");
                fetchDocuments(true);
              }
            }, 1000);
            timeoutsRef.current.push(refreshTimeout);
          } else {
            // Set isDocumentsAvailable to true if we found documents
            console.log(
              `Found ${pdfDocs.length} PDF documents, setting isDocumentsAvailable to true`,
            );
            setIsDocumentsAvailable(true);
          }

          // Mark as fetched to prevent duplicate fetches
          fetchedDocsRef.current = true;

          if (isMounted && isMountedRef.current) {
            console.log(
              `Setting ${pdfDocs.length} PDF documents in initial load`,
            );
            setDocuments(pdfDocs);

            // If there's no document selected yet but we have documents, select the first one
            if (!documentIdToGenerate && pdfDocs.length > 0) {
              setDocumentIdToGenerate(pdfDocs[0].id);
            }
          }
        } else {
          console.log("No documents found during initial load");
          if (isMounted && isMountedRef.current) {
            setDocuments([]);
            fetchedDocsRef.current = false; // Allow refetching since we got empty results
          }
        }
      } catch (err) {
        // Check mounted state before showing error
        if (!isMounted || !isMountedRef.current) return;

        console.error("Error fetching documents:", err);
        fetchedDocsRef.current = false; // Allow refetching since there was an error

        if (isMountedRef.current) {
          setDocuments([]);
        }
      } finally {
        // Always turn off loading state for documents
        if (isMounted && isMountedRef.current) {
          console.log(
            "Initial document fetch complete, turning off loading state",
          );
          setLoading((prev) => ({ ...prev, documents: false }));
        }
      }
    };

    // Execute the fetch function
    fetchData();

    // Add a secondary safety timeout to ensure loading state is cleared
    // in case something goes wrong with the API calls or fetchData function
    const globalSafetyTimeout = setTimeout(() => {
      if (isMounted && isMountedRef.current && loading.decks) {
        console.log(
          "Global safety timeout triggered: Forcing loading state to false",
        );
        setLoading((prev) => ({ ...prev, decks: false }));
      }
    }, 10000); // 10 seconds timeout
    timeoutsRef.current.push(globalSafetyTimeout);

    return () => {
      isMounted = false;
      clearTimeout(globalSafetyTimeout);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Replace the Fetch cards useEffect with this optimized version
  useEffect(() => {
    // Only proceed if we have a selected deck with no cards yet
    // AND we haven't already attempted to fetch cards for this deck
    // AND we're not currently in the process of fetching
    if (
      selectedDeck &&
      selectedDeck.cards.length === 0 &&
      !loading.cards &&
      !fetchedDeckIdsRef.current.has(selectedDeck.id) &&
      !fetchingCardsRef.current
    ) {
      // Immediately mark as fetching to prevent duplicate attempts
      fetchingCardsRef.current = true;

      // Mark this deck as already fetched to prevent repeated attempts
      fetchedDeckIdsRef.current.add(selectedDeck.id);

      // Use a more efficient way to fetch cards
      const fetchCards = async () => {
        // Set loading state - do this outside the async function
        setLoading((prev) => ({ ...prev, cards: true }));

        // Add timeout to prevent infinite loading
        const timeoutId = setTimeout(() => {
          if (isMountedRef.current) {
            console.warn(`Fetch cards timeout for deck: ${selectedDeck.id}`);
            setLoading((prev) => ({ ...prev, cards: false }));
            setError((prev) => ({
              ...prev,
              cards: "Request timed out. The server took too long to respond.",
            }));
            fetchingCardsRef.current = false;
          }
        }, 15000); // 15 seconds timeout
        timeoutsRef.current.push(timeoutId);

        try {
          // Use the deck ID to fetch flashcards
          console.log(`Fetching flashcards for deck: ${selectedDeck.id}`);

          // Add a specific try/catch just for the API call
          let cards: FlashCard[] = [];
          try {
            cards = await getFlashcards(selectedDeck.id);
          } catch (apiError) {
            console.error("API Error fetching flashcards:", apiError);
            // Continue with empty array
          }

          // Clear timeout since we got a response
          clearTimeout(timeoutId);

          // Make sure we have a valid array and component is still mounted
          if (!isMountedRef.current) {
            return; // Exit early if component unmounted
          }

          // Force to array if response is invalid
          const validCards: FlashCard[] = Array.isArray(cards) ? cards : [];
          console.log(`Retrieved ${validCards.length} flashcards`);

          // Only update state if component is still mounted and not unmounting
          if (isMountedRef.current) {
            // Update state more efficiently - in a single batch
            setSelectedDeck((prev) => {
              if (!prev) return null;
              if (prev.id !== selectedDeck.id) return prev; // If deck changed during API call

              // Create the updated deck
              const updatedDeck = {
                ...prev,
                cards: validCards,
                stats: {
                  ...prev.stats,
                  totalCards: validCards.length,
                },
              };

              return updatedDeck;
            });

            // Also update the deck in the decks array
            setDecks((currentDecks) =>
              currentDecks.map((deck) =>
                deck.id === selectedDeck.id
                  ? {
                      ...deck,
                      cards: validCards,
                      stats: {
                        ...deck.stats,
                        totalCards: validCards.length,
                      },
                    }
                  : deck,
              ),
            );
          }
        } catch (err) {
          // Clear timeout since we got an error
          clearTimeout(timeoutId);

          if (isMountedRef.current) {
            console.error("Error fetching flashcards:", err);
            setError((prev) => ({
              ...prev,
              cards: "Failed to load flashcards",
            }));
          }
        } finally {
          // Always clean up
          if (isMountedRef.current) {
            setLoading((prev) => ({ ...prev, cards: false }));
          }
          fetchingCardsRef.current = false;
        }
      };

      // Start fetching cards, but don't await - let it run asynchronously
      fetchCards();
    } else if (
      selectedDeck &&
      selectedDeck.cards.length === 0 &&
      loading.cards
    ) {
      // Add safety timeout if we've been loading for too long
      const safetyTimeoutId = setTimeout(() => {
        if (isMountedRef.current && loading.cards) {
          console.warn(`Safety timeout triggered for deck: ${selectedDeck.id}`);
          setLoading((prev) => ({ ...prev, cards: false }));
          fetchingCardsRef.current = false;
        }
      }, 5000); // 5 second safety timeout

      timeoutsRef.current.push(safetyTimeoutId);

      return () => {
        clearTimeout(safetyTimeoutId);
      };
    }
    // We rely on selectedDeck.id inside this effect, but including the entire selectedDeck object
    // in the dependency array would cause issues with deep equality checks and potential infinite loops.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDeck?.id, loading.cards]);

  // Clear the fetched decks tracking when component unmounts
  useEffect(() => {
    // Copy the ref value to a variable inside the effect to use in cleanup
    const fetchedDeckIds = fetchedDeckIdsRef.current;

    return () => {
      // Use the copied variable instead of accessing .current in cleanup
      fetchedDeckIds.clear();
    };
  }, []);

  // Create new deck
  const handleCreateDeck = async () => {
    try {
      if (!newDeckTitle.trim()) {
        setError((prev) => ({ ...prev, creating: "Deck title is required" }));
        return;
      }

      setLoading((prev) => ({ ...prev, creating: true }));
      setError((prev) => ({ ...prev, creating: null }));

      // Check if we have any preserved PDFs with similar titles
      if (documents.length > 0) {
        const matchingPdfs = documents.filter(
          (doc) =>
            doc.title &&
            doc.title.toLowerCase().includes(newDeckTitle.toLowerCase()),
        );

        if (matchingPdfs.length > 0) {
          // Show suggestion as notification
          const pdfTitles = matchingPdfs.map((pdf) => pdf.title).join(", ");
          showInfoToast(
            "PDF Match Found",
            `Found similar PDFs: ${pdfTitles}. Consider creating decks from these PDFs.`,
          );
        }
      }

      const newDeck: CreateStudySetData = {
        title: newDeckTitle,
        description: newDeckDescription,
        source: "manual",
        cards: [],
      };

      await createStudySet(newDeck);

      showSuccessToast("Success", "Flashcard deck created successfully");

      setShowNewDeckForm(false);
      setNewDeckTitle("");
      setNewDeckDescription("");

      fetchDecks();
    } catch (err) {
      console.error("Error creating deck:", err);
      setError((prev) => ({ ...prev, creating: "Failed to create deck" }));
    } finally {
      setLoading((prev) => ({ ...prev, creating: false }));
    }
  };

  // Function to show success notification after deleting a deck
  const showDeckDeletionSuccess = (deckTitle: string) => {
    toast({
      title: "Success",
      description: `Deck "${deckTitle}" deleted successfully.`,
      variant: "success",
      duration: 5000,
    });
  };

  // Function to handle the actual deletion after confirmation
  const confirmDeleteDeck = async () => {
    if (!deckToDelete) return;

    try {
      setLoading((prev) => ({ ...prev, creating: true }));

      // Get the deck details before deletion
      const deck = decks.find((deck) => deck.id === deckToDelete);

      // Call the API to delete the deck with the preservePdf option
      await deleteStudySet(deckToDelete, { preservePdf });

      // Update the UI after successful deletion
      setDecks(decks.filter((deck) => deck.id !== deckToDelete));

      // If the deleted deck was selected, reset to deck list
      if (selectedDeck && selectedDeck.id === deckToDelete) {
        setSelectedDeck(null);
        setMode("browse");
      }

      // Show success notification
      showDeckDeletionSuccess(deck?.title || "Unknown");
    } catch (error) {
      console.error("Error deleting deck:", error);
      toast({
        title: "Error",
        description: "Failed to delete deck. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading((prev) => ({ ...prev, creating: false }));
      setDeckToDelete(null);
      setShowDeleteDialog(false);
    }
  };

  // Function to cancel the deletion
  const cancelDeleteDeck = () => {
    setShowDeleteDialog(false);
    setDeckToDelete(null);
  };

  // Add card to deck
  const handleAddCard = async () => {
    if (!selectedDeck || !newCardFront || !newCardBack) return;

    setLoading((prev) => ({ ...prev, creating: true }));
    setError((prev) => ({ ...prev, creating: null }));

    // Clear form inputs immediately for better UX
    const frontValue = newCardFront;
    const backValue = newCardBack;
    setNewCardFront("");
    setNewCardBack("");
    setShowNewCardForm(false);

    try {
      // Make API request to backend first
      console.log("Creating new flashcard through API");
      const newCardData = await createFlashcard(selectedDeck.id, {
        front: frontValue,
        back: backValue,
      });

      console.log("Received new card data from backend:", newCardData);

      // Create new card with real ID from backend
      const newCard: FlashCard = {
        id: newCardData.id,
        front: newCardData.front,
        back: newCardData.back,
      };

      // Update the deck with data from backend
      const updatedCards = [...selectedDeck.cards, newCard];
      const updatedDeck = {
        ...selectedDeck,
        cards: updatedCards,
        stats: {
          ...selectedDeck.stats,
          totalCards: updatedCards.length,
          needReview: selectedDeck.stats.needReview + 1,
        },
      };

      // Update state with real data from backend
      setDecks(
        decks.map((deck) => (deck.id === selectedDeck.id ? updatedDeck : deck)),
      );
      setSelectedDeck(updatedDeck);

      // Show success toast
      toast({
        title: "Success",
        description: "Flashcard added successfully",
        variant: "default",
      });
    } catch (err) {
      console.error("Error creating flashcard:", err);
      setError((prev) => ({ ...prev, creating: "Failed to create flashcard" }));

      // Show error toast
      toast({
        title: "Error",
        description: "Failed to create flashcard",
        variant: "destructive",
      });

      // Re-open the form if there was an error
      setNewCardFront(frontValue);
      setNewCardBack(backValue);
      setShowNewCardForm(true);
    } finally {
      setLoading((prev) => ({ ...prev, creating: false }));
    }
  };

  // Delete card from deck
  const handleDeleteCard = async (cardId: string) => {
    if (!selectedDeck) return;

    try {
      await deleteFlashcard(selectedDeck.id, cardId);

      const updatedCards = selectedDeck.cards.filter(
        (card) => card.id !== cardId,
      );
      const updatedDeck = {
        ...selectedDeck,
        cards: updatedCards,
        stats: {
          ...selectedDeck.stats,
          totalCards: updatedCards.length,
          needReview: Math.max(0, selectedDeck.stats.needReview - 1),
        },
      };

      setDecks(
        decks.map((deck) => (deck.id === selectedDeck.id ? updatedDeck : deck)),
      );
      setSelectedDeck(updatedDeck);
    } catch (err) {
      console.error("Error deleting flashcard:", err);
      // Handle error state if needed
    }
  };

  // Handle selecting a deck
  const handleSelectDeck = (deck: Deck) => {
    try {
      console.log(
        "Selecting deck:",
        deck.id,
        "with",
        deck.stats.totalCards,
        "cards",
      );

      // Reset loading and error states when switching decks
      setLoading((prev) => ({ ...prev, cards: false }));
      setError((prev) => ({ ...prev, cards: null }));

      // Reset AI and form states
      setAiGenerateMode(false);
      setShowNewCardForm(false);

      // Prevent re-selecting the same deck
      if (selectedDeck?.id === deck.id) {
        console.log("Already selected this deck, ignoring");
        return;
      }

      // Safety check - if the deck or cards are undefined, set up an empty array
      if (!deck.cards) {
        deck.cards = [];
        console.log("Initializing empty cards array for deck");
      }

      // Make a copy of the deck to avoid direct mutations
      const deckCopy = { ...deck };

      // Add source property if missing to prevent API errors
      if (!deckCopy.source) {
        console.log("Adding missing 'source' property to deck");
        deckCopy.source = "manual";
      }

      // Set the selected deck with safety checks
      setSelectedDeck(deckCopy);
      setCurrentCardIndex(0);
      setShowAnswer(false);

      // If there are no cards, show a message to the user
      if (deckCopy.stats.totalCards === 0) {
        toast({
          title: "Empty Deck",
          description:
            "This deck has no flashcards yet. Add some cards to start studying.",
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Error selecting deck:", error);
      // Make sure to reset loading state in case of error
      setLoading((prev) => ({ ...prev, cards: false }));
      toast({
        title: "Error",
        description: "There was a problem loading this deck. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Go to learning mode
  const handleStartLearning = () => {
    if (!selectedDeck) {
      console.error("No deck selected");
      return;
    }

    if (!selectedDeck.cards || selectedDeck.cards.length === 0) {
      console.log("Cannot start learning mode: no cards available");
      toast({
        title: "Cannot Start Learning",
        description: "This deck has no flashcards. Add some cards first.",
        variant: "default",
      });
      return;
    }

    setMode("learn");
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };

  // Handle card navigation
  const handleNextCard = () => {
    if (!selectedDeck) return;

    if (currentCardIndex < selectedDeck.cards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setShowAnswer(false);
    } else {
      // End of deck
      setMode("browse");
      setShowAnswer(false);
    }
  };

  const handlePrevCard = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1);
      setShowAnswer(false);
    }
  };

  // Mark card correct/incorrect
  const handleMarkCard = async (correct: boolean) => {
    if (!selectedDeck) {
      console.error("No deck selected");
      return;
    }

    if (!selectedDeck.cards || selectedDeck.cards.length === 0) {
      console.error("No cards available");
      return;
    }

    if (currentCardIndex < 0 || currentCardIndex >= selectedDeck.cards.length) {
      console.error("Card index out of bounds:", currentCardIndex);
      return;
    }

    try {
      const currentCard = selectedDeck.cards[currentCardIndex];
      if (!currentCard || !currentCard.id) {
        console.error("Invalid card data at index", currentCardIndex);
        return;
      }

      // Update progress on the server
      await updateStudyProgress(selectedDeck.id, {
        cardId: currentCard.id,
        correct,
        timestamp: new Date().toISOString(),
      });

      // Update local state
      const updatedStats = { ...selectedDeck.stats };
      if (correct) {
        updatedStats.mastered = Math.min(
          updatedStats.mastered + 1,
          updatedStats.totalCards,
        );
        updatedStats.needReview = Math.max(0, updatedStats.needReview - 1);
        updatedStats.accuracy =
          (updatedStats.mastered / updatedStats.totalCards) * 100 || 0;
      } else {
        updatedStats.needReview = Math.min(
          updatedStats.needReview + 1,
          updatedStats.totalCards,
        );
        updatedStats.accuracy =
          (updatedStats.mastered / updatedStats.totalCards) * 100 || 0;
      }

      const updatedDeck = {
        ...selectedDeck,
        stats: updatedStats,
      };

      setDecks(
        decks.map((deck) => (deck.id === selectedDeck.id ? updatedDeck : deck)),
      );
      setSelectedDeck(updatedDeck);

      // Move to next card
      handleNextCard();
    } catch (err) {
      console.error("Error updating progress:", err);
      // Continue to next card even if update fails
      handleNextCard();
    }
  };

  // Generate flashcards using AI
  const handleGenerateFlashcards = async () => {
    console.log("Generate Flashcards button clicked");
    console.log("Topic:", topicToGenerate);
    console.log("Document ID:", documentIdToGenerate);
    console.log("Number of cards:", numCardsToGenerate);
    console.log("Documents length:", documents.length);
    console.log("isDocumentsAvailable:", isDocumentsAvailable);

    if (!topicToGenerate || !documentIdToGenerate) {
      console.log("Missing information - showing toast");
      toast({
        title: "Missing Information",
        description: "Please provide a topic and select a document",
        variant: "destructive",
      });
      return;
    }

    // Set generating state to show the loading UI
    setGeneratingCards(true);
    setGenerationProgress(0);
    setGenerationMessage("Preparing to generate flashcards...");

    let progressCleanupFn: (() => void) | undefined;

    try {
      console.log("Calling generateFlashcards service");
      const response = await generateFlashcards(
        documentIdToGenerate,
        topicToGenerate,
        numCardsToGenerate,
        {
          // WebSocket callback for completed flashcards - get full data from backend
          onCompleted: (data) => {
            console.log(
              "Received completed flashcards data via callback:",
              data,
            );
            // Pass the complete data object to use backend provided information
            handleFlashcardGenerated(data);
          },
          // WebSocket callback for errors
          onError: (error) => {
            console.error("Received error via callback:", error);
            handleFlashcardGenerationError(error);
          },
        },
      );

      // Register progress callback if available
      if (response.registerProgressCallback) {
        // Set up progress callback
        progressCleanupFn = response.registerProgressCallback(
          (message: string, progress: number) => {
            console.log(`Progress update: ${progress}% - ${message}`);
            setGenerationProgress(progress);
            setGenerationMessage(message);
          },
        );
      }

      // Check if the response contains an error immediately
      if (response.error) {
        console.error("Error in response:", response.error);
        toast({
          title: "Error",
          description: response.error,
          variant: "destructive",
        });

        // Clean up and reset state
        setGeneratingCards(false);
        if (progressCleanupFn) progressCleanupFn();
        return;
      }

      // If we have a job_id, we're using WebSockets or polling
      // Just wait for the callbacks to update the UI
      if (response.job_id) {
        console.log(`Flashcard job started with ID: ${response.job_id}`);
        console.log("Waiting for WebSocket or polling updates...");
        // The rest will be handled by the progress callback and the onCompleted/onError callbacks
        return;
      }

      // If we have flashcards immediately (synchronous response), process them
      if (response.flashcards && response.flashcards.length > 0) {
        console.log(
          "Successfully generated flashcards:",
          response.flashcards.length,
        );

        // Process received flashcards into our app format
        const formattedFlashcards = response.flashcards.map((card, index) => ({
          id: `ai-${Date.now()}-${index}`,
          front: card.question,
          back: card.answer,
          metadata: card.metadata,
          difficulty: card.difficulty || "Medium",
        }));

        // Create a new deck with the flashcards
        const newDeck: Deck = {
          id: `deck-${Date.now()}`,
          title: `${topicToGenerate} Flashcards`,
          description: `AI-generated flashcards about ${topicToGenerate}`,
          cards: formattedFlashcards,
          source: "ai",
          stats: {
            totalCards: formattedFlashcards.length,
            mastered: 0,
            needReview: formattedFlashcards.length,
            accuracy: 0,
            streak: 0,
          },
        };

        // Add the new deck to our decks
        setDecks((prevDecks) => [newDeck, ...prevDecks]);

        // Use the dedicated handler function to complete the process
        handleFlashcardGenerationComplete(newDeck);
      }
    } catch (error: any) {
      console.error("Error generating flashcards:", error);

      // Extract detailed error information from our improved backend response
      const errorMessage = error.isApiError
        ? error.error
        : error.response?.data?.error
          ? error.response.data.error
          : error.message || "An unknown error occurred";

      // Get the detailed explanation if available
      const errorDetails = error.isApiError
        ? error.details
        : error.response?.data?.details
          ? error.response.data.details
          : "";

      // Force immediate toast display for any error
      if (error.isApiError || error.response?.data?.error) {
        toast({
          title: "Error Generating Flashcards",
          description: errorDetails
            ? `${errorMessage}: ${errorDetails}`
            : errorMessage,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }

      // Reset generating state
      setGeneratingCards(false);

      // Clean up the progress callback
      if (progressCleanupFn) {
        progressCleanupFn();
      }
    }
  };

  // Add a dedicated function to handle view transitions after flashcard generation
  const handleFlashcardGenerationComplete = useCallback(
    (newDeck: Deck) => {
      console.log(
        "Handling view transition after flashcard generation complete:",
        newDeck.id,
      );

      // Ensure all modals and dropdowns are closed
      const dropdown = document.getElementById("addCardDropdown");
      if (dropdown) dropdown.classList.add("hidden");

      // Select the new deck - this forces the UI to show it
      setSelectedDeck(newDeck);

      // Reset all generation-related state
      setGeneratingCards(false);
      setAiGenerateMode(false);
      setTopicToGenerate("");
      setDocumentIdToGenerate("");
      setNumCardsToGenerate(10);
      setGenerationProgress(0);
      setGenerationMessage("");

      // Force a UI refresh by updating the timestamp
      setLastFlashcardUpdate(Date.now());

      // Announce state update to all components
      try {
        // Publish to sync service for other components
        syncService.publish("flashcards-created", {
          timestamp: Date.now(),
          deck_id: newDeck.id,
        });

        // Broadcast a global event for any listening components
        window.dispatchEvent(
          new CustomEvent("flashcardsRefreshNeeded", {
            detail: { deckId: newDeck.id, timestamp: Date.now() },
          }),
        );

        // Ensure we have the latest data
        fetchDecks();
      } catch (e) {
        console.warn("Error dispatching sync event:", e);
        // Still try to fetch decks even if sync fails
        fetchDecks();
      }

      // Show success toast
      toast({
        title: "Success",
        description: `Generated ${newDeck.cards.length} flashcards${newDeck.title ? " for " + newDeck.title : ""}`,
        variant: "default",
      });
    },
    [toast, fetchDecks],
  );

  // Handler for WebSocket flashcard notifications - using backend data
  const handleFlashcardGenerated = useCallback(
    async (data: any) => {
      console.log(
        "Handling flashcard generation completion from WebSocket",
        JSON.stringify(data),
      );

      // Extract and validate flashcards data
      let flashcards = data.flashcards || [];
      const documentId = data.document_id;
      const jobId = data.job_id;

      // Log what we received
      console.log(
        `Received ${flashcards.length} flashcards for document ${documentId} from job ${jobId}`,
      );

      // If we have flashcards, show the first one as a sample
      if (flashcards.length > 0) {
        console.log("Sample flashcard:", JSON.stringify(flashcards[0]));
      }

      // Reset generation state immediately using flushSync
      flushSync(() => {
        setGeneratingCards(false);
      });

      if (!flashcards || flashcards.length === 0) {
        console.warn("No flashcards received in websocket notification");
        toast({
          title: "Warning",
          description:
            "No flashcards were generated. Please try again with a different topic.",
          variant: "destructive",
        });
        return;
      }

      // Process received flashcards - use IDs from backend when available
      // Also handle different possible field names for question/answer
      const formattedFlashcards = flashcards.map((card: any) => ({
        id:
          card.id ||
          card._id ||
          `ai-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        front: card.question || card.front || "No question provided",
        back: card.answer || card.back || "No answer provided",
        metadata: card.metadata || {},
        difficulty: card.difficulty || "Medium",
      }));

      console.log(`Formatted ${formattedFlashcards.length} flashcards`);

      // Create a deck using data from backend when available
      const studySetId = data.study_set_id || `deck-${Date.now()}`;
      const studySetTitle =
        data.title || `${topicToGenerate || "Generated"} Flashcards`;
      const studySetDescription =
        data.description ||
        `AI-generated flashcards about ${topicToGenerate || "a topic"}`;

      const newDeck: Deck = {
        id: studySetId,
        title: studySetTitle,
        description: studySetDescription,
        cards: formattedFlashcards,
        source: "ai",
        stats: {
          totalCards: formattedFlashcards.length,
          mastered: 0,
          needReview: formattedFlashcards.length,
          accuracy: 0,
          streak: 0,
        },
      };

      console.log("Creating new deck from WebSocket data:", newDeck);

      try {
        // Immediately update UI first for responsiveness
        flushSync(() => {
          // Add the new deck to the beginning of the list
          setDecks((prevDecks) => {
            // Check if the deck already exists
            const existingDeckIndex = prevDecks.findIndex(
              (deck) => deck.id === studySetId,
            );

            if (existingDeckIndex >= 0) {
              console.log(`Updating existing deck ${studySetId} locally`);
              const updatedDecks = [...prevDecks];
              updatedDecks[existingDeckIndex] = newDeck;
              return updatedDecks;
            } else {
              console.log(`Adding new deck ${studySetId} locally`);
              return [newDeck, ...prevDecks];
            }
          });

          // Select the new deck to show it
          setSelectedDeck(newDeck);

          // Force UI update with timestamp
          setLastFlashcardUpdate(Date.now());
        });

        // Log the current state for debugging
        console.log("Current decks after update:", decks.length);
        console.log("Currently selected deck:", selectedDeck?.id);

        // Then fetch fresh data from server asynchronously
        console.log("Fetching latest decks after UI update");
        getStudySets()
          .then((studySets) => {
            console.log(`Received ${studySets.length} study sets from server`);

            // Transform to match our Deck interface
            const transformedDecks = studySets.map((set: any) => ({
              id: set.id,
              title: set.title,
              description: set.description || "",
              cards: [], // Will load cards when deck is selected
              source: set.source as "manual" | "pdf" | "ai",
              stats: {
                totalCards: set.cardCount || 0,
                mastered: set.stats?.mastered || 0,
                needReview: set.stats?.needReview || 0,
                accuracy: set.stats?.accuracy || 0,
                streak: set.stats?.streak || 0,
              },
            }));

            // Find if our new deck is already in the list
            const existingDeck = transformedDecks.find(
              (deck) => deck.id === studySetId,
            );

            if (existingDeck) {
              console.log(
                `Found deck ${studySetId} in fresh data, using server version`,
              );
              // Make sure our cards are assigned to the deck
              existingDeck.cards = formattedFlashcards;

              // Update with server data but preserve selection
              setDecks(transformedDecks);
              setSelectedDeck(existingDeck);
            }

            // Force UI update again with timestamp after server data
            setLastFlashcardUpdate(Date.now());
          })
          .catch((error) => {
            console.error("Error fetching study sets:", error);
            // Still keep local changes if fetch fails
          });
      } catch (error) {
        console.error("Error updating flashcards:", error);
        // Still update UI locally even if server sync failed
        toast({
          title: "Warning",
          description:
            "Flashcards created but there was an error syncing with the server.",
          variant: "default",
        });
      }
    },
    [toast, topicToGenerate],
  );

  // Handler for WebSocket generation errors
  const handleFlashcardGenerationError = useCallback(
    (error: string) => {
      console.error("Flashcard generation error via WebSocket:", error);

      // Show error toast
      toast({
        title: "Generation Failed",
        description: error || "An error occurred during flashcard generation",
        variant: "destructive",
      });

      // Reset generating state, but stay in AI mode so user can try again
      setGeneratingCards(false);
    },
    [toast],
  );

  // Add an effect to monitor document state changes and ensure a document is selected if available
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      // Close any open dropdowns when clicking outside them
      const dropdown = document.getElementById("addCardDropdown");
      if (dropdown && !dropdown.contains(event.target as Node)) {
        dropdown.classList.add("hidden");
      }

      const emptyDeckDropdown = document.getElementById("emptyDeckDropdown");
      if (
        emptyDeckDropdown &&
        !emptyDeckDropdown.contains(event.target as Node)
      ) {
        emptyDeckDropdown.classList.add("hidden");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Delete deck with confirmation dialog
  const handleDeleteDeck = async (id: string) => {
    const deck = decks.find((deck) => deck.id === id);
    if (!deck) return;

    // Open the delete confirmation dialog
    setDeckToDelete(id);
    setPreservePdf(true); // Default to preserving the PDF
    setShowDeleteDialog(true);
  };

  // Add function to check for PDF matches
  const checkForPdfMatches = () => {
    // Check if we have any PDFs with titles matching the new deck title
    const matchingPdfs = documents.filter((doc) =>
      doc.title.toLowerCase().includes(newDeckTitle.toLowerCase()),
    );

    if (matchingPdfs.length > 0) {
      const pdfTitles = matchingPdfs.map((pdf) => `"${pdf.title}"`).join(", ");
      showInfoToast(
        "Matching PDFs Found",
        `Found ${matchingPdfs.length} similar PDFs: ${pdfTitles}`,
      );
    } else {
      showInfoToast(
        "No Matches",
        "No matching PDFs found for this title. You can still create a manual deck.",
      );
    }
  };

  // useEffect for syncing with other components
  useEffect(() => {
    // Ensure the component is mounted
    const isMounted = { current: true };

    // Create event handlers
    const handleSyncEvent = (eventType: SyncEventType, data?: any) => {
      if (!isMounted.current) return;

      console.log(`FlashCards received sync event: ${eventType}`, data);

      // Refresh data based on event type
      switch (eventType) {
        case "pdf-uploaded":
          console.log(`FlashCards refreshing due to PDF upload event:`, data);
          // Reset tracking of fetched deck IDs
          fetchedDeckIdsRef.current.clear();
          // Fetch fresh data immediately
          getStudySets().then((studySets) => {
            if (isMounted.current) {
              // Transform study sets to match Deck interface
              const transformedDecks = studySets.map((set: any) => ({
                id: set.id,
                title: set.title,
                description: set.description || "",
                cards: [], // Will load cards when deck is selected
                source: set.source as "manual" | "pdf" | "ai",
                stats: {
                  totalCards: set.cardCount || set.cards?.length || 0,
                  mastered: set.stats?.mastered || 0,
                  needReview: set.stats?.needReview || 0,
                  accuracy: set.stats?.accuracy || 0,
                  streak: set.stats?.streak || 0,
                },
              }));
              setDecks(transformedDecks);
              console.log(
                `FlashCards refreshed with ${transformedDecks.length} decks after PDF upload`,
              );

              // Show upload notification
              showInfoToast(
                "New PDF Added",
                "Your flashcard library has been updated with a new PDF",
              );
            }
          });
          break;
        case "pdf-deleted":
          console.log(`FlashCards refreshing due to PDF deletion event:`, data);
          // Reset tracking of fetched deck IDs
          fetchedDeckIdsRef.current.clear();

          // Check if we need to deselect a currently selected deck that was deleted
          if (selectedDeck && data?.id && selectedDeck.id === data.id) {
            console.log(
              `Currently selected deck was deleted, resetting to browse mode`,
            );
            setSelectedDeck(null);
            setMode("browse");
            showInfoToast(
              "PDF Deleted",
              `The PDF "${data.title || "Unknown"}" and its flashcards have been removed`,
            );
          }

          // Fetch fresh data with a short delay to ensure backend processing is complete
          setTimeout(() => {
            if (isMounted.current) {
              getStudySets().then((studySets) => {
                if (isMounted.current) {
                  // Transform study sets to match Deck interface
                  const transformedDecks = studySets.map((set: any) => ({
                    id: set.id,
                    title: set.title,
                    description: set.description || "",
                    cards: [], // Will load cards when deck is selected
                    source: set.source as "manual" | "pdf" | "ai",
                    stats: {
                      totalCards: set.cardCount || set.cards?.length || 0,
                      mastered: set.stats?.mastered || 0,
                      needReview: set.stats?.needReview || 0,
                      accuracy: set.stats?.accuracy || 0,
                      streak: set.stats?.streak || 0,
                    },
                  }));
                  setDecks(transformedDecks);
                  console.log(
                    `FlashCards refreshed with ${transformedDecks.length} decks after PDF deletion`,
                  );
                }
              });
            }
          }, 500); // Short delay to ensure backend has completed the deletion
          break;
        case "flashcards-created":
          console.log(
            `FlashCards refreshing due to flashcards creation event:`,
            data,
          );
          // Reset tracking of fetched deck IDs
          fetchedDeckIdsRef.current.clear();
          // Fetch fresh data
          getStudySets().then((studySets) => {
            if (isMounted.current) {
              // Transform and update state
              const transformedDecks = studySets.map((set: any) => ({
                id: set.id,
                title: set.title,
                description: set.description || "",
                cards: [], // Will load cards when deck is selected
                source: set.source as "manual" | "pdf" | "ai",
                stats: {
                  totalCards: set.cardCount || set.cards?.length || 0,
                  mastered: set.stats?.mastered || 0,
                  needReview: set.stats?.needReview || 0,
                  accuracy: set.stats?.accuracy || 0,
                  streak: set.stats?.streak || 0,
                },
              }));
              setDecks(transformedDecks);
              console.log(
                `FlashCards refreshed with ${transformedDecks.length} decks after flashcards creation`,
              );
            }
          });
          break;
        case "study-set-updated":
          // Only refresh specific deck if we're viewing it
          if (data?.id && selectedDeck?.id === data.id) {
            studyBuddyService
              .getStudySetById(data.id)
              .then((updatedSet: any) => {
                if (isMounted.current) {
                  // Transform the updated study set to a Deck
                  const updatedDeck: Deck = {
                    id: updatedSet.id,
                    title: updatedSet.title,
                    description: updatedSet.description || "",
                    cards: [], // Will load cards when needed
                    source: updatedSet.source as "manual" | "pdf" | "ai",
                    stats: {
                      totalCards:
                        updatedSet.cardCount || updatedSet.cards?.length || 0,
                      mastered: updatedSet.stats?.mastered || 0,
                      needReview: updatedSet.stats?.needReview || 0,
                      accuracy: updatedSet.stats?.accuracy || 0,
                      streak: updatedSet.stats?.streak || 0,
                    },
                  };

                  setDecks((prevDecks) =>
                    prevDecks.map((deck) =>
                      deck.id === data.id ? updatedDeck : deck,
                    ),
                  );
                }
              });
          }
          break;
      }
    };

    // Subscribe to all relevant events
    const unsubscribeHandlers: Array<() => void> = [
      // Direct subscription to syncService
      syncService.subscribe("pdf-uploaded", () =>
        handleSyncEvent("pdf-uploaded"),
      ),
      syncService.subscribe("pdf-deleted", () =>
        handleSyncEvent("pdf-deleted"),
      ),
      syncService.subscribe("flashcards-created", () =>
        handleSyncEvent("flashcards-created"),
      ),
      syncService.subscribe("study-set-updated", (data) =>
        handleSyncEvent("study-set-updated", data),
      ),

      // DOM event listeners for backward compatibility
      (() => {
        const handler = () => handleSyncEvent("flashcards-created");
        window.addEventListener("flashcardsRefreshNeeded", handler);
        return () =>
          window.removeEventListener("flashcardsRefreshNeeded", handler);
      })(),
    ];

    // Add the spread array of event listeners
    const customEventListeners = (
      [
        "pdf-uploaded",
        "pdf-deleted",
        "flashcards-created",
        "study-set-updated",
      ] as SyncEventType[]
    ).map((eventType) => {
      const handler = (e: CustomEvent) => handleSyncEvent(eventType, e.detail);
      window.addEventListener(`foster-${eventType}`, handler as EventListener);
      return () =>
        window.removeEventListener(
          `foster-${eventType}`,
          handler as EventListener,
        );
    });

    // Add all the custom event listeners to the unsubscribe handlers
    unsubscribeHandlers.push(...customEventListeners);

    // Add storage event listener for cross-tab communication
    const handleStorageChange = (e: StorageEvent) => {
      if (!isMounted.current) return;

      // Check if it's our sync event
      if (e.key === "syncTimestamp" || e.key === "flashcardsRefreshTimestamp") {
        console.log("FlashCards detected storage change event for sync");

        // Get the event type if available
        const eventType = localStorage.getItem(
          "lastSyncEvent",
        ) as SyncEventType | null;

        // Get any stored data
        let data;
        try {
          const dataStr = localStorage.getItem("lastSyncData");
          if (dataStr) {
            data = JSON.parse(dataStr);
          }
        } catch (e) {
          console.warn("Error parsing sync data from localStorage:", e);
        }

        // Handle as a generic flashcards refresh if no specific event type
        handleSyncEvent(eventType || "flashcards-created", data);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Add visibility change handler for when tab becomes visible again
    const handleVisibilityChange = () => {
      if (!isMounted.current) return;

      if (document.visibilityState === "visible") {
        console.log("FlashCards page became visible, checking for updates");

        // Check if refresh is needed based on storage flag
        const needsRefresh =
          localStorage.getItem("flashcardsNeedsRefresh") === "true";
        if (needsRefresh) {
          console.log("Refresh flag is set, refreshing flashcards");
          // Reset flag
          localStorage.removeItem("flashcardsNeedsRefresh");
          // Trigger refresh
          handleSyncEvent("flashcards-created");
        }
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    // Cleanup function
    return () => {
      isMounted.current = false;

      // Clean up all subscriptions
      unsubscribeHandlers.forEach((unsubscribe) => {
        if (typeof unsubscribe === "function") {
          unsubscribe();
        }
      });

      // Remove DOM event listeners
      window.removeEventListener("storage", handleStorageChange);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [selectedDeck?.id, toast, selectedDeck]); // Add toast and selectedDeck to dependencies

  // Inside the component, add logging for initial state
  useEffect(() => {
    console.log("FlashCards component mounted with initial state:");
    console.log("Loading state:", loading);
    console.log("Decks length:", decks.length);
    console.log("Documents length:", documents.length);
    console.log("Has errors:", !!error.decks);

    // Safety check to reset loading state for documents if it's stuck
    if (loading.documents && documents.length > 0) {
      console.log(
        "Safety: documents are loaded but loading state is still true, resetting",
      );
      setLoading((prev) => ({ ...prev, documents: false }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Safety effect to monitor document loading state
  useEffect(() => {
    // If we have documents but loading state is still true, that's a problem - fix it
    if (documents.length > 0 && loading.documents) {
      console.log(
        "State mismatch detected: Documents loaded but loading state is true - fixing",
      );
      // Add a small delay to avoid potential race conditions
      const fixTimeout = setTimeout(() => {
        if (isMountedRef.current) {
          console.log("Resetting loading.documents state to false");
          setLoading((prev) => ({ ...prev, documents: false }));
        }
      }, 50);

      return () => clearTimeout(fixTimeout);
    }
  }, [documents.length, loading.documents, isMountedRef]);

  // Add a useEffect to the main FlashCards component to limit document recovery attempts
  useEffect(() => {
    // Hard limit on time spent trying to recover documents
    const maxRecoveryTime = 10000; // 10 seconds

    // Set a global timeout to stop excessive recovery attempts
    const timeout = setTimeout(() => {
      console.log(
        "Maximum recovery time reached, stopping all recovery attempts",
      );

      // Force create a last-resort emergency document
      if (documents.length === 0) {
        try {
          console.log("Creating last-resort emergency document directly");
          const emergencyDoc = {
            id: "emergency-doc-" + Date.now(),
            title: "PDF Document (Last Resort Recovery)",
            description: "Emergency document created as last resort",
            fileType: "pdf",
            isPersistent: false,
            isPreserved: false,
          };

          // Update state
          setDocuments([emergencyDoc]);
          setDocumentIdToGenerate(emergencyDoc.id);

          // Also store in localStorage
          localStorage.setItem("pdfDocsExist", "true");
          localStorage.setItem("lastResortRecovery", "true");

          const docs = JSON.parse(
            localStorage.getItem("cachedDocuments") || "[]",
          );
          docs.push(emergencyDoc);
          localStorage.setItem("cachedDocuments", JSON.stringify(docs));

          // Force loading state to false
          setLoading((prev) => ({ ...prev, documents: false }));
        } catch (e) {
          console.error("Failed to create last-resort document:", e);
        }
      }
    }, maxRecoveryTime);

    return () => clearTimeout(timeout);
  }, [documents.length, setDocuments, setDocumentIdToGenerate, setLoading]); // Add missing dependencies

  // Add these missing functions before the return statement
  const renderResetButton = () => {
    return (
      <Button
        variant="outline"
        size="sm"
        className="border-gray-700 text-gray-400 hover:text-white hover:bg-gray-700"
        onClick={() => window.location.reload()}
      >
        <RefreshCw className="h-4 w-4 mr-1" /> Reset
      </Button>
    );
  };

  const renderAiGenerateForm = () => {
    return (
      <div className="mb-8 bg-gray-800/50 rounded-lg border border-gray-700 p-6 backdrop-blur-sm animate-fade-in">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center">
          <Sparkles className="mr-2 h-5 w-5 text-yellow-500" />
          Generate AI Flashcards
        </h2>

        {generatingCards ? (
          <div className="space-y-4 animate-fade-in">
            <div className="flex flex-col items-center justify-center py-4">
              <div className="text-center mb-4">
                {generationProgress < 100 ? (
                  <RotateCw className="h-10 w-10 text-purple-500 mb-3 mx-auto animate-spin" />
                ) : generationMessage.includes("Error") ? (
                  <AlertCircle className="h-10 w-10 text-red-500 mb-3 mx-auto" />
                ) : (
                  <CheckCircle className="h-10 w-10 text-green-500 mb-3 mx-auto" />
                )}
                <h3 className="text-lg font-semibold text-white">
                  {generationMessage}
                </h3>
                <p className="text-gray-400 text-sm mt-1">
                  {generationProgress < 100
                    ? "This may take a minute or two depending on the document size"
                    : generationMessage.includes("Error")
                      ? "There was a problem generating your flashcards"
                      : "Flashcards ready!"}
                </p>
              </div>

              {/* Progress bar */}
              <div className="w-full max-w-md mx-auto mt-2">
                <div className="bg-gray-700 rounded-full h-2.5 mb-1">
                  <div
                    className={`h-2.5 rounded-full transition-all duration-300 ${
                      generationMessage.includes("Error")
                        ? "bg-red-500"
                        : "bg-gradient-to-r from-indigo-500 to-purple-600"
                    }`}
                    style={{ width: `${generationProgress}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>0%</span>
                  <span>{generationProgress.toFixed(0)}%</span>
                  <span>100%</span>
                </div>
              </div>

              {/* Cancel button */}
              <Button
                variant="outline"
                size="sm"
                className="mt-4 bg-transparent border-gray-600 hover:bg-gray-700 text-gray-300"
                onClick={() => {
                  // If generation is complete or errored, just close the form
                  if (generationProgress >= 100) {
                    setGeneratingCards(false);
                    setAiGenerateMode(false);
                    return;
                  }

                  // Ask for confirmation before canceling an in-progress generation
                  const confirmCancel = window.confirm(
                    "Are you sure you want to cancel generating flashcards? The process will stop and any progress will be lost.",
                  );

                  if (confirmCancel) {
                    setGeneratingCards(false);
                    setAiGenerateMode(false);
                    toast({
                      title: "Canceled",
                      description: "Flashcard generation was canceled",
                      variant: "default",
                    });
                  }
                }}
              >
                {generationProgress < 100 ? (
                  <>
                    <X className="h-4 w-4 mr-1" /> Cancel Generation
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4 mr-1" /> Close
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Document selection */}
            <div>
              <Label
                htmlFor="document-select"
                className="block text-sm font-medium text-gray-300 mb-2"
              >
                Select Document
              </Label>
              <Select
                value={documentIdToGenerate}
                onValueChange={setDocumentIdToGenerate}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a document" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Available Documents</SelectLabel>
                    {documents.length > 0 ? (
                      documents.map((doc) => (
                        <SelectItem key={doc.id} value={doc.id}>
                          {doc.title}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-docs" disabled>
                        No documents available
                      </SelectItem>
                    )}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>

            {/* Topic input */}
            <div>
              <Label
                htmlFor="topic"
                className="block text-sm font-medium text-gray-300 mb-2"
              >
                Topic
              </Label>
              <Input
                id="topic"
                placeholder="Enter a specific topic (e.g. Photosynthesis)"
                value={topicToGenerate}
                onChange={(e) => setTopicToGenerate(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            {/* Number of cards */}
            <div>
              <Label
                htmlFor="num-cards"
                className="block text-sm font-medium text-gray-300 mb-2"
              >
                Number of Cards: {numCardsToGenerate}
              </Label>
              <Slider
                id="num-cards"
                min={5}
                max={20}
                step={1}
                value={[numCardsToGenerate]}
                onValueChange={(value) => setNumCardsToGenerate(value[0])}
                className="my-4"
              />
            </div>

            {/* Generate button */}
            <Button
              className="w-full mt-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              disabled={
                !documentIdToGenerate || !topicToGenerate || generatingCards
              }
              onClick={handleGenerateFlashcards}
            >
              <Sparkles className="mr-2 h-4 w-4" />
              Generate Flashcards
            </Button>
          </div>
        )}
      </div>
    );
  };

  // Connect to WebSocket for flashcard updates - with dynamic key based on component instance
  useEffect(() => {
    // Use a unique key for each component instance, but reuse it on re-renders
    const wsListenerKey = websocketRef.current || `flashcards_${Date.now()}`;
    websocketRef.current = wsListenerKey;

    console.log(`Setting up WebSocket listener with key: ${wsListenerKey}`);

    // Set up WebSocket listener for all flashcard updates
    const wsListener = {
      onMessage: (data: any) => {
        console.log(
          "WebSocket message received in FlashCards component:",
          data,
        );

        try {
          // Handle subscription confirmation
          if (data.type === "subscription_confirmed") {
            console.log("WebSocket subscription confirmed:", data.message);
            setWsConnected(true);
          }

          // Handle job completion messages
          if (
            data.notification_type === "job_completed" ||
            data.type === "job_completed"
          ) {
            console.log("🎯 Job completed notification received:", data);
            console.log(
              "Flashcard data:",
              data.flashcards ? `${data.flashcards.length} cards` : "none",
            );
            console.log("Study set ID:", data.study_set_id || "not provided");

            // Validate we have the required data before proceeding
            if (!data.flashcards || data.flashcards.length === 0) {
              console.warn(
                "WebSocket notification received but no flashcards found in data",
              );
              // Update timestamp to trigger UI refresh anyway - maybe we can fetch them
              flushSync(() => {
                setLastFlashcardUpdate(Date.now());
                // Also try to fetch the decks in case they were saved elsewhere
                fetchDecks();
              });
              return;
            }

            // Call the handler directly with data from websocket if we have flashcards
            console.log("Calling handleFlashcardGenerated with WebSocket data");
            // Use flushSync to ensure immediate UI update
            flushSync(() => {
              handleFlashcardGenerated(data);
            });

            // Double-check we're updating state
            console.log(
              "After handleFlashcardGenerated, setting lastFlashcardUpdate",
            );
            flushSync(() => {
              setLastFlashcardUpdate(Date.now());
            });
          }

          // Handle other notification types
          if (data.notification_type === "flashcard_created") {
            console.log("New flashcard created notification received");
            // Update timestamp to trigger UI refresh
            flushSync(() => {
              setLastFlashcardUpdate(Date.now());
              fetchDecks(); // Also fetch latest data
            });
          }

          if (data.notification_type === "study_set_updated") {
            console.log("Study set updated notification received");
            // Update timestamp to trigger UI refresh
            flushSync(() => {
              setLastFlashcardUpdate(Date.now());
              fetchDecks(); // Also fetch latest data
            });
          }
        } catch (error) {
          console.error("Error handling WebSocket message:", error);
        }
      },
      onConnect: () => {
        console.log("WebSocket connected in FlashCards component");
        setWsConnected(true);

        // Send a message to subscribe to all flashcard updates for this user
        console.log("Sending subscribe message");
        // Use plain string as per backend logs
        websocketService.send("subscribe");

        // Send a ping to ensure connection is active
        setTimeout(() => {
          if (websocketService.isConnected()) {
            websocketService.send("ping");
          }
        }, 500);
      },
      onDisconnect: () => {
        console.log("WebSocket disconnected in FlashCards component");
        setWsConnected(false);
      },
    };

    // Connect to the WebSocket - always create a fresh connection for this component
    console.log("Creating WebSocket connection for FlashCards");
    websocketService.connect("flashcards", wsListener, wsListenerKey);

    // Set up a ping interval to keep the connection alive
    const pingInterval = setInterval(() => {
      if (websocketService.isConnected()) {
        websocketService.send("ping");
      }
    }, 30000); // Send ping every 30 seconds

    // Clean up on unmount - normal cleanup without delays
    return () => {
      console.log(`Removing WebSocket listener: ${wsListenerKey}`);
      websocketService.removeListener(wsListenerKey);
      websocketRef.current = null;
      clearInterval(pingInterval);
    };
  }, [handleFlashcardGenerated, fetchDecks]);

  // Add an effect to check for existing notifications at mount time
  useEffect(() => {
    console.log("Checking for existing WebSocket notifications at mount time");

    // Check if there are any notifications that weren't processed
    if (
      window.websocketNotifications &&
      window.websocketNotifications.length > 0
    ) {
      console.log(
        `Found ${window.websocketNotifications.length} unprocessed notifications:`,
        window.websocketNotifications,
      );

      // Process each notification
      window.websocketNotifications.forEach((notification) => {
        if (
          notification &&
          (notification.notification_type === "job_completed" ||
            notification.type === "job_completed")
        ) {
          console.log(
            "Processing stored job_completed notification:",
            notification,
          );

          // Use flushSync to ensure UI updates immediately
          flushSync(() => {
            // Force UI update first
            setLastFlashcardUpdate(Date.now());

            // Then process the notification with our handler
            handleFlashcardGenerated(notification);
          });
        }
      });

      // Clear the notifications after processing
      window.websocketNotifications = [];
    }
  }, [handleFlashcardGenerated]);

  // Enhance the global event listener for flashcard updates to process using flushSync
  // Replace the existing useEffect for flashcardsRefreshNeeded
  useEffect(() => {
    const handleGlobalFlashcardUpdate = (event: CustomEvent) => {
      console.log(
        "Received global flashcard update event with details:",
        event.detail,
      );

      // Check if this is coming from a WebSocket with flashcards data
      if (
        event.detail?.source === "websocket" &&
        event.detail?.flashcards?.length > 0
      ) {
        console.log(
          "Event contains WebSocket flashcard data - using handleFlashcardGenerated",
        );

        // Use flushSync to ensure immediate UI update
        flushSync(() => {
          handleFlashcardGenerated({
            flashcards: event.detail.flashcards,
            study_set_id: event.detail.deckId,
            timestamp: event.detail.timestamp,
          });
        });
      } else {
        // Handle normal refresh events
        console.log(
          "Standard refresh event - updating timestamp and fetching decks",
        );
        // Update timestamp to force re-renders using flushSync
        flushSync(() => {
          setLastFlashcardUpdate(Date.now());
        });
        // Fetch latest deck data
        fetchDecks();
      }
    };

    // Listen for the custom event
    window.addEventListener(
      "flashcardsRefreshNeeded",
      handleGlobalFlashcardUpdate as EventListener,
    );

    return () => {
      window.removeEventListener(
        "flashcardsRefreshNeeded",
        handleGlobalFlashcardUpdate as EventListener,
      );
    };
  }, [fetchDecks, handleFlashcardGenerated]);

  // First, add a state variable for the cancellation dialog
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  // Add this to FlashCards component after the state variable declarations
  const checkAndProcessWebSocketNotifications = useCallback(() => {
    console.log("Checking for WebSocket notifications");

    // Check session storage for notifications
    try {
      const storedUpdate = sessionStorage.getItem(
        "lastFlashcardWebSocketUpdate",
      );
      if (storedUpdate) {
        console.log("Found WebSocket update in sessionStorage");
        const update = JSON.parse(storedUpdate);

        if (update && update.data) {
          console.log("Processing stored WebSocket update:", update.data);

          // Clear it immediately to prevent duplicate processing
          sessionStorage.removeItem("lastFlashcardWebSocketUpdate");

          // Process using our handler
          flushSync(() => {
            handleFlashcardGenerated(update.data);
            setLastFlashcardUpdate(Date.now());
          });

          return true; // Notification processed
        }
      }
    } catch (err) {
      console.error("Error processing stored WebSocket notification:", err);
    }

    return false;
  }, [handleFlashcardGenerated]);

  // Add this useEffect to check sessionStorage when component mounts and becomes visible
  useEffect(() => {
    // Check for WebSocket notifications when component mounts
    checkAndProcessWebSocketNotifications();

    // Set up mutation observer to detect DOM changes
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => {
            if (
              node instanceof HTMLElement &&
              node.id === "websocket-update-trigger"
            ) {
              console.log("Detected DOM trigger for WebSocket update");

              // Check session storage as that contains the full data
              checkAndProcessWebSocketNotifications();
            }
          });
        }
      });
    });

    // Start observing the document body for DOM changes
    observer.observe(document.body, { childList: true, subtree: true });

    // Also check when document becomes visible after being hidden
    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        console.log(
          "Document became visible, checking for WebSocket notifications",
        );
        checkAndProcessWebSocketNotifications();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);

    // Cleanup function
    return () => {
      observer.disconnect();
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [checkAndProcessWebSocketNotifications]);

  return (
    <div className="relative pb-10">
      {/* Add AutoRecovery component to ensure documents are always available */}
      <AutoRecovery
        loading={loading.documents}
        documentsLength={documents.length}
        fetchDocuments={fetchDocuments}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              {deckToDelete && (
                <>
                  Are you sure you want to delete the "
                  {decks.find((d) => d.id === deckToDelete)?.title}" deck? This
                  will remove all flashcards in this deck.
                  {decks.find((d) => d.id === deckToDelete)?.source ===
                    "pdf" && (
                    <div className="mt-4 flex items-start space-x-2">
                      <Checkbox
                        id="preservePdf"
                        checked={preservePdf}
                        onCheckedChange={(checked: boolean) =>
                          setPreservePdf(checked)
                        }
                      />
                      <label
                        htmlFor="preservePdf"
                        className="text-sm text-gray-300 leading-tight"
                      >
                        Preserve the associated PDF for future use (recommended)
                      </label>
                    </div>
                  )}
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 sm:justify-end mt-4">
            <Button
              variant="outline"
              onClick={cancelDeleteDeck}
              className="border-gray-700 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDeleteDeck}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Deck
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {mode === "browse" && (
        <>
          <h1 className="text-3xl font-bold mb-8 text-center text-purple-100">
            Flashcards
            {(error.decks || error.cards) && (
              <span className="ml-4">{renderResetButton()}</span>
            )}
          </h1>

          {selectedDeck ? (
            // Deck details view
            <div className="animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <Button
                  variant="outline"
                  className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                  onClick={() => {
                    setSelectedDeck(null);
                    // Reset states to ensure clean transition
                    setShowNewCardForm(false);
                    setAiGenerateMode(false);
                    setError({
                      decks: null,
                      cards: null,
                      creating: null,
                      documents: null,
                    });
                    fetchedDeckIdsRef.current.clear(); // Clear fetched decks tracking
                  }}
                >
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back to Decks
                </Button>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Button
                      variant="outline"
                      className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                      onClick={() => {
                        // Toggle the dropdown menu directly in the component state
                        const dropdown =
                          document.getElementById("addCardDropdown");
                        if (dropdown) {
                          dropdown.classList.toggle("hidden");
                        }
                      }}
                    >
                      <PlusCircle
                        size={16}
                        className="mr-2 text-white"
                        strokeWidth={2}
                      />{" "}
                      Add
                    </Button>

                    <div
                      id="addCardDropdown"
                      className="absolute z-50 mt-1 w-48 p-0 bg-gray-800 border border-gray-700 rounded-md shadow-lg hidden"
                    >
                      <div className="py-1">
                        <button
                          className="flex items-center w-full px-3 py-2 text-sm text-white hover:bg-gray-700 transition-colors"
                          onClick={() => {
                            setAiGenerateMode(true);
                            setShowNewCardForm(false);
                            // Hide the dropdown
                            const dropdown = document.getElementById("addCardDropdown");
                            if (dropdown) dropdown.classList.add("hidden");
                          }}
                        >
                          <Sparkles className="mr-2 h-4 w-4 text-purple-400" />{" "}
                          Generate with AI from PDF
                        </button>
                      </div>
                    </div>
                  </div>

                  <Button
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    disabled={selectedDeck.cards.length === 0 || loading.cards}
                    onClick={handleStartLearning}
                  >
                    Start Learning
                  </Button>
                </div>
              </div>

              <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-5 mb-6">
                <h2 className="text-2xl font-semibold text-white mb-1">
                  {selectedDeck.title}
                </h2>
                <p className="text-gray-400 mb-4">
                  {selectedDeck.description || "No description"}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                    <p className="text-gray-400 text-sm mb-1">Total Cards</p>
                    <p className="text-xl font-bold text-white">
                      {selectedDeck.stats.totalCards}
                    </p>
                  </div>
                  <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                    <p className="text-gray-400 text-sm mb-1">Memorized</p>
                    <p className="text-xl font-bold text-green-400">
                      {selectedDeck.stats.mastered}
                    </p>
                  </div>
                  <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                    <p className="text-gray-400 text-sm mb-1">Learning</p>
                    <p className="text-xl font-bold text-yellow-400">
                      {selectedDeck.stats.needReview}
                    </p>
                  </div>
                  <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                    <p className="text-gray-400 text-sm mb-1">Retention Rate</p>
                    <p className="text-xl font-bold text-blue-400">
                      {selectedDeck.stats.accuracy}%
                    </p>
                  </div>
                  <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                    <p className="text-gray-400 text-sm mb-1">Streak</p>
                    <p className="text-xl font-bold text-purple-400">
                      {selectedDeck.stats.streak || 0}
                    </p>
                  </div>
                </div>
              </div>

              {/* Add new card form */}
              {showNewCardForm && (
                <div className="mb-6 bg-gray-800/60 border border-gray-700 rounded-lg p-5 animate-fade-in">
                  <h3 className="text-lg font-semibold text-white mb-4">
                    Add New Flashcard
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-gray-400 mb-2">Front (Question)</p>
                      <Input
                        value={newCardFront}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          setNewCardFront(e.target.value)
                        }
                        placeholder="Enter question..."
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div>
                      <p className="text-gray-400 mb-2">Back (Answer)</p>
                      <Input
                        value={newCardBack}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                          setNewCardBack(e.target.value)
                        }
                        placeholder="Enter answer..."
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      className="border-gray-700 text-white hover:bg-gray-700"
                      onClick={() => {
                        setShowNewCardForm(false);
                        setNewCardFront("");
                        setNewCardBack("");
                      }}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      disabled={
                        !newCardFront || !newCardBack || loading.creating
                      }
                      onClick={handleAddCard}
                    >
                      {loading.creating ? (
                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white"></div>
                      ) : (
                        "Add Card"
                      )}
                    </Button>
                  </div>
                  {error.creating && (
                    <p className="mt-2 text-red-400 text-sm">
                      {error.creating}
                    </p>
                  )}
                </div>
              )}

              {/* Add AI generate form for selected deck */}
              {aiGenerateMode && selectedDeck && !showNewCardForm && (
                <div className="mb-6 bg-gray-800/60 border border-gray-700 rounded-lg p-5 animate-fade-in">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                    <Sparkles className="mr-2 h-5 w-5 text-yellow-500" />
                    Generate AI Flashcards for "{selectedDeck.title}"
                  </h3>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-gray-400 mb-2">Document</label>
                      <Select
                        value={documentIdToGenerate}
                        onValueChange={setDocumentIdToGenerate}
                      >
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Select a document" />
                        </SelectTrigger>
                        <SelectContent>
                          {documents.map((doc) => (
                            <SelectItem key={doc.id} value={doc.id}>
                              {doc.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-gray-400 mb-2">Topic</label>
                      <Textarea
                        placeholder="Enter the topic for flashcards"
                        value={topicToGenerate}
                        onChange={(e) => setTopicToGenerate(e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-gray-400 mb-2">
                        Number of Cards
                      </label>
                      <Select
                        value={numCardsToGenerate.toString()}
                        onValueChange={(val) =>
                          setNumCardsToGenerate(parseInt(val))
                        }
                      >
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue placeholder="Number of cards" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2">2 cards</SelectItem>
                          <SelectItem value="5">5 cards</SelectItem>
                          <SelectItem value="10">10 cards</SelectItem>
                          <SelectItem value="15">15 cards</SelectItem>
                          <SelectItem value="20">20 cards</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 mt-6">
                    <Button
                      variant="outline"
                      className="border-gray-700 text-white hover:bg-gray-700"
                      onClick={() => {
                        setAiGenerateMode(false);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                      disabled={
                        generatingCards ||
                        !topicToGenerate ||
                        !documentIdToGenerate
                      }
                      onClick={handleGenerateFlashcards}
                    >
                      {generatingCards ? (
                        <>
                          <RotateCw className="mr-2 h-4 w-4 animate-spin" />{" "}
                          Generating...
                        </>
                      ) : (
                        "Generate Flashcards"
                      )}
                    </Button>
                  </div>

                  {error.creating && (
                    <p className="mt-2 text-red-400 text-sm">
                      {error.creating}
                    </p>
                  )}
                </div>
              )}

              <h3 className="text-xl font-semibold text-white mb-4">
                Flashcards
              </h3>

              {loading.cards ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-400"></div>
                </div>
              ) : error.cards ? (
                <div className="text-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
                  <p className="text-red-400">{error.cards}</p>
                  <Button
                    className="mt-4 bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={() =>
                      setError((prev) => ({ ...prev, cards: null }))
                    }
                  >
                    Retry
                  </Button>
                </div>
              ) : selectedDeck.cards.length === 0 ? (
                <div className="text-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
                  <TooltipProvider>
                    <div className="relative">
                      <div
                        className="bg-gray-700/50 h-20 w-20 mx-auto rounded-full flex items-center justify-center mb-4 cursor-pointer hover:bg-gray-600/60 transition-colors hover:shadow-md hover:shadow-purple-500/20 animate-pulse-slow group"
                        onClick={() => {
                          // Toggle the dropdown menu
                          const dropdown =
                            document.getElementById("emptyDeckDropdown");
                          if (dropdown) {
                            dropdown.classList.toggle("hidden");
                          }
                        }}
                      >
                        <PlusCircle
                          size={32}
                          className="text-purple-400 group-hover:text-purple-300 transition-colors"
                          strokeWidth={1.5}
                        />
                      </div>

                      <div
                        id="emptyDeckDropdown"
                        className="absolute left-1/2 transform -translate-x-1/2 z-50 mt-1 w-48 p-0 bg-gray-800 border border-gray-700 rounded-md shadow-lg hidden"
                      >
                        <div className="py-1">
                          <button
                            className="flex items-center w-full px-3 py-2 text-sm text-white hover:bg-gray-700 transition-colors"
                            onClick={() => {
                              // First make sure AI mode is disabled
                              setAiGenerateMode(false);
                              // Ensure any existing errors are cleared
                              setError((prev) => ({ ...prev, creating: null }));
                              // Reset form fields
                              setNewCardFront("");
                              setNewCardBack("");
                              // Then show the form
                              setShowNewCardForm(true);

                              // Hide the dropdown
                              const dropdown =
                                document.getElementById("emptyDeckDropdown");
                              if (dropdown) dropdown.classList.add("hidden");
                            }}
                          >
                            <PlusCircle
                              className="mr-2 h-4 w-4 text-blue-400"
                              strokeWidth={2}
                            />{" "}
                            Add Cards Manually
                          </button>
                          <button
                            className="flex items-center w-full px-3 py-2 text-sm text-white hover:bg-gray-700 transition-colors"
                            onClick={() => {
                              setAiGenerateMode(true);
                              setShowNewCardForm(false);
                            }}
                          >
                            <Sparkles className="mr-2 h-4 w-4 text-purple-400" />{" "}
                            Generate with AI
                          </button>
                        </div>
                      </div>
                    </div>
                  </TooltipProvider>
                  <h3 className="text-xl font-medium text-white mb-2">
                    No Flashcards Yet
                  </h3>
                  <p className="text-gray-400 mb-6">
                    Add some flashcards to start studying
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {selectedDeck.cards.map((card, index) => (
                    <motion.div
                      key={card.id}
                      className="relative bg-gray-800/60 border border-gray-700 rounded-lg p-5 hover:bg-gray-800/90 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div>
                        <p className="text-gray-400 mb-2 text-sm">Question:</p>
                        <p className="text-white font-medium mb-4">
                          {card.front}
                        </p>
                        <p className="text-gray-400 mb-2 text-sm">Answer:</p>
                        <p className="text-white opacity-75">{card.back}</p>
                      </div>
                      <div className="absolute top-3 right-3">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-700"
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation();
                            handleDeleteCard(card.id);
                          }}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            // Decks list view
            <div className="animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <div className="relative w-full max-w-md">
                  <Input
                    type="text"
                    placeholder="Search flashcard decks..."
                    className="pl-10 bg-gray-800/50 border-gray-700 text-white"
                  />
                  <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                  </div>
                </div>
                <Button
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={() => setShowNewDeckForm(true)}
                >
                  Create Deck{" "}
                  <PlusCircle
                    size={16}
                    className="ml-2 text-white"
                    strokeWidth={2}
                  />
                </Button>
              </div>

              {/* Create new deck form */}
              {showNewDeckForm && (
                <div className="mb-8 bg-gray-800/50 rounded-lg border border-gray-700 p-6 backdrop-blur-sm">
                  <h2 className="text-xl font-bold text-white mb-4">
                    Create New Deck
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <label
                        className="block text-sm font-medium text-gray-400 mb-1"
                        htmlFor="title"
                      >
                        Title
                      </label>
                      <div className="flex gap-2">
                        <Input
                          id="title"
                          type="text"
                          placeholder="Enter deck title"
                          value={newDeckTitle}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                            setNewDeckTitle(e.target.value)
                          }
                          className="bg-gray-900/50 border-gray-700 text-white flex-1"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="border-gray-700 hover:border-blue-500 text-gray-300"
                          onClick={checkForPdfMatches}
                        >
                          Check PDFs
                        </Button>
                      </div>
                    </div>
                    <div>
                      <label
                        className="block text-sm font-medium text-gray-400 mb-1"
                        htmlFor="description"
                      >
                        Description
                      </label>
                      <Textarea
                        id="description"
                        placeholder="Enter deck description (optional)"
                        value={newDeckDescription}
                        onChange={(e) => setNewDeckDescription(e.target.value)}
                        className="bg-gray-900/50 border-gray-700 text-white"
                      />
                    </div>
                    {error.creating && (
                      <div className="text-red-400 text-sm">
                        {error.creating}
                      </div>
                    )}
                    <div className="flex space-x-3">
                      <Button
                        onClick={handleCreateDeck}
                        disabled={loading.creating}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                      >
                        {loading.creating ? "Creating..." : "Create Deck"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowNewDeckForm(false);
                          setNewDeckTitle("");
                          setNewDeckDescription("");
                          setError((prev) => ({ ...prev, creating: null }));
                        }}
                        className="border-gray-700 text-gray-400 hover:text-white"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Add AI generate flashcards button when showing deck list */}
              {mode === "browse" && !selectedDeck && !showNewDeckForm && (
                <div className="flex justify-between items-center mb-6">
                  <h1 className="text-2xl font-bold">Your Flashcard Decks</h1>
                  <div className="flex gap-2">
                    {/* AI Generate from PDF button removed */}
                    <Button
                      variant="outline"
                      asChild
                      className="border-purple-700 text-purple-400 hover:bg-purple-900/20"
                    >
                      <Link to="/study-dashboard/pdf-library">
                        <FileText size={16} className="mr-2" /> Go to PDF
                        Library
                      </Link>
                    </Button>
                  </div>
                </div>
              )}

              {/* Show AI generate form if in AI generate mode */}
              {mode === "browse" &&
                !selectedDeck &&
                aiGenerateMode &&
                renderAiGenerateForm()}

              {loading.decks ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-400 mb-4"></div>
                  <p className="text-gray-400 mb-2">
                    Loading your flashcard decks...
                  </p>
                  <p className="text-sm text-gray-500">
                    This may take a moment if you have many decks
                  </p>
                </div>
              ) : error.decks ? (
                <div className="text-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
                  <p className="text-red-400">{error.decks}</p>
                  <Button
                    className="mt-4 bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={() => window.location.reload()}
                  >
                    Retry
                  </Button>
                </div>
              ) : decks.length === 0 ? (
                <div className="text-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
                  <TooltipProvider>
                    <div className="bg-gray-700/50 h-20 w-20 mx-auto rounded-full flex items-center justify-center mb-4 cursor-pointer hover:bg-gray-600/60 transition-colors hover:shadow-md hover:shadow-purple-500/20 animate-pulse-slow">
                      <Sparkles
                        size={32}
                        className="text-purple-400 hover:text-purple-300 transition-colors"
                        strokeWidth={1.5}
                      />
                    </div>
                  </TooltipProvider>
                  <h3 className="text-xl font-medium text-white mb-2">
                    No Flashcard Decks Yet
                  </h3>
                  <p className="text-gray-400 mb-3">
                    Create a deck from your PDF documents
                  </p>

                  <div className="flex flex-col items-center mt-6 space-y-3 max-w-md mx-auto">
                    <div className="bg-gray-800/80 p-3 rounded-lg text-center w-full">
                      <h4 className="text-purple-400 font-medium mb-1">
                        Generate from PDF
                      </h4>
                      <p className="text-gray-400 text-sm mb-2">
                        Upload a PDF to create AI-generated flashcards
                      </p>
                      <Button
                        variant="outline"
                        className="border-purple-700 text-purple-400 hover:bg-purple-900/20"
                        asChild
                      >
                        <Link to="/study-dashboard/pdf-library">
                          <FileText size={16} className="mr-2" /> Go to PDF
                          Library
                        </Link>
                      </Button>
                    </div>

                    <div className="bg-gray-800/80 p-3 rounded-lg text-center w-full">
                      <h4 className="text-yellow-400 font-medium mb-1">
                        AI Generation
                      </h4>
                      <p className="text-gray-400 text-sm mb-2">
                        Create flashcards with AI from uploaded PDFs
                      </p>
                      <Button
                        variant="outline"
                        className="border-yellow-700 text-yellow-400 hover:bg-yellow-900/20"
                        onClick={() => setAiGenerateMode(true)}
                      >
                        <Sparkles size={16} className="mr-2" /> AI Generate
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
                  key={`deck-grid-${lastFlashcardUpdate}-${decks.length}`}
                >
                  {decks.map((deck) => (
                    <motion.div
                      key={`${deck.id}-${lastFlashcardUpdate}-${deck.stats.totalCards}`}
                      className="bg-gray-800/60 border border-gray-700 rounded-lg p-5 hover:bg-gray-800/90 transition-colors cursor-pointer"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSelectDeck(deck)}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="text-lg font-semibold text-white">
                          {deck.title}
                        </h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-700"
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation();
                            handleDeleteDeck(deck.id);
                          }}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                      <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                        {deck.description || "No description"}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="text-sm">
                          <span className="text-gray-400">Cards: </span>
                          <span className="text-white font-medium">
                            {deck.stats.totalCards}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <div className="h-2 w-24 bg-gray-700 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-green-500"
                              style={{ width: `${deck.stats.accuracy}%` }}
                            ></div>
                          </div>
                          <span className="ml-2 text-sm text-gray-400">
                            {deck.stats.accuracy}%
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {mode === "learn" && selectedDeck && (
        <div className="animate-fade-in">
          <div className="flex items-center justify-between mb-6">
            <Button
              variant="outline"
              className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
              onClick={() => setMode("browse")}
            >
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Deck
            </Button>
            <div className="text-gray-400">
              {selectedDeck.cards && selectedDeck.cards.length > 0
                ? `Card ${currentCardIndex + 1} of ${selectedDeck.cards.length}`
                : "No cards available"}
            </div>
          </div>

          {selectedDeck.cards && selectedDeck.cards.length > 0 ? (
            <div className="relative">
              <div className="flex justify-center mb-12">
                <div
                  className="w-full max-w-2xl bg-gray-800/60 backdrop-blur-sm border border-gray-700 rounded-xl p-10 min-h-[300px] 
                          flex flex-col items-center justify-center text-center relative"
                >
                  <div className="absolute top-4 left-4 px-3 py-1 bg-gray-700 rounded-full text-gray-400 text-sm">
                    {showAnswer ? "Answer" : "Question"}
                  </div>

                  <AnimatePresence mode="wait">
                    <motion.div
                      key={`${currentCardIndex}-${showAnswer ? "answer" : "question"}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.2 }}
                      className="w-full"
                    >
                      <h3 className="text-2xl font-medium text-white">
                        {showAnswer
                          ? selectedDeck.cards[currentCardIndex]?.back ||
                            "No answer available"
                          : selectedDeck.cards[currentCardIndex]?.front ||
                            "No question available"}
                      </h3>
                    </motion.div>
                  </AnimatePresence>

                  <div className="absolute bottom-4 right-4">
                    <Button
                      variant="ghost"
                      className="text-blue-400 hover:text-blue-300 hover:bg-gray-700/50"
                      onClick={() => setShowAnswer(!showAnswer)}
                    >
                      <RotateCw size={18} className="mr-1" />
                      {showAnswer ? "Show Question" : "Show Answer"}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <Button
                  variant="outline"
                  className="border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white"
                  onClick={handlePrevCard}
                  disabled={currentCardIndex === 0}
                >
                  <ChevronLeft size={20} className="mr-1" />
                  Previous
                </Button>

                {showAnswer && (
                  <div className="flex items-center gap-3">
                    <Button
                      className="bg-red-600 hover:bg-red-700 text-white px-6 py-6 rounded-full"
                      onClick={() => handleMarkCard(false)}
                    >
                      <X size={30} />
                    </Button>
                    <Button
                      className="bg-green-600 hover:bg-green-700 text-white px-6 py-6 rounded-full"
                      onClick={() => handleMarkCard(true)}
                    >
                      <Check size={30} />
                    </Button>
                  </div>
                )}

                <Button
                  variant="outline"
                  className="border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white"
                  onClick={handleNextCard}
                  disabled={currentCardIndex === selectedDeck.cards.length - 1}
                >
                  Next
                  <ChevronRight size={20} className="ml-1" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-10 bg-gray-800/30 border border-gray-700 rounded-lg">
              <TooltipProvider>
                <div
                  className="bg-gray-700/50 h-20 w-20 mx-auto rounded-full flex items-center justify-center mb-4 cursor-pointer hover:bg-gray-600/60 transition-colors hover:shadow-md hover:shadow-purple-500/20 animate-pulse-slow group"
                  onClick={() => {
                    setMode("browse");
                    setShowNewCardForm(true);
                  }}
                >
                  <PlusCircle
                    size={32}
                    className="text-purple-400 group-hover:text-purple-300 transition-colors"
                    strokeWidth={1.5}
                  />
                </div>
              </TooltipProvider>
              <h3 className="text-xl font-medium text-white mb-2">
                No Flashcards In This Deck
              </h3>
              <p className="text-gray-400 mb-6">
                Add some flashcards to start studying
              </p>
            </div>
          )}
        </div>
      )}

      {/* Cancellation Confirmation Dialog */}
      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Cancel Generation?
            </DialogTitle>
            <DialogDescription>
              Canceling may leave your flashcards in an inconsistent state. Are
              you sure you want to proceed?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 sm:justify-end mt-4">
            <Button
              variant="outline"
              onClick={() => setShowCancelDialog(false)}
              className="border-gray-700 text-white hover:bg-gray-700"
            >
              Go Back
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                setGeneratingCards(false);
                setAiGenerateMode(false);
                setShowCancelDialog(false);
              }}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Yes, Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FlashCards;
