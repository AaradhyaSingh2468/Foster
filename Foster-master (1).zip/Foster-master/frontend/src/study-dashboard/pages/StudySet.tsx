import type React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiChevronLeft, FiEdit, FiShare2, FiDownload, FiCopy, FiMenu, FiBookOpen, FiClipboard, FiLayout } from 'react-icons/fi';
import { Card, CardContent } from '../components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { motion } from 'framer-motion';
import { Label } from '../components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/select';
import { Checkbox } from '../components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import studyBuddyService from '../../services/studyBuddyService';
import type { ExamConfig, StudySet as StudySetType, QuestionType } from '../../services/types';
import { showSuccessToast, showErrorToast, showInfoToast } from '../../utils/toastUtils';

interface CardItem {
  id: number;
  term: string;
  definition: string;
}

interface LocalStudySet {
  id: string;
  title: string;
  description: string;
  source?: string;
  createdAt: string;
  createdBy: string;
  avatar: string;
  cards: CardItem[];
}

// Mock data for the study set
const MOCK_STUDY_SET: LocalStudySet = {
  id: 'foster',
  title: 'foster',
  description: 'No Description',
  createdAt: '29/4/2025',
  createdBy: 'User',
  avatar: 'https://github.com/shadcn.png',
  cards: [
    { id: 1, term: 'Term 1', definition: 'Definition 1' },
    { id: 2, term: 'Term 2', definition: 'Definition 2' },
    { id: 3, term: 'Term 3', definition: 'Definition 3' },
    { id: 4, term: 'Term 4', definition: 'Definition 4' },
    { id: 5, term: 'Term 5', definition: 'Definition 5' },
  ],
};

const QUESTION_TYPES: Array<{ id: QuestionType; label: string }> = [
  { id: 'multiple_choice', label: 'Multiple Choice' },
  { id: 'true_false', label: 'True/False' },
  { id: 'short_answer', label: 'Short Answer' }
];

const defaultExamConfig: ExamConfig = {
  startPage: 1,
  endPage: 10,
  numQuestions: 10,
  questionTypes: ['multiple_choice']
};

const StudySet: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [isGeneratingExam, setIsGeneratingExam] = useState(false);
  const [examConfig, setExamConfig] = useState<ExamConfig>(defaultExamConfig);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [studySet, setStudySet] = useState<StudySetType | null>(null);

  // Get the study set data (in a real app, this would be fetched from an API)
  const studySetData = MOCK_STUDY_SET;

  // Filter cards based on search term
  const filteredCards = studySetData.cards.filter((card) =>
    card.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
    card.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGenerateExam = async () => {
    if (!studySet) return;

    setIsGeneratingExam(true);
    showInfoToast("Generating Exam", "Please wait while we prepare your exam...");
    
    try {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const exam = await studyBuddyService.generateExam(studySet.id, examConfig);
      showSuccessToast("Exam Generated", "Your exam has been generated successfully");
      // Handle the generated exam...
    } catch (error) {
      console.error('Error generating exam:', error);
      showErrorToast("Generation Failed", "There was a problem generating your exam");
    } finally {
      setIsGeneratingExam(false);
    }
  };

  const handleQuestionTypeChange = (type: QuestionType, checked: boolean) => {
    setExamConfig(prev => ({
      ...prev,
      questionTypes: checked
        ? [...prev.questionTypes, type]
        : prev.questionTypes.filter(t => t !== type)
    }));
  };

  const handleNumQuestionsChange = (value: string) => {
    setExamConfig(prev => ({
      ...prev,
      numQuestions: parseInt(value, 10)
    }));
  };

  return (
    <div className="animate-fade-in">
      {/* Header section with back button and title */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="sm"
          className="p-2 rounded-full"
          onClick={() => navigate(-1)}
        >
          <FiChevronLeft size={24} />
        </Button>
        <h1 className="text-2xl font-bold text-purple-100">{studySetData.title}</h1>
      </div>

      {/* Study set info and action buttons */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 mb-8 backdrop-blur-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="bg-gray-700 h-16 w-16 rounded-full flex items-center justify-center text-purple-400 font-bold overflow-hidden">
              <FiBookOpen size={30} />
            </div>
            <div>
              <h3 className="text-white font-medium text-xl">{studySetData.title}</h3>
              <p className="text-gray-400">{studySetData.description}</p>
              <p className="text-gray-500 text-sm">Created At: {studySetData.createdAt}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="bg-gray-700 p-2 rounded-full">
                  <span className="text-green-400">•</span>
                  <span className="text-white ml-1">{studySetData.cards.length}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700">
              <FiEdit size={16} className="mr-2" /> Edit
            </Button>
            <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700">
              <FiShare2 size={16} className="mr-2" /> Share
            </Button>
            <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700">
              <FiDownload size={16} className="mr-2" /> Export
            </Button>
            <Button variant="outline" className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700">
              <FiCopy size={16} className="mr-2" /> Duplicate
            </Button>
            <Button variant="default" className="bg-blue-600 hover:bg-blue-700 text-white">
              Study
            </Button>
          </div>
        </div>
      </div>

      {/* Study tools tabs */}
      <Tabs defaultValue="flashcards" className="w-full">
        <TabsList className="bg-transparent border-b border-gray-700 w-full justify-start h-auto p-0 space-x-6">
          <TabsTrigger
            value="flashcards"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Flashcards
          </TabsTrigger>
          <TabsTrigger
            value="quizfetch"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            QuizFetch
          </TabsTrigger>
          <TabsTrigger
            value="test"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Test
          </TabsTrigger>
          <TabsTrigger
            value="match"
            className="pb-2 px-1 text-gray-400 data-[state=active]:border-b-2 data-[state=active]:border-purple-500 data-[state=active]:text-purple-300 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
          >
            Match Game
          </TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <div className="flex items-center justify-between mb-6">
            <div className="relative w-full max-w-md">
              <Input
                type="text"
                placeholder="Search..."
                className="pl-4 bg-gray-800/50 border-gray-700 text-white focus-visible:ring-purple-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 ml-4">
              <Button
                variant="outline"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
              >
                <FiMenu size={18} />
              </Button>
            </div>
          </div>

          <TabsContent value="flashcards" className="space-y-6">
            {filteredCards.map((card) => (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="bg-gray-800/50 border-gray-700 overflow-hidden backdrop-blur-sm">
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-gray-700">
                      <div className="p-6 flex flex-col min-h-[150px]">
                        <h3 className="text-white text-lg font-medium mb-2">Term</h3>
                        <p className="text-gray-300">{card.term}</p>
                      </div>
                      <div className="p-6 flex flex-col min-h-[150px]">
                        <h3 className="text-white text-lg font-medium mb-2">Definition</h3>
                        <p className="text-gray-300">{card.definition}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </TabsContent>

          <TabsContent value="quizfetch" className="space-y-6">
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-8 text-center backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="w-32 h-32 mx-auto mb-4 bg-blue-500/20 rounded-full flex items-center justify-center"
              >
                <FiClipboard className="h-16 w-16 text-blue-400" />
              </motion.div>
              <h3 className="text-xl font-semibold text-white mb-2">Generate a Quiz</h3>
              <p className="text-gray-400 mb-6">Create a personalized quiz based on this study set</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Generate Quiz
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="test" className="space-y-6">
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-8 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="w-32 h-32 mx-auto mb-4 bg-green-500/20 rounded-full flex items-center justify-center"
              >
                <FiLayout className="h-16 w-16 text-green-400" />
              </motion.div>
              <h3 className="text-xl font-semibold text-white mb-2">Generate an Exam</h3>
              <p className="text-gray-400 mb-6">Create a comprehensive exam based on this study set</p>
              
              <div className="space-y-4 max-w-md mx-auto">
                <div>
                  <Label className="text-white">Number of Questions</Label>
                  <Select
                    value={examConfig.numQuestions.toString()}
                    onValueChange={handleNumQuestionsChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select number of questions" />
                    </SelectTrigger>
                    <SelectContent>
                      {[5, 10, 15, 20].map(num => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} questions
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white">Question Types</Label>
                  <div className="space-y-2">
                    {QUESTION_TYPES.map(type => (
                      <div key={type.id} className="flex items-center">
                        <Checkbox
                          id={type.id}
                          checked={examConfig.questionTypes.includes(type.id)}
                          onCheckedChange={(checked: boolean) => {
                            handleQuestionTypeChange(type.id, checked as boolean);
                          }}
                        />
                        <Label htmlFor={type.id} className="ml-2 text-gray-300">
                          {type.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleGenerateExam}
                  disabled={isGeneratingExam || examConfig.questionTypes.length === 0}
                >
                  {isGeneratingExam ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin inline" />
                      Generating Exam...
                    </>
                  ) : (
                    'Generate Exam'
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="match" className="space-y-6">
            <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-8 text-center backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="w-32 h-32 mx-auto mb-4 bg-purple-500/20 rounded-full flex items-center justify-center"
              >
                <FiLayout className="h-16 w-16 text-purple-400" />
              </motion.div>
              <h3 className="text-xl font-semibold text-white mb-2">Play Match Game</h3>
              <p className="text-gray-400 mb-6">Match terms with their definitions in a fun game</p>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Start Game
              </Button>
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default StudySet;
