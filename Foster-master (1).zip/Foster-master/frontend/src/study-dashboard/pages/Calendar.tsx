import { format, parse, startOfWeek, getDay, addMinutes } from 'date-fns';
import { enUS } from 'date-fns/locale/en-US';
import { dateFnsLocalizer, type SlotInfo } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { PlusCircle, Edit2, Trash2, Bell, BellOff, X } from 'lucide-react';
import { motion } from 'framer-motion';
import BigCalendar from '../components/BigCalendar';
import { getEvents, createEvent, updateEvent, deleteEvent } from '../../services/calendarService';
import { useToast } from '../lib/useToast';
import { showSuccessToast, showErrorToast, showInfoToast } from '../../utils/toastUtils';
import { CalendarEvent as ApiCalendarEvent } from '../../services/types';

const locales = {
  'en-US': enUS,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

type CalendarView = 'month' | 'week' | 'day' | 'agenda' | 'work_week';

// Define a flexible API response interface that can handle both naming conventions
interface FlexibleApiResponse {
  id: string;
  title: string;
  // CamelCase versions
  startTime?: string;
  endTime?: string;
  description?: string;
  eventType?: string;
  reminderTime?: number;
  // Snake_case versions
  start_time?: string;
  end_time?: string;
  desc?: string;
  event_type?: string;
  reminder_time?: number;
  // Common fields
  location?: string;
  reminder?: boolean;
  created_at?: string;
  createdAt?: string;
}

// Interface for our frontend event format
interface Event {
  id: string;
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
  desc?: string;
  reminder?: boolean;
  reminderTime?: Date;
  location?: string;
  utcStartTime: string;
  utcEndTime: string;
}

// Add these helper functions before the component definition
const formatUtcDate = (dateString: string): string => {
  try {
    // Try multiple date parsing approaches
    let date: Date | null = null;
    
    if (typeof dateString === 'string') {
      // Approach 1: Try direct ISO string parsing
      date = new Date(dateString);
      
      if (isNaN(date.getTime())) {
        // Approach 2: If dateString is in a MongoDB-style format without Z
        // Example: 2025-05-26T04:30:00.000+00:00 or 2025-05-26T04:30:00.000
        if (dateString.includes('T')) {
          // Ensure it has a timezone or add Z for UTC
          if (!dateString.includes('Z') && !dateString.includes('+')) {
            dateString += 'Z';
          }
          date = new Date(dateString);
        } else {
          // Approach 3: Try parsing date-only format
          const parts = dateString.split(/[-: ]/);
          if (parts.length >= 3) {
            // Try to create a date with available parts
            const year = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10) - 1; // JS months are 0-based
            const day = parseInt(parts[2], 10);
            const hour = parts.length > 3 ? parseInt(parts[3], 10) : 0;
            const minute = parts.length > 4 ? parseInt(parts[4], 10) : 0;
            const second = parts.length > 5 ? parseInt(parts[5], 10) : 0;
            
            date = new Date(Date.UTC(year, month, day, hour, minute, second));
          }
        }
      }
    }
    
    // If we have a valid date, format it as UTC
    if (date && !isNaN(date.getTime())) {
      return date.toUTCString();
    }
    
    // If all approaches fail, return an error message
    return `Cannot parse: ${dateString}`;
  } catch (e) {
    console.error('Error formatting UTC date:', e);
    return `Error parsing date: ${String(e)}`;
  }
};

const CalendarPage = () => {
  const { toast } = useToast();
  const [myEvents, setMyEvents] = useState<Event[]>([]);
  // Used to track initial data loading state 
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<CalendarView>('month');
  const [date, setDate] = useState(new Date());
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showEventForm, setShowEventForm] = useState(false);
  const [eventFormMode, setEventFormMode] = useState<'add' | 'edit'>('add');
  const [newEvent, setNewEvent] = useState<Omit<Event, 'id'>>({
    title: '',
    start: new Date(),
    end: addMinutes(new Date(), 60),
    desc: '',
    reminder: false,
    utcStartTime: new Date().toISOString(),
    utcEndTime: addMinutes(new Date(), 60).toISOString()
  });
  const [error, setError] = useState<string | null>(null);

  // Helper function to format dates consistently
  const formatDisplayDateTime = (date: Date): string => {
    try {
      if (isNaN(date.getTime())) {
        return "Invalid Date";
      }
      
      // Format as "DD/MM/YYYY"
      const day = date.getDate();
      const month = date.getMonth() + 1; // JavaScript months are 0-indexed
      const year = date.getFullYear();
      const dateDisplay = `${day}/${month}/${year}`;
      
      // Format time as "HH:mm AM/PM"
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const ampm = hours >= 12 ? 'pm' : 'am';
      const hoursDisplay = hours % 12 || 12; // Convert 0 to 12 for 12 AM
      const minutesDisplay = minutes < 10 ? `0${minutes}` : minutes;
      const timeDisplay = `${hoursDisplay}:${minutesDisplay} ${ampm}`;
      
      return `${dateDisplay} · ${timeDisplay}`;
    } catch (e) {
      console.error("Error formatting date:", e);
      return "Invalid Date";
    }
  };

  // Create a function to refresh events that can be used elsewhere in the component
  const refreshEvents = async () => {
      try {
        setLoading(true);
        const startDate = new Date();
        startDate.setMonth(startDate.getMonth() - 1); // Get events from last month
        const endDate = new Date();
        endDate.setMonth(endDate.getMonth() + 2); // Get events until next month
        
      const data = await getEvents(startDate.toISOString(), endDate.toISOString()) as unknown as FlexibleApiResponse[];
      console.log('Fetched events:', data);
      
      if (data.length > 0) {
        // Log detailed debug info for first event
        const firstEvent = data[0];
        console.log('Event debugging:');
        console.log('- Raw event data:', firstEvent);
        
        // Check which field naming convention the API is using
        const hasSnakeCase = firstEvent.start_time !== undefined;
        const hasCamelCase = firstEvent.startTime !== undefined;
        
        console.log('- Field format detection: snake_case:', hasSnakeCase, 'camelCase:', hasCamelCase);
        
        if (hasSnakeCase) {
          console.log('- start_time:', firstEvent.start_time, typeof firstEvent.start_time);
          console.log('- end_time:', firstEvent.end_time, typeof firstEvent.end_time);
          console.log('- Javascript Date interpretation:');
          console.log('  - new Date(start_time):', new Date(firstEvent.start_time || '').toString());
          console.log('  - new Date(end_time):', new Date(firstEvent.end_time || '').toString());
        } else if (hasCamelCase) {
          console.log('- startTime:', firstEvent.startTime, typeof firstEvent.startTime);
          console.log('- endTime:', firstEvent.endTime, typeof firstEvent.endTime);
          console.log('- Javascript Date interpretation:');
          console.log('  - new Date(startTime):', new Date(firstEvent.startTime || '').toString());
          console.log('  - new Date(endTime):', new Date(firstEvent.endTime || '').toString());
        }
      }
      
      // Ensure proper date parsing for all events
      setMyEvents(data.map((event: FlexibleApiResponse) => {
        // Check which fields are available (snake_case or camelCase)
        const startTimeField = event.startTime || event.start_time || '';
        const endTimeField = event.endTime || event.end_time || '';
        const descriptionField = event.description || event.desc || '';
        const eventTypeField = event.eventType || event.event_type || 'study_session';
        const reminderTimeField = event.reminderTime || event.reminder_time || 15;
        
        // Parse dates from UTC ISO strings to local Date objects
        const start = new Date(startTimeField);
        const end = new Date(endTimeField);
        
        console.log(`Event "${event.title}" converted:`, {
          utcStart: startTimeField,
          localStart: start.toLocaleString(),
          utcEnd: endTimeField,
          localEnd: end.toLocaleString(),
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        });
        
        // Calculate reminderTime as a Date if it exists
        let reminderTimeDate: Date | undefined = undefined;
        if (event.reminder && reminderTimeField && !isNaN(reminderTimeField)) {
          // If reminderTime is a number (minutes before start), calculate the actual date
          reminderTimeDate = new Date(start.getTime() - (reminderTimeField * 60 * 1000));
        }
        
        return {
          // Store the original string ID rather than forcing it to be a number
          id: event.id,
          title: event.title,
          start: isNaN(start.getTime()) ? new Date() : start, // Local time for display
          end: isNaN(end.getTime()) ? new Date() : end, // Local time for display
          desc: descriptionField,
          reminder: event.reminder,
          location: event.location,
          reminderTime: reminderTimeDate,
          // Keep track of original UTC values for editing
          utcStartTime: startTimeField,
          utcEndTime: endTimeField
        };
      }));
    } catch (err) {
      console.error('Error refreshing events:', err);
      setError('Failed to refresh events');
      showErrorToast("Calendar Error", "Unable to load your events");
      } finally {
        setLoading(false);
      }
    };

  // Fetch events when component mounts
  useEffect(() => {
    refreshEvents();
  }, []);

  // Check for upcoming reminders
  useEffect(() => {
    const now = new Date();
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');

    // Find current reminders that should be shown
    const currentReminders = myEvents.filter(
      event =>
        event.reminder &&
        event.reminderTime &&
        // Check if current time is within 5 minutes of the reminder time
        Math.abs(event.reminderTime.getTime() - now.getTime()) < 5 * 60 * 1000 && // Within 5 minutes
        // Check if event hasn't already started (don't show reminders for past events)
        event.start.getTime() > now.getTime() &&
        // Verify this reminder hasn't been dismissed
        !dismissedReminders.includes(event.id) && 
        !dismissedReminders.includes(`reminder-${event.id}`)
    );

    // Show toast for each reminder that should be displayed
    currentReminders.forEach(event => {
      // Create a unique ID for this reminder toast to prevent duplicates
      const toastId = `reminder-${event.id}`;
      
      // Check if we've already shown this reminder
      if (!dismissedReminders.includes(toastId)) {
        // Show the reminder toast with styled content
        toast({
          title: "Reminder",
          description: (
            <div className="space-y-2">
              <div className="flex items-center gap-2 mb-1">
                <Bell className="text-yellow-300" size={18} />
                <h4 className="text-lg font-semibold">{event.title}</h4>
              </div>
              <p className="text-gray-200 text-sm">
                {formatDisplayDateTime(event.start)}
              </p>
              {event.desc && (
                <p className="text-gray-200 text-sm border-l-2 border-purple-500 pl-3 italic">
                  {event.desc}
                </p>
              )}
              <Button
                className="mt-2 bg-purple-600 hover:bg-purple-700 text-white"
                onClick={() => handleDismissReminder(event)}
              >
                Dismiss
              </Button>
            </div>
          ),
          duration: 0, // Don't auto-dismiss
        });
        
        // Add to dismissedReminders to prevent showing again
        dismissedReminders.push(toastId);
        localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
      }
    });

    // For demo purposes, comment out the random reminder
    /* 
    const timer = setTimeout(() => {
        const eventsWithReminders = myEvents.filter(e =>
        e.reminder && 
        !dismissedReminders.includes(e.id) && 
        !dismissedReminders.includes(`reminder-${e.id}`)
        );

        if (eventsWithReminders.length > 0) {
        // ... existing code ...
      }
    }, 10000);

    return () => clearTimeout(timer);
    */
  }, [myEvents, toast]);

  // Function to dismiss a reminder and remember the dismissal
  const handleDismissReminder = (event: Event) => {
    // Get currently dismissed reminders
    const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');

    // Add this event ID to the list if not already present
    if (!dismissedReminders.includes(event.id)) {
      dismissedReminders.push(event.id);
    }
    
    // Also add the toast ID to the list
    const toastId = `reminder-${event.id}`;
    if (!dismissedReminders.includes(toastId)) {
      dismissedReminders.push(toastId);
    }

    // Save updated list
    localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
  };

  const handleSelectEvent = (event: Event) => {
    setSelectedEvent(event);
    setShowEventForm(false);
  };

  const handleSelectSlot = (slotInfo: SlotInfo) => {
    setNewEvent({
      title: '',
      start: slotInfo.start,
      end: slotInfo.end,
      desc: '',
      reminder: false,
      utcStartTime: slotInfo.start.toISOString(),
      utcEndTime: slotInfo.end.toISOString()
    });
    setEventFormMode('add');
    setShowEventForm(true);
    setSelectedEvent(null);
  };

  const handleAddEvent = async () => {
    if (!newEvent.title) return;

    try {
      // Make sure we're explicitly working with the correct time
      // From the datetime-local input
      const eventData = {
        title: newEvent.title,
        startTime: newEvent.start.toISOString(),
        endTime: newEvent.end.toISOString(),
        description: newEvent.desc,
        reminder: newEvent.reminder,
        reminderTime: newEvent.reminder ? 15 : undefined,
      };

      console.log('Creating event with data:', eventData);
      
      const response = await createEvent(eventData) as unknown as FlexibleApiResponse;
      console.log('Create event API response:', response);
      
      // Get field values from response (handle both snake_case and camelCase)
      const startTimeField = response.startTime || response.start_time || '';
      const endTimeField = response.endTime || response.end_time || '';
      const descriptionField = response.description || response.desc || '';
      const reminderTimeField = response.reminderTime || response.reminder_time || 15;
      
      // Calculate reminderTime as a Date if the event has reminders enabled
      let reminderTimeDate: Date | undefined = undefined;
      if (response.reminder && reminderTimeField) {
        reminderTimeDate = new Date(new Date(startTimeField).getTime() - (reminderTimeField * 60 * 1000));
      }
      
      const eventToAdd: Event = {
        id: response.id,
        title: response.title,
        start: new Date(startTimeField),
        end: new Date(endTimeField),
        desc: descriptionField,
        reminder: response.reminder,
        reminderTime: reminderTimeDate,
        location: response.location,
        utcStartTime: startTimeField,
        utcEndTime: endTimeField
      };

      // Update events list with the new event
      setMyEvents([...myEvents, eventToAdd]);
      setShowEventForm(false);
      setNewEvent({
        title: '',
        start: new Date(),
        end: addMinutes(new Date(), 60),
        desc: '',
        reminder: false,
        utcStartTime: new Date().toISOString(),
        utcEndTime: addMinutes(new Date(), 60).toISOString()
      });

      showSuccessToast('Event Created', 'Your event was added to the calendar');
      
      // Refresh events to ensure everything is up to date
      await refreshEvents();
    } catch (error) {
      console.error('Error creating event:', error);
      showErrorToast('Calendar Error', 'Failed to create event');
    }
  };

  const handleUpdateEvent = async () => {
    if (!selectedEvent || !newEvent.title) return;

    try {
      const eventData = {
        title: newEvent.title,
        startTime: newEvent.start.toISOString(),
        endTime: newEvent.end.toISOString(),
        description: newEvent.desc,
        reminder: newEvent.reminder,
        reminderTime: newEvent.reminder ? 15 : undefined,
      };

      console.log('Updating event with data:', eventData);
      
      const response = await updateEvent(selectedEvent.id, eventData) as unknown as FlexibleApiResponse;
      console.log('Update event API response:', response);
      
      // Get field values from response (handle both snake_case and camelCase)
      const startTimeField = response.startTime || response.start_time || '';
      const endTimeField = response.endTime || response.end_time || '';
      const descriptionField = response.description || response.desc || '';
      const reminderTimeField = response.reminderTime || response.reminder_time || 15;
      
      // Calculate reminderTime as a Date if the event has reminders enabled
      let reminderTimeDate: Date | undefined = undefined;
      if (response.reminder && reminderTimeField) {
        reminderTimeDate = new Date(new Date(startTimeField).getTime() - (reminderTimeField * 60 * 1000));
      }
      
      const updatedEvent: Event = {
        id: response.id,
        title: response.title,
        start: new Date(startTimeField),
        end: new Date(endTimeField),
        desc: descriptionField,
        reminder: response.reminder,
        reminderTime: reminderTimeDate,
        location: response.location,
        utcStartTime: startTimeField,
        utcEndTime: endTimeField
      };

      setMyEvents(myEvents.map(event => event.id === selectedEvent.id ? updatedEvent : event));
      setShowEventForm(false);
      setSelectedEvent(updatedEvent);

      showSuccessToast('Event Updated', 'Your event was updated successfully');

      // Handle reminder dismissal/re-enabling
      if (updatedEvent.reminder) {
        const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
        const idx = dismissedReminders.indexOf(updatedEvent.id);
        const toastIdx = dismissedReminders.indexOf(`reminder-${updatedEvent.id}`);
        if (idx !== -1) {
          dismissedReminders.splice(idx, 1);
        }
        if (toastIdx !== -1) {
          dismissedReminders.splice(toastIdx, 1);
        }
        localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
      } else {
        handleDismissReminder(updatedEvent);
      }
      
      // Refresh events to ensure everything is up to date
      await refreshEvents();
    } catch (error) {
      console.error('Error updating event:', error);
      showErrorToast('Calendar Error', 'Failed to update event');
    }
  };

  const handleDeleteEvent = async (id: string) => {
    try {
      console.log(`Deleting event with ID: ${id}`);
      
      await deleteEvent(id);
      setMyEvents(myEvents.filter(event => event.id !== id));
      setSelectedEvent(null);
      setShowEventForm(false);

      showSuccessToast('Event Deleted', 'Your event was removed from the calendar');

      // Remove from dismissedReminders if deleted
      const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
      const idx = dismissedReminders.indexOf(id);
      const toastIdx = dismissedReminders.indexOf(`reminder-${id}`);
      if (idx !== -1) {
        dismissedReminders.splice(idx, 1);
      }
      if (toastIdx !== -1) {
        dismissedReminders.splice(toastIdx, 1);
      }
      localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
      
      // Refresh events to ensure everything is up to date
      await refreshEvents();
    } catch (error) {
      console.error('Error deleting event:', error);
      showErrorToast('Calendar Error', 'Failed to delete event');
    }
  };

  const handleEditEvent = (event: Event) => {
    setSelectedEvent(event);
    setNewEvent({
      title: event.title,
      start: event.start,
      end: event.end,
      desc: event.desc || '',
      reminder: event.reminder || false,
      utcStartTime: event.utcStartTime,
      utcEndTime: event.utcEndTime
    });
    setEventFormMode('edit');
    setShowEventForm(true);
  };

  const toggleEventReminder = (id: string) => {
    const targetEvent = myEvents.find(event => event.id === id);
    if (!targetEvent) return;

    const newReminderState = !targetEvent.reminder;

    // First update the UI
    setMyEvents(myEvents.map(event => {
      if (event.id === id) {
        // Calculate new reminderTime as a Date object if enabling reminder
        const reminderTimeDate = newReminderState ? 
          new Date(targetEvent.start.getTime() - 15 * 60 * 1000) : undefined;
          
        const updatedEvent = {
          ...targetEvent,
          reminder: newReminderState,
          reminderTime: reminderTimeDate
        };
        
        if (selectedEvent && selectedEvent.id === id) {
          setSelectedEvent(updatedEvent);
        }
        
        // If enabling reminder, remove from dismissedReminders; if disabling, add to dismissedReminders
        const dismissedReminders = JSON.parse(localStorage.getItem('dismissedReminders') || '[]');
        if (updatedEvent.reminder) {
          const idx = dismissedReminders.indexOf(updatedEvent.id);
          const toastIdx = dismissedReminders.indexOf(`reminder-${updatedEvent.id}`);
          if (idx !== -1) {
            dismissedReminders.splice(idx, 1);
          }
          if (toastIdx !== -1) {
            dismissedReminders.splice(toastIdx, 1);
          }
          localStorage.setItem('dismissedReminders', JSON.stringify(dismissedReminders));
          showInfoToast('Reminder Enabled', `You'll be reminded about "${targetEvent.title}"`);
          
          // Update the event on the server
          updateEvent(id, {
            reminder: true,
            reminderTime: 15 // 15 minutes before event
          }).catch(error => {
            console.error('Error updating event reminder:', error);
          });
        } else {
          handleDismissReminder(updatedEvent);
          showInfoToast('Reminder Disabled', `Reminders turned off for "${targetEvent.title}"`);
          
          // Update the event on the server
          updateEvent(id, {
            reminder: false,
            reminderTime: undefined
          }).catch(error => {
            console.error('Error updating event reminder:', error);
          });
        }
        return updatedEvent;
      }
      return event;
    }));
  };

  // Add a wrapper function for handling view changes 
  const handleViewChange = (newView: string) => {
    // Convert the string to CalendarView type
    setView(newView as CalendarView);
  };

  return (
    <div className="animate-fade-in p-2">
      <h1 className="text-3xl font-bold text-center mb-8 text-purple-100">Calendar</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Calendar */}
        <Card className="lg:col-span-3 bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Schedule</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('month')}
              >
                Month
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('week')}
              >
                Week
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('day')}
              >
                Day
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                onClick={() => setView('agenda')}
              >
                Agenda
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[600px] calendar-container">
              <style>{`
                .rbc-calendar {
                  background-color: rgba(31, 41, 55, 0.4);
                  border-radius: 0.5rem;
                  padding: 1rem;
                  color: white;
                }
                .rbc-toolbar button {
                  color: white;
                  background-color: rgba(31, 41, 55, 0.7);
                }
                .rbc-toolbar button:hover {
                  background-color: rgba(67, 56, 202, 0.7);
                }
                .rbc-toolbar button.rbc-active {
                  background-color: rgba(67, 56, 202, 0.9);
                }
                .rbc-header {
                  background-color: rgba(31, 41, 55, 0.7);
                  padding: 0.5rem;
                }
                .rbc-date-cell {
                  color: rgba(255, 255, 255, 0.8);
                }
                .rbc-off-range-bg {
                  background-color: rgba(31, 41, 55, 0.4);
                }
                .rbc-event {
                  background-color: rgba(79, 70, 229, 0.8);
                }
                .rbc-today {
                  background-color: rgba(79, 70, 229, 0.2);
                }
              `}</style>
              <BigCalendar
                customLocalizer={localizer}
                events={myEvents}
                startAccessor="start"
                endAccessor="end"
                style={{ height: '100%' }}
                views={['month', 'week', 'day', 'agenda']}
                view={view}
                date={date}
                onNavigate={setDate}
                onView={handleViewChange}
                onSelectEvent={handleSelectEvent}
                onSelectSlot={handleSelectSlot}
                selectable
                toolbar={false}
                eventPropGetter={(event: Event) => ({
                  style: {
                    backgroundColor: event.reminder
                      ? 'rgba(139, 92, 246, 0.9)'
                      : 'rgba(67, 56, 202, 0.7)',
                    borderRadius: '4px',
                    border: event.reminder
                      ? '2px solid rgba(250, 204, 21, 0.7)'
                      : 'none',
                    color: 'white',
                  },
                })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sidebar with event details and controls */}
        <Card className="bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium">{showEventForm ? (eventFormMode === 'add' ? 'Add Event' : 'Edit Event') : 'Event Details'}</CardTitle>
          </CardHeader>
          <CardContent>
            {showEventForm ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Title</label>
                  <Input
                    value={newEvent.title}
                    onChange={(e) => setNewEvent({...newEvent, title: e.target.value})}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Event title"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Start Date & Time</label>
                  <Input
                    type="datetime-local"
                    value={format(newEvent.start, "yyyy-MM-dd'T'HH:mm")}
                    onChange={(e) => {
                      const start = new Date(e.target.value);
                      setNewEvent({
                        ...newEvent,
                        start,
                        end: new Date(Math.max(start.getTime(), newEvent.end.getTime()))
                      });
                    }}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">End Date & Time</label>
                  <Input
                    type="datetime-local"
                    value={format(newEvent.end, "yyyy-MM-dd'T'HH:mm")}
                    onChange={(e) => {
                      const end = new Date(e.target.value);
                      setNewEvent({
                        ...newEvent,
                        end
                      });
                    }}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-300 mb-1 block">Description</label>
                  <Input
                    value={newEvent.desc}
                    onChange={(e) => setNewEvent({...newEvent, desc: e.target.value})}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Event description"
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="reminder"
                    checked={newEvent.reminder}
                    onChange={(e) => setNewEvent({...newEvent, reminder: e.target.checked})}
                    className="mr-2"
                  />
                  <label htmlFor="reminder" className="text-sm text-gray-300">Set reminder (15 min before)</label>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={eventFormMode === 'add' ? handleAddEvent : handleUpdateEvent}
                    className="flex-1 bg-purple-600 text-white hover:bg-purple-700"
                  >
                    {eventFormMode === 'add' ? 'Add Event' : 'Update Event'}
                  </Button>
                  <Button
                    onClick={() => {
                      setShowEventForm(false);
                      if (eventFormMode === 'edit' && selectedEvent) {
                        setSelectedEvent(selectedEvent);
                      }
                    }}
                    variant="outline"
                    className="flex-1 bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : selectedEvent ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">{selectedEvent.title}</h3>

                <div className="space-y-1">
                  <p className="text-sm text-gray-300">Time:</p>
                  <div className="bg-gray-700/30 p-2 rounded-md space-y-2">
                    <div>
                      <p className="text-xs text-gray-400">LOCAL TIME ({Intl.DateTimeFormat().resolvedOptions().timeZone})</p>
                      <p className="text-sm text-white">
                        <span className="font-medium">Start:</span> {formatDisplayDateTime(selectedEvent.start)}
                      </p>
                      <p className="text-sm text-white">
                        <span className="font-medium">End:</span> {formatDisplayDateTime(selectedEvent.end)}
                      </p>
                    </div>
                    <div className="mt-2 pt-2 border-t border-gray-700">
                      <p className="text-xs text-gray-400">UTC TIME (Stored in database)</p>
                      <div className="text-sm text-white opacity-75">
                        <div>
                          <span className="font-medium">Start:</span> {formatUtcDate(selectedEvent.utcStartTime)}
                        </div>
                        <div>
                          <span className="font-medium">End:</span> {formatUtcDate(selectedEvent.utcEndTime)}
                        </div>
                      </div>
                    </div>
                </div>
                </div>

                {selectedEvent.desc && (
                  <div className="space-y-1">
                    <p className="text-sm text-gray-300">Description:</p>
                    <p className="text-sm text-white">{selectedEvent.desc}</p>
                  </div>
                )}

                <div className="flex items-center justify-between px-2 py-3 bg-gray-700/30 rounded-md">
                  <span className="text-sm">Reminder</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleEventReminder(selectedEvent.id)}
                    className={`h-8 w-8 p-0 ${selectedEvent.reminder ? 'text-yellow-400' : 'text-gray-400'}`}
                  >
                    {selectedEvent.reminder ? <Bell size={16} /> : <BellOff size={16} />}
                  </Button>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    onClick={() => handleEditEvent(selectedEvent)}
                    variant="outline"
                    className="flex-1 bg-gray-800/50 border-gray-700 text-white hover:bg-gray-700"
                  >
                    <Edit2 size={16} className="mr-2" /> Edit
                  </Button>
                  <Button
                    onClick={() => handleDeleteEvent(selectedEvent.id)}
                    variant="destructive"
                    className="flex-1"
                  >
                    <Trash2 size={16} className="mr-2" /> Delete
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => {
                    setNewEvent({
                      title: '',
                      start: new Date(),
                      end: addMinutes(new Date(), 60),
                      desc: '',
                      reminder: false,
                      utcStartTime: new Date().toISOString(),
                      utcEndTime: addMinutes(new Date(), 60).toISOString()
                    });
                    setEventFormMode('add');
                    setShowEventForm(true);
                  }}
                  className="w-full mb-6 py-2 bg-purple-600 text-white rounded-lg font-medium text-sm flex items-center justify-center gap-2"
                >
                  <PlusCircle size={18} />
                  <span>Add New Event</span>
                </motion.button>

                <div className="text-center py-8 text-gray-400">
                  <p>Select an event to view details</p>
                  <p className="mt-2 text-xs">or click on the calendar to create a new event</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CalendarPage;
