import React, { useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../components/layouts/Sidebar';
import Header from '../components/layouts/Header';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { TooltipProvider } from '../components/ui/tooltip';
import { clearAllToasts } from '../lib/useToast';

const StudyMain: React.FC = () => {
  // Background with subtle pattern/gradient - optimized by caching
  const appBgStyle = React.useMemo(
    () => ({
      backgroundImage: `
      linear-gradient(to bottom right, rgba(17, 24, 39, 0.97), rgba(30, 27, 75, 0.97)),
      url("https://static.vecteezy.com/system/resources/previews/054/238/446/non_2x/abstract-dark-black-textured-background-with-subtle-wavy-lines-perfect-for-website-banners-presentations-or-design-projects-vector.jpg")
    `,
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundAttachment: "fixed",
    }),
    []
  );

  // Clear any toasts when this component mounts (e.g., after login)
  useEffect(() => {
    try {
      // Clear any lingering toast messages when the dashboard loads
      clearAllToasts();
      console.log("Cleared toasts on dashboard mount");
    } catch (error) {
      console.error("Failed to clear toasts:", error);
    }
  }, []);

  return (
    <TooltipProvider>
      <div className="flex h-screen text-white" style={appBgStyle}>
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <Header />

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto px-6 py-4">
            <Outlet />
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default StudyMain; 