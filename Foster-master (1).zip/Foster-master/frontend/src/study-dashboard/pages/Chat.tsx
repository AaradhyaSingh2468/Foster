import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { SendHorizonal, Smile, Paperclip, Bot, User, Image, FileText, Loader2 } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import studyBuddyService from '../../services/studyBuddyService';
import { useToast } from '../lib/useToast';
import { StudySet, StudyBuddyResponse, Message } from '../../services/types';

const Chat: React.FC = () => {
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your Foster AI assistant. How can I help you with your documents today?",
      isUser: false,
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessingDocument, setIsProcessingDocument] = useState(false);
  const [studySets, setStudySets] = useState<StudySet[]>([]);
  const [selectedSet, setSelectedSet] = useState<StudySet | null>(null);
  const [showSources, setShowSources] = useState<{[key: string]: boolean}>({});

  useEffect(() => {
    const loadStudySets = async () => {
      try {
        const sets = await studyBuddyService.getStudySets();
        const pdfSets = sets.filter(set => set.source === 'pdf');
        setStudySets(pdfSets);
        if (pdfSets.length > 0 && !selectedSet) {
          setSelectedSet(pdfSets[0]);
        }
      } catch (error) {
        console.error('Error loading study sets:', error);
      }
    };
    loadStudySets();
  }, [selectedSet]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const toggleSources = (messageId: string) => {
    setShowSources(prev => ({
      ...prev,
      [messageId]: !prev[messageId]
    }));
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Add a "thinking" message that will be replaced when the response arrives
    const thinkingId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: thinkingId,
      content: 'Thinking...',
      isUser: false,
      timestamp: new Date(),
    }]);

    try {
      const response = await studyBuddyService.askQuestion(inputValue, selectedSet?.id);

      // Remove the thinking message
      setMessages(prev => prev.filter(msg => msg.id !== thinkingId));
      
      // Check for error with document processing requirement
      if (response.error && response.error.includes('No documents available')) {
        toast({
          title: "Document Required",
          description: "Please upload a PDF document first",
          variant: "destructive",
        });
      } else if (response.error && response.error.includes('processing')) {
        // If the error indicates document processing is needed
        setIsProcessingDocument(true);
        const processingId = (Date.now() + 2).toString();
        setMessages(prev => [...prev, {
          id: processingId,
          content: "I'm processing your document for the first time. This might take a minute...",
          isUser: false,
          timestamp: new Date(),
          isProcessing: true
        }]);
        
        // Wait a bit and try again
        setTimeout(() => {
          handleRetryProcessing(processingId, inputValue);
        }, 5000);
      } else {
        // Normal successful response
        handleResponse(response);
      }
    } catch (error) {
      // Remove the thinking message and add an error message
      setMessages(prev => prev.filter(msg => msg.id !== thinkingId));
      
      console.error('Error getting AI response:', error);
      toast({
        title: "Error",
        description: "Failed to get AI response",
        variant: "destructive",
      });
      
      const errorMessage: Message = {
        id: (Date.now() + 2).toString(),
        content: 'Sorry, I encountered an error while processing your question. Please try again.',
        isUser: false,
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryProcessing = async (processingMsgId: string, originalQuestion: string) => {
    try {
      // Update the processing message
      setMessages(prev => prev.map(msg => 
        msg.id === processingMsgId 
          ? {...msg, content: "Almost done processing your document..."}
          : msg
      ));
      
      // Try asking the question again
      const response = await studyBuddyService.askQuestion(originalQuestion, selectedSet?.id);
      
      // Update processing status
      setIsProcessingDocument(false);
      
      // Replace the processing message with the actual response
      handleResponse(response, processingMsgId);
    } catch (error) {
      console.error('Error retrying after processing:', error);
      // Update the processing message to show error
      setMessages(prev => prev.map(msg => 
        msg.id === processingMsgId 
          ? {
              ...msg, 
              content: "I'm sorry, there was an error processing your document. Please try uploading it again.",
              isProcessing: false
            }
          : msg
      ));
      
      setIsProcessingDocument(false);
    }
  };

  const handleResponse = (response: StudyBuddyResponse, processingMsgId?: string) => {
    const aiMessage: Message = {
      id: processingMsgId || (Date.now() + 2).toString(),
      content: response.answer || response.message || 'Sorry, I could not generate a response.',
      isUser: false,
      timestamp: new Date(),
      sources: response.sources || [],
      isProcessing: false
    };

    if (processingMsgId) {
      setMessages(prev => prev.map(msg =>
        msg.id === processingMsgId ? aiMessage : msg
      ));
    } else {
      setMessages(prev => [...prev, aiMessage]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h1 className="text-3xl font-bold mb-6 text-purple-100">Chat with AI Assistant</h1>

      <div className="flex-1 flex gap-4">
        <div className="w-1/4">
          <Card className="h-full bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader className="pb-3 border-b border-gray-700">
              <CardTitle className="text-lg">Study Materials</CardTitle>
              <CardDescription className="text-gray-400">
                Select a document to discuss
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              {studySets.length > 0 ? (
                <>
                  <Select value={selectedSet?.id || ''} onValueChange={(value: string) => setSelectedSet(studySets.find(set => set.id === value) || null)}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue placeholder="Select a document" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600 text-white">
                      {studySets.map(set => (
                        <SelectItem key={set.id} value={set.id}>
                          <div className="flex items-center">
                            <FileText size={16} className="mr-2 text-purple-400" />
                            {set.title}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <div className="mt-6">
                    <h3 className="text-sm font-medium mb-2">Suggested Questions</h3>
                    <div className="space-y-2">
                      {[
                        "Summarize this document",
                        "What are the key concepts?",
                        "Explain this in simpler terms",
                        "Generate practice questions"
                      ].map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="w-full justify-start text-xs border-gray-700 text-gray-300 hover:bg-gray-700"
                          onClick={() => {
                            setInputValue(suggestion);
                          }}
                          disabled={!selectedSet || isLoading || isProcessingDocument}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-gray-400 text-sm">
                  No documents available. Please upload a PDF from the library section.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="flex-1">
          <Card className="h-full flex flex-col bg-gray-800/60 border-gray-700 text-white backdrop-blur-sm">
            <CardHeader className="pb-3 border-b border-gray-700">
              <CardTitle className="flex items-center text-lg">
                <Bot className="mr-2 text-purple-400" size={20} />
                AI Study Assistant
                {selectedSet && (
                  <span className="ml-2 text-sm text-gray-400">
                    • Discussing: {selectedSet.title}
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.isUser ? 'justify-end' : 'justify-start'} mb-4`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-2 ${
                      message.isUser
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-700 text-white'
                    }`}
                  >
                    <div className="flex items-center mb-1">
                      {message.isUser ? (
                        <User size={16} className="mr-2 text-white" />
                      ) : (
                        <Bot size={16} className="mr-2 text-purple-400" />
                      )}
                      <span className="text-xs text-gray-300">
                        {message.isUser ? 'You' : 'AI Assistant'} • {' '}
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="text-sm whitespace-pre-wrap">
                      {message.isProcessing ? (
                        <div className="flex items-center">
                          <Loader2 size={16} className="mr-2 animate-spin text-purple-400" />
                          {message.content}
                        </div>
                      ) : (
                        message.content
                      )}
                    </div>
                    
                    {/* Sources section for AI responses */}
                    {!message.isUser && message.sources && message.sources.length > 0 && (
                      <div className="mt-2">
                        <button 
                          onClick={() => toggleSources(message.id)}
                          className="text-xs text-purple-300 hover:text-purple-200 underline"
                        >
                          {showSources[message.id] ? 'Hide sources' : 'Show sources'}
                        </button>
                        
                        {showSources[message.id] && (
                          <div className="mt-2 border-t border-gray-600 pt-2">
                            <p className="text-xs text-gray-400 mb-1">Sources:</p>
                            <div className="max-h-32 overflow-y-auto">
                              {message.sources.map((source, index) => (
                                <div key={index} className="text-xs text-gray-300 bg-gray-800 p-2 rounded mb-1">
                                  {typeof source === 'string' 
                                    ? ((source as string).length > 200 ? `${(source as string).substring(0, 200)}...` : source)
                                    : ((source as { content: string }).content.length > 200 
                                        ? `${(source as { content: string }).content.substring(0, 200)}...` 
                                        : (source as { content: string }).content)}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
              
              {isLoading && !isProcessingDocument && (
                <div className="flex justify-start">
                  <div className="bg-gray-700 text-white rounded-lg px-4 py-2">
                    <div className="flex items-center gap-2">
                      <Bot size={16} className="text-purple-400" />
                      <div className="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </CardContent>

            <div className="p-4 border-t border-gray-700">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={selectedSet ? "Type your question here..." : "Please select a document first"}
                  className="bg-gray-700 border-gray-600 text-white"
                  disabled={isLoading || !selectedSet || isProcessingDocument}
                />
                <Button
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim() || isLoading || !selectedSet || isProcessingDocument}
                >
                  {isProcessingDocument ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <SendHorizonal size={18} />
                  )}
                </Button>
              </div>
              <div className="flex justify-between mt-2">
                <div className="flex gap-2">
                  {/* Commented out attachment icon
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white" disabled={!selectedSet || isLoading || isProcessingDocument}>
                    <Paperclip size={16} />
                  </Button>
                  */}
                  {/* Commented out image icon
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white" disabled={!selectedSet || isLoading || isProcessingDocument}>
                    <Image size={16} />
                  </Button>
                  */}
                  {/* Commented out emoji icon
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white" disabled={!selectedSet || isLoading || isProcessingDocument}>
                    <Smile size={16} />
                  </Button>
                  */}
                </div>
                {isProcessingDocument && (
                  <div className="text-xs text-purple-400 flex items-center">
                    <Loader2 size={12} className="mr-1 animate-spin" />
                    Processing document...
                  </div>
                )}
                {!isProcessingDocument && (
                  <div className="text-xs text-gray-500">
                    Powered by Foster AI
                  </div>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Chat;
