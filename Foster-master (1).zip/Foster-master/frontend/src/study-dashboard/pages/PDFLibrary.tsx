import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, Trash2, Search, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '../components/ui/dialog';
import { Checkbox } from "../components/ui/checkbox";
import studyBuddyService from '../../services/studyBuddyService';
import { getUserDocuments, type Document } from '../../services/documentService';
import type { StudySet, StudySetStats } from '../../services/types';
import UploadPDFButton from '../components/UploadPDFButton';
import { showSuccessToast, showErrorToast } from '../../utils/toastUtils';
import syncService from '../../services/syncService';

// Helper function to format dates safely
const formatDate = (dateString: string | null | undefined) => {
  try {
    if (!dateString) {
      return 'Date not available';
    }
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      return 'Date not available';
    }
    
    // Compare only the date parts (year, month, day)
    const now = new Date();
    const dateOnly = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const nowOnly = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const diffTime = nowOnly.getTime() - dateOnly.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    // If the date is in the future (including later today), show the formatted date
    if (diffDays < 0) {
      return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }
    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }
  } catch (error) {
    console.error('Error formatting date:', error, 'Date string:', dateString);
    return 'Date not available';
  }
};

// Define a unified interface for documents/study sets
interface PDFDocument {
  id: string;
  title: string;
  description?: string | null;
  createdAt?: string;
  uploadDate?: string;
  stats?: StudySetStats;
  isPersistent?: boolean;
}

// Normalize study set data
const normalizeStudySet = (set: StudySet): PDFDocument => ({
  id: set.id,
  title: set.title,
  description: set.description,
  createdAt: set.createdAt,
  stats: set.stats,
  isPersistent: false
});

// Normalize document data
const normalizeDocument = (doc: Document): PDFDocument => ({
  id: doc.id,
  title: doc.title || doc.filename || 'Unnamed PDF',
  description: doc.description,
  createdAt: doc.uploadDate || doc.createdAt,
  stats: doc.stats ? {
    mastered: doc.stats.mastered ?? 0,
    needReview: doc.stats.needReview ?? 0,
    accuracy: doc.stats.accuracy ?? 0
  } : undefined,
  isPersistent: !!doc.isPersistent
});

const PDFLibrary: React.FC = () => {
  const [pdfs, setPdfs] = useState<PDFDocument[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [pdfToDelete, setPdfToDelete] = useState<PDFDocument | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [preservePdf, setPreservePdf] = useState(false);
  const [isDeletingPdf, setIsDeletingPdf] = useState(false);

  const fetchPDFs = async () => {
    try {
      setIsLoading(true);
      
      // Get both regular study sets with source='pdf' and preserved PDFs from filesystem
      const [studySets, documents] = await Promise.all([
        studyBuddyService.getStudySets('pdf'),
        getUserDocuments()
      ]);
      
      console.log(`Found ${studySets.length} study sets and ${documents.length} documents`);
      
      // Normalize the data structure
      const normalizedStudySets = studySets.map(normalizeStudySet);
      
      // Convert documents to the same format, filtering out ones that are already in study sets
      const studySetIds = new Set(normalizedStudySets.map(set => set.id));
      const normalizedDocuments = documents
        .filter(doc => doc.fileType === 'pdf')
        .filter(doc => !studySetIds.has(doc.id)) // Avoid duplicates
        .map(normalizeDocument);
      
      // Combine both sources
      const combinedPDFs = [...normalizedStudySets, ...normalizedDocuments];
      console.log(`Total PDFs available: ${combinedPDFs.length}`);
      
      setPdfs(combinedPDFs);
    } catch (error) {
      console.error('Error fetching PDFs:', error);
      showErrorToast("Error", "Failed to fetch PDF documents");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPDFs();
  }, []);

  const confirmDelete = (pdf: PDFDocument) => {
    setPdfToDelete(pdf);
    setPreservePdf(false);
    setShowDeleteDialog(true);
  };

  const cancelDelete = () => {
    setPdfToDelete(null);
    setShowDeleteDialog(false);
  };

  const handleDelete = async () => {
    if (!pdfToDelete) return;
    
    try {
      setIsDeletingPdf(true);
      
      // Get the ID of the PDF to delete
      const id = pdfToDelete.id;
      
      // Delete the study set with preservePdf=false to ensure PDF is fully deleted
      await studyBuddyService.deleteStudySet(id, { preservePdf: preservePdf });
      
      // Use multiple broadcast methods for redundancy and reliability
      console.log(`Broadcasting deletion of PDF ${id} across components`);
      
      // Broadcast via syncService with detailed information
      syncService.publish('pdf-deleted', { 
        id, 
        title: pdfToDelete.title,
        timestamp: Date.now(),
        preservePdf 
      });
      
      // Additional broadcast with slightly different event type to ensure catchall
      syncService.publish('flashcards-created', {
        action: 'delete',
        source: 'pdf-library',
        pdfId: id,
        timestamp: Date.now()
      });
      
      // Force clear localStorage caches to ensure fresh data
      try {
        localStorage.removeItem('cachedDocuments');
        localStorage.removeItem('cachedDocumentsTimestamp');
        localStorage.removeItem('cachedStudySets');
        localStorage.removeItem('cachedStudySetsTimestamp');
        
        // Set flashcard refresh flag
        localStorage.setItem('flashcardsNeedsRefresh', 'true');
        localStorage.setItem('flashcardsRefreshTimestamp', Date.now().toString());
      } catch (e) {
        console.warn('Failed to clear caches:', e);
      }
      
      // Direct DOM event for immediate refresh in current window
      try {
        window.dispatchEvent(new Event('flashcardsRefreshNeeded'));
      } catch (err) {
        console.warn('Failed to dispatch direct refresh event:', err);
      }
      
      // Success toast notification
      showSuccessToast("Success", `PDF "${pdfToDelete.title}" deleted successfully`);
      
      // Close the dialog and reset state
      setShowDeleteDialog(false);
      setPdfToDelete(null);
      
      // Refresh the PDF list
      fetchPDFs();
      
    } catch (error) {
      console.error('Error deleting PDF:', error);
      showErrorToast("Error", "Failed to delete PDF. Please try again.");
    } finally {
      setIsDeletingPdf(false);
    }
  };

  const filteredPDFs = pdfs.filter(pdf => 
    pdf.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              {pdfToDelete && (
                <>
                  <p className="mt-2">
                    Are you sure you want to delete the PDF "{pdfToDelete.title}"?
                    {pdfToDelete.stats?.mastered ? 
                      ` This PDF has ${pdfToDelete.stats.mastered} mastered flashcards that will also be deleted.` : 
                      ''
                    }
                  </p>
                  
                  <div className="mt-4 flex items-start space-x-2">
                    <Checkbox 
                      id="preservePdf" 
                      checked={preservePdf} 
                      onCheckedChange={(checked) => setPreservePdf(!!checked)}
                    />
                    <label htmlFor="preservePdf" className="text-sm text-gray-300 leading-tight">
                      Keep the PDF document but remove associated flashcards
                    </label>
                  </div>
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2 sm:justify-end mt-4">
            <Button 
              variant="outline" 
              onClick={cancelDelete}
              className="border-gray-700 text-white hover:bg-gray-700"
              disabled={isDeletingPdf}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={isDeletingPdf}
            >
              {isDeletingPdf ? (
                <>
                  <span className="animate-spin rounded-full h-4 w-4 border-t-2 border-white mr-2" />
                  Deleting...
                </>
              ) : 'Delete PDF'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">PDF Library</h1>
          <p className="text-gray-400">Upload PDFs to create AI-generated flashcards</p>
        </div>
        <UploadPDFButton onUploadSuccess={fetchPDFs} />
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input
            type="text"
            placeholder="Search PDFs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-800/50 border-gray-700 text-white w-full max-w-md"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <Card key={i} className="bg-gray-800/50 border-gray-700 backdrop-blur-sm animate-pulse">
              <CardContent className="p-6 h-[200px]" />
            </Card>
          ))
        ) : filteredPDFs.length > 0 ? (
          filteredPDFs.map((pdf) => (
            <motion.div
              key={pdf.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm hover:bg-gray-800/70 transition-colors group">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-white font-medium">
                    {pdf.title}
                    {pdf.isPersistent && (
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                        Preserved
                      </span>
                    )}
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-gray-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => confirmDelete(pdf)}
                  >
                    <Trash2 size={16} />
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
                    <FileText size={16} />
                    <span>PDF Document</span>
                  </div>
                  {pdf.description && (
                    <p className="text-sm text-gray-400 line-clamp-2">{pdf.description}</p>
                  )}
                  <div className="mt-4 pt-4 border-t border-gray-700">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Uploaded {formatDate(pdf.createdAt)}</span>
                      {pdf.stats?.mastered && pdf.stats.mastered > 0 && (
                        <span>{pdf.stats.mastered} terms mastered</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full">
            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm">
              <CardContent className="p-12 text-center">
                <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">No PDFs Found</h3>
                <p className="text-gray-400 mb-4">
                  {searchTerm ? "No PDFs match your search" : "Upload PDFs to create AI-generated flashcards"}
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default PDFLibrary; 