import React from 'react';
import FeatureAIStudy from '../../components/features/FeatureAIStudy';

const StudyBuddyAI: React.FC = () => {
  return (
    <div className="study-dashboard-content">
      <div className="content-header">
        <h1>StudyBuddy AI</h1>
        <p>Your intelligent study assistant powered by AI</p>
      </div>
      <div className="content-body">
        <FeatureAIStudy />
      </div>
    </div>
  );
};

export default StudyBuddyAI; 