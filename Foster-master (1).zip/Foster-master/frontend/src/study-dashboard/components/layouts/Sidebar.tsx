import type React from 'react';
import { useLocation } from 'react-router-dom';
import { cn } from '../../lib/utils';
import { motion } from 'framer-motion';
import {
  HomeIcon,
  MessageSquareIcon,
  CalendarIcon,
  BarChart2Icon,
  BookOpenIcon,
  ClipboardCheckIcon,
  PencilIcon,
  FileTextIcon,
  PlayCircleIcon,
  LibraryIcon
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  to: string;
  active?: boolean;
  onClick?: () => void;
}

// Optimize animations by prefetching and reducing complexity
const transition = { duration: 0.2, ease: 'easeOut' };

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, to, active, onClick }) => {
  return (
    <Link to={to}>
      <motion.li
        whileHover={{ x: 3 }}
        whileTap={{ scale: 0.98 }}
        transition={transition}
        onClick={onClick}
        className={cn(
          'flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition-colors',
          active ? 'bg-purple-900/20 text-purple-300' : 'hover:bg-gray-800'
        )}
      >
        <div className={cn("text-xl", active ? "text-purple-400" : "text-gray-400")}>
          {icon}
        </div>
        <span className={cn("text-sm font-medium", active ? "text-purple-300" : "text-gray-400")}>
          {label}
        </span>
      </motion.li>
    </Link>
  );
};

const Sidebar: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  // Background with subtle pattern
  const sidebarBgStyle = {
    backgroundImage: 'url("https://static.vecteezy.com/system/resources/previews/054/238/446/non_2x/abstract-dark-black-textured-background-with-subtle-wavy-lines-perfect-for-website-banners-presentations-or-design-projects-vector.jpg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundColor: 'rgba(17, 24, 39, 0.95)', // Dark overlay
    backgroundBlendMode: 'overlay' // Blend for subtlety
  };

  const navItems = [
    { icon: <HomeIcon size={20} />, label: 'Home', to: '/study-dashboard' },
    { 
      icon: <LibraryIcon size={20} />, 
      label: 'PDF Library', 
      to: '/study-dashboard/pdf-library',
    },
    { icon: <MessageSquareIcon size={20} />, label: 'Chat', to: '/study-dashboard/chat' },
    { icon: <BookOpenIcon size={20} />, label: 'Flash Cards', to: '/study-dashboard/flashcards' },
    { icon: <CalendarIcon size={20} />, label: 'Calendar', to: '/study-dashboard/calendar' },
    { icon: <PencilIcon size={20} />, label: 'Sketchboard', to: '/study-dashboard/sketchboard' },
    { icon: <BarChart2Icon size={20} />, label: 'Insights', to: '/study-dashboard/insights' },
    { icon: <ClipboardCheckIcon size={20} />, label: 'Tests & QuizFetch', to: '/study-dashboard/tests' },
    { icon: <FileTextIcon size={20} />, label: 'Exam Generation', to: '/study-dashboard/exam-generation' },
    { icon: <PlayCircleIcon size={20} />, label: 'Video Generation', to: '/study-dashboard/video-generation' },
  ];

  return (
    <div className="w-60 h-full overflow-y-auto border-r border-gray-800" style={sidebarBgStyle}>
      <div className="flex items-center gap-2 p-4 border-b border-gray-800/50">
        <div className="flex items-center">
          <motion.div
            whileHover={{ scale: 1.03 }}
            transition={transition}
            className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold"
          >
            F
          </motion.div>
          <span className="ml-2 text-xl font-semibold text-white">Foster</span>
        </div>
      </div>

      <div className="py-6">
        <ul className="space-y-1 px-2">
          {navItems.map((item) => (
            <SidebarItem
              key={item.label}
              icon={item.icon}
              label={item.label}
              to={item.to}
              active={currentPath === item.to}
            />
          ))}
        </ul>
      </div>

      {/* Decorative element at the bottom */}
      <div className="mt-auto p-4 border-t border-gray-800/50">
        <div className="text-xs text-gray-500 text-center">
          Powered by Foster AI
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
