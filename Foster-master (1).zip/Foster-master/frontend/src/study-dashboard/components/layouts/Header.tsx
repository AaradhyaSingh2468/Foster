import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiShare2, FiMessageCircle, FiPlus, FiUpload } from 'react-icons/fi';
import { Button } from '../ui/button';
import { SearchBar } from '../header/SearchBar';
import { UserProfileDropdown } from '../header/UserProfileDropdown';
import { ShareModal } from '../modals/ShareModal';
import { UpgradeModal } from '../modals/UpgradeModal';
import { FeedbackModal } from '../modals/FeedbackModal';
import { CreateSetModal } from '../modals/CreateSetModal';
import UploadPDFButton from '../UploadPDFButton';

const Header: React.FC = () => {
  // State for expanded search bar
  const [searchExpanded, setSearchExpanded] = useState(false);

  // State for modals
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);
  const [createSetModalOpen, setCreateSetModalOpen] = useState(false);

  // Button animations
  const buttonAnimation = {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.95 },
    transition: { duration: 0.2 }
  };

  return (
    <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-900/95 backdrop-blur-sm sticky top-0 z-50">
      <div className="flex items-center space-x-4">
        {/* <SearchBar
          expanded={searchExpanded}
          onToggleExpand={() => setSearchExpanded(!searchExpanded)}
        /> */}
        <div className="flex items-center gap-2 ml-2">
          <span className="text-orange-500">🔥</span>
          <span className="text-white font-semibold">0</span>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        {/* <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white hover:bg-gray-800/50"
            onClick={() => setShareModalOpen(true)}
          >
            <FiShare2 className="mr-2" />
            Share
          </Button>
        </motion.div> */}

        <motion.div
          whileHover={buttonAnimation.whileHover}
          whileTap={buttonAnimation.whileTap}
          transition={buttonAnimation.transition}
        >
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white hover:bg-gray-800/50"
            onClick={() => setFeedbackModalOpen(true)}
          >
            <FiMessageCircle className="mr-2" />
            Feedback
          </Button>
        </motion.div>

        {/* Action Buttons Group */}
        <div className="flex items-center bg-gray-800/30 rounded-full p-1 ml-2">
          {/* <motion.div
            whileHover={buttonAnimation.whileHover}
            whileTap={buttonAnimation.whileTap}
            transition={buttonAnimation.transition}
          >
            <Button
              variant="default"
              className="rounded-full px-4 bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2 shadow-lg shadow-purple-500/20"
              onClick={() => setCreateSetModalOpen(true)}
            >
              <FiPlus size={18} />
              <span className="font-medium">Create Set</span>
            </Button>
          </motion.div> */}

          <motion.div
            whileHover={buttonAnimation.whileHover}
            whileTap={buttonAnimation.whileTap}
            transition={buttonAnimation.transition}
            className="ml-1"
          >
            <UploadPDFButton />
          </motion.div>
        </div>

        <div className="ml-2">
          <motion.div
            whileHover={buttonAnimation.whileHover}
            whileTap={buttonAnimation.whileTap}
            transition={buttonAnimation.transition}
          >
            <Button
              variant="default"
              size="sm"
              className="rounded-full px-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg shadow-emerald-500/20"
              onClick={() => setUpgradeModalOpen(true)}
            >
              <span className="font-medium">Upgrade</span>
            </Button>
          </motion.div>
        </div>

        <UserProfileDropdown />
      </div>

      {/* Modals */}
      <ShareModal
        open={shareModalOpen}
        onOpenChange={setShareModalOpen}
      />

      <UpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
      />

      <FeedbackModal
        open={feedbackModalOpen}
        onOpenChange={setFeedbackModalOpen}
      />

      <CreateSetModal
        open={createSetModalOpen}
        onOpenChange={setCreateSetModalOpen}
      />
    </div>
  );
};

export default Header;
