import { useEffect } from "react";
import { useToast, clearAllToasts } from "../../lib/useToast";
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastTitle,
} from "./toast";

interface ToasterProps {
  clearOnMount?: boolean;
}

export function Toaster({ clearOnMount = false }: ToasterProps) {
  const { toasts } = useToast();

  // Clear all toasts when component mounts if clearOnMount is true
  useEffect(() => {
    if (clearOnMount) {
      // Only clear toasts if we're not showing a logout message
      if (!localStorage.getItem('show_logout_message')) {
        clearAllToasts();
      }
    }
  }, [clearOnMount]);

  // Debug toast rendering
  useEffect(() => {
    if (toasts.length > 0) {
      console.log("Toaster: Rendering toasts:", toasts);
    }
  }, [toasts]);

  return (
    <div className="fixed bottom-4 right-4 flex flex-col gap-2 w-full max-w-[420px] z-50">
      {toasts.map(({ id, title, description, action, variant, ...props }) => {
        // Check if this is a logout toast
        const isLogoutToast = title?.toString().toLowerCase().includes('logged out') || 
                             description?.toString().toLowerCase().includes('logged out');
        
        // Apply extra classes for logout toasts
        const extraClasses = isLogoutToast ? 'toast-success z-[1000] scale-110' : '';
        
        return (
          <Toast 
            key={id} 
            variant={variant}
            className={`${variant === 'success' ? 'border-2' : ''} ${variant === 'success' ? 'shadow-lg' : ''} ${extraClasses}`}
            {...props}
          >
            <div className="grid gap-1">
              {title && <ToastTitle className={variant === 'success' ? 'text-lg font-bold' : ''}>{title}</ToastTitle>}
              {description && (
                <ToastDescription>
                  {description}
                </ToastDescription>
              )}
            </div>
            {action}
            <ToastClose />
          </Toast>
        );
      })}
    </div>
  );
}
