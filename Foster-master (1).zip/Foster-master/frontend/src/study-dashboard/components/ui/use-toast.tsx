// This file is deprecated. Use the hooks from lib/useToast.ts instead
import { useToast as useLibToast, tostify } from "../../lib/useToast";

export const useToast = useLibToast;
export const toast = tostify.toast; 