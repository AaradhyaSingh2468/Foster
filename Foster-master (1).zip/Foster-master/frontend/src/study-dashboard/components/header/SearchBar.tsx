import type React from 'react';
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, File, Book, Tag, X } from 'lucide-react';
import { FiFileText } from 'react-icons/fi';
import { Input } from '../ui/input';
import { Button } from '../ui/button';

// Mock data for search suggestions
const mockItems = [
  { id: '1', type: 'set', title: 'Biology 101', tags: ['science', 'biology'] },
  { id: '2', type: 'set', title: 'Chemistry Fundamentals', tags: ['science', 'chemistry'] },
  { id: '3', type: 'flashcard', title: 'Human Anatomy', tags: ['medical', 'biology'] },
  { id: '4', type: 'note', title: 'Physics Notes', tags: ['science', 'physics'] },
  { id: '5', type: 'set', title: 'Mathematics Formulas', tags: ['math'] },
  { id: '6', type: 'flashcard', title: 'Programming Concepts', tags: ['computer science', 'coding'] },
  { id: '7', type: 'note', title: 'Study Techniques', tags: ['productivity', 'study'] },
  { id: '8', type: 'set', title: 'French Vocabulary', tags: ['language', 'french'] },
];

interface SearchBarProps {
  expanded?: boolean;
  onToggleExpand?: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  expanded = false,
  onToggleExpand
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredItems, setFilteredItems] = useState(mockItems);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Handle search input changes
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);

    if (query.length > 0) {
      setShowSuggestions(true);
      filterItems(query, selectedType, selectedTag);
    } else {
      setShowSuggestions(false);
    }
  };

  // Filter items based on search query, type, and tag
  const filterItems = (query: string, type: string | null, tag: string | null) => {
    let results = mockItems.filter(item =>
      item.title.toLowerCase().includes(query.toLowerCase())
    );

    if (type) {
      results = results.filter(item => item.type === type);
    }

    if (tag) {
      results = results.filter(item => item.tags.includes(tag));
    }

    setFilteredItems(results);
  };

  // Handle type filter selection
  const handleTypeFilter = (type: string) => {
    const newType = selectedType === type ? null : type;
    setSelectedType(newType);
    filterItems(searchQuery, newType, selectedTag);
  };

  // Handle tag filter selection
  const handleTagFilter = (tag: string) => {
    const newTag = selectedTag === tag ? null : tag;
    setSelectedTag(newTag);
    filterItems(searchQuery, selectedType, newTag);
  };

  // Clear search
  const handleClearSearch = () => {
    setSearchQuery('');
    setShowSuggestions(false);
    setSelectedType(null);
    setSelectedTag(null);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  // Get all unique tags from items
  const getAllTags = () => {
    const tags = new Set<string>();
    for (const item of mockItems) {
      for (const tag of item.tags) {
        tags.add(tag);
      }
    }
    return Array.from(tags).sort();
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'set':
        return <Book size={16} className="text-blue-400" />;
      case 'flashcard':
        return <File size={16} className="text-green-400" />;
      case 'note':
        return <FiFileText size={16} className="text-yellow-400" />;
      default:
        return <File size={16} />;
    }
  };

  return (
    <div className="relative">
      <div className={`relative transition-all duration-300 ${expanded ? 'w-[300px]' : 'w-12'}`}>
        <div className="relative">
          <Search
            className={`absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 cursor-pointer ${
              expanded ? '' : 'transition-all hover:text-gray-200'
            }`}
            onClick={onToggleExpand}
          />
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search for anything"
            value={searchQuery}
            onChange={handleSearchChange}
            onFocus={() => searchQuery && setShowSuggestions(true)}
            className={`pl-10 ${
              expanded
                ? 'w-full rounded-full bg-gray-800 border-0 text-gray-200 focus-visible:ring-purple-500 pr-10'
                : 'w-12 rounded-full bg-gray-800 border-0'
            }`}
          />
          {expanded && searchQuery && (
            <button
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
              onClick={handleClearSearch}
            >
              <X size={16} />
            </button>
          )}
        </div>

        <AnimatePresence>
          {showSuggestions && expanded && (
            <motion.div
              ref={dropdownRef}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="absolute mt-2 w-full bg-gray-800 rounded-lg border border-gray-700 shadow-lg z-50 overflow-hidden"
            >
              {/* Type filters */}
              <div className="p-2 border-b border-gray-700">
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant={selectedType === 'set' ? 'default' : 'outline'}
                    className={`text-xs flex items-center gap-1 h-7 px-2 ${
                      selectedType === 'set' ? 'bg-blue-600' : ''
                    }`}
                    onClick={() => handleTypeFilter('set')}
                  >
                    <Book size={14} /> Sets
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedType === 'flashcard' ? 'default' : 'outline'}
                    className={`text-xs flex items-center gap-1 h-7 px-2 ${
                      selectedType === 'flashcard' ? 'bg-green-600' : ''
                    }`}
                    onClick={() => handleTypeFilter('flashcard')}
                  >
                    <File size={14} /> Flashcards
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedType === 'note' ? 'default' : 'outline'}
                    className={`text-xs flex items-center gap-1 h-7 px-2 ${
                      selectedType === 'note' ? 'bg-yellow-600' : ''
                    }`}
                    onClick={() => handleTypeFilter('note')}
                  >
                    <FiFileText size={14} /> Notes
                  </Button>
                </div>
              </div>

              {/* Tag filters */}
              <div className="p-2 border-b border-gray-700 max-h-[100px] overflow-y-auto">
                <div className="flex flex-wrap gap-2">
                  {getAllTags().map(tag => (
                    <Button
                      key={tag}
                      size="sm"
                      variant={selectedTag === tag ? 'default' : 'outline'}
                      className={`text-xs flex items-center gap-1 h-6 px-2 ${
                        selectedTag === tag ? 'bg-purple-600' : ''
                      }`}
                      onClick={() => handleTagFilter(tag)}
                    >
                      <Tag size={10} /> {tag}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Results */}
              <div className="max-h-[300px] overflow-y-auto">
                {filteredItems.length > 0 ? (
                  filteredItems.map(item => (
                    <div
                      key={item.id}
                      className="p-3 hover:bg-gray-700 cursor-pointer transition-colors flex items-center gap-3"
                    >
                      {getTypeIcon(item.type)}
                      <div className="flex-1">
                        <p className="text-sm font-medium text-white">{item.title}</p>
                        <div className="flex items-center gap-1 mt-1">
                          {item.tags.slice(0, 2).map(tag => (
                            <span
                              key={tag}
                              className="text-xs bg-gray-700 text-gray-300 px-1.5 py-0.5 rounded"
                            >
                              {tag}
                            </span>
                          ))}
                          {item.tags.length > 2 && (
                            <span className="text-xs text-gray-400">+{item.tags.length - 2} more</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-gray-400">
                    No results found
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
