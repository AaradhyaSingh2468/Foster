import type React from 'react';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { User, Settings, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import { useToast } from '../../lib/useToast';
// @ts-ignore
import { useAuth } from '../../../context/AuthContext';
// @ts-ignore - Import our standalone toast function and toast utilities
import { showLogoutToast } from '../../../hooks/useGlobalToast';
import { showInfoToast, clearToasts } from '../../../utils/toastUtils';
// @ts-ignore
import * as userService from '../../../services/userService';

interface UserProfileDropdownProps {
  userInitial?: string;
  userImage?: string;
}

export const UserProfileDropdown: React.FC<UserProfileDropdownProps> = ({
  userInitial = 'F',
  userImage
}) => {
  const { toast } = useToast();
  const { logout, currentUser, userProfile } = useAuth();
  const navigate = useNavigate();
  const [profilePicture, setProfilePicture] = useState<string | undefined>(userImage);

  useEffect(() => {
    // Try to get user avatar from various sources
    const fetchUserAvatar = async () => {
      try {
        // First check if userImage prop was provided
        if (userImage) {
          setProfilePicture(userImage);
          return;
        }
        
        // Then check userProfile state
        if (userProfile?.avatar) {
          setProfilePicture(userProfile.avatar);
          return;
        }
        
        // Then check localStorage
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        if (userData.avatar) {
          setProfilePicture(userData.avatar);
          return;
        }
        
        // If we still don't have an avatar, fetch it from the API
        if (currentUser) {
          const profile = await userService.getUserProfile();
          if (profile.avatar) {
            setProfilePicture(profile.avatar);
          }
        }
      } catch (error) {
        console.error('Error fetching avatar:', error);
      }
    };
    
    fetchUserAvatar();
  }, [userImage, userProfile, currentUser]);

  // Get the user's first initial for the avatar fallback
  const getInitial = () => {
    if (userInitial !== 'F') return userInitial;
    if (userProfile?.username) return userProfile.username.charAt(0).toUpperCase();
    if (currentUser?.email) return currentUser.email.charAt(0).toUpperCase();
    return 'F';
  };

  const handleLogout = async () => {
    try {
      console.log("Starting logout process...");
      
      // Show in-progress toast using our toast utility
      showInfoToast("Logging out...", "Please wait while we securely log you out", 2000);
      
      // Set multiple flags to ensure toast appears after navigation
      localStorage.setItem('show_logout_message', 'true');
      localStorage.setItem('logout_timestamp', Date.now().toString());
      sessionStorage.setItem('just_logged_out', 'true');
      
      // Make sure we haven't already shown a logout toast
      localStorage.removeItem('logout_toast_shown');
      
      // Use toast utils instead of directly accessing window.globalToast
      console.log("Using global toast system for logout notification");
      
      // Create global flag for the toast and dispatch event for logout-handler.js
      if (typeof window !== 'undefined') {
        console.log("Setting window.showLogoutToast flag");
        
        // This will be used by our logout-handler.js script
        if (typeof (window as any).showLogoutToast === 'function') {
          // Don't call it yet to avoid showing toast before navigation
          // Just prepare it for after navigation
          console.log("Found showLogoutToast function");
        } else {
          // Set it as a boolean flag for the handler to detect
          (window as any).showLogoutToast = true;
        }
        
        // Also try to dispatch an event that the logout-handler.js can listen for
        try {
          document.dispatchEvent(new CustomEvent('userLogout', {
            detail: { timestamp: Date.now() }
          }));
          console.log("Dispatched userLogout event");
        } catch (eventError) {
          console.error('Error dispatching logout event:', eventError);
        }
      }
      
      // Clear any existing toasts
      clearToasts();
      
      // Perform logout
      await logout();
      
      // Immediately show toast before redirect
      try {
        // Directly use our standalone toast function
        showLogoutToast();
      } catch (toastError) {
        console.error("Error showing toast before navigate:", toastError);
        
        // Fallback to regular toast
        toast({
          title: "Logged out successfully",
          description: "You have been securely logged out of your account",
          variant: "success",
          duration: 5000,
        });
      }
      
      console.log("Redirecting to landing page...");
      
      // Set a flag to ensure toast is shown after navigation
      sessionStorage.setItem('from_logout', 'true');
      
      // Navigate with state containing logout info
      navigate('/', { 
        state: { 
          justLoggedOut: true,
          logoutTime: Date.now()
        } 
      });
      
    } catch (error) {
      console.error('Failed to log out', error);
      
      toast({
        title: "Logout had some issues",
        description: "There were some problems during logout, but we've redirected you to safety",
        variant: "destructive",
        duration: 5000,
      });
      
      // Clear any remaining tokens to ensure the user can't access protected routes
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      localStorage.removeItem('sessionId');
      
      // Even if logout fails, redirect the user to the landing page for safety
      console.log("Redirecting to landing page despite errors...");
      navigate('/');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="cursor-pointer"
        >
          <Avatar className="h-10 w-10 ring-2 ring-gray-700">
            <AvatarImage src={profilePicture} alt="User" />
            <AvatarFallback className="bg-purple-600 text-white">
              {getInitial()}
            </AvatarFallback>
          </Avatar>
        </motion.div>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        {currentUser && <DropdownMenuLabel className="text-xs text-gray-400 font-normal">{currentUser.email}</DropdownMenuLabel>}
        <DropdownMenuSeparator />

        <Link to="/study-dashboard/profile">
          <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
            <User size={16} />
            <span>View Profile</span>
          </DropdownMenuItem>
        </Link>

        <Link to="/study-dashboard/account-settings">
          <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
            <Settings size={16} />
            <span>Account Settings</span>
          </DropdownMenuItem>
        </Link>

        <DropdownMenuSeparator />

        <DropdownMenuItem
          className="flex items-center gap-2 cursor-pointer text-red-400 focus:text-red-400"
          onClick={handleLogout}
        >
          <LogOut size={16} />
          <span>Logout</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
