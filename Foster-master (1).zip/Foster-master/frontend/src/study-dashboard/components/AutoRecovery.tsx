import React, { useState, useEffect } from 'react';

interface AutoRecoveryProps {
  loading: boolean;
  documentsLength: number;
  fetchDocuments: (forceFresh?: boolean) => Promise<void>;
}

const AutoRecovery: React.FC<AutoRecoveryProps> = ({ loading, documentsLength, fetchDocuments }) => {
  const [recoveryAttempts, setRecoveryAttempts] = useState(0);
  const [recoveryInProgress, setRecoveryInProgress] = useState(false);
  const maxAttempts = 3; // Maximum number of automatic recovery attempts
  
  useEffect(() => {
    // Avoid running recovery if already in progress
    if (recoveryInProgress) return;
    
    // Check if there's evidence PDFs should exist in localStorage 
    const checkForPdfEvidence = () => {
      try {
        // Check various sources of truth about PDFs
        const pdfDocsExist = localStorage.getItem('pdfDocsExist') === 'true';
        const recentLogs = localStorage.getItem('recentApiLogs') || '';
        const hasPdfInLogs = recentLogs.includes('PDF') || recentLogs.includes('pdf');
        
        return pdfDocsExist || hasPdfInLogs;
      } catch (e) {
        console.warn('Error checking for PDF evidence:', e);
        return false; // Don't assume PDFs exist on error to prevent loops
      }
    };
    
    // Stop recovery attempts after reaching max attempts
    if (recoveryAttempts >= maxAttempts) {
      console.log(`AutoRecovery: Maximum recovery attempts (${maxAttempts}) reached, stopping auto-recovery`);
      return;
    }
    
    // If no documents are available and not loading, trigger auto-recovery
    // but only if we haven't reached the maximum attempts
    if (!loading && documentsLength === 0 && recoveryAttempts < maxAttempts && 
        (checkForPdfEvidence() || recoveryAttempts === 0)) {
      console.log(`AutoRecovery: No documents available, triggering recovery (attempt ${recoveryAttempts + 1}/${maxAttempts})`);
      
      // Prevent multiple simultaneous recovery attempts
      setRecoveryInProgress(true);
      
      // Use longer delays for subsequent attempts
      const delay = recoveryAttempts === 0 ? 300 : (recoveryAttempts * 1000 + 500);
      
      const timer = setTimeout(() => {
        console.log(`AutoRecovery: Fetching documents with emergency fallback (attempt ${recoveryAttempts + 1}/${maxAttempts})`);
        
        fetchDocuments(true)
          .then(() => {
            console.log(`AutoRecovery: Fetch attempt ${recoveryAttempts + 1} completed`);
            // Increment counter after fetch completes
            setRecoveryAttempts(prev => prev + 1);
          })
          .catch(err => {
            console.error('AutoRecovery fetch error:', err);
            // Still increment counter on error
            setRecoveryAttempts(prev => prev + 1);
          })
          .finally(() => {
            // Allow next recovery attempt after this one completes
            setRecoveryInProgress(false);
          });
      }, delay);
      
      return () => clearTimeout(timer);
    }
  }, [loading, documentsLength, fetchDocuments, recoveryAttempts, recoveryInProgress, maxAttempts]);
  
  return null; // This component doesn't render anything
};

export default AutoRecovery; 