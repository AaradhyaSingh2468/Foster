import type React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { motion } from 'framer-motion';
import { FiSettings } from 'react-icons/fi';

const UserProfile: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center py-6 animate-fade-in">
      <motion.div
        whileHover={{ scale: 1.05 }}
        className="relative"
      >
        <Avatar className="h-16 w-16 ring-4 ring-blue-100">
          <AvatarImage src="https://github.com/shadcn.png" alt="User" />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
        <motion.button
          whileHover={{ rotate: 45 }}
          whileTap={{ scale: 0.9 }}
          className="absolute bottom-0 right-0 bg-white p-1 rounded-full shadow-md text-gray-600"
        >
          <FiSettings size={14} />
        </motion.button>
      </motion.div>

      <div className="mt-4 text-center">
        <h2 className="text-xl font-bold text-gray-800">foster</h2>
        <p className="text-sm text-gray-500">No Description</p>
      </div>
    </div>
  );
};

export default UserProfile;
