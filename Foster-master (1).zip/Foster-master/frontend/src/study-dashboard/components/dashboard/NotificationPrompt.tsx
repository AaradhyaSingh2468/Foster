import type React from 'react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '../ui/button';

const NotificationPrompt: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  // Check localStorage on component mount - with additional check for dismissal
  useEffect(() => {
    const hasPromptBeenShown = localStorage.getItem('notificationPromptShown');
    const hasPromptBeenDismissed = localStorage.getItem('notificationPromptDismissed');

    // Only show the prompt if it hasn't been shown or dismissed before
    if (!hasPromptBeenShown && !hasPromptBeenDismissed) {
      // Small delay before showing to avoid rendering during page load
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 500);

      return () => clearTimeout(timer);
    }
  }, []);

  const handleDismiss = (choice: 'enable' | 'disable') => {
    // Save user's choice and dismissal in localStorage
    localStorage.setItem('notificationPromptShown', 'true');
    localStorage.setItem('notificationPromptDismissed', 'true');
    localStorage.setItem('notificationsEnabled', choice === 'enable' ? 'true' : 'false');

    // Hide the prompt
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.2 }}
          className="fixed bottom-6 right-6 p-6 bg-gray-800 rounded-lg shadow-lg border border-gray-700 max-w-xl text-white z-50"
        >
          <div className="flex items-start">
            <div className="flex-grow">
              <h3 className="font-medium text-white mb-1">Would you like to receive notifications?</h3>
              <p className="text-gray-300 text-sm mb-4">
                We will notify when your documents finish uploading, when its time to study, when you are
                losing your streak and about any new features.
              </p>
              <div className="flex space-x-3">
                <Button
                  onClick={() => handleDismiss('enable')}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  Enable Notifications
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleDismiss('disable')}
                  className="border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  No, Thanks
                </Button>
              </div>
            </div>
            <div className="flex-shrink-0 ml-4">
              <img
                src="https://same-assets.com/HFc4Ys0TfRrFUdkeMUdU-s-200.png"
                alt="Robot mascot"
                className="w-24 h-24 object-contain"
                loading="lazy"
              />
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default NotificationPrompt;
