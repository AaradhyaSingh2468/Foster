import type React from 'react';
import { useState } from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { motion } from 'framer-motion';
import { FiFolder, FiPlus } from 'react-icons/fi';

const DashboardTabs: React.FC = () => {
  const [activeTab, setActiveTab] = useState('all');

  return (
    <div className="mb-10">
      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
        <div className="border-b mb-6">
          <TabsList className="bg-transparent p-0 h-auto space-x-6">
            <TabsTrigger
              value="all"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              All Study Sets
            </TabsTrigger>
            <TabsTrigger
              value="materials"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Materials
            </TabsTrigger>
            <TabsTrigger
              value="flashcards"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Flashcards
            </TabsTrigger>
            <TabsTrigger
              value="quizfetch"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              QuizFetch
            </TabsTrigger>
            <TabsTrigger
              value="tests"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Tests
            </TabsTrigger>
            <TabsTrigger
              value="match"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Match Games
            </TabsTrigger>
            <TabsTrigger
              value="audio"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Audio Recap
            </TabsTrigger>
            <TabsTrigger
              value="explainers"
              className="pb-2 px-1 text-gray-600 data-[state=active]:border-b-2 data-[state=active]:border-blue-500 data-[state=active]:text-blue-600 data-[state=active]:shadow-none data-[state=active]:bg-transparent rounded-none"
            >
              Explainers
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-gray-700 font-medium">Other Study Sets</h3>
            <div className="flex space-x-3">
              <Button variant="outline" size="sm" className="text-sm border-gray-300">
                All Study Sets
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex-shrink-0">
              <Button variant="outline" size="sm" className="flex items-center gap-1 border-gray-300 text-gray-600">
                <img
                  src="https://github.com/shadcn.png"
                  alt="Profile"
                  className="h-5 w-5 rounded-full mr-1"
                />
                foster
                <span className="text-xs ml-1">▼</span>
              </Button>
            </div>
          </div>
        </div>

        <TabsContent value="all" className="mt-0">
          <div className="flex flex-col space-y-6">
            <div className="flex justify-between items-center">
              <Button
                variant="outline"
                className="flex items-center gap-2 border-gray-300"
                onClick={() => {}}
              >
                <FiPlus size={18} className="text-gray-600" />
                <span>Add Material</span>
              </Button>

              <Button
                variant="outline"
                className="flex items-center gap-2 border-gray-300"
                onClick={() => {}}
              >
                <FiFolder size={18} className="text-gray-600" />
                <span>Create Folder</span>
              </Button>
            </div>

            <div className="mt-6">
              <div className="flex flex-col space-y-2">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium text-gray-700">Search for Materials</h4>
                </div>
                <div className="flex gap-3">
                  <div className="flex-grow relative">
                    <Input
                      type="text"
                      placeholder="Search..."
                      className="border-gray-300 focus-visible:ring-blue-500"
                    />
                  </div>
                  <Button variant="default">Search</Button>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <motion.div
                className="border rounded-lg p-3 flex items-center hover:bg-gray-50 cursor-pointer"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="w-10 h-10 flex-shrink-0 mr-3 bg-gray-100 flex items-center justify-center rounded-md">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-800">Untitled Document</h4>
                  <p className="text-xs text-gray-500">Apr 29, 2025</p>
                </div>
              </motion.div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="materials" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No materials found.</p>
          </div>
        </TabsContent>

        <TabsContent value="flashcards" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No flashcards found.</p>
          </div>
        </TabsContent>

        <TabsContent value="quizfetch" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No quizzes found.</p>
          </div>
        </TabsContent>

        <TabsContent value="tests" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No tests found.</p>
          </div>
        </TabsContent>

        <TabsContent value="match" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No match games found.</p>
          </div>
        </TabsContent>

        <TabsContent value="audio" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No audio recaps found.</p>
          </div>
        </TabsContent>

        <TabsContent value="explainers" className="mt-0">
          <div className="flex justify-center items-center py-10">
            <p className="text-gray-500">No explainers found.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardTabs;
