import type React from 'react';
import { Input } from '../ui/input';
import { FiSearch } from 'react-icons/fi';
import { motion } from 'framer-motion';

const SearchBar: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative w-full max-w-xl mx-auto mb-6"
    >
      <div className="relative">
        <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        <Input
          type="text"
          placeholder="Search for anything"
          className="pl-12 pr-4 py-3 h-12 rounded-full bg-gray-100 border-0 focus-visible:ring-blue-500 shadow-sm w-full"
        />
      </div>
    </motion.div>
  );
};

export default SearchBar;
