import React from 'react';

interface FlashCardSetProps {
  id: string;
  title: string;
  description?: string;
  cardCount?: number;
}

const FlashCardSet: React.FC<FlashCardSetProps> = ({ title, description, cardCount }) => {
  return (
    <div className="p-4 border rounded-lg bg-gray-800 border-gray-700">
      <h3 className="text-lg font-medium text-white">{title}</h3>
      {description && <p className="mt-2 text-sm text-gray-400">{description}</p>}
      {cardCount !== undefined && (
        <div className="mt-4 text-xs text-gray-500">
          {cardCount} {cardCount === 1 ? 'card' : 'cards'}
        </div>
      )}
    </div>
  );
};

export default FlashCardSet; 