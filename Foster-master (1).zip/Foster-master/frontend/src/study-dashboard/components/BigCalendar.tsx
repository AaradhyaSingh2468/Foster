import React from 'react';
import { Calendar, CalendarProps } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';

// Define props without generic constraints to avoid the type error
export interface BigCalendarProps {
  customLocalizer: any;
  events: any[];
  startAccessor?: string | ((event: any) => Date);
  endAccessor?: string | ((event: any) => Date);
  view?: string;
  date?: Date;
  onNavigate?: (date: Date) => void;
  onView?: (view: string) => void;
  onSelectEvent?: (event: any) => void;
  onSelectSlot?: (slotInfo: any) => void;
  eventPropGetter?: (event: any) => any;
  selectable?: boolean;
  style?: React.CSSProperties;
  views?: string[];
  [key: string]: any;
}

// Create a class component to properly extend React.Component
class BigCalendar extends React.Component<BigCalendarProps> {
  render() {
    const { customLocalizer, ...rest } = this.props;
    
    // @ts-ignore - Ignore the type error for Calendar component
    return <Calendar localizer={customLocalizer} {...rest} />;
  }
}

export default BigCalendar; 