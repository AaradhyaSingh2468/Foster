import React, { useRef, useState } from 'react';
import { Button } from './ui/button';
import { Upload, Loader2 } from 'lucide-react';
import { uploadPdf } from '../../services/pdfUploadService';
import { showSuccessToast, showErrorToast, showInfoToast } from '../../utils/toastUtils';
import syncService from '../../services/syncService';

interface UploadPDFButtonProps {
  onUploadSuccess?: () => void;
}

const UploadPDFButton: React.FC<UploadPDFButtonProps> = ({ onUploadSuccess }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      showErrorToast("Invalid file type", "Please select a PDF file");
      return;
    }

    setIsUploading(true);
    showInfoToast("Uploading", `Uploading ${file.name}...`);
    console.log("Starting upload for file:", file.name);
    
    try {
      // Using direct uploadPdf function from new service
      const result = await uploadPdf(file);
      console.log("Upload successful:", result);
      
      // Force immediate refresh in multiple ways for redundancy
      const refreshFlashcards = () => {
        console.log("Triggering flashcard refresh after PDF upload");
        
        // 1. Use syncService
        syncService.publish('pdf-uploaded', {
          filename: file.name,
          timestamp: Date.now(),
          responseData: result
        });
        
        // 2. Set localStorage flag
        localStorage.setItem('flashcardsNeedsRefresh', 'true');
        localStorage.setItem('flashcardsRefreshTimestamp', Date.now().toString());
        
        // 3. Dispatch direct DOM event
        try {
          window.dispatchEvent(new Event('flashcardsRefreshNeeded'));
        } catch (e) {
          console.warn('Failed to dispatch refresh event:', e);
        }
      };
      
      // Trigger refresh immediately
      refreshFlashcards();
      
      // Also trigger refresh after a short delay to ensure backend is ready
      setTimeout(refreshFlashcards, 500);

      // Clear the file input to allow re-uploading the same file
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      setIsUploading(false);
      showSuccessToast("Upload complete", "PDF uploaded successfully!");
      
      // Call the success callback if provided
      if (onUploadSuccess) {
        onUploadSuccess();
      }
    } catch (error) {
      console.error("Upload error:", error);
      setIsUploading(false);
      showErrorToast("Upload failed", "There was a problem uploading your PDF. Please try again.");
      
      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div>
      <input
        type="file"
        accept="application/pdf"
        ref={fileInputRef}
        onChange={handleFileSelect}
        className="hidden"
        aria-label="Upload PDF file"
        title="Choose a PDF file to upload"
      />
      <Button
        variant="default"
        className="bg-blue-600 hover:bg-blue-700"
        onClick={() => fileInputRef.current?.click()}
        disabled={isUploading}
        aria-controls={fileInputRef.current?.id}
      >
        {isUploading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Uploading...
          </>
        ) : (
          <>
            <Upload className="mr-2 h-4 w-4" />
            Upload PDF
          </>
        )}
      </Button>
    </div>
  );
};

export default UploadPDFButton; 