import React from 'react';
import Sidebar from './layouts/Sidebar';
import Header from './layouts/Header';
import NotificationPrompt from './dashboard/NotificationPrompt';
import { Toaster } from './ui/toaster';
import { TooltipProvider } from './ui/tooltip';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  // Background with subtle pattern/gradient - optimized by caching
  const appBgStyle = React.useMemo(() => ({
    backgroundImage: `
      linear-gradient(to bottom right, rgba(17, 24, 39, 0.97), rgba(30, 27, 75, 0.97)),
      url("https://static.vecteezy.com/system/resources/previews/054/238/446/non_2x/abstract-dark-black-textured-background-with-subtle-wavy-lines-perfect-for-website-banners-presentations-or-design-projects-vector.jpg")
    `,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
  }), []);

  return (
    <TooltipProvider>
      <div className="flex h-screen text-white" style={appBgStyle}>
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <Header />

          {/* Main Content */}
          <div className="flex-1 overflow-y-auto px-6 py-4">
            {children}

            {/* Notification Prompt */}
            <NotificationPrompt />
          </div>
        </div>
      </div>
      <Toaster />
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
    </TooltipProvider>
  );
};

export default Layout;
