import type React from 'react';
import { motion } from 'framer-motion';
import { Check, Zap } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Button } from '../ui/button';
import { useToast } from '../../lib/useToast';

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const pricingTiers = [
  {
    name: 'Free',
    description: 'Basic features for students.',
    price: '$0',
    period: 'Forever',
    isPopular: false,
    buttonText: 'Current Plan',
    features: [
      'Create up to 5 study sets',
      'Basic flashcards',
      'Limited AI explanations',
      'Community access'
    ]
  },
  {
    name: 'Pro',
    description: 'Everything you need for serious studying.',
    price: '$8.99',
    period: 'Per month',
    isPopular: true,
    buttonText: 'Upgrade to Pro',
    features: [
      'Unlimited study sets',
      'Advanced flashcards',
      'Unlimited AI explanations',
      'Priority support',
      'Progress tracking',
      'PDF and document imports'
    ]
  },
  {
    name: 'Premium',
    description: 'For power users and teams.',
    price: '$14.99',
    period: 'Per month',
    isPopular: false,
    buttonText: 'Upgrade to Premium',
    features: [
      'Everything in Pro',
      'Team collaboration',
      'Advanced analytics',
      'API access',
      'Custom branding',
      'Dedicated support'
    ]
  }
];

export const UpgradeModal: React.FC<UpgradeModalProps> = ({ open, onOpenChange }) => {
  const { toast } = useToast();

  const handleUpgradeClick = (tierName: string) => {
    // This would normally redirect to a payment page or open a payment form
    toast({
      title: "Upgrade requested",
      description: `You selected the ${tierName} plan. This would redirect to payment in a real app.`,
      variant: "default",
      duration: 5000,
    });

    // Close modal after a short delay
    setTimeout(() => {
      onOpenChange(false);
    }, 1000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[900px]">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl text-white">Upgrade Your Study Experience</DialogTitle>
          <DialogDescription className="text-center text-gray-300">
            Choose the plan that fits your study needs and take your learning to the next level.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-6">
          {pricingTiers.map((tier) => (
            <motion.div
              key={tier.name}
              whileHover={{ scale: 1.02, y: -5 }}
              transition={{ duration: 0.2 }}
              className={`relative rounded-xl border p-6 shadow-sm flex flex-col ${
                tier.isPopular ? 'border-purple-500 bg-purple-900/20' : 'border-gray-700 bg-gray-800/50'
              }`}
            >
              {tier.isPopular && (
                <div className="absolute -top-3 left-0 right-0 flex justify-center">
                  <span className="bg-purple-500 text-white text-xs px-3 py-1 rounded-full font-medium flex items-center gap-1">
                    <Zap size={12} /> Most Popular
                  </span>
                </div>
              )}

              <div className="mb-5">
                <h3 className="text-lg font-semibold text-white">{tier.name}</h3>
                <p className="text-sm text-gray-400 mt-1">{tier.description}</p>
              </div>

              <div className="mb-5">
                <span className="text-3xl font-bold text-white">{tier.price}</span>
                <span className="text-gray-400 text-sm ml-1">{tier.period}</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm">
                    <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
                    <span className="text-gray-200">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={tier.name === 'Free' ? 'outline' : (tier.isPopular ? 'default' : 'outline')}
                className={tier.isPopular ? 'bg-purple-600 hover:bg-purple-700' : ''}
                onClick={() => handleUpgradeClick(tier.name)}
                disabled={tier.name === 'Free'}
              >
                {tier.buttonText}
              </Button>
            </motion.div>
          ))}
        </div>

        <DialogFooter className="text-sm text-gray-400 text-center justify-center border-t border-gray-700 pt-4">
          All plans include a 7-day free trial. No credit card required until the trial ends.
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
