import type React from 'react';
import { useState } from 'react';
import { AlertCircle, LogOut } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { useToast } from '../../lib/useToast';

interface SessionLogoutModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const SessionLogoutModal: React.FC<SessionLogoutModalProps> = ({
  open,
  onOpenChange,
}) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleLogout = () => {
    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      setLoading(false);

      toast({
        title: "Sessions terminated",
        description: "All other sessions have been logged out successfully",
        variant: "success",
        duration: 3000,
      });

      onOpenChange(false);
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl text-white flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-500" />
            Sign out of all other sessions
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            This will terminate all active sessions on other devices. You'll stay logged in on this device.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="border border-amber-500/20 rounded-lg p-4 bg-amber-500/10 text-sm text-gray-300">
            <p>All your sessions on other devices will be ended immediately. Anyone using those sessions will be logged out.</p>
            <p className="mt-2">You'll need to log in again on those devices.</p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            className="bg-amber-500 hover:bg-amber-600 text-white"
            onClick={handleLogout}
            disabled={loading}
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                Signing out...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <LogOut size={16} />
                Sign Out All Other Sessions
              </span>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
