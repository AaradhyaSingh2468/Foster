import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { useToast } from '../../lib/useToast';

interface FeedbackModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ open, onOpenChange }) => {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = () => {
    // Form validation
    if (!message.trim()) {
      toast({
        title: "Missing information",
        description: "Please enter a message",
        variant: "destructive",
      });
      return;
    }

    if (rating === 0) {
      toast({
        title: "Missing information",
        description: "Please provide a rating",
        variant: "destructive",
      });
      return;
    }

    // Simulate form submission
    setIsSubmitting(true);

    setTimeout(() => {
      // In a real app, this would call an API to submit feedback
      setIsSubmitting(false);

      toast({
        title: "Feedback submitted",
        description: "Thank you for your feedback! We'll review it soon.",
        variant: "success",
      });

      // Reset form and close modal
      setName('');
      setEmail('');
      setMessage('');
      setRating(0);
      onOpenChange(false);
    }, 1500);
  };

  const renderStars = () => {
    const stars = [];

    for (let i = 1; i <= 5; i++) {
      stars.push(
        <motion.div
          key={i}
          whileHover={{ scale: 1.2 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setRating(i)}
          onMouseEnter={() => setHoveredRating(i)}
          onMouseLeave={() => setHoveredRating(0)}
          className="cursor-pointer"
        >
          <Star
            className={`h-8 w-8 ${
              i <= (hoveredRating || rating)
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-400'
            }`}
          />
        </motion.div>
      );
    }

    return stars;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-white">Send Feedback</DialogTitle>
          <DialogDescription className="text-gray-300">
            Let us know what you think about Study Dashboard. Your feedback helps us improve!
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">Name (optional)</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-white">Email (optional)</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message" className="text-white required">Message</Label>
            <Textarea
              id="message"
              placeholder="Tell us what you think..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[100px] text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="rating" className="text-white required">Rating</Label>
            <div className="flex items-center space-x-2" id="rating">
              {renderStars()}
            </div>
            <p className="text-sm text-gray-400 mt-1">
              {rating > 0 ? `You rated ${rating} out of 5 stars` : 'Please select a rating'}
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
