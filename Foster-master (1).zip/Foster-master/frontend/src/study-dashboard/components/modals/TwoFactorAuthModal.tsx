import type React from 'react';
import { useState } from 'react';
import { Check, X, Copy, RefreshCw } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useToast } from '../../lib/useToast';

interface TwoFactorAuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const TwoFactorAuthModal: React.FC<TwoFactorAuthModalProps> = ({
  open,
  onOpenChange,
}) => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [verificationCode, setVerificationCode] = useState('');
  const [recoveryKey, setRecoveryKey] = useState('ABCD-1234-EFGH-5678-IJKL-9012');
  const [loading, setLoading] = useState(false);

  // Mock QR code URL - in a real app, this would come from the backend
  const qrCodeUrl = 'https://same-assets.com/AYfFbdI1YJEJGijBmR01-qrcode.png';

  const handleCopySecret = () => {
    // In a real app, this would copy the secret to the clipboard
    toast({
      title: "Secret copied",
      description: "Authentication secret has been copied to clipboard",
      variant: "success",
      duration: 3000,
    });
  };

  const handleCopyRecoveryKey = () => {
    // In a real app, this would copy the recovery key to the clipboard
    toast({
      title: "Recovery key copied",
      description: "Recovery key has been copied to clipboard",
      variant: "success",
      duration: 3000,
    });
  };

  const handleVerify = () => {
    if (verificationCode.length < 6) {
      toast({
        title: "Invalid code",
        description: "Please enter a valid 6-digit verification code",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setStep(3);
    }, 1500);
  };

  const handleFinish = () => {
    toast({
      title: "2FA enabled",
      description: "Two-factor authentication has been successfully enabled",
      variant: "success",
      duration: 3000,
    });

    // Reset the modal state for next time
    setStep(1);
    setVerificationCode('');
    onOpenChange(false);
  };

  const handleCancel = () => {
    // Reset the modal state
    setStep(1);
    setVerificationCode('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl text-white">
            {step === 1 && "Set Up Two-Factor Authentication"}
            {step === 2 && "Verify Authentication Code"}
            {step === 3 && "Setup Complete"}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            {step === 1 && "Scan the QR code with your authentication app or enter the code manually."}
            {step === 2 && "Enter the 6-digit code from your authentication app."}
            {step === 3 && "Save your recovery key in a safe place."}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex flex-col items-center">
                <div className="p-4 bg-white rounded-lg mb-4">
                  <img
                    src={qrCodeUrl}
                    alt="QR Code"
                    className="w-48 h-48 object-contain"
                  />
                </div>
                <p className="text-sm text-gray-400 text-center">
                  Scan this QR code with your authentication app (Google Authenticator, Authy, etc.)
                </p>
              </div>

              <div className="border border-gray-700 rounded-lg p-4 bg-gray-800/50">
                <Label htmlFor="secret-key" className="text-sm text-gray-300 mb-2 block">
                  Or enter this key manually
                </Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="secret-key"
                    value="GZTDMZSG4ZTDMBQGIZS2MJY"
                    readOnly
                    className="bg-gray-700/50 border-gray-600 text-white font-mono"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 border-gray-600 hover:bg-gray-700"
                    onClick={handleCopySecret}
                  >
                    <Copy size={16} />
                  </Button>
                </div>
              </div>

              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={() => setStep(2)}
              >
                Continue
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="verification-code" className="text-sm text-gray-300">
                  Verification Code
                </Label>
                <Input
                  id="verification-code"
                  placeholder="Enter 6-digit code"
                  value={verificationCode}
                  onChange={(e) => {
                    // Only allow numbers and limit to 6 digits
                    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                    setVerificationCode(value);
                  }}
                  className="bg-gray-700/50 border-gray-600 text-white text-center tracking-widest text-xl font-mono"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Enter the 6-digit code shown in your authentication app
                </p>
              </div>

              <div className="flex flex-col space-y-2">
                <Button
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={handleVerify}
                  disabled={loading}
                >
                  {loading ? 'Verifying...' : 'Verify'}
                </Button>
                <Button
                  variant="ghost"
                  className="w-full text-gray-400 hover:text-white hover:bg-gray-700"
                  onClick={handleCancel}
                  disabled={loading}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="rounded-full bg-green-500/20 w-16 h-16 mx-auto flex items-center justify-center">
                <Check className="h-8 w-8 text-green-500" />
              </div>

              <p className="text-white text-center">
                Two-factor authentication has been enabled successfully!
              </p>

              <div className="border border-yellow-500/30 rounded-lg p-4 bg-yellow-500/10">
                <h4 className="text-yellow-400 font-medium mb-2">Recovery Key</h4>
                <p className="text-sm text-gray-300 mb-4">
                  Save this recovery key somewhere safe. You'll need it if you lose access to your authentication device.
                </p>

                <div className="flex items-center gap-2">
                  <div className="bg-gray-800 p-3 rounded-lg flex-1 font-mono text-center text-yellow-300">
                    {recoveryKey}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-10 w-10 border-gray-600 hover:bg-gray-700"
                    onClick={handleCopyRecoveryKey}
                  >
                    <Copy size={16} />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {step === 3 && (
            <Button
              className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700"
              onClick={handleFinish}
            >
              Done
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
