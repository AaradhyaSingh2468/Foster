import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "../../components/ui/button";
import { X } from 'lucide-react';
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { createObjective } from '../../../services/objectiveService';
import { showSuccessToast, showErrorToast } from '../../../utils/toastUtils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';

interface ObjectiveFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onObjectiveCreated: () => void;
}

const OBJECTIVE_TYPES = [
  { value: 'custom', label: 'Custom Objective' },
  { value: 'video', label: 'Watch AI Video' },
  { value: 'flashcard', label: 'Review Flashcards' },
  { value: 'quiz', label: 'Complete Quiz' },
  { value: 'pdf', label: 'Read PDF' },
];

const ObjectiveFormModal: React.FC<ObjectiveFormModalProps> = ({ isOpen, onClose, onObjectiveCreated }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [objectiveType, setObjectiveType] = useState('custom');
  const [dueDate, setDueDate] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      showErrorToast('Required Field', 'Please enter a title for your objective');
      return;
    }
    
    setIsLoading(true);
    
    try {
      await createObjective({
        title,
        description,
        objectiveType,
        completed: false,
        dueDate: dueDate || new Date().toISOString().split('T')[0]
      });
      
      showSuccessToast('Objective Created', 'New learning objective has been added');
      onObjectiveCreated();
      onClose();
      
      // Reset form
      setTitle('');
      setDescription('');
      setObjectiveType('custom');
      setDueDate('');
    } catch (error) {
      console.error('Error creating objective:', error);
      showErrorToast('Error', 'Failed to create objective');
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.2 }}
        className="bg-gray-800 rounded-lg w-full max-w-md p-6 shadow-xl border border-gray-700"
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-2xl font-semibold text-white">Add Objective</h2>
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-white"
            onClick={onClose}
          >
            <X size={20} />
          </Button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-white">Title</Label>
            <Input
              id="title"
              placeholder="Enter objective title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description" className="text-white">Description (optional)</Label>
            <Textarea
              id="description"
              placeholder="Enter objective description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white min-h-[80px]"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="objective-type" className="text-white">Objective Type</Label>
            <Select value={objectiveType} onValueChange={setObjectiveType}>
              <SelectTrigger id="objective-type" className="bg-gray-700 border-gray-600 text-white">
                <SelectValue placeholder="Select objective type" />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                {OBJECTIVE_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value} className="text-white">
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="due-date" className="text-white">Due Date</Label>
            <Input
              id="due-date"
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {isLoading ? "Creating..." : "Create Objective"}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default ObjectiveFormModal; 