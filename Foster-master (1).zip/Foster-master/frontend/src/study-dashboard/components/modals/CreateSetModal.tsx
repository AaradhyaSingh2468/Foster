import type React from 'react';
import { useState } from 'react';
import { Plus, Trash2, Save } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import * as studyBuddyService from '../../../services/studyBuddyService';
import { showSuccessToast, showErrorToast, showInfoToast } from '../../../utils/toastUtils';

interface FlashcardItem {
  id: string;
  term: string;
  definition: string;
}

interface CreateSetModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateSetModal: React.FC<CreateSetModalProps> = ({ open, onOpenChange }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [cards, setCards] = useState<FlashcardItem[]>([
    { id: '1', term: '', definition: '' },
    { id: '2', term: '', definition: '' }
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAddCard = () => {
    const newId = Date.now().toString();
    setCards([...cards, { id: newId, term: '', definition: '' }]);
  };

  const handleRemoveCard = (id: string) => {
    if (cards.length <= 2) {
      showErrorToast("Cannot Remove Card", "You need at least 2 cards in a study set");
      return;
    }

    setCards(cards.filter(card => card.id !== id));
  };

  const handleCardChange = (id: string, field: 'term' | 'definition', value: string) => {
    setCards(cards.map(card =>
      card.id === id ? { ...card, [field]: value } : card
    ));
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      showErrorToast("Missing Information", "Please enter a title for your study set");
      return;
    }

    const emptyCards = cards.filter(card => !card.term.trim() || !card.definition.trim());
    if (emptyCards.length > 0) {
      showErrorToast("Incomplete Cards", "Please fill out all term and definition fields");
      return;
    }

    setIsSubmitting(true);
    showInfoToast("Creating Study Set", "Please wait while we save your study set...");

    try {
      // Save the study set
      await studyBuddyService.createStudySet({
        title,
        description,
        cards: cards.map((card, index) => ({
          question: card.term,
          answer: card.definition
        })),
        source: 'manual'
      });

      showSuccessToast("Study Set Created", `Your study set "${title}" with ${cards.length} cards has been created!`);

      // Reset form and close modal
      setTitle('');
      setDescription('');
      setCards([
        { id: '1', term: '', definition: '' },
        { id: '2', term: '', definition: '' }
      ]);
      onOpenChange(false);
    } catch (error) {
      console.error('Error creating study set:', error);
      showErrorToast("Creation Failed", "Failed to create study set. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Create a New Study Set</DialogTitle>
          <DialogDescription className="text-gray-300">
            Create your study set with terms and definitions. Add as many cards as you need.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-white">Title</Label>
            <Input
              id="title"
              placeholder="Enter a title for your study set"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-white">Description (optional)</Label>
            <Textarea
              id="description"
              placeholder="Add a description for your study set"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <Separator className="my-4" />

          <div className="space-y-4">
            {cards.map((card, index) => (
              <div key={card.id} className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-300">Card {index + 1}</span>
                  {cards.length > 2 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveCard(card.id)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 size={16} />
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`term-${card.id}`} className="text-white">Term</Label>
                    <Input
                      id={`term-${card.id}`}
                      value={card.term}
                      onChange={(e) => handleCardChange(card.id, 'term', e.target.value)}
                      placeholder="Enter term"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`definition-${card.id}`} className="text-white">Definition</Label>
                    <Input
                      id={`definition-${card.id}`}
                      value={card.definition}
                      onChange={(e) => handleCardChange(card.id, 'definition', e.target.value)}
                      placeholder="Enter definition"
                    />
                  </div>
                </div>
              </div>
            ))}

            <Button
              type="button"
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={handleAddCard}
            >
              <Plus size={16} className="mr-2" />
              Add Card
            </Button>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="gap-2"
          >
            {isSubmitting ? (
              'Creating...'
            ) : (
              <>
                <Save size={16} /> Create Study Set
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
