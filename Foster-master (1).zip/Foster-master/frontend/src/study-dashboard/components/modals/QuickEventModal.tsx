import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '../../components/ui/dialog';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { createQuickEvent } from '../../../services/quickEventService';
import { showSuccessToast, showErrorToast } from '../../../utils/toastUtils';

interface QuickEventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEventCreated: () => void;
}

export function QuickEventModal({ isOpen, onClose, onEventCreated }: QuickEventModalProps) {
  const [title, setTitle] = useState('Study Session');
  const [date, setDate] = useState(format(getTomorrow(), 'yyyy-MM-dd'));
  const [time, setTime] = useState('10:00');
  const [duration, setDuration] = useState(60);
  const [loading, setLoading] = useState(false);

  // Helper to get tomorrow's date
  function getTomorrow() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      showErrorToast('Missing Information', 'Please provide a title for the event');
      return;
    }

    try {
      setLoading(true);
      
      // Parse date and time into a Date object
      const [year, month, day] = date.split('-').map(Number);
      const [hours, minutes] = time.split(':').map(Number);
      
      // Create a date object with the correct values based on local time
      const localEventDate = new Date();
      localEventDate.setFullYear(year);
      localEventDate.setMonth(month - 1); // JavaScript months are 0-based
      localEventDate.setDate(day);
      localEventDate.setHours(hours);
      localEventDate.setMinutes(minutes);
      localEventDate.setSeconds(0);
      localEventDate.setMilliseconds(0);

      // The local date is automatically converted to UTC when using toISOString
      const utcIsoString = localEventDate.toISOString();
      
      // Log for debugging
      console.log('Creating event:');
      console.log('- Input date/time:', `${date} ${time}`);
      console.log('- Local date object:', localEventDate.toString());
      console.log('- Local timezone offset:', localEventDate.getTimezoneOffset() / -60, 'hours');
      console.log('- UTC ISO string to be sent:', utcIsoString);
      
      // Create the event - sending the ISO string which is in UTC
      await createQuickEvent(title, localEventDate, duration);
      showSuccessToast('Event Created', 'Your study session has been scheduled');
      
      // Clear form and close modal
      setTitle('');
      onEventCreated();
      onClose();
    } catch (error) {
      console.error('Error creating event:', error);
      showErrorToast('Error', 'Failed to create the study session');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={isOpen => !isOpen && onClose()}>
      <DialogContent className="bg-gray-800 text-white border border-gray-700 sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-purple-400" />
            Schedule Study Session
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Create a new event for your study schedule
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="What are you studying?"
              className="bg-gray-700 border-gray-600 focus:border-purple-500"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="bg-gray-700 border-gray-600 focus:border-purple-500"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="bg-gray-700 border-gray-600 focus:border-purple-500"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="duration">Duration (minutes)</Label>
            <Input
              id="duration"
              type="number"
              min={15}
              max={480}
              step={15}
              value={duration}
              onChange={e => setDuration(Number(e.target.value))}
              className="bg-gray-700 border-gray-600 focus:border-purple-500"
            />
          </div>
          
          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-gray-600 text-white hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-purple-600 hover:bg-purple-700 text-white"
              disabled={loading}
            >
              {loading ? 'Scheduling...' : 'Schedule Event'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
} 