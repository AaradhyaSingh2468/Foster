import type React from 'react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, Mail, Link as LinkIcon } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Switch } from '../ui/switch';
import { useToast } from '../../lib/useToast';
import { Label } from '../ui/label';

interface ShareModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ open, onOpenChange }) => {
  const { toast } = useToast();
  const [shareUrl] = useState('https://study-dashboard.app/share/abc123');
  const [copied, setCopied] = useState(false);
  const [email, setEmail] = useState('');
  const [permissions, setPermissions] = useState('view-only');
  const [allowComments, setAllowComments] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);

    toast({
      title: "Link copied",
      description: "The share link has been copied to your clipboard",
      variant: "success",
      duration: 3000,
    });

    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  const handleSendEmail = () => {
    // In a real app, this would send the email via an API
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    toast({
      title: "Email sent",
      description: `Share link has been sent to ${email}`,
      variant: "success",
      duration: 3000,
    });

    setEmail('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-white">Share this study set</DialogTitle>
          <DialogDescription className="text-gray-300">
            Share this study set with others or get a link to share.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          <div className="space-y-2">
            <Label htmlFor="share-link" className="text-white">Share link</Label>
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <LinkIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                <Input
                  id="share-link"
                  value={shareUrl}
                  readOnly
                  className="pl-10 text-white"
                />
              </div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleCopyLink}
                  className="h-9 w-9"
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </motion.div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="share-email" className="text-white">Send via email</Label>
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                <Input
                  id="share-email"
                  placeholder="Enter email address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 text-white"
                />
              </div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant="default"
                  onClick={handleSendEmail}
                  disabled={!email}
                >
                  Send
                </Button>
              </motion.div>
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="permissions" className="text-white">Permissions</Label>
            <RadioGroup
              defaultValue="view-only"
              value={permissions}
              onValueChange={setPermissions}
              id="permissions"
              className="flex flex-col space-y-3"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="view-only" id="view-only" />
                <Label htmlFor="view-only" className="text-gray-200">View only</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="can-edit" id="can-edit" />
                <Label htmlFor="can-edit" className="text-gray-200">Can edit</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="allow-comments"
              checked={allowComments}
              onCheckedChange={setAllowComments}
            />
            <Label htmlFor="allow-comments" className="text-gray-200">Allow comments</Label>
          </div>
        </div>

        <DialogFooter className="sm:justify-end">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
