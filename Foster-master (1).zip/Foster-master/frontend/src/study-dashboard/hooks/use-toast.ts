// Re-export the useToast hook from the lib directory
import { useToast as useToastFromLib, toast, clearAllToasts } from '../lib/useToast';

export { toast, clearAllToasts };

export const useToast = useToastFromLib;

export default useToast; 