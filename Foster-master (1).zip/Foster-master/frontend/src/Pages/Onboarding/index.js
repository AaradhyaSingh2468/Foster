import React, { useState, useEffect } from 'react';
import { useLocation, Navigate } from 'react-router-dom';
import { OnboardingProvider, useOnboarding } from '../../context/onboarding/OnboardingContext';
import RoleStep from '../../components/onboarding/steps/RoleStep';
import DomainStep from '../../components/onboarding/steps/DomainStep';
import InterestsStep from '../../components/onboarding/steps/InterestsStep';
import LearningStyleStep from '../../components/onboarding/steps/LearningStyleStep';
import GoalStep from '../../components/onboarding/steps/GoalStep';
import OnboardingComplete from '../../components/onboarding/steps/OnboardingComplete';
import { useAuth } from '../../context/AuthContext';
import styled, { keyframes, css } from 'styled-components';

// Animation keyframes
const fadeIn = keyframes`
  0% { opacity: 0; transform: translateX(20px); }
  100% { opacity: 1; transform: translateX(0); }
`;

const fadeOut = keyframes`
  0% { opacity: 1; transform: translateX(0); }
  100% { opacity: 0; transform: translateX(-20px); }
`;

const StepContainer = styled.div`
  width: 100%;
  position: relative;
  animation: ${props => props.isEntering 
    ? css`${fadeIn} 0.3s ease-out forwards`
    : props.isExiting 
      ? css`${fadeOut} 0.3s ease-out forwards`
      : 'none'};
  opacity: ${props => (props.isActive && !props.isEntering && !props.isExiting) ? 1 : 0};
`;

// This component will render the appropriate step based on the current step in the context
const OnboardingContent = () => {
  const { currentStep, direction } = useOnboarding();
  const { currentUser } = useAuth();
  const { state } = useLocation();
  
  const [currentStepState, setCurrentStepState] = useState(currentStep);
  const [previousStep, setPreviousStep] = useState(null);
  const [transitionStage, setTransitionStage] = useState('done'); // 'entering', 'exiting', 'done'

  // Handle step transitions
  useEffect(() => {
    if (currentStep !== currentStepState) {
      // Start exit animation for current step
      setTransitionStage('exiting');
      setPreviousStep(currentStepState);
      
      // Wait for exit animation to complete then change step
      const exitTimer = setTimeout(() => {
        setCurrentStepState(currentStep);
        setTransitionStage('entering');
        
        // Start enter animation for new step
        const enterTimer = setTimeout(() => {
          setTransitionStage('done');
        }, 300); // match the animation duration
        
        return () => clearTimeout(enterTimer);
      }, 300); // match the animation duration
      
      return () => clearTimeout(exitTimer);
    }
  }, [currentStep, currentStepState]);

  // Check if the user is authenticated
  if (!currentUser) {
    return <Navigate to="/auth" replace />;
  }

  // Verify that the user came from authentication 
  // This is optional and can be modified depending on your desired flow
  const isFromAuth = state?.isFromAuth;
  if (!isFromAuth && currentStep === 1) {
    // If this check isn't needed, you can remove this condition
    console.warn('User accessed onboarding directly without coming from auth');
    // You might still allow the user to continue, depending on your requirements
  }

  // Function to render the current step with transitions
  const renderCurrentStep = () => {
    let stepComponent;
    
    switch (currentStepState) {
      case 1:
        stepComponent = <RoleStep />;
        break;
      case 2:
        stepComponent = <DomainStep />;
        break;
      case 3:
        stepComponent = <InterestsStep />;
        break;
      case 4:
        stepComponent = <LearningStyleStep />;
        break;
      case 5:
        stepComponent = <GoalStep />;
        break;
      case 6:
        stepComponent = <OnboardingComplete />;
        break;
      default:
        stepComponent = <RoleStep />;
    }

    return (
      <StepContainer 
        isActive={true}
        isEntering={transitionStage === 'entering'}
        isExiting={transitionStage === 'exiting'}
      >
        {stepComponent}
      </StepContainer>
    );
  };

  return renderCurrentStep();
};

// This is the main component that wraps the content with the provider
const Onboarding = () => {
  return (
    <OnboardingProvider>
      <OnboardingContent />
    </OnboardingProvider>
  );
};

export default Onboarding; 