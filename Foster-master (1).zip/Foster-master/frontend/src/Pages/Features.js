import React, { useState, useEffect, useRef } from "react";
import styled, { keyframes, css } from "styled-components";
import FeatureAIStudy from "../components/features/FeatureAIStudy";
import FeatureVideoGen from "../components/features/FeatureVideoGen";
import FeatureExamGen from "../components/features/FeatureExamGen";
import FeatureFlashcards from "../components/features/FeatureFlashcards";
import FeatureMentorSession from "../components/features/FeatureMentorSession";
import FeatureInsights from "../components/features/FeatureInsights";
import { createGlobalStyle } from "styled-components";
import { Link } from "react-router-dom";

// Animations
const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const float = keyframes`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
`;

const floatHorizontal = keyframes`
  0% { transform: translate(0, 0); }
  50% { transform: translate(15px, -15px); }
  100% { transform: translate(0, 0); }
`;

const floatDelayed = keyframes`
  0% { transform: translate(0, 0); }
  50% { transform: translate(-10px, 10px); }
  100% { transform: translate(0, 0); }
`;

const pulseGlow = keyframes`
  0% { box-shadow: 0 0 0 0 rgba(124, 58, 237, 0.4); }
  70% { box-shadow: 0 0 0 10px rgba(124, 58, 237, 0); }
  100% { box-shadow: 0 0 0 0 rgba(124, 58, 237, 0); }
`;

const shimmer = keyframes`
  0% { background-position: -500px 0; }
  100% { background-position: 500px 0; }
`;

// Additional animations for springy effects
const springIn = keyframes`
  0% { transform: scale(0.9); opacity: 0; }
  70% { transform: scale(1.05); opacity: 1; }
  100% { transform: scale(1); opacity: 1; }
`;

const fadeInUp = keyframes`
  0% { opacity: 0; transform: translateY(20px); }
  100% { opacity: 1; transform: translateY(0); }
`;

// Styled Components
const PageContainer = styled.div`
  min-height: 100vh;
  background-color: #0a0b10;
  color: var(--white);
  overflow-x: hidden;
  position: relative;
  padding-top: 3rem; /* Add padding for navbar */
`;

const MainContent = styled.main`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem 2rem 8rem;
  position: relative;
  z-index: 2;
`;

const BackgroundElements = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
  overflow: hidden;
`;

const BackgroundBlob = styled.div`
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  width: ${props => props.width};
  height: ${props => props.height};
  background-color: ${props => props.color};
  top: ${props => props.top};
  left: ${props => props.left};
  right: ${props => props.right};
  bottom: ${props => props.bottom};
  transform: ${props => props.transform};
  animation: ${float} 3s ease-in-out infinite;
  animation-delay: ${props => props.delay || "0s"};
  opacity: ${props => props.opacity || 0.5};
`;

const HeaderContainer = styled.div`
  text-align: center;
  margin-bottom: 4rem;
  padding-top: 2rem;
  animation: ${fadeIn} 0.6s ease-out;
`;

const BadgeContainer = styled.div`
  display: inline-block;
  margin-bottom: 1rem;
  transform: scale(0.9);
  opacity: 0;
  animation: ${springIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
`;

const Badge = styled.div`
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background: linear-gradient(to right, rgba(124, 58, 237, 0.4), rgba(99, 102, 241, 0.4));
  backdrop-filter: blur(4px);
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  animation: ${pulseGlow} 3s infinite;
  box-shadow: 0 0 15px rgba(124, 58, 237, 0.3);
`;

const BadgeCircle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: var(--purple);
  border-radius: 50%;
`;

const BadgeText = styled.span`
  font-weight: 500;
`;

const PageTitle = styled.h1`
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
  background: linear-gradient(to right, #fff, #a78bfa);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  opacity: 0;
  transform: translateY(20px);
  animation: ${fadeInUp} 0.5s ease-out forwards;
  animation-delay: 0.3s;

  @media (min-width: 768px) {
    font-size: 3.5rem;
  }
`;

const PageDescription = styled.p`
  font-size: 1.25rem;
  color: #d1d5db;
  max-width: 48rem;
  margin: 0 auto;
  opacity: 0;
  transform: translateY(20px);
  animation: ${fadeInUp} 0.5s ease-out forwards;
  animation-delay: 0.4s;
`;

const TabContainer = styled.div`
  margin-bottom: 3rem;
  position: sticky;
  top: 0;
  padding: 1rem 0;
  z-index: 20;
  background-color: rgba(15, 13, 30, 0.8);
  backdrop-filter: blur(12px);
  animation: ${fadeIn} 0.5s ease-out;
  animation-delay: 0.5s;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
`;

const TabScroller = styled.div`
  overflow-x: auto;
  padding-bottom: 1rem;
  -ms-overflow-style: none;
  scrollbar-width: none;

  &::-webkit-scrollbar {
    display: none;
  }
`;

const TabList = styled.div`
  display: flex;
  gap: 0.5rem;
  min-width: max-content;
  justify-content: center;
  padding: 0 0.5rem;

  @media (min-width: 768px) {
    gap: 1rem;
  }
`;

const TabButton = styled.button`
  padding: 0.75rem 1rem;
  border-radius: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.2s ease;
  font-weight: 500;
  font-size: 0.875rem;
  letter-spacing: 0;
  background: ${props => props.active 
    ? 'linear-gradient(to right, #7c3aed, #6d28d9)'
    : 'rgba(255, 255, 255, 0.05)'
  };
  color: ${props => props.active ? 'var(--white)' : '#9ca3af'};
  border: none;
  cursor: pointer;
  box-shadow: ${props => props.active 
    ? '0 0 15px rgba(139, 92, 246, 0.4)' 
    : 'none'
  };
  
  @media (min-width: 768px) {
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
  }
  
  &:hover {
    background: ${props => props.active 
      ? 'linear-gradient(to right, #8b5cf6, #7c3aed)'
      : 'rgba(255, 255, 255, 0.1)'
    };
    transform: ${props => props.active ? 'scale(1.05)' : 'scale(1.02)'};
  }
  
  &:active {
    transform: scale(0.95);
  }

  svg {
    width: 20px;
    height: 20px;
    stroke-width: 2px;
  }
`;

const ContentContainer = styled.div`
  margin-top: 2rem;
  position: relative;
`;

const TabContent = styled.div`
  animation: ${fadeInUp} 0.6s cubic-bezier(0.22, 1, 0.36, 1);
  width: 100%;
  position: relative;
  overflow: hidden;
  min-height: 600px;
  transition: all 0.3s cubic-bezier(0.22, 1, 0.36, 1);
  opacity: 1;
`;

const CTASection = styled.div`
  margin-top: 6rem;
  text-align: center;
  opacity: 0;
  transform: translateY(30px);
  animation: ${fadeInUp} 0.7s ease-out forwards;
  animation-delay: 0.8s;
`;

const CTATitle = styled.h2`
  font-size: 1.875rem;
  font-weight: bold;
  margin-bottom: 1rem;
  
  @media (min-width: 768px) {
    font-size: 2.25rem;
  }
`;

const CTADescription = styled.p`
  color: #d1d5db;
  margin-bottom: 2rem;
  max-width: 36rem;
  margin-left: auto;
  margin-right: auto;
`;

const CTAButton = styled(Link)`
  padding: 1rem 2rem;
  border-radius: 0.75rem;
  background: linear-gradient(to right, #7c3aed, #6d28d9);
  color: white;
  font-weight: 600;
  font-size: 1rem;
  border: none;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    transform: scale(1.05);
    background: linear-gradient(to right, #8b5cf6, #7c3aed);
    box-shadow: 0 0 25px rgba(139, 92, 246, 0.6);
  }
  
  &:active {
    transform: scale(0.95);
  }
`;

// Add a CSS class in the stylesheet section
const GlobalStyle = createGlobalStyle`
  :root {
    --white: #ffffff;
    --purple: #7c3aed;
  }
  
  .purple-glow {
    box-shadow: 0 0 15px rgba(124, 58, 237, 0.5);
  }
`;

// Tab icon components with better styling
const TabIcon = ({ name }) => {
  switch (name) {
    case "brain":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"></path>
          <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"></path>
        </svg>
      );
    case "video":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m22 8-6 4 6 4V8Z"></path>
          <rect width="14" height="12" x="2" y="6" rx="2" ry="2"></rect>
        </svg>
      );
    case "file-text":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" x2="8" y1="13" y2="13"></line>
          <line x1="16" x2="8" y1="17" y2="17"></line>
          <line x1="10" x2="8" y1="9" y2="9"></line>
        </svg>
      );
    case "book":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
          <path d="m9 10 2-2 2 2"></path>
          <path d="M9 14h4"></path>
        </svg>
      );
    case "users":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
          <circle cx="9" cy="7" r="4"></circle>
          <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
          <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
        </svg>
      );
    case "lightbulb":
      return (
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"></path>
          <path d="M9 18h6"></path>
          <path d="M10 22h4"></path>
        </svg>
      );
    default:
      return null;
  }
};

const Features = () => {
  const [activeTab, setActiveTab] = useState("ai-study");
  const [isVisible, setIsVisible] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const contentRef = useRef(null);
  
  const tabs = [
    { id: "ai-study", label: "AI Study", icon: "brain" },
    { id: "video-gen", label: "Video Generation", icon: "video" },
    { id: "exam-gen", label: "Exam Generation", icon: "file-text" },
    { id: "flashcards", label: "Flashcards", icon: "book" },
    { id: "mentor", label: "Meet Mentors", icon: "users" },
    { id: "insights", label: "Insights", icon: "lightbulb" },
  ];

  useEffect(() => {
    setIsVisible(true);
    
    const handleScroll = () => {
      if (window) {
        setScrollPosition(window.scrollY);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    
    // Smooth scroll to content when tab changes on mobile
    if (contentRef.current && window.innerWidth < 768) {
      contentRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const backgroundOpacity = Math.min(0.6, Math.max(0.3, scrollPosition / 1000));

  const renderTabContent = () => {
    switch (activeTab) {
      case "ai-study":
        return <FeatureAIStudy />;
      case "video-gen":
        return <FeatureVideoGen />;
      case "exam-gen":
        return <FeatureExamGen />;
      case "flashcards":
        return <FeatureFlashcards />;
      case "mentor":
        return <FeatureMentorSession />;
      case "insights":
        return <FeatureInsights />;
      default:
        return <FeatureAIStudy />;
    }
  };

  return (
    <PageContainer>
      <GlobalStyle />
      {/* Background Elements with higher opacity and less blur */}
      <BackgroundElements>
        <BackgroundBlob 
          color="#7c3aed" 
          width="1000px" 
          height="1000px" 
          top="0" 
          right="0" 
          transform="translate(25%, -25%)" 
          opacity="0.4"
        />
        <BackgroundBlob 
          color="#8b5cf6" 
          width="800px" 
          height="800px" 
          bottom="0" 
          left="0" 
          transform="translate(-33%, 25%)" 
          delay="-1.5s" 
          opacity="0.35"
        />
        <BackgroundBlob 
          color="#6366f1" 
          width="600px" 
          height="600px" 
          top="50%" 
          left="25%" 
          transform="translate(0, -50%)" 
          delay="-1s" 
          opacity={0.3 + backgroundOpacity}
        />
      </BackgroundElements>
      
      <MainContent>
        <HeaderContainer>
          <BadgeContainer>
            <Badge>
              <BadgeCircle />
              <BadgeText>Discover Foster's Features</BadgeText>
            </Badge>
          </BadgeContainer>
          <PageTitle>Powerful Learning Features</PageTitle>
          <PageDescription>
            Discover how Foster's AI-powered features can transform your learning experience
          </PageDescription>
        </HeaderContainer>

        <TabContainer>
          <TabScroller>
            <TabList>
              {tabs.map((tab) => (
                <TabButton
                  key={tab.id}
                  active={activeTab === tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={activeTab === tab.id ? "purple-glow" : ""}
                >
                  <TabIcon name={tab.icon} />
                  <span>{tab.label}</span>
                </TabButton>
              ))}
            </TabList>
          </TabScroller>
        </TabContainer>

        <ContentContainer ref={contentRef}>
          {isVisible && (
            <TabContent key={activeTab}>
              {renderTabContent()}
            </TabContent>
          )}
        </ContentContainer>
        
        <CTASection>
          <CTATitle>Ready to Transform Your Learning?</CTATitle>
          <CTADescription>
            Join thousands of students who are already using Foster to achieve their academic goals faster.
          </CTADescription>
          <CTAButton to="/auth">
            Get Started for Free
          </CTAButton>
        </CTASection>
      </MainContent>
    </PageContainer>
  );
};

export default Features; 