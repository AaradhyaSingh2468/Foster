import React from 'react';
import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const DashboardContainer = styled.div`
  min-height: 100vh;
  background-color: #0a0b10;
  color: white;
  padding: 5rem 2rem 2rem;
`;

const Content = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  background-color: rgba(30, 30, 40, 0.7);
  border-radius: 20px;
  backdrop-filter: blur(10px);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding-bottom: 1rem;
`;

const Title = styled.h1`
  font-size: 1.8rem;
  color: var(--pink);
`;

const UserInfo = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-end;
`;

const UserEmail = styled.p`
  font-size: 1rem;
  color: var(--white);
  margin-bottom: 0.5rem;
`;

const LogoutButton = styled.button`
  background-color: transparent;
  border: 1px solid var(--purple);
  color: var(--purple);
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: all 0.2s;
  
  &:hover {
    background-color: var(--purple);
    color: white;
  }
`;

const WelcomeMessage = styled.p`
  font-size: 1.2rem;
  margin-bottom: 2rem;
  color: rgba(255, 255, 255, 0.8);
`;

const Dashboard = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };

  return (
    <DashboardContainer>
      <Content>
        <Header>
          <Title>Dashboard</Title>
          <UserInfo>
            <UserEmail>{currentUser?.email}</UserEmail>
            <LogoutButton onClick={handleLogout}>Logout</LogoutButton>
          </UserInfo>
        </Header>
        
        <WelcomeMessage>
          Welcome to your Foster dashboard! This is a protected page that only authenticated users can access.
        </WelcomeMessage>
        
        <p>
          You can customize this dashboard with your own content. Some ideas:
        </p>
        <ul>
          <li>User profile information</li>
          <li>Your courses and learning progress</li>
          <li>Recommended content</li>
          <li>Notifications and messages</li>
        </ul>
      </Content>
    </DashboardContainer>
  );
};

export default Dashboard; 