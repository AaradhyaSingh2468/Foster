//This is home page, It will contains all the sections require in this page.

//Import all the require sections here
import HeroSection from "../Sections/Hero/index";
import About from "../Sections/About/index";
import Services from "../Sections/Services/index";
import Testimonials from "../Sections/Testimonials/index";
import Contact from "../Sections/Contact/index";
import styled from "styled-components";
import { useEffect } from "react";
import { useToast, clearAllToasts } from "../study-dashboard/lib/useToast";
import { useLocation } from "react-router-dom";
// Import our standalone toast function
import { showLogoutToast } from "../hooks/useGlobalToast";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* position: relative; */
`;

const Home = () => {
  const { toast } = useToast();
  const location = useLocation();
  
  // Check for logout indicators when component mounts
  useEffect(() => {
    // Multiple approaches to detect logout
    const showLogoutMessage = localStorage.getItem('show_logout_message');
    const justLoggedOut = sessionStorage.getItem('just_logged_out');
    const fromLogout = sessionStorage.getItem('from_logout');
    const locationState = location.state;
    const logoutFromState = locationState && locationState.justLoggedOut;
    const logoutTimestamp = localStorage.getItem('logout_timestamp');
    
    const isRecentLogout = logoutTimestamp && 
      (Date.now() - parseInt(logoutTimestamp, 10) < 30000); // Within 30 seconds
    
    const shouldShowToast = showLogoutMessage || 
                           justLoggedOut || 
                           logoutFromState || 
                           isRecentLogout || 
                           fromLogout;
    
    if (shouldShowToast) {
      console.log("Home component detected logout, showing toast");
      
      // Clear the flags to prevent showing the toast again
      localStorage.removeItem('show_logout_message');
      sessionStorage.removeItem('just_logged_out');
      sessionStorage.removeItem('from_logout');
      
      // Check if toast was already shown
      const toastShown = localStorage.getItem('logout_toast_shown') === 'true';
      if (toastShown) {
        console.log("Home: Skipping toast - already shown");
        return;
      }
      
      // Try showing toast with our standalone function first
      try {
        console.log("Home: Using standalone showLogoutToast");
        showLogoutToast();
        return;
      } catch (err) {
        console.error("Error with standalone toast, trying fallbacks:", err);
      }
      
      // Try direct global toast access
      if (window.globalToast?.show) {
        try {
          console.log("Home: Using global toast system");
          window.globalToast.show({
            title: "Logged out successfully",
            message: "You have been securely logged out of your account",
            type: "success",
            duration: 5000
          });
          return;
        } catch (err) {
          console.error("Error using global toast system:", err);
        }
      }
      
      // Clear any existing toasts first
      clearAllToasts();
      
      // Fallback to regular toast
      toast({
        title: "Logged out successfully",
        description: "You have been securely logged out of your account",
        variant: "success",
        duration: 5000,
      });
    }
  }, [toast, location]);
  
  return (
    <Container>
      <HeroSection />
      <About />
      <Services />
      <Testimonials />
      <Contact />
    </Container>
  );
};

export default Home;
