import React, { useEffect, useState } from "react";
import styled, { keyframes } from "styled-components";
import AuthCard from "../components/AuthCard";
import AuthHeader from "../components/AuthHeader";
import { useLocation } from "react-router-dom";

const wave = keyframes`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
`;

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
`;

const AuthPage = styled.div`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0a0b10;
  overflow: hidden;
  position: relative;
  padding-top: 0;
`;

const MainContent = styled.div`
  padding-top: 3rem;
  flex: 1;
  display: flex;
  flex-direction: column;
`;

const WaveBg = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 40%;
  background: linear-gradient(to top, rgba(155, 70, 255, 0.2) 0%, rgba(155, 70, 255, 0) 100%);
  border-top-left-radius: 50%;
  border-top-right-radius: 50%;
  transform: scaleX(1.5);
  animation: ${wave} 2s infinite ease-in-out;
`;

const Container = styled.div`
  flex-grow: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  position: relative;
  z-index: 1;
`;

const CardWrapper = styled.div`
  width: 100%;
  max-width: 500px;
  transition: all 0.5s;
  opacity: ${props => props.showAnimation ? '1' : '0'};
  transform: translateY(${props => props.showAnimation ? '0' : '8px'});
`;

const PulsingDots = styled.div`
  position: absolute;
  bottom: 10px;
  left: 10px;
  display: flex;
  gap: 8px;
  
  @media (max-width: 768px) {
    display: none;
  }
`;

const Dot = styled.div`
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background-color: var(--purple);
  opacity: ${props => props.opacity || 1};
  animation: ${pulse} 2s infinite ease-in-out;
  animation-delay: ${props => props.delay || '0s'};
`;

const Copyright = styled.div`
  position: absolute;
  bottom: 10px;
  right: 10px;
  color: rgba(255, 255, 255, 0.4);
  font-size: 0.8rem;
  
  @media (max-width: 768px) {
    display: none;
  }
`;

const Auth = () => {
  const [showAnimation, setShowAnimation] = useState(false);
  const location = useLocation();

  // Check if user came from the "Get Started" button
  const initialMode = location.state?.mode || "signin";

  useEffect(() => {
    setShowAnimation(true);
  }, []);

  return (
    <AuthPage>
      <AuthHeader />
      <MainContent>
        <WaveBg />
        <Container>
          <CardWrapper showAnimation={showAnimation}>
            <AuthCard initialMode={initialMode} />
          </CardWrapper>
        </Container>
        
        <PulsingDots>
          <Dot opacity={1} />
          <Dot opacity={0.7} delay="0.2s" />
          <Dot opacity={0.4} delay="0.4s" />
        </PulsingDots>
        
        <Copyright>
          © {new Date().getFullYear()} Foster. All rights reserved.
        </Copyright>
      </MainContent>
    </AuthPage>
  );
};

export default Auth; 