import React, { useEffect, useState } from "react";
import styled, { keyframes } from "styled-components";
import { Toaster } from "../components/ui/toaster";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { Routes, Route } from "react-router-dom";

// Import blog components from blog-clone-main (will need to be copied over)
const BlogIndex = React.lazy(() => import("../blog-components/Index"));
const BlogPost = React.lazy(() => import("../blog-components/BlogPost"));
const NotFound = React.lazy(() => import("../blog-components/NotFound"));

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const BlogPage = styled.div`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #0a0b10;
  overflow: hidden;
  position: relative;
  padding-top: 3rem;
  animation: ${fadeIn} 0.5s ease-in-out;
  
  /* Main background styling */
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at top right, rgba(155, 70, 255, 0.1) 0%, rgba(0, 0, 0, 0) 70%),
                radial-gradient(circle at bottom left, rgba(255, 83, 182, 0.05) 0%, rgba(0, 0, 0, 0) 70%);
    z-index: 0;
  }
`;

const MainContent = styled.div`
  padding-top: 2rem;
  flex: 1;
  display: flex;
  flex-direction: column;
`;

const Container = styled.div`
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 1;
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;
  padding: 2rem;
`;

// Loading animation
const pulse = keyframes`
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.7; }
`;

const LoadingContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 75vh;
  width: 100%;
`;

const LoadingDot = styled.div`
  width: 1rem;
  height: 1rem;
  background: var(--purple);
  border-radius: 50%;
  margin: 0 0.5rem;
  animation: ${pulse} 1.5s ease-in-out infinite;
  animation-delay: ${(props) => props.delay || "0s"};
`;

const LoadingIndicator = () => (
  <LoadingContainer>
    <LoadingDot delay="0s" />
    <LoadingDot delay="0.2s" />
    <LoadingDot delay="0.4s" />
  </LoadingContainer>
);

const queryClient = new QueryClient();

const Blog = () => {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // This simulates the initial loading of the blog content
    setTimeout(() => {
      setLoaded(true);
    }, 300);
    
    // Set document title
    document.title = "Foster | Blog";
  }, []);

  return (
    <BlogPage>
      <MainContent>
        <QueryClientProvider client={queryClient}>
          <React.Suspense fallback={<LoadingIndicator />}>
            <Container>
              <Toaster />
              <Routes>
                <Route path="/" element={<BlogIndex />} />
                <Route path="/:id" element={<BlogPost />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Container>
          </React.Suspense>
        </QueryClientProvider>
      </MainContent>
    </BlogPage>
  );
};

export default Blog; 