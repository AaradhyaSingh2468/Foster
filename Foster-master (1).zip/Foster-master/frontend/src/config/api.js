import axios from 'axios';
import { auth } from './firebase';

// Create axios instance with default config
const api = axios.create({
  baseURL: 'http://localhost:8000/api',  // Set the base URL for the backend API
  headers: {
    'Content-Type': 'application/json',
  },
  // Enable sending cookies in cross-domain requests
  withCredentials: true,
  // Add a reasonable timeout to prevent hanging requests
  timeout: 60000, // 60 seconds - increased from 15 seconds to handle LLM processing
});

// Track in-flight requests to prevent duplicates
const pendingRequests = new Map();

// Generate a request identifier
const getRequestId = (config) => {
  // For flashcard endpoints, use a special ID to ensure uniqueness
  if (config.url && config.url.includes('/flashcards/')) {
    return `flashcards-${config.url}`;
  }
  
  return `${config.method}:${config.url}:${JSON.stringify(config.params || {})}`;
};

// Request interceptor for adding Firebase auth token
api.interceptors.request.use(
  async (config) => {
    try {
      // Check for duplicate requests
      const requestId = getRequestId(config);
      
      // Skip duplicate detection for specific endpoints that are called frequently
      const skipDuplicateCheck = config.skipDuplicateCheck === true;
      
      if (!skipDuplicateCheck && pendingRequests.has(requestId)) {
        console.log(`Duplicate request detected: ${requestId}. Cancelling.`);
        return Promise.reject({ 
          canceled: true, 
          message: `Duplicate request: ${requestId}` 
        });
      }
      
      // Add this request to pending
      if (!skipDuplicateCheck) {
        pendingRequests.set(requestId, true);
        
        // Add an onComplete function to the config to remove from pending
        const originalComplete = config.onComplete || (() => {});
        config.onComplete = () => {
          pendingRequests.delete(requestId);
          originalComplete();
        };
      }
      
      // Log the request URL and method for debugging
      console.log(`API Request: ${config.method.toUpperCase()} ${config.baseURL}${config.url}`);
      console.log(`Full URL: ${config.baseURL}${config.url}`);
      
      // Skip authentication for anonymous endpoints 
      const anonymousEndpoints = ['/documents/', '/study-sets/', '/users/statistics/', '/calendar/events/', '/study-buddy/', '/users/events/'];
      const isAnonymousEndpoint = anonymousEndpoints.some(endpoint => config.url.startsWith(endpoint));
      
      console.log(`Request URL: ${config.url}, isAnonymousEndpoint: ${isAnonymousEndpoint}`);
      
      if (isAnonymousEndpoint) {
        console.log(`This is an anonymous endpoint (${config.url}). Auth optional.`);
      }
      
      // Get current user
      const user = auth.currentUser;
      if (user) {
        try {
          // For anonymous endpoints, don't force token refresh
          const forceRefresh = !isAnonymousEndpoint;
          console.log(`Getting token with forceRefresh=${forceRefresh} for ${config.url}`);
          
          // Get fresh token with a timeout to prevent hangs
          const tokenPromise = user.getIdToken(forceRefresh);
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Token refresh timeout')), 3000)
          );
          
          const token = await Promise.race([tokenPromise, timeoutPromise]);
          
          // Special handling for multipart/form-data requests
          if (config.headers['Content-Type'] === 'multipart/form-data' || 
              (config.data instanceof FormData)) {
            // For FormData requests, don't set Content-Type at all,
            // let the browser set it with the correct boundary
            delete config.headers['Content-Type'];
            
            // Log that this is a FormData request for debugging
            console.log('FormData upload request detected, removed Content-Type header');
          }
          
          // Always set the Authorization header with the token
          config.headers.Authorization = `Bearer ${token}`;
          console.log('Added Firebase token to request');
          
          // Print part of the token for debugging
          if (token) {
            console.log(`Token starts with: ${token.substring(0, 20)}...`);
          }
        } catch (tokenError) {
          console.warn('Error getting fresh token:', tokenError);
          // Continue with the request even without a fresh token
          // The existing token in localStorage might still work
          
          // For anonymous endpoints, we can proceed without a token
          if (isAnonymousEndpoint) {
            console.log('Continuing with anonymous access for endpoint:', config.url);
          }
        }
      } else {
        console.warn('No current user found for authentication');
        
        // For anonymous endpoints, we can proceed without authentication
        if (isAnonymousEndpoint) {
          console.log('Continuing with anonymous access for endpoint:', config.url);
        }
      }
    } catch (error) {
      console.error('Error getting Firebase token:', error);
    }
    
    // Log the final headers being sent
    console.log('Request headers:', config.headers);
    // Log request data if it's not too large
    if (config.data && typeof config.data === 'object' && Object.keys(config.data).length < 10) {
      console.log('Request data:', config.data);
    }
    return config;
  },
  (error) => {
    // Handle request cancellations
    if (error.canceled) {
      console.log('Request canceled:', error.message);
      return Promise.reject(error);
    }
    
    console.error('❌ Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for handling errors
api.interceptors.response.use(
  (response) => {
    // Log successful responses
    console.log(`API Response success [${response.status}]:`, response.config.url);
    
    // Store more detailed logs for debugging
    if (response.config.url && response.config.url.includes('/documents/')) {
      try {
        // Handle both array and non-array responses
        const responseData = Array.isArray(response.data) ? response.data : 
                            (response.data ? [response.data] : []);
        
        // More aggressively check for PDF evidence - any hint of PDF in the response
        const hasPdfData = responseData.some(doc => 
          doc.fileType === 'pdf' || 
          doc.fileType === 'application/pdf' ||
          (doc.filename && doc.filename.toLowerCase().includes('.pdf')) ||
          (doc.title && doc.title.toLowerCase().includes('pdf')) ||
          (doc.description && doc.description && doc.description.toLowerCase().includes('pdf')) ||
          (doc.id && doc.id.toLowerCase().includes('pdf')) ||
          (doc.contentType && doc.contentType.toLowerCase().includes('pdf'))
        );
        
        // Check the response raw text for PDF mentions
        const responseStr = JSON.stringify(response.data).toLowerCase();
        const hasPdfInText = responseStr.includes('pdf') || responseStr.includes('application/pdf');
        
        // Store API response data for documents endpoint for diagnostics
        const logData = {
          timestamp: new Date().toISOString(),
          url: response.config.url,
          status: response.status,
          dataLength: responseData.length,
          hasPdfData: hasPdfData || hasPdfInText,
          pdfEvidence: hasPdfInText ? 'text-match' : (hasPdfData ? 'object-match' : 'none'),
          rawTextContainsPdf: hasPdfInText
        };
        
        // Store PDF evidence in localStorage
        if (hasPdfData || hasPdfInText) {
          localStorage.setItem('pdfDocsExist', 'true');
          console.log('PDF evidence detected in API response, setting pdfDocsExist flag');
          
          // Also store the raw response data as evidence
          try {
            localStorage.setItem('lastDocumentResponse', JSON.stringify(response.data));
            console.log('Saved raw document response for diagnostics');
          } catch (e) {
            console.warn('Could not save raw document response:', e);
          }
        }
        
        // Look for server-side logs indicating PDF existence
        const serverMessage = response.headers && response.headers['x-server-message'];
        if (serverMessage && 
            (serverMessage.includes('PDF') || serverMessage.includes('pdf'))) {
          localStorage.setItem('pdfDocsExist', 'true');
          console.log('PDF evidence in server message:', serverMessage);
        }
        
        // Keep a rolling log of last 10 API responses for diagnostics
        const apiLogs = JSON.parse(localStorage.getItem('apiDocumentLogs') || '[]');
        apiLogs.unshift(logData);
        localStorage.setItem('apiDocumentLogs', JSON.stringify(apiLogs.slice(0, 10)));
        
        // Also store a simplified string version
        const recentLogs = localStorage.getItem('recentApiLogs') || '';
        const newLog = `[${new Date().toISOString()}] ${response.config.url}: Found ${responseData.length} documents${hasPdfData ? ' (PDF evidence found)' : ''}\n`;
        localStorage.setItem('recentApiLogs', newLog + recentLogs.slice(0, 2000));
      } catch (e) {
        console.warn('Failed to store API logs:', e);
      }
    }
    
    // Clean up pendingRequests
    if (response.config.onComplete) {
      response.config.onComplete();
    }
    
    return response;
  },
  async (error) => {
    // Add error logging for diagnostics
    try {
      if (error.config && error.config.url && error.config.url.includes('/documents/')) {
        const errorData = {
          timestamp: new Date().toISOString(),
          url: error.config.url,
          status: error.response?.status || 'network error',
          message: error.message || 'Unknown error'
        };
        
        // Keep a rolling log of last 10 API errors
        const apiErrors = JSON.parse(localStorage.getItem('apiDocumentErrors') || '[]');
        apiErrors.unshift(errorData);
        localStorage.setItem('apiDocumentErrors', JSON.stringify(apiErrors.slice(0, 10)));
        
        // Also store a simplified string version
        const recentErrors = localStorage.getItem('recentApiErrors') || '';
        const newError = `[${new Date().toISOString()}] Error ${error.config.url}: ${error.message}\n`;
        localStorage.setItem('recentApiErrors', newError + recentErrors.slice(0, 2000));
        
        // Check error response for PDF evidence
        if (error.response && error.response.data) {
          try {
            const responseStr = JSON.stringify(error.response.data).toLowerCase();
            if (responseStr.includes('pdf') || responseStr.includes('application/pdf')) {
              console.log('PDF evidence found in error response, setting flag');
              localStorage.setItem('pdfDocsExist', 'true');
            }
          } catch (e) {
            console.warn('Error checking error response for PDF evidence:', e);
          }
        }
      }
    } catch (e) {
      console.warn('Failed to store API error logs:', e);
    }
    
    if (error.code === 'ECONNABORTED') {
      console.error('Request timeout:', error.config && error.config.url);
    } else if (!error.config) {
      console.error('Error with no config:', error);
    } else if (error.response) {
      console.error(`API Response error [${error.response.status}]:`, error.config.url, error.response.data);
    } else {
      console.error('API Request failed:', error.config.url, error.message);
    }

    if (error.config && error.config.onError) {
      error.config.onError(error);
    }

    if (error.config && error.config.onComplete) {
      error.config.onComplete();
    }

    return Promise.reject(error);
  }
);

export default api; 