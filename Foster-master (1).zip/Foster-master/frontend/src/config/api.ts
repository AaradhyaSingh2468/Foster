import axios from 'axios';
import { getAuth } from 'firebase/auth';

// Determine the base URL based on environment
const isProduction = process.env.NODE_ENV === 'production';
const baseURL = isProduction 
  ? '/api' 
  : process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

console.log(`API configured with baseURL: ${baseURL}`);

// Create axios instance
const api = axios.create({
  baseURL,
  withCredentials: true, // Required for cookies/CSRF
  headers: {
    'Content-Type': 'application/json',
  }
});

// Add a request interceptor for authentication
api.interceptors.request.use(async (config) => {
  try {
    const auth = getAuth();
    const user = auth.currentUser;
    
    // If user is logged in, get the token and add it to headers
    if (user) {
      const token = await user.getIdToken();
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    
    return config;
  } catch (error) {
    console.error('Error adding auth token to request:', error);
    return config;
  }
});

// Add response interceptor for debugging
api.interceptors.response.use(
  (response) => {
    // For successful responses, return as is
    return response;
  },
  (error) => {
    // For errors, log additional details to help debugging
    console.error('API Error:', error.message);
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
      console.error('Headers:', error.response.headers);
    } else if (error.request) {
      console.error('Request was made but no response was received:', error.request);
    }
    return Promise.reject(error);
  }
);

export default api; 