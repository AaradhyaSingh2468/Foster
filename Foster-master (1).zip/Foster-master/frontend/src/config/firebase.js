import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, GithubAuthProvider, browserPopupRedirectResolver } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.REACT_APP_FIREBASE_APP_ID,
  measurementId: process.env.REACT_APP_FIREBASE_MEASUREMENT_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configure auth for better popup handling
auth.useDeviceLanguage();

// Create providers with custom parameters
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
  // The following helps with COOP issues
  access_type: 'offline',
  // For browser compatibility with Firefox and other browsers
  redirect_uri: window.location.origin
});

// Configure GitHub provider with necessary scopes
const githubProvider = new GithubAuthProvider();
githubProvider.setCustomParameters({
  allow_signup: 'true',
  // The following helps with COOP issues
  redirect_uri: window.location.origin
});

// Add GitHub scopes for additional permissions
// These are common GitHub scopes that may be required
githubProvider.addScope('user');      // Read access to profile info
githubProvider.addScope('user:email'); // Access to user's email

// Enable debug mode for auth in development
if (process.env.NODE_ENV === 'development') {
  console.log("Firebase Auth in development mode");
  console.log("Firebase config:", {
    authDomain: firebaseConfig.authDomain,
    projectId: firebaseConfig.projectId
  });
}

// Export configured auth and providers
export { auth, googleProvider, githubProvider, browserPopupRedirectResolver }; 