import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

/**
 * Show a success toast notification
 * @param title The toast title
 * @param message The toast message
 */
export const showSuccessToast = (title: string, message: string) => {
  toast.success(`${title}: ${message}`, {
    position: "top-right",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
  });
};

/**
 * Show an error toast notification
 * @param title The toast title
 * @param message The toast message
 */
export const showErrorToast = (title: string, message: string) => {
  toast.error(`${title}: ${message}`, {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
  });
};

/**
 * Show an info toast notification
 * @param title The toast title
 * @param message The toast message
 * @param duration Optional duration in milliseconds
 */
export const showInfoToast = (title: string, message: string, duration?: number) => {
  toast.info(`${title}: ${message}`, {
    position: "top-right",
    autoClose: duration || 3000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
  });
};

/**
 * Clear all active toasts
 */
export const clearToasts = () => {
  toast.dismiss();
}; 