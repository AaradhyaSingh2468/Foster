/**
 * Toast Utilities
 * 
 * This file provides simplified access to toast notifications
 * throughout the application with multiple fallback mechanisms.
 */

// Import the standalone toast function if available
let defaultToast;
try {
  defaultToast = require('../components/Toast').default;
} catch (err) {
  defaultToast = null;
}

// Import clearAllToasts if available
let clearAllToasts;
try {
  clearAllToasts = require('../study-dashboard/lib/useToast').clearAllToasts;
} catch (err) {
  clearAllToasts = null;
}

/**
 * Show a success toast notification
 * @param {string} title - Toast title
 * @param {string} message - Toast message/description
 * @param {number} duration - Duration in ms (default: 5000)
 */
export const showSuccessToast = (title, message, duration = 5000) => {
  // Try multiple methods to show the toast
  
  // Method 1: Use the global toast system if available
  if (typeof window !== 'undefined' && window.globalToast?.show) {
    window.globalToast.show({
      title,
      message,
      type: 'success',
      duration,
    });
    return;
  }
  
  // Method 2: Use the showAppToast function if available
  if (typeof window !== 'undefined' && typeof window.showAppToast === 'function') {
    window.showAppToast({
      title,
      description: message,
      variant: 'success',
      duration,
    });
    return;
  }
  
  // Method 3: Use our standalone toast if available
  if (defaultToast) {
    defaultToast({
      title,
      message,
      type: 'success',
      duration,
    });
    return;
  }
  
  // Method 4: Direct dispatch if available
  if (typeof window !== 'undefined' && window.dispatchToastAction) {
    // Clear existing toasts first
    if (clearAllToasts) {
      clearAllToasts();
    } else if (window.clearAllToasts) {
      window.clearAllToasts();
    }
    
    window.dispatchToastAction({
      type: "ADD_TOAST",
      toast: {
        id: "toast-" + Date.now(),
        title: title,
        description: message,
        variant: 'success',
        duration: duration,
        open: true,
      }
    });
    return;
  }
  
  // Method 5: Console log as last resort
  console.log(`SUCCESS TOAST: ${title} - ${message}`);
};

/**
 * Show an error toast notification
 * @param {string} title - Toast title
 * @param {string} message - Toast message/description
 * @param {number} duration - Duration in ms (default: 5000)
 */
export const showErrorToast = (title, message, duration = 5000) => {
  // Try multiple methods to show the toast
  
  // Method 1: Use the global toast system if available
  if (typeof window !== 'undefined' && window.globalToast?.show) {
    window.globalToast.show({
      title,
      message,
      type: 'error',
      duration,
    });
    return;
  }
  
  // Method 2: Use the showAppToast function if available
  if (typeof window !== 'undefined' && typeof window.showAppToast === 'function') {
    window.showAppToast({
      title,
      description: message,
      variant: 'destructive',
      duration,
    });
    return;
  }
  
  // Method 3: Use our standalone toast if available
  if (defaultToast) {
    defaultToast({
      title,
      message,
      type: 'error',
      duration,
    });
    return;
  }
  
  // Method 4: Direct dispatch if available
  if (typeof window !== 'undefined' && window.dispatchToastAction) {
    // Clear existing toasts first
    if (clearAllToasts) {
      clearAllToasts();
    } else if (window.clearAllToasts) {
      window.clearAllToasts();
    }
    
    window.dispatchToastAction({
      type: "ADD_TOAST",
      toast: {
        id: "toast-" + Date.now(),
        title: title,
        description: message,
        variant: 'destructive',
        duration: duration,
        open: true,
      }
    });
    return;
  }
  
  // Method 5: Console log as last resort
  console.error(`ERROR TOAST: ${title} - ${message}`);
};

/**
 * Show an info toast notification
 * @param {string} title - Toast title
 * @param {string} message - Toast message/description
 * @param {number} duration - Duration in ms (default: 5000)
 */
export const showInfoToast = (title, message, duration = 5000) => {
  // Try multiple methods to show the toast
  
  // Method 1: Use the global toast system if available
  if (typeof window !== 'undefined' && window.globalToast?.show) {
    window.globalToast.show({
      title,
      message,
      type: 'default',
      duration,
    });
    return;
  }
  
  // Method 2: Use the showAppToast function if available
  if (typeof window !== 'undefined' && typeof window.showAppToast === 'function') {
    window.showAppToast({
      title,
      description: message,
      variant: 'default',
      duration,
    });
    return;
  }
  
  // Method 3: Use our standalone toast if available
  if (defaultToast) {
    defaultToast({
      title,
      message,
      type: 'default',
      duration,
    });
    return;
  }
  
  // Method 4: Direct dispatch if available
  if (typeof window !== 'undefined' && window.dispatchToastAction) {
    // Clear existing toasts first
    if (clearAllToasts) {
      clearAllToasts();
    } else if (window.clearAllToasts) {
      window.clearAllToasts();
    }
    
    window.dispatchToastAction({
      type: "ADD_TOAST",
      toast: {
        id: "toast-" + Date.now(),
        title: title,
        description: message,
        variant: 'default',
        duration: duration,
        open: true,
      }
    });
    return;
  }
  
  // Method 5: Console log as last resort
  console.log(`INFO TOAST: ${title} - ${message}`);
};

/**
 * Clear all toast notifications
 */
export const clearToasts = () => {
  // Try multiple methods to clear toasts
  
  // Method 1: Use the global toast system if available
  if (typeof window !== 'undefined' && window.globalToast?.clear) {
    window.globalToast.clear();
    return;
  }
  
  // Method 2: Use clearAllToasts if available
  if (clearAllToasts) {
    clearAllToasts();
    return;
  }
  
  // Method 3: Use window.clearAllToasts if available
  if (typeof window !== 'undefined' && typeof window.clearAllToasts === 'function') {
    window.clearAllToasts();
    return;
  }
  
  // Method 4: Use defaultToast.dismiss if available
  if (defaultToast && typeof defaultToast.dismiss === 'function') {
    defaultToast.dismiss();
    return;
  }
  
  // Method 5: Direct dispatch if available
  if (typeof window !== 'undefined' && window.dispatchToastAction) {
    window.dispatchToastAction({
      type: "REMOVE_TOAST",
      id: "all"
    });
  }
}; 