import { GlobalStyle } from "./globalStyles";
import { lazy, Suspense, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import "./study-dashboard/study-dashboard.css";
import { Dashboard } from "./study-dashboard";
// Import Toaster directly to ensure it's always available
import { Toaster } from "./study-dashboard/components/ui/toaster";
import { useToast, clearAllToasts } from "./study-dashboard/lib/useToast";
// Import our Toast Manager
import { ToastManagerProvider } from "./ToastManager";
// Import our new global toast system
import { GlobalToastProvider } from "./hooks/useGlobalToast";
import { ToastProvider } from "./components/Toast";

const Home = lazy(() => import("./Pages/Home"));
const Header = lazy(() => import("./components/Header/index"));
const Footer = lazy(() => import("./components/Footer/index"));
const ScrollToTop = lazy(() => import("./components/ScrollToTop/index"));
const Auth = lazy(() => import("./Pages/Auth"));
const Blog = lazy(() => import("./Pages/Blog"));
const Features = lazy(() => import("./Pages/Features"));
const Onboarding = lazy(() => import("./Pages/Onboarding"));
const ProtectedRoute = lazy(() => import("./components/ProtectedRoute"));

// Study Dashboard components
const StudyMain = lazy(() => import("./study-dashboard/pages/StudyMain"));
const StudyChat = lazy(() => import("./study-dashboard/pages/Chat"));
const StudyCalendar = lazy(() => import("./study-dashboard/pages/Calendar"));
const StudyInsights = lazy(() => import("./study-dashboard/pages/Insights"));
const StudyFlashCards = lazy(() => import("./study-dashboard/pages/FlashCards"));
const StudyTests = lazy(() => import("./study-dashboard/pages/Tests"));
const StudySketchboard = lazy(() => import("./study-dashboard/pages/Sketchboard"));
const StudyExamGeneration = lazy(() => import("./study-dashboard/pages/ExamGeneration"));
const StudyVideoGeneration = lazy(() => import("./study-dashboard/pages/VideoGeneration"));
const StudySet = lazy(() => import("./study-dashboard/pages/StudySet"));
const StudyProfile = lazy(() => import("./study-dashboard/pages/Profile"));
const StudyAccountSettings = lazy(() => import("./study-dashboard/pages/AccountSettings"));
const StudyBuddyAI = lazy(() => import("./study-dashboard/pages/StudyBuddyAI"));
const PDFLibrary = lazy(() => import("./study-dashboard/pages/PDFLibrary"));

// Wrapper component to conditionally render the Header
const AppContent = () => {
  const location = useLocation();
  const { toast } = useToast();
  const isStudyDashboard = location.pathname.startsWith('/study-dashboard');
  const hideNavbar = location.pathname.startsWith('/auth') || location.pathname.startsWith('/onboarding') || isStudyDashboard;
  // Also hide footer on auth and onboarding pages and study dashboard
  const hideFooter = location.pathname.startsWith('/auth') || location.pathname.startsWith('/onboarding') || isStudyDashboard;
  
  useEffect(() => {
    // Add or remove class from body depending on route
    if (isStudyDashboard) {
      document.body.classList.add('study-dashboard-active');
    } else {
      document.body.classList.remove('study-dashboard-active');
    }
    
    return () => {
      document.body.classList.remove('study-dashboard-active');
    };
  }, [isStudyDashboard]);

  // Check for logout message flag on route change
  useEffect(() => {
    const checkForLogout = () => {
      // If on home page, check for logout indicators
      if (location.pathname === '/') {
        const showLogoutMessage = localStorage.getItem('show_logout_message');
        const justLoggedOut = sessionStorage.getItem('just_logged_out');
        const locationState = location.state;
        const logoutFromState = locationState && locationState.justLoggedOut;
        
        if (showLogoutMessage || justLoggedOut || logoutFromState) {
          console.log("AppContent detected logout, showing toast");
          
          // Clear indicators
          localStorage.removeItem('show_logout_message');
          sessionStorage.removeItem('just_logged_out');
          
          // Show toast with a slight delay to ensure rendering is complete
          setTimeout(() => {
            toast({
              title: "Logged out successfully",
              description: "You have been securely logged out",
              variant: "success",
              duration: 5000,
            });
          }, 300);
        }
      }
    };
    
    // Run on initial render and route changes
    checkForLogout();
    
    // Also try again after a delay to catch async navigation
    const timer = setTimeout(checkForLogout, 500);
    return () => clearTimeout(timer);
  }, [location, toast]);

  return (
    <>
      <ScrollToTop />
      {!hideNavbar && <Header />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/features" element={<Features />} />
        <Route path="/onboarding" element={
          <ProtectedRoute>
            <Onboarding />
          </ProtectedRoute>
        } />
        <Route path="/blog/*" element={<Blog />} />
        
        {/* Study Dashboard Routes */}
        <Route path="/study-dashboard" element={
          <ProtectedRoute>
            <StudyMain />
          </ProtectedRoute>
        }>
          <Route path="" element={<Dashboard />} />
          <Route path="chat" element={<StudyChat />} />
          <Route path="calendar" element={<StudyCalendar />} />
          <Route path="insights" element={<StudyInsights />} />
          <Route path="flashcards" element={<StudyFlashCards />} />
          <Route path="tests" element={<StudyTests />} />
          <Route path="sketchboard" element={<StudySketchboard />} />
          <Route path="exam-generation" element={<StudyExamGeneration />} />
          <Route path="video-generation" element={<StudyVideoGeneration />} />
          <Route path="study-buddy-ai" element={<StudyBuddyAI />} />
          <Route path="pdf-library" element={<PDFLibrary />} />
          <Route path="study-set/:id" element={<StudySet />} />
          <Route path="profile" element={<StudyProfile />} />
          <Route path="account-settings" element={<StudyAccountSettings />} />
        </Route>
      </Routes>
      {!hideFooter && <Footer />}
    </>
  );
};

// Toast message container component with improved positioning and visibility
const ToastContainer = () => {
  const { toast } = useToast();
  
  useEffect(() => {
    // Global initialization for toast system
    if (typeof window !== 'undefined') {
      // Define a global method for showing toast notifications
      window.showAppToast = (props) => {
        toast(props);
      };
      
      // Define a specific method for logout toast
      window.showLogoutToast = () => {
        console.log("Global showLogoutToast called from ToastContainer");
        // Only show toast if we haven't shown it recently (within 5 seconds)
        const lastShown = parseInt(localStorage.getItem('logout_toast_timestamp') || '0', 10);
        const now = Date.now();
        
        if (now - lastShown > 5000) {
          // Clear any existing toasts first
          clearAllToasts();
          
          // Show the toast
          toast({
            title: "Logged out successfully",
            description: "You have been securely logged out of your account",
            variant: "success",
            duration: 5000,
          });
          
          // Record that we've shown the toast
          localStorage.setItem('logout_toast_timestamp', now.toString());
          localStorage.setItem('logout_toast_shown', 'true');
          localStorage.removeItem('show_logout_message');
          sessionStorage.removeItem('just_logged_out');
        } else {
          console.log("Skipping duplicate logout toast (shown recently)");
        }
      };
      
      // Check if we need to show a logout toast globally
      if (localStorage.getItem('show_logout_message') && !localStorage.getItem('logout_toast_shown')) {
        setTimeout(() => {
          localStorage.removeItem('show_logout_message');
          window.showLogoutToast();
        }, 500);
      }
    }
  }, [toast]);

  return (
    <div style={{ 
      position: 'fixed', 
      bottom : '20px', 
      right: '20px',
      top : "auto",
      zIndex: 9999,
      maxWidth: '400px',
      pointerEvents: 'none' // Let clicks pass through the container but not the toasts
    }}>
      <div style={{ pointerEvents: 'auto' }}> {/* Restore pointer events for actual toasts */}
        <Toaster clearOnMount={false} />
      </div>
    </div>
  );
};

function App() {
  const { toast } = useToast();
  
  // Set up global event listener for logout
  useEffect(() => {
    // Function to handle logout events
    const handleLogoutEvent = (event) => {
      console.log("Logout event received in App:", event.detail);
      
      // Check if we've already shown a toast recently
      const lastShown = parseInt(localStorage.getItem('logout_toast_timestamp') || '0', 10);
      const now = Date.now();
      
      if (now - lastShown > 5000) {
        // Show logout toast
        toast({
          title: "Logged out successfully",
          description: "You have been securely logged out of your account",
          variant: "success",
          duration: 5000,
        });
        
        // Record that we've shown the toast
        localStorage.setItem('logout_toast_timestamp', now.toString());
        localStorage.setItem('logout_toast_shown', 'true');
      } else {
        console.log("Skipping duplicate logout toast (shown recently)");
      }
    };
    
    // Add event listener for custom logout event
    document.addEventListener('userLoggedOut', handleLogoutEvent);
    
    // Check for stored toast data
    const storedToastData = localStorage.getItem('logout_toast_data');
    if (storedToastData && !localStorage.getItem('logout_toast_shown')) {
      try {
        const toastData = JSON.parse(storedToastData);
        console.log("Found stored logout toast data:", toastData);
        
        // Remove the data to prevent showing it again
        localStorage.removeItem('logout_toast_data');
        
        // Check if we've already shown a toast recently
        const lastShown = parseInt(localStorage.getItem('logout_toast_timestamp') || '0', 10);
        const now = Date.now();
        
        if (now - lastShown > 5000) {
          // Show the toast
          toast({
            title: toastData.title || "Logged out successfully",
            description: toastData.description || "You have been securely logged out",
            variant: "success",
            duration: 5000,
          });
          
          // Record that we've shown the toast
          localStorage.setItem('logout_toast_timestamp', now.toString());
          localStorage.setItem('logout_toast_shown', 'true');
        }
      } catch (e) {
        console.error("Error parsing stored toast data:", e);
      }
    }
    
    // Set a 30-second timer to reset the logout_toast_shown flag
    const resetTimer = setTimeout(() => {
      localStorage.removeItem('logout_toast_shown');
    }, 30000);
    
    // Clean up
    return () => {
      document.removeEventListener('userLoggedOut', handleLogoutEvent);
      clearTimeout(resetTimer);
    };
  }, [toast]);
  
  return (
    <>
      <Suspense fallback={null}>
        <GlobalStyle />
        {/* Add our standalone Toast Provider at the top level */}
        <ToastProvider>
          {/* Add our new GlobalToastProvider */}
          <GlobalToastProvider>
            <ToastManagerProvider>
              <AuthProvider>
                <Router>
                  <AppContent />
                </Router>
              </AuthProvider>
            </ToastManagerProvider>
          </GlobalToastProvider>
        </ToastProvider>
        
        {/* Use the improved toast container */}
        <ToastContainer />
      </Suspense>
    </>
  );
}

export default App;
