import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProfileSettings from '../components/ProfileSettings';

const ProfileSettingsRoute = () => {
  const { currentUser } = useAuth();
  
  // Redirect to login if not authenticated
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  return <ProfileSettings />;
};

export default ProfileSettingsRoute; 