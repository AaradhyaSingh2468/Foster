# Foster Authentication System

This document explains how to use and customize the authentication system in the Foster application.

## Setup

The authentication system uses Firebase Authentication, which needs to be properly configured before use.

### 1. Firebase Configuration

1. Create a Firebase project at [firebase.google.com](https://firebase.google.com/)
2. Enable Authentication in your Firebase project:
   - Navigate to the "Authentication" section in your Firebase project
   - Enable Email/Password authentication
   - Enable Google authentication
   - Enable GitHub authentication

3. Update the Firebase configuration in `src/config/firebase.js`:
   ```javascript
   const firebaseConfig = {
     apiKey: "YOUR_API_KEY",
     authDomain: "your-project-id.firebaseapp.com",
     projectId: "your-project-id",
     storageBucket: "your-project-id.appspot.com",
     messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
     appId: "YOUR_APP_ID",
     measurementId: "YOUR_MEASUREMENT_ID"
   };
   ```

### 2. GitHub OAuth Setup

For GitHub authentication:

1. Go to your GitHub account settings
2. Navigate to "Developer settings" > "OAuth Apps" > "New OAuth App"
3. Register a new OAuth application with the following details:
   - Application name: "Foster" (or your preferred name)
   - Homepage URL: Your website URL (e.g., http://localhost:3000 for development)
   - Authorization callback URL: Your Firebase auth callback URL (found in Firebase Auth settings)
4. Once registered, copy the Client ID and Client Secret
5. In Firebase Authentication, go to the "Sign-in method" tab
6. Enable GitHub authentication and paste your GitHub Client ID and Client Secret

### 3. Google OAuth Setup

For Google authentication:

1. In Firebase, navigate to Authentication > Sign-in methods
2. Enable Google authentication
3. Configure your OAuth consent screen in Google Cloud Console (link provided in Firebase)
4. Add your domain to the authorized domains list

## Usage

### AuthContext

The application uses a React Context to manage authentication state. To use authentication in your components:

```javascript
import { useAuth } from '../context/AuthContext';

function MyComponent() {
  const { currentUser, signInWithEmail, signInWithGoogle, signInWithGithub, logout } = useAuth();
  
  // Use these functions and values as needed
}
```

### Available Authentication Methods

- `signInWithEmail(email, password)` - Sign in with email and password
- `signUpWithEmail(email, password)` - Create a new account with email and password
- `signInWithGoogle()` - Sign in with Google
- `signInWithGithub()` - Sign in with GitHub
- `logout()` - Sign out the current user

### Protected Routes

The application includes a `ProtectedRoute` component that requires authentication:

```javascript
<Route path="/dashboard" element={
  <ProtectedRoute>
    <Dashboard />
  </ProtectedRoute>
} />
```

## Customization

### UI Customization

The authentication UI is styled using styled-components and can be customized in:
- `src/components/AuthCard/index.js` - For the authentication card
- `src/Pages/Auth.js` - For the authentication page layout

### Adding More Authentication Providers

To add more authentication providers (e.g., Facebook, Twitter):

1. Enable the provider in Firebase Authentication
2. Configure the provider in `src/config/firebase.js`
3. Add the sign-in function to `src/context/AuthContext.js`
4. Update the UI in `src/components/AuthCard/index.js`

## Troubleshooting

### Common Issues

1. **Authentication popup blocked**: Make sure you're calling the authentication methods directly from a user interaction (like clicking a button)

2. **Invalid OAuth redirect URI**: Make sure your Firebase project is correctly configured with the right authorized domains

3. **Auth providers not working**: Check if the provider is correctly enabled in Firebase and properly configured 