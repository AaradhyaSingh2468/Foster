import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../config/api'; // Import the API client

// Create a session-persistent memory of onboarding completion
// This will persist even if localStorage is cleared during the session
const onboardingMemory = {
  hasCompletedOnboarding: false,
  setCompleted: function() {
    this.hasCompletedOnboarding = true;
    // Also set in localStorage as backup
    try {
      localStorage.setItem('onboardingCompleted', 'true');
    } catch (e) {
      console.warn('Could not write to localStorage:', e);
    }
  },
  isCompleted: function() {
    return this.hasCompletedOnboarding || localStorage.getItem('onboardingCompleted') === 'true';
  }
};

// Make it available globally
try {
  window.onboardingMemory = onboardingMemory;
} catch (e) {
  console.warn('Could not set global onboardingMemory:', e);
}

const ProtectedRoute = ({ children }) => {
  const { currentUser, userProfile, loading } = useAuth();
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const location = useLocation();
  
  // FIRST check: If we're coming directly from onboarding completion, bypass all other logic
  useEffect(() => {
    if (localStorage.getItem('directDashboardNavigation') === 'true' && location.pathname === '/study-dashboard') {
      console.log('Direct dashboard navigation detected - bypassing all onboarding checks');
      // Record this successful navigation to dashboard in our memory
      onboardingMemory.setCompleted();
      setNeedsOnboarding(false);
    }
  }, [location.pathname]);
  
  // Effect to check if user needs onboarding
  useEffect(() => {
    // Skip check if we're already on onboarding page or loading
    if (location.pathname === '/onboarding' || loading || !currentUser) {
      return;
    }
    
    // Skip ALL checks if we have a direct navigation flag set or memory of completion
    if (localStorage.getItem('directDashboardNavigation') === 'true' || onboardingMemory.isCompleted()) {
      console.log('Bypassing onboarding checks due to direct navigation flag or memory of completion');
      setNeedsOnboarding(false);
      return;
    }
    
    const checkNeedsOnboarding = async () => {
      // Special case: User just clicked "Go to Dashboard" button from onboarding completion
      // This is a one-time direct pass to dashboard with no checks
      if (localStorage.getItem('directDashboardNavigation') === 'true') {
        console.log('User is coming directly from onboarding completion button - bypassing all checks');
        onboardingMemory.setCompleted();
        setNeedsOnboarding(false);
        return;
      }
      
      // If onboardingCompleted is in localStorage but not confirmed by server yet,
      // we'll still need to verify with the server
      const localStorageOnboardingComplete = localStorage.getItem('onboardingCompleted') === 'true';
      
      // If our onboardingMemory indicates completion, we're done
      if (onboardingMemory.isCompleted()) {
        console.log('Onboarding memory indicates completion - bypassing all checks');
        setNeedsOnboarding(false);
        return;
      }
      
      // If signupIntent exists in localStorage, user needs onboarding
      if (localStorage.getItem('signupIntent') === 'true') {
        console.log('Signup intent found in localStorage - user needs onboarding');
        setNeedsOnboarding(true);
        return;
      }
      
      // Check profile from context
      if (userProfile && userProfile.onboarding_completed === true) {
        console.log('User profile in context indicates onboarding IS completed');
        onboardingMemory.setCompleted();
        setNeedsOnboarding(false);
        return;
      }
      
      try {
        // Use the API client instead of direct fetch
        const response = await api.get('/users/profile/');
        
        if (!response || !response.data) {
          console.error('Profile API returned invalid response');
          return;
        }
        
        const profile = response.data;
        console.log('Profile for onboarding check:', profile);
        
        // More robust check for onboarding_completed
        const onboardingCompleted = profile?.onboarding_completed;
        console.log('Onboarding completed value:', onboardingCompleted, 'Type:', typeof onboardingCompleted, 'JSON value:', JSON.stringify(onboardingCompleted));
        console.log('localStorage onboardingCompleted:', localStorageOnboardingComplete);
        console.log('onboardingMemory:', onboardingMemory.isCompleted());
        
        // If the server or localStorage indicates completion, that's good enough
        if (onboardingCompleted === true || onboardingCompleted === 'true' || onboardingCompleted === 'True' || localStorageOnboardingComplete) {
          console.log('Server OR localStorage indicates onboarding is completed');
          onboardingMemory.setCompleted();
          setNeedsOnboarding(false);
        } else if (onboardingCompleted === false || onboardingCompleted === 'false' || onboardingCompleted === 'False') {
          console.log('API profile indicates onboarding not completed - explicit false detected');
          // Don't override onboardingMemory if it says we're done
          if (!onboardingMemory.isCompleted()) {
            setNeedsOnboarding(true);
          } else {
            console.log('But onboardingMemory says we are done, so ignoring server');
            setNeedsOnboarding(false);
          }
        } else {
          console.log('Ambiguous onboarding status, checking memory and localStorage');
          // Don't override onboardingMemory if it says we're done
          if (onboardingMemory.isCompleted()) {
            console.log('onboardingMemory says we are done, so ignoring ambiguity');
            setNeedsOnboarding(false);
          } else {
            setNeedsOnboarding(!localStorageOnboardingComplete);
          }
        }
      } catch (err) {
        console.error('Error checking onboarding status:', err);
        // If there's an error, don't override onboardingMemory
        if (onboardingMemory.isCompleted() || localStorageOnboardingComplete) {
          console.log('Error, but memory or localStorage says we are done');
          setNeedsOnboarding(false);
        }
      }
    };
    
    checkNeedsOnboarding();
  }, [currentUser, loading, location.pathname, userProfile]);

  if (loading) {
    // You could return a loading spinner here
    return <div>Loading...</div>;
  }

  if (!currentUser) {
    return <Navigate to="/auth" replace />;
  }
  
  // Redirect to onboarding if user needs it and not already there
  if (needsOnboarding && location.pathname !== '/onboarding') {
    // Special protection: Never redirect away from dashboard if we have direct navigation flag set
    if (localStorage.getItem('directDashboardNavigation') === 'true' && location.pathname === '/study-dashboard') {
      console.log('Protected from redirect to onboarding due to direct navigation flag');
      return children;
    }
    
    // Also never redirect if we have memory of successful completion
    if (onboardingMemory.isCompleted()) {
      console.log('Protected from redirect to onboarding due to onboardingMemory');
      return children;
    }
    
    console.log('User needs onboarding, redirecting from', location.pathname);
    return <Navigate to="/onboarding" replace />;
  }

  return children;
};

export default ProtectedRoute; 