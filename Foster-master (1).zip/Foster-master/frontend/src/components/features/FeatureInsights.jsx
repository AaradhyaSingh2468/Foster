import React from "react";
import styled, { keyframes } from "styled-components";
import { Link } from "react-router-dom";

// Adding animation keyframes
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(16, 185, 129, 0.2);
  color: #6ee7b7;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #10b981;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #10b981;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #10b981;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #059669;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
  min-height: 580px;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  height: 100%;
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const InsightHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const InsightTitle = styled.h3`
  font-weight: 600;
  font-size: 1.125rem;
`;

const InsightTimeframe = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: center;
`;

const TimeframeButton = styled.button`
  padding: 0.375rem 0.75rem;
  background-color: ${props => props.active ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.active ? 'rgba(16, 185, 129, 0.4)' : 'transparent'};
  color: ${props => props.active ? '#10b981' : '#d1d5db'};
  font-size: 0.75rem;
  border-radius: 0.375rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.active ? 'rgba(16, 185, 129, 0.25)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
`;

const StatCard = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const StatLabel = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const StatValue = styled.div`
  font-size: 1.5rem;
  font-weight: 600;
  color: #fff;
`;

const StatChange = styled.div`
  display: flex;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.75rem;
  color: ${props => props.positive ? '#10b981' : '#ef4444'};
`;

const ChartContainer = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1.5rem;
  height: 250px;
  position: relative;
`;

const ChartHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const ChartTitle = styled.div`
  font-weight: 500;
`;

const ChartLegend = styled.div`
  display: flex;
  gap: 1rem;
`;

const LegendItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.75rem;
  color: #9ca3af;
`;

const LegendDot = styled.div`
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 50%;
  background-color: ${props => props.color || '#10b981'};
`;

const Chart = styled.div`
  position: relative;
  height: 8rem;
`;

const ChartLine = styled.div`
  width: 100%;
  height: ${props => props.height || '30%'};
  background: linear-gradient(90deg, 
    ${props => `${props.color || '#10b981'}00`} 0%, 
    ${props => props.color || '#10b981'} 30%, 
    ${props => props.color || '#10b981'} 70%, 
    ${props => `${props.color || '#10b981'}00`} 100%
  );
  position: absolute;
  bottom: ${props => props.bottom || '0'};
  opacity: 0.2;
  border-radius: 999px;
`;

const ChartPoints = styled.div`
  display: flex;
  justify-content: space-between;
  width: 100%;
  position: absolute;
  bottom: ${props => props.bottom || '0'};
  height: 2px;
`;

const ChartPoint = styled.div`
  width: 0.5rem;
  height: 0.5rem;
  border-radius: 50%;
  background-color: ${props => props.color || '#10b981'};
  transform: translateY(-50%);
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
`;

const ChartLabels = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 0.5rem;
  padding: 0 0.5rem;
`;

const ChartLabel = styled.div`
  font-size: 0.625rem;
  color: #9ca3af;
`;

const SubjectsSection = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1.5rem;
  min-height: 135px;
`;

const SubjectsHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const SubjectsTitle = styled.div`
  font-weight: 500;
`;

const SubjectFilter = styled.div`
  font-size: 0.75rem;
  color: #10b981;
  display: flex;
  align-items: center;
  gap: 0.25rem;
  cursor: pointer;
`;

const SubjectsList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const SubjectItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const SubjectHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const SubjectName = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
`;

const SubjectIcon = styled.div`
  width: 1.5rem;
  height: 1.5rem;
  border-radius: 0.375rem;
  background-color: ${props => props.bgColor || 'rgba(16, 185, 129, 0.2)'};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${props => props.color || '#10b981'};
`;

const SubjectScore = styled.div`
  font-weight: 600;
  color: ${props => props.color || '#10b981'};
`;

const ProgressBar = styled.div`
  width: 100%;
  height: 0.5rem;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 999px;
  overflow: hidden;
`;

const ProgressFill = styled.div`
  height: 100%;
  width: ${props => props.width || '50%'};
  background-color: ${props => props.color || '#10b981'};
  border-radius: 999px;
`;

const FeatureInsights = () => {
  return (
    <Container>
      <ContentSection>
        <Badge>
          <Circle />
          <span>Learning Analytics</span>
        </Badge>
        <Title>Performance Insights</Title>
        <Description>
          Track your learning progress with data-driven insights. Foster analyzes your study patterns, test performances, and engagement to help you understand your strengths and areas for improvement.
        </Description>
        <FeatureList>
          {[
            "Comprehensive learning analytics dashboard",
            "Track progress across all your courses and subjects",
            "Personalized recommendations based on your performance",
            "Identify knowledge gaps and optimize study time",
            "Set and monitor learning goals with visual progress tracking"
          ].map((item, index) => (
            <FeatureItem key={index}>
              <CheckIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </CheckIcon>
              <span>{item}</span>
            </FeatureItem>
          ))}
        </FeatureList>
        <div>
          <Button to="/auth">Explore Your Insights</Button>
        </div>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#eab308" />
              <WindowControl color="#22c55e" />
            </WindowControls>
            <WindowTitle>Learning Analytics</WindowTitle>
          </WindowHeader>
          
          <WindowContent>
            <InsightHeader>
              <InsightTitle>Learning Overview</InsightTitle>
              <InsightTimeframe>
                <TimeframeButton>Week</TimeframeButton>
                <TimeframeButton active>Month</TimeframeButton>
                <TimeframeButton>Semester</TimeframeButton>
                <TimeframeButton>All</TimeframeButton>
              </InsightTimeframe>
            </InsightHeader>
            
            <StatsGrid>
              <StatCard>
                <StatLabel>Study Hours</StatLabel>
                <StatValue>42.5</StatValue>
                <StatChange positive>
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m18 15-6-6-6 6"/>
                  </svg>
                  <span>12% from last month</span>
                </StatChange>
              </StatCard>
              
              <StatCard>
                <StatLabel>Practice Quizzes</StatLabel>
                <StatValue>24</StatValue>
                <StatChange positive>
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m18 15-6-6-6 6"/>
                  </svg>
                  <span>8% from last month</span>
                </StatChange>
              </StatCard>
              
              <StatCard>
                <StatLabel>Avg. Performance</StatLabel>
                <StatValue>87%</StatValue>
                <StatChange positive>
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m18 15-6-6-6 6"/>
                  </svg>
                  <span>5% from last month</span>
                </StatChange>
              </StatCard>
            </StatsGrid>
            
            <ChartContainer>
              <ChartHeader>
                <ChartTitle>Study Performance</ChartTitle>
                <ChartLegend>
                  <LegendItem>
                    <LegendDot color="#10b981" />
                    <span>Quiz Scores</span>
                  </LegendItem>
                  <LegendItem>
                    <LegendDot color="#6366f1" />
                    <span>Study Time</span>
                  </LegendItem>
                </ChartLegend>
              </ChartHeader>
              
              <Chart>
                <ChartLine color="#10b981" height="60%" />
                <ChartPoints bottom="60%">
                  {[...Array(7)].map((_, i) => (
                    <ChartPoint key={i} color="#10b981" />
                  ))}
                </ChartPoints>
                
                <ChartLine color="#6366f1" height="40%" bottom="20%" />
                <ChartPoints bottom="40%">
                  {[...Array(7)].map((_, i) => (
                    <ChartPoint key={i} color="#6366f1" />
                  ))}
                </ChartPoints>
              </Chart>
              
              <ChartLabels>
                {["Week 1", "Week 2", "Week 3", "Week 4", "Week 5", "Week 6", "Week 7"].map((label, i) => (
                  <ChartLabel key={i}>{label}</ChartLabel>
                ))}
              </ChartLabels>
            </ChartContainer>
            
            <SubjectsSection>
              <SubjectsHeader>
                <SubjectsTitle>Subject Performance</SubjectsTitle>
                <SubjectFilter>
                  <span>View All</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6"></polyline>
                  </svg>
                </SubjectFilter>
              </SubjectsHeader>
              
              <SubjectsList>
                <SubjectItem>
                  <SubjectHeader>
                    <SubjectName>
                      <SubjectIcon bgColor="rgba(16, 185, 129, 0.2)" color="#10b981">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M10.5 20.5 3 13l7.5-7.5"></path>
                          <path d="m21 13-7.5 7.5L21 13ZM3 13h18"></path>
                        </svg>
                      </SubjectIcon>
                      <span>Computer Science</span>
                    </SubjectName>
                    <SubjectScore color="#10b981">94%</SubjectScore>
                  </SubjectHeader>
                  <ProgressBar>
                    <ProgressFill width="94%" color="#10b981" />
                  </ProgressBar>
                </SubjectItem>
                
                <SubjectItem>
                  <SubjectHeader>
                    <SubjectName>
                      <SubjectIcon bgColor="rgba(99, 102, 241, 0.2)" color="#6366f1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="10"></circle>
                          <path d="m16.24 7.76-4.24 4.24-4.24-4.24"></path>
                          <path d="m12 12-4.24 4.24"></path>
                        </svg>
                      </SubjectIcon>
                      <span>Mathematics</span>
                    </SubjectName>
                    <SubjectScore color="#6366f1">87%</SubjectScore>
                  </SubjectHeader>
                  <ProgressBar>
                    <ProgressFill width="87%" color="#6366f1" />
                  </ProgressBar>
                </SubjectItem>
                
                <SubjectItem>
                  <SubjectHeader>
                    <SubjectName>
                      <SubjectIcon bgColor="rgba(234, 88, 12, 0.2)" color="#f97316">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M18.387 12C19.198 15.799 21 17 21 17H3s3-2 3-9a6 6 0 0 1 12 0c0 1.892-.402 3.13-.613 4"></path>
                        </svg>
                      </SubjectIcon>
                      <span>Physics</span>
                    </SubjectName>
                    <SubjectScore color="#f97316">76%</SubjectScore>
                  </SubjectHeader>
                  <ProgressBar>
                    <ProgressFill width="76%" color="#f97316" />
                  </ProgressBar>
                </SubjectItem>
              </SubjectsList>
            </SubjectsSection>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

export default FeatureInsights; 