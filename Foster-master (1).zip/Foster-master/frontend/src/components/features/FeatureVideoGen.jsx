import React from "react";
import styled, { keyframes } from "styled-components";
import { Link } from "react-router-dom";

// Adding animation keyframes
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(124, 58, 237, 0.2);
  color: #d4b5ff;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #a78bfa;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #7c3aed;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #7c3aed;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #6d28d9;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
  min-height: 580px;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(124, 58, 237, 0.2), rgba(59, 130, 246, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  height: 100%;
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const VideoPreview = styled.div`
  position: relative;
  border-radius: 0.75rem;
  overflow: hidden;
  aspect-ratio: 16 / 9;
  background-color: rgba(0, 0, 0, 0.5);
  height: 250px;
`;

const VideoOverlay = styled.div`
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const PlayButton = styled.div`
  width: 4rem;
  height: 4rem;
  border-radius: 50%;
  background-color: rgba(124, 58, 237, 0.5);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s;
`;

const PlayButtonInner = styled.div`
  width: 3.5rem;
  height: 3.5rem;
  border-radius: 50%;
  background-color: #7c3aed;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const VideoGradient = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 33%;
  background: linear-gradient(to top, rgba(0, 0, 0, 0.8), transparent);
`;

const VideoInfo = styled.div`
  position: absolute;
  bottom: 1rem;
  left: 1rem;
`;

const VideoTitle = styled.h4`
  font-weight: 500;
  margin-bottom: 0.25rem;
`;

const VideoMeta = styled.p`
  font-size: 0.875rem;
  color: #d1d5db;
`;

const ProgressSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1rem;
`;

const ProgressHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const ProgressTitle = styled.h4`
  font-weight: 500;
`;

const ProgressValue = styled.span`
  color: #a78bfa;
`;

const ProgressBar = styled.div`
  width: 100%;
  height: 0.5rem;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 9999px;
`;

const ProgressFill = styled.div`
  height: 0.5rem;
  border-radius: 9999px;
  background-color: #7c3aed;
  width: ${props => props.width || '50%'};
`;

const StagesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1rem;
`;

const StageItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const StagePreview = styled.div`
  aspect-ratio: 16 / 9;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.5rem;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: ${props => props.inactive ? 0.5 : 1};
`;

const CheckMark = styled.div`
  font-size: 1.5rem;
`;

const Spinner = styled.div`
  width: 1.5rem;
  height: 1.5rem;
  border: 2px solid #7c3aed;
  border-top-color: transparent;
  border-radius: 50%;
`;

const StageName = styled.p`
  font-size: 0.75rem;
  color: #9ca3af;
  text-align: center;
`;

const GridSection = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
  min-height: 135px;
`;

const GridItem = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1rem;
`;

const GridTitle = styled.h4`
  font-weight: 500;
  margin-bottom: 0.5rem;
`;

const GridContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const MediaItem = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: center;
`;

const MediaIcon = styled.div`
  width: 2rem;
  height: 2rem;
  border-radius: 0.375rem;
  background-color: rgba(124, 58, 237, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
`;

const MediaInfo = styled.div`
  font-size: 0.875rem;
`;

const MediaTitle = styled.p`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const MediaDuration = styled.p`
  font-size: 0.75rem;
  color: #9ca3af;
`;

const TemplateIcon = styled(MediaIcon)`
  background: ${props => props.gradientBg || 'linear-gradient(to bottom right, #7c3aed, #db2777)'};
`;

const FeatureVideoGen = () => {
  return (
    <Container>
      <ContentSection>
        <Badge>
          <Circle />
          <span>Visual Learning</span>
        </Badge>
        <Title>AI Video Generation</Title>
        <Description>
          Transform complex topics into engaging educational videos with Foster's AI video generation. Our platform analyzes your study material and creates customized videos to enhance understanding and retention.
        </Description>
        <FeatureList>
          {[
            "Convert text notes to animated video explanations",
            "Visualize complex concepts with dynamic illustrations",
            "Generate step-by-step tutorial videos",
            "Create interactive problem-solving walkthroughs",
            "Customize video style and pacing to your preferences"
          ].map((item, index) => (
            <FeatureItem key={index}>
              <CheckIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </CheckIcon>
              <span>{item}</span>
            </FeatureItem>
          ))}
        </FeatureList>
        <div>
          <Button to="/auth">Generate Your First Video</Button>
        </div>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#eab308" />
              <WindowControl color="#22c55e" />
            </WindowControls>
            <WindowTitle>Video Generator</WindowTitle>
          </WindowHeader>
          
          <WindowContent>
            <VideoPreview>
              <VideoOverlay>
                <PlayButton>
                  <PlayButtonInner>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  </PlayButtonInner>
                </PlayButton>
              </VideoOverlay>
              <VideoGradient />
              <VideoInfo>
                <VideoTitle>Understanding Machine Learning Algorithms</VideoTitle>
                <VideoMeta>Generated video • 8:45</VideoMeta>
              </VideoInfo>
            </VideoPreview>
            
            <ProgressSection>
              <ProgressHeader>
                <ProgressTitle>Video Generation Progress</ProgressTitle>
                <ProgressValue>78%</ProgressValue>
              </ProgressHeader>
              
              <ProgressBar>
                <ProgressFill width="78%" />
              </ProgressBar>
              
              <StagesGrid>
                <StageItem>
                  <StagePreview>
                    <CheckMark>✓</CheckMark>
                  </StagePreview>
                  <StageName>Script</StageName>
                </StageItem>
                <StageItem>
                  <StagePreview>
                    <CheckMark>✓</CheckMark>
                  </StagePreview>
                  <StageName>Graphics</StageName>
                </StageItem>
                <StageItem>
                  <StagePreview>
                    <Spinner />
                  </StagePreview>
                  <StageName>Animation</StageName>
                </StageItem>
                <StageItem>
                  <StagePreview inactive>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect>
                      <circle cx="9" cy="9" r="2"></circle>
                      <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"></path>
                    </svg>
                  </StagePreview>
                  <StageName>Audio</StageName>
                </StageItem>
              </StagesGrid>
            </ProgressSection>
            
            <GridSection>
              <GridItem>
                <GridTitle>Recently Created</GridTitle>
                <GridContent>
                  <MediaItem>
                    <MediaIcon>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m22 8-6 4 6 4V8Z"></path>
                        <rect width="14" height="12" x="2" y="6" rx="2" ry="2"></rect>
                      </svg>
                    </MediaIcon>
                    <MediaInfo>
                      <MediaTitle>Data Structures</MediaTitle>
                      <MediaDuration>3:42</MediaDuration>
                    </MediaInfo>
                  </MediaItem>
                  <MediaItem>
                    <MediaIcon>
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m22 8-6 4 6 4V8Z"></path>
                        <rect width="14" height="12" x="2" y="6" rx="2" ry="2"></rect>
                      </svg>
                    </MediaIcon>
                    <MediaInfo>
                      <MediaTitle>Calculus Basics</MediaTitle>
                      <MediaDuration>5:15</MediaDuration>
                    </MediaInfo>
                  </MediaItem>
                </GridContent>
              </GridItem>
              
              <GridItem>
                <GridTitle>Templates</GridTitle>
                <GridContent>
                  <MediaItem>
                    <TemplateIcon gradientBg="linear-gradient(to bottom right, #7c3aed, #db2777)">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path>
                        <path d="M2 12h20"></path>
                      </svg>
                    </TemplateIcon>
                    <MediaInfo>
                      <MediaTitle>Animated Explainer</MediaTitle>
                    </MediaInfo>
                  </MediaItem>
                  <MediaItem>
                    <TemplateIcon gradientBg="linear-gradient(to bottom right, #3b82f6, #06b6d4)">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m2 7 5 5-5 5V7z"></path>
                        <path d="m17 7 5 5-5 5V7z"></path>
                        <path d="M12 22v-6"></path>
                        <path d="M12 8V2"></path>
                        <path d="M12 8a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"></path>
                        <path d="M12 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"></path>
                      </svg>
                    </TemplateIcon>
                    <MediaInfo>
                      <MediaTitle>Step-by-Step Tutorial</MediaTitle>
                    </MediaInfo>
                  </MediaItem>
                </GridContent>
              </GridItem>
            </GridSection>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

export default FeatureVideoGen; 