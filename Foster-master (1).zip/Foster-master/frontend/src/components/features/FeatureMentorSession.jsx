import React from "react";
import styled, { keyframes } from "styled-components";
import { Link } from "react-router-dom";

// Adding animation keyframes
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(79, 70, 229, 0.2);
  color: #818cf8;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #4f46e5;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #4f46e5;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #4f46e5;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #4338ca;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
  min-height: 580px;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(79, 70, 229, 0.2), rgba(67, 56, 202, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  height: 100%;
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const MentorGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1.5rem;
  height: 250px;
  overflow-y: auto;
`;

const MentorCard = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  transition: all 0.2s;
  border: 1px solid transparent;
  cursor: pointer;
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.08);
    transform: translateY(-4px);
    border-color: rgba(79, 70, 229, 0.3);
  }
`;

const MentorHeader = styled.div`
  display: flex;
  gap: 1rem;
  align-items: center;
`;

const MentorAvatar = styled.div`
  width: 3.5rem;
  height: 3.5rem;
  border-radius: 50%;
  overflow: hidden;
  background-color: #4f46e5;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: 600;
  font-size: 1.25rem;
  border: 2px solid rgba(79, 70, 229, 0.6);
`;

const MentorInfo = styled.div`
  flex: 1;
`;

const MentorName = styled.div`
  font-weight: 600;
  font-size: 1.125rem;
  margin-bottom: 0.25rem;
`;

const MentorTitle = styled.div`
  color: #9ca3af;
  font-size: 0.875rem;
`;

const MentorBio = styled.div`
  color: #d1d5db;
  font-size: 0.875rem;
  line-height: 1.5;
`;

const MentorStats = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-top: 0.5rem;
`;

const MentorStat = styled.div`
  display: flex;
  align-items: center;
  gap: 0.375rem;
  color: #9ca3af;
  font-size: 0.75rem;
`;

const MentorActions = styled.div`
  display: flex;
  gap: 0.75rem;
  margin-top: 0.5rem;
`;

const MentorButton = styled.button`
  flex: 1;
  padding: 0.5rem;
  background-color: ${props => props.primary ? 'rgba(79, 70, 229, 0.3)' : 'rgba(255, 255, 255, 0.05)'};
  color: ${props => props.primary ? '#818cf8' : '#d1d5db'};
  border: 1px solid ${props => props.primary ? 'rgba(79, 70, 229, 0.5)' : 'transparent'};
  border-radius: 0.375rem;
  font-size: 0.875rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.primary ? 'rgba(79, 70, 229, 0.4)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const SearchSection = styled.div`
  margin-bottom: 1.5rem;
`;

const SearchContainer = styled.div`
  display: flex;
  gap: 1rem;
`;

const SearchInput = styled.input`
  flex: 1;
  padding: 0.75rem 1rem;
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 0.5rem;
  color: white;
  outline: none;
  
  &:focus {
    border-color: #4f46e5;
  }
  
  &::placeholder {
    color: #9ca3af;
  }
`;

const FilterSelect = styled.select`
  padding: 0.75rem 1rem;
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 0.5rem;
  color: white;
  outline: none;
  
  &:focus {
    border-color: #4f46e5;
  }
`;

const DateSelector = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1.5rem;
  margin-top: 1.5rem;
  min-height: 135px;
`;

const DateTitle = styled.h4`
  font-weight: 500;
  margin-bottom: 1rem;
`;

const DateGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0.5rem;
`;

const DateCard = styled.div`
  padding: 0.75rem;
  text-align: center;
  border-radius: 0.5rem;
  background-color: ${props => props.active ? 'rgba(79, 70, 229, 0.2)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.active ? 'rgba(79, 70, 229, 0.3)' : 'transparent'};
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.active ? 'rgba(79, 70, 229, 0.3)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const DateDay = styled.div`
  font-size: 0.75rem;
  color: #9ca3af;
  margin-bottom: 0.25rem;
`;

const DateNumber = styled.div`
  font-weight: 600;
  margin-bottom: 0.25rem;
`;

const DateMonth = styled.div`
  font-size: 0.75rem;
  color: #9ca3af;
`;

const TimeList = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.5rem;
  margin-top: 1rem;
`;

const TimeSlot = styled.div`
  padding: 0.5rem;
  text-align: center;
  border-radius: 0.375rem;
  background-color: ${props => props.active ? 'rgba(79, 70, 229, 0.2)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.active ? 'rgba(79, 70, 229, 0.3)' : 'transparent'};
  font-size: 0.875rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.active ? 'rgba(79, 70, 229, 0.3)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const FeatureMentorSession = () => {
  return (
    <Container>
      <ContentSection>
        <Badge>
          <Circle />
          <span>Expert Guidance</span>
        </Badge>
        <Title>Connect with Mentors</Title>
        <Description>
          Get personalized advice and guidance from industry experts, professors, and accomplished students. Schedule one-on-one sessions to tackle challenging concepts or plan your academic journey.
        </Description>
        <FeatureList>
          {[
            "Connect with experts in your field of study",
            "Schedule one-on-one virtual mentoring sessions",
            "Get personalized feedback on your work",
            "Access a diverse network of mentors from various disciplines",
            "Build lasting professional relationships"
          ].map((item, index) => (
            <FeatureItem key={index}>
              <CheckIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </CheckIcon>
              <span>{item}</span>
            </FeatureItem>
          ))}
        </FeatureList>
        <div>
          <Button to="/auth">Find Your Mentor</Button>
        </div>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#eab308" />
              <WindowControl color="#22c55e" />
            </WindowControls>
            <WindowTitle>Mentor Connections</WindowTitle>
          </WindowHeader>
          
          <WindowContent>
            <SearchSection>
              <SearchContainer>
                <SearchInput placeholder="Search mentors by expertise or name..." />
                <FilterSelect>
                  <option value="">All Subjects</option>
                  <option value="cs">Computer Science</option>
                  <option value="math">Mathematics</option>
                  <option value="physics">Physics</option>
                  <option value="biology">Biology</option>
                </FilterSelect>
              </SearchContainer>
            </SearchSection>
            
            <MentorGrid>
              <MentorCard>
                <MentorHeader>
                  <MentorAvatar>DR</MentorAvatar>
                  <MentorInfo>
                    <MentorName>Dr. Rachel Chen</MentorName>
                    <MentorTitle>Machine Learning Researcher</MentorTitle>
                  </MentorInfo>
                </MentorHeader>
                <MentorBio>
                  Former Google AI researcher with 10+ years of experience in machine learning and neural networks. Specialized in helping students master complex ML concepts.
                </MentorBio>
                <MentorStats>
                  <MentorStat>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5z"></path>
                    </svg>
                    <span>4.9 (128 reviews)</span>
                  </MentorStat>
                  <MentorStat>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                      <path d="M12 6v6l4 2"></path>
                    </svg>
                    <span>345 sessions</span>
                  </MentorStat>
                </MentorStats>
                <MentorActions>
                  <MentorButton primary>Book Session</MentorButton>
                  <MentorButton>View Profile</MentorButton>
                </MentorActions>
              </MentorCard>
              
              <MentorCard>
                <MentorHeader>
                  <MentorAvatar>JM</MentorAvatar>
                  <MentorInfo>
                    <MentorName>Prof. James Martin</MentorName>
                    <MentorTitle>Quantum Physics Professor</MentorTitle>
                  </MentorInfo>
                </MentorHeader>
                <MentorBio>
                  Physics professor at MIT with expertise in quantum mechanics and theoretical physics. Passionate about making complex concepts accessible to students.
                </MentorBio>
                <MentorStats>
                  <MentorStat>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11.48 3.499a.562.562 0 0 1 1.04 0l2.125 5.111a.563.563 0 0 0 .475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 0 0-.182.557l1.285 5.385a.562.562 0 0 1-.84.61l-4.725-2.885a.562.562 0 0 0-.586 0L6.982 20.54a.562.562 0 0 1-.84-.61l1.285-5.386a.562.562 0 0 0-.182-.557l-4.204-3.602a.562.562 0 0 1 .321-.988l5.518-.442a.563.563 0 0 0 .475-.345L11.48 3.5z"></path>
                    </svg>
                    <span>4.8 (87 reviews)</span>
                  </MentorStat>
                  <MentorStat>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                      <path d="M12 6v6l4 2"></path>
                    </svg>
                    <span>203 sessions</span>
                  </MentorStat>
                </MentorStats>
                <MentorActions>
                  <MentorButton primary>Book Session</MentorButton>
                  <MentorButton>View Profile</MentorButton>
                </MentorActions>
              </MentorCard>
            </MentorGrid>
            
            <DateSelector>
              <DateTitle>Available Sessions with Dr. Rachel Chen</DateTitle>
              <DateGrid>
                {[
                  { day: "Mon", date: "15", month: "May", active: false },
                  { day: "Tue", date: "16", month: "May", active: false },
                  { day: "Wed", date: "17", month: "May", active: true },
                  { day: "Thu", date: "18", month: "May", active: false },
                ].map((date, index) => (
                  <DateCard key={index} active={date.active}>
                    <DateDay>{date.day}</DateDay>
                    <DateNumber>{date.date}</DateNumber>
                    <DateMonth>{date.month}</DateMonth>
                  </DateCard>
                ))}
              </DateGrid>
              
              <TimeList>
                {[
                  { time: "9:00 AM", active: false },
                  { time: "11:30 AM", active: false },
                  { time: "1:00 PM", active: true },
                  { time: "3:30 PM", active: false },
                  { time: "5:00 PM", active: false },
                  { time: "6:30 PM", active: false },
                ].map((slot, index) => (
                  <TimeSlot key={index} active={slot.active}>
                    {slot.time}
                  </TimeSlot>
                ))}
              </TimeList>
            </DateSelector>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

export default FeatureMentorSession; 