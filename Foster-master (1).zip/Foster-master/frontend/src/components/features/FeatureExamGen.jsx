import React from "react";
import styled, { keyframes } from "styled-components";
import { Link } from "react-router-dom";

// Adding animation keyframes
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(245, 158, 11, 0.2);
  color: #fcd34d;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #f59e0b;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #f59e0b;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #f59e0b;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #d97706;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
  min-height: 580px;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(245, 158, 11, 0.2), rgba(234, 88, 12, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  height: 100%;
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const ExamPreviewContainer = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1.5rem;
  height: 250px;
  overflow-y: auto;
`;

const ExamHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1.5rem;
  gap: 1rem;
`;

const ExamTitle = styled.div`
  font-weight: 600;
  font-size: 1.25rem;
`;

const ExamMeta = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
`;

const ExamMetaItem = styled.div`
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.875rem;
  color: #9ca3af;
`;

const Question = styled.div`
  margin-bottom: 1.5rem;
`;

const QuestionHeader = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
`;

const QuestionNumber = styled.div`
  font-weight: 600;
  color: #f59e0b;
`;

const QuestionText = styled.div`
  font-weight: 500;
  line-height: 1.5;
`;

const OptionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  margin-left: 1.5rem;
`;

const Option = styled.div`
  display: flex;
  gap: 0.75rem;
  align-items: flex-start;
  padding: 0.75rem;
  border-radius: 0.5rem;
  background-color: ${props => props.selected ? 'rgba(245, 158, 11, 0.15)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.selected ? 'rgba(245, 158, 11, 0.3)' : 'transparent'};
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.selected ? 'rgba(245, 158, 11, 0.2)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const OptionMarker = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 1.5rem;
  height: 1.5rem;
  border-radius: 50%;
  background-color: ${props => props.selected ? 'rgba(245, 158, 11, 0.3)' : 'rgba(255, 255, 255, 0.1)'};
  color: ${props => props.selected ? '#f59e0b' : '#fff'};
  font-weight: 500;
  font-size: 0.875rem;
`;

const OptionText = styled.div`
  flex: 1;
`;

const ExamControls = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 2rem;
`;

const ControlButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  border-radius: 0.5rem;
  font-weight: 500;
  transition: all 0.2s;
  border: none;
  cursor: pointer;
  background-color: ${props => props.primary ? '#f59e0b' : 'rgba(255, 255, 255, 0.1)'};
  color: ${props => props.primary ? 'white' : '#d1d5db'};
  
  &:hover {
    background-color: ${props => props.primary ? '#d97706' : 'rgba(255, 255, 255, 0.15)'};
  }
`;

const ExamSettings = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1rem;
  min-height: 135px;
`;

const SettingsTitle = styled.h4`
  font-weight: 500;
  color: var(--white);
  margin-bottom: 1rem;
`;

const SettingsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
`;

const SettingItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const SettingLabel = styled.label`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const SettingSelect = styled.select`
  padding: 0.5rem;
  border-radius: 0.375rem;
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 0.875rem;
  outline: none;
  
  &:focus {
    border-color: #f59e0b;
  }
`;

const FeatureExamGen = () => {
  return (
    <Container>
      <ContentSection>
        <Badge>
          <Circle />
          <span>Test Preparation</span>
        </Badge>
        <Title>AI Exam Generator</Title>
        <Description>
          Create customized exams and assessments tailored to your specific learning needs. Foster analyzes your course materials and generates relevant questions to help you prepare for any test.
        </Description>
        <FeatureList>
          {[
            "Generate questions based on your study materials",
            "Adjust difficulty level to match your exam requirements",
            "Create multiple exam formats (MCQ, essay, fill-in-the-blank)",
            "Receive detailed explanations for each answer",
            "Track your performance across practice exams"
          ].map((item, index) => (
            <FeatureItem key={index}>
              <CheckIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </CheckIcon>
              <span>{item}</span>
            </FeatureItem>
          ))}
        </FeatureList>
        <div>
          <Button to="/auth">Create Your First Exam</Button>
        </div>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#eab308" />
              <WindowControl color="#22c55e" />
            </WindowControls>
            <WindowTitle>AI Exam Generator</WindowTitle>
          </WindowHeader>
          
          <WindowContent>
            <ExamPreviewContainer>
              <ExamHeader>
                <ExamTitle>Neural Networks Practice Exam</ExamTitle>
                <ExamMeta>
                  <ExamMetaItem>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
                      <path d="M12 6V12L16 14"></path>
                    </svg>
                    <span>20 minutes</span>
                  </ExamMetaItem>
                  <ExamMetaItem>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                      <polyline points="14 2 14 8 20 8"></polyline>
                    </svg>
                    <span>10 questions</span>
                  </ExamMetaItem>
                </ExamMeta>
              </ExamHeader>
              
              <Question>
                <QuestionHeader>
                  <QuestionNumber>1.</QuestionNumber>
                  <QuestionText>Which of the following is NOT an activation function commonly used in neural networks?</QuestionText>
                </QuestionHeader>
                <OptionsContainer>
                  <Option>
                    <OptionMarker>A</OptionMarker>
                    <OptionText>ReLU (Rectified Linear Unit)</OptionText>
                  </Option>
                  <Option>
                    <OptionMarker>B</OptionMarker>
                    <OptionText>Sigmoid</OptionText>
                  </Option>
                  <Option selected>
                    <OptionMarker selected>C</OptionMarker>
                    <OptionText>Quadratic Function</OptionText>
                  </Option>
                  <Option>
                    <OptionMarker>D</OptionMarker>
                    <OptionText>Tanh (Hyperbolic Tangent)</OptionText>
                  </Option>
                </OptionsContainer>
              </Question>
              
              <Question>
                <QuestionHeader>
                  <QuestionNumber>2.</QuestionNumber>
                  <QuestionText>What is the primary purpose of backpropagation in neural networks?</QuestionText>
                </QuestionHeader>
                <OptionsContainer>
                  <Option>
                    <OptionMarker>A</OptionMarker>
                    <OptionText>To initialize weights randomly</OptionText>
                  </Option>
                  <Option selected>
                    <OptionMarker selected>B</OptionMarker>
                    <OptionText>To update weights based on error gradients</OptionText>
                  </Option>
                  <Option>
                    <OptionMarker>C</OptionMarker>
                    <OptionText>To normalize input data</OptionText>
                  </Option>
                  <Option>
                    <OptionMarker>D</OptionMarker>
                    <OptionText>To prevent overfitting</OptionText>
                  </Option>
                </OptionsContainer>
              </Question>
              
              <ExamControls>
                <ControlButton>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m12 19-7-7 7-7"></path>
                    <path d="M19 12H5"></path>
                  </svg>
                  <span>Previous</span>
                </ControlButton>
                <span>2 of 10</span>
                <ControlButton primary>
                  <span>Next</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m12 5 7 7-7 7"></path>
                    <path d="M5 12h14"></path>
                  </svg>
                </ControlButton>
              </ExamControls>
            </ExamPreviewContainer>
            
            <ExamSettings>
              <SettingsTitle>Exam Generation Settings</SettingsTitle>
              <SettingsGrid>
                <SettingItem>
                  <SettingLabel>Difficulty Level</SettingLabel>
                  <SettingSelect>
                    <option>Beginner</option>
                    <option selected>Intermediate</option>
                    <option>Advanced</option>
                    <option>Expert</option>
                  </SettingSelect>
                </SettingItem>
                <SettingItem>
                  <SettingLabel>Question Type</SettingLabel>
                  <SettingSelect>
                    <option selected>Multiple Choice</option>
                    <option>True/False</option>
                    <option>Fill in the Blank</option>
                    <option>Short Answer</option>
                  </SettingSelect>
                </SettingItem>
                <SettingItem>
                  <SettingLabel>Number of Questions</SettingLabel>
                  <SettingSelect>
                    <option>5</option>
                    <option selected>10</option>
                    <option>15</option>
                    <option>20</option>
                  </SettingSelect>
                </SettingItem>
                <SettingItem>
                  <SettingLabel>Time Limit</SettingLabel>
                  <SettingSelect>
                    <option>10 minutes</option>
                    <option selected>20 minutes</option>
                    <option>30 minutes</option>
                    <option>No Limit</option>
                  </SettingSelect>
                </SettingItem>
              </SettingsGrid>
            </ExamSettings>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

export default FeatureExamGen; 