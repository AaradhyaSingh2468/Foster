import React, { useState, useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { toast, Toaster } from "react-hot-toast";
import studyBuddyService from "../../services/studyBuddyService";
import { useAuth } from "../../hooks/useAuth";

// Adding animation keyframes to simulate framer-motion effects
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(124, 58, 237, 0.2);
  color: #d4b5ff;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #a78bfa;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #7c3aed;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #7c3aed;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #6d28d9;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(124, 58, 237, 0.2), rgba(59, 130, 246, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const ChatContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const MessageRow = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  ${props => props.isUser && 'justify-content: flex-end;'}
`;

const Avatar = styled.div`
  width: 2rem;
  height: 2rem;
  border-radius: 50%;
  background-color: ${props => props.isAI ? '#7c3aed' : '#4b5563'};
  display: flex;
  align-items: center;
  justify-content: center;
`;

const MessageBubble = styled.div`
  background-color: ${props => props.type === 'user' ? 'rgba(124, 58, 237, 0.2)' : 'rgba(255, 255, 255, 0.05)'};
  padding: 1rem;
  border-radius: 1rem;
  ${props => props.type === 'user' ? 'border-top-right-radius: 0;' : 'border-top-left-radius: 0;'}
  color: ${props => props.type === 'error' ? '#ef4444' : 'white'};
  max-width: ${props => props.type === 'user' ? '24rem' : 'auto'};
  flex: 1;
`;

const InputContainer = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
  width: 100%;
`;

const FileUploadContainer = styled.div`
  display: flex;
  gap: 0.5rem;
  align-items: center;
  width: 100%;
`;

const UploadButton = styled.button`
  padding: 0.75rem 1.5rem;
  background-color: #7c3aed;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background-color: #6d28d9;
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

const ProgressContainer = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1rem;
`;

const ProgressHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5rem;
`;

const ProgressTitle = styled.h4`
  font-weight: 500;
  color: var(--white);
`;

const ProgressTimestamp = styled.span`
  font-size: 0.75rem;
  color: #a78bfa;
`;

const ProgressItems = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const ProgressItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
`;

const ProgressLabel = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: 0.875rem;
`;

const ProgressBar = styled.div`
  width: 100%;
  height: 0.5rem;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 9999px;
`;

const ProgressFill = styled.div`
  height: 0.5rem;
  border-radius: 9999px;
  background-color: ${props => props.color};
  width: ${props => props.width};
`;

const QuestionInput = styled.div`
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
`;

const Input = styled.input`
  flex: 1;
  padding: 0.75rem;
  border-radius: 0.5rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background-color: rgba(255, 255, 255, 0.05);
  color: white;
  font-size: 0.875rem;

  &:focus {
    outline: none;
    border-color: #7c3aed;
  }
`;

const SendButton = styled.button`
  padding: 0.75rem 1.5rem;
  background-color: #7c3aed;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background-color: #6d28d9;
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

const FeatureAIStudy = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentDocumentId, setCurrentDocumentId] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState("");
  const { user, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) {
      toast.error("Please sign in to use the Study Buddy");
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const pathname = window.location.pathname;
    const match = pathname.match(/\/study-sets\/([^\/]+)/);
    if (match) {
      setCurrentDocumentId(match[1]);
    }
  }, []);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast.error("Please select a PDF file");
        return;
      }
      setSelectedFile(file);
      toast.success(`Selected file: ${file.name}`);
    }
  };

  const handleUpload = async () => {
    if (!user) {
      toast.error("Please sign in to upload documents");
      navigate("/login");
      return;
    }

    if (!selectedFile) {
      toast.error("Please select a file first");
      return;
    }

    setIsLoading(true);
    try {
      const response = await studyBuddyService.uploadDocument(selectedFile);
      setCurrentDocumentId(response.documentId);
      toast.success("File uploaded successfully!");
      setMessages([
        {
          type: "system",
          content: "Document uploaded successfully. You can now ask questions about it!"
        }
      ]);
    } catch (error) {
      console.error("Upload error:", error);
      toast.error(error.message || "Failed to upload file");
      if (error.message?.includes("sign in")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAskQuestion = async (question) => {
    if (!user) {
      toast.error("Please sign in to ask questions");
      navigate("/login");
      return;
    }

    if (!question.trim()) {
      toast.error("Please enter a question");
      return;
    }

    setIsLoading(true);
    try {
      const userMessage = { type: "user", content: question };
      setMessages(prev => [...prev, userMessage]);

      console.log(`Asking question with documentId: ${currentDocumentId}`);
      const response = await studyBuddyService.askQuestion(question, currentDocumentId);

      const aiMessage = {
        type: "ai",
        content: response.answer,
        sources: response.sources
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error asking question:", error);
      toast.error(error.message || "Failed to get an answer");
      
      const errorMessage = {
        type: "error",
        content: error.message || "Sorry, I couldn't process your question. Please try again."
      };
      setMessages(prev => [...prev, errorMessage]);

      if (error.message?.includes("sign in")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
      setCurrentQuestion("");
    }
  };

  const handleQuestionSubmit = async (e) => {
    e.preventDefault();
    await handleAskQuestion(currentQuestion);
  };

  return (
    <Container>
      <Toaster position="top-right" />
      <ContentSection>
        <Badge>
          <Circle />
          AI-Powered Study Assistant
        </Badge>
        <Title>Your Personal Study Buddy</Title>
        <Description>
          Upload your study materials and let our AI help you understand them better.
          Ask questions, generate flashcards, and create practice exams.
        </Description>
        <FeatureList>
          <FeatureItem>
            <CheckIcon>✓</CheckIcon>
            <div>
              <strong>Document Processing</strong>
              <p>Upload PDFs and get instant access to AI-powered study tools</p>
            </div>
          </FeatureItem>
          <FeatureItem>
            <CheckIcon>✓</CheckIcon>
            <div>
              <strong>Smart Q&A</strong>
              <p>Get detailed answers to your questions with source references</p>
            </div>
          </FeatureItem>
          <FeatureItem>
            <CheckIcon>✓</CheckIcon>
            <div>
              <strong>Flashcard Generation</strong>
              <p>Create custom flashcards for any topic in your materials</p>
            </div>
          </FeatureItem>
          <FeatureItem>
            <CheckIcon>✓</CheckIcon>
            <div>
              <strong>Practice Exams</strong>
              <p>Generate and take practice exams with AI-powered grading</p>
            </div>
            </FeatureItem>
        </FeatureList>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#f59e0b" />
              <WindowControl color="#10b981" />
            </WindowControls>
            <WindowTitle>StudyBuddy AI Chat</WindowTitle>
          </WindowHeader>
          <WindowContent>
            <ChatContainer>
              {messages.map((message, index) => (
                <MessageRow key={index} isUser={message.type === "user"}>
                  <MessageBubble type={message.type}>
                    {message.content}
                    {message.sources && message.sources.length > 0 && (
                      <SourcesContainer>
                        <SourcesTitle>Sources:</SourcesTitle>
                        {message.sources.map((source, idx) => (
                          <SourceItem key={idx}>
                            {source.content}
                            {source.metadata && (
                              <SourceMetadata>
                                {source.metadata.page && `Page ${source.metadata.page}`}
                                {source.metadata.source && ` - ${source.metadata.source}`}
                              </SourceMetadata>
                            )}
                          </SourceItem>
                        ))}
                      </SourcesContainer>
                    )}
                  </MessageBubble>
                </MessageRow>
              ))}
              {isLoading && (
                <MessageRow>
                  <MessageBubble type="ai">
                    <LoadingDots>Thinking</LoadingDots>
                  </MessageBubble>
                </MessageRow>
              )}
            </ChatContainer>

            <form onSubmit={handleQuestionSubmit}>
              <InputContainer>
                {!currentDocumentId ? (
                  <FileUploadContainer>
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={handleFileSelect}
                      style={{ display: "none" }}
                      id="file-upload"
                    />
                    <label htmlFor="file-upload">
                      <UploadButton type="button">
                        Choose PDF
                      </UploadButton>
                    </label>
                    {selectedFile && (
                      <UploadButton type="button" onClick={handleUpload} disabled={isLoading}>
                        {isLoading ? "Uploading..." : "Upload"}
                      </UploadButton>
                    )}
                  </FileUploadContainer>
                ) : (
                  <>
                    <Input
                      type="text"
                      placeholder="Ask a question about your document..."
                      value={currentQuestion}
                      onChange={(e) => setCurrentQuestion(e.target.value)}
                      disabled={isLoading}
                    />
                    <SendButton type="submit" disabled={isLoading || !currentQuestion.trim()}>
                      Send
                    </SendButton>
                  </>
                )}
              </InputContainer>
            </form>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

// Styled components for new features
const SourcesContainer = styled.div`
  margin-top: 0.5rem;
  padding-top: 0.5rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
`;

const SourcesTitle = styled.div`
  font-size: 0.75rem;
  color: #9ca3af;
  margin-bottom: 0.25rem;
`;

const SourceItem = styled.div`
  font-size: 0.875rem;
  color: #d1d5db;
  margin-bottom: 0.25rem;
  padding: 0.25rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 0.25rem;
`;

const SourceMetadata = styled.div`
  font-size: 0.75rem;
  color: #9ca3af;
  margin-top: 0.25rem;
`;

const LoadingDots = styled.div`
  &:after {
    content: '...';
    animation: dots 1.5s steps(5, end) infinite;
  }

  @keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60% { content: '...'; }
    80%, 100% { content: ''; }
  }
`;

export default FeatureAIStudy; 