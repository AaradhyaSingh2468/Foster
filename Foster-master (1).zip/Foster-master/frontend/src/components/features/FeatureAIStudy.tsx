import React, { useState, useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { Link, useNavigate } from "react-router-dom";
import { toast, Toaster } from "react-hot-toast";
import studyBuddyService from "../../services/studyBuddyService";
import { useAuth } from "../../hooks/useAuth";
import type { StudyBuddyResponse } from "../../services/types";

interface Message {
  type: 'user' | 'ai' | 'system' | 'error';
  content: string;
  sources?: Array<{
    content: string;
    metadata?: {
      page?: number;
      source?: string;
    };
  }>;
}

// ... existing styled components ...

const FeatureAIStudy: React.FC<{}> = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentDocumentId, setCurrentDocumentId] = useState<string | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState("");
  const { user, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) {
      toast.error("Please sign in to use the Study Buddy");
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const pathname = window.location.pathname;
    const match = pathname.match(/\/study-sets\/([^\/]+)/);
    if (match) {
      setCurrentDocumentId(match[1]);
    }
  }, []);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast.error("Please select a PDF file");
        return;
      }
      setSelectedFile(file);
      toast.success(`Selected file: ${file.name}`);
    }
  };

  const handleUpload = async () => {
    if (!user) {
      toast.error("Please sign in to upload documents");
      navigate("/login");
      return;
    }

    if (!selectedFile) {
      toast.error("Please select a file first");
      return;
    }

    setIsLoading(true);
    try {
      const response: StudyBuddyResponse = await studyBuddyService.uploadDocument(selectedFile);
      if (response.documentId) {
        setCurrentDocumentId(response.documentId);
        toast.success("File uploaded successfully!");
        setMessages([
          {
            type: "system",
            content: "Document uploaded successfully. You can now ask questions about it!"
          }
        ]);
      } else {
        throw new Error("No document ID received from server");
      }
    } catch (error) {
      console.error("Upload error:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to upload file";
      toast.error(errorMessage);
      if (errorMessage.includes("sign in")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAskQuestion = async (question: string) => {
    if (!user) {
      toast.error("Please sign in to ask questions");
      navigate("/login");
      return;
    }

    if (!question.trim()) {
      toast.error("Please enter a question");
      return;
    }

    setIsLoading(true);
    try {
      const userMessage: Message = { type: "user", content: question };
      setMessages(prev => [...prev, userMessage]);

      console.log(`Asking question with documentId: ${currentDocumentId}`);
      const response: StudyBuddyResponse = await studyBuddyService.askQuestion(question, currentDocumentId);

      if (!response.answer) {
        throw new Error("No answer received from server");
      }

      const aiMessage: Message = {
        type: "ai",
        content: response.answer,
        sources: response.sources
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error asking question:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to get an answer";
      toast.error(errorMessage);
      
      const errorMsg: Message = {
        type: "error",
        content: errorMessage
      };
      setMessages(prev => [...prev, errorMsg]);

      if (errorMessage.includes("sign in")) {
        navigate("/login");
      }
    } finally {
      setIsLoading(false);
      setCurrentQuestion("");
    }
  };

  const handleQuestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleAskQuestion(currentQuestion);
  };

  return (
    // ... existing JSX ...
    <div>Component JSX here</div>
  );
};

export default FeatureAIStudy; 