import React from "react";
import styled, { keyframes } from "styled-components";
import { Link } from "react-router-dom";

// Adding animation keyframes
const fadeInUp = keyframes`
  from { 
    opacity: 0; 
    transform: translateY(20px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
`;

const scaleIn = keyframes`
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
`;

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 3rem;
  align-items: center;
  margin-top: 2rem;
  
  @media (min-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }
`;

const ContentSection = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  animation: ${fadeInUp} 0.5s ease-out forwards;
`;

const Badge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  background-color: rgba(16, 185, 129, 0.2);
  color: #6ee7b7;
  font-size: 0.875rem;
  font-weight: 500;
`;

const Circle = styled.span`
  width: 0.5rem;
  height: 0.5rem;
  background-color: #10b981;
  border-radius: 50%;
`;

const Title = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  color: var(--white);
  
  @media (min-width: 768px) {
    font-size: 2.5rem;
  }
`;

const Description = styled.p`
  font-size: 1.125rem;
  color: #d1d5db;
  line-height: 1.6;
`;

const FeatureList = styled.ul`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const FeatureItem = styled.li`
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
`;

const CheckIcon = styled.div`
  min-width: 1.25rem;
  min-height: 1.25rem;
  background-color: #10b981;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 0.25rem;
`;

const Button = styled(Link)`
  padding: 0.75rem 1.5rem;
  background-color: #10b981;
  color: white;
  font-weight: 500;
  border-radius: 0.5rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  
  &:hover {
    background-color: #059669;
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.98);
  }
`;

const PreviewContainer = styled.div`
  position: relative;
  animation: ${scaleIn} 0.5s ease-out forwards;
  animation-delay: 0.2s;
  opacity: 0;
  animation-fill-mode: forwards;
  min-height: 580px;
`;

const GlowEffect = styled.div`
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.2));
  border-radius: 1.5rem;
  filter: blur(1.5rem);
  z-index: -1;
`;

const PreviewWindow = styled.div`
  background-color: #1a1830;
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1.5rem;
  overflow: hidden;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  height: 100%;
`;

const WindowHeader = styled.div`
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const WindowControls = styled.div`
  display: flex;
  gap: 0.375rem;
`;

const WindowControl = styled.div`
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 50%;
  background-color: ${props => props.color};
`;

const WindowTitle = styled.div`
  font-size: 0.875rem;
  color: #9ca3af;
`;

const WindowContent = styled.div`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const FlashcardContainer = styled.div`
  perspective: 1000px;
  width: 100%;
  height: 250px;
`;

const FlashcardInner = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;
  transition: transform 0.8s;
  transform-style: preserve-3d;
  transform: ${props => props.flipped ? 'rotateY(180deg)' : 'rotateY(0)'};
`;

const FlashcardFace = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  border-radius: 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-color: ${props => props.back 
    ? 'rgba(16, 185, 129, 0.15)' 
    : 'rgba(255, 255, 255, 0.05)'
  };
  border: 1px solid ${props => props.back 
    ? 'rgba(16, 185, 129, 0.3)' 
    : 'rgba(255, 255, 255, 0.1)'
  };
  transform: ${props => props.back ? 'rotateY(180deg)' : 'rotateY(0)'};
`;

const FlashcardNumber = styled.div`
  position: absolute;
  top: 1rem;
  left: 1rem;
  font-size: 0.875rem;
  color: ${props => props.back ? '#10b981' : '#9ca3af'};
`;

const FlashcardText = styled.div`
  font-size: ${props => props.isQuestion ? '1.5rem' : '1.25rem'};
  font-weight: ${props => props.isQuestion ? '600' : '400'};
  line-height: 1.6;
  max-width: 90%;
`;

const FlashcardTip = styled.div`
  position: absolute;
  bottom: 1rem;
  right: 1rem;
  font-size: 0.75rem;
  color: #9ca3af;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const FlashcardControls = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const FlashcardButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.625rem 1rem;
  border-radius: 0.5rem;
  font-weight: 500;
  transition: all 0.2s;
  border: none;
  cursor: pointer;
  background-color: ${props => props.primary ? '#10b981' : 'rgba(255, 255, 255, 0.1)'};
  color: ${props => props.primary ? 'white' : '#d1d5db'};
  
  &:hover {
    background-color: ${props => props.primary ? '#059669' : 'rgba(255, 255, 255, 0.15)'};
  }
`;

const FlashcardAction = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 3rem;
  height: 3rem;
  border-radius: 50%;
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: #d1d5db;
  transition: all 0.2s;
  cursor: pointer;
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }
`;

const DeckSelector = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 0.75rem;
  padding: 1rem;
  min-height: 135px;
`;

const DeckHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const DeckTitle = styled.h4`
  font-weight: 500;
  color: var(--white);
`;

const DeckDescription = styled.p`
  color: #9ca3af;
  font-size: 0.875rem;
  margin-bottom: 1rem;
`;

const DeckGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.75rem;
`;

const DeckItem = styled.div`
  padding: 1rem;
  border-radius: 0.5rem;
  background-color: ${props => props.active ? 'rgba(16, 185, 129, 0.15)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.active ? 'rgba(16, 185, 129, 0.3)' : 'transparent'};
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background-color: ${props => props.active ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255, 255, 255, 0.08)'};
  }
`;

const DeckName = styled.div`
  font-weight: 500;
  margin-bottom: 0.25rem;
`;

const DeckMeta = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: 0.75rem;
  color: #9ca3af;
`;

const FeatureFlashcards = () => {
  return (
    <Container>
      <ContentSection>
        <Badge>
          <Circle />
          <span>Memory Retention</span>
        </Badge>
        <Title>Smart Flashcards</Title>
        <Description>
          Boost your memory and retention with AI-powered flashcards that adapt to your learning patterns. Foster analyzes your performance to prioritize cards you struggle with and optimize your study sessions.
        </Description>
        <FeatureList>
          {[
            "AI-generated flashcards from your study materials",
            "Spaced repetition system for optimal memory retention",
            "Real-time difficulty adjustment based on your performance",
            "Rich media support including images and diagrams",
            "Sync across all your devices for studying anywhere"
          ].map((item, index) => (
            <FeatureItem key={index}>
              <CheckIcon>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </CheckIcon>
              <span>{item}</span>
            </FeatureItem>
          ))}
        </FeatureList>
        <div>
          <Button to="/auth">Start Creating Flashcards</Button>
        </div>
      </ContentSection>
      
      <PreviewContainer>
        <GlowEffect />
        <PreviewWindow>
          <WindowHeader>
            <WindowControls>
              <WindowControl color="#ef4444" />
              <WindowControl color="#eab308" />
              <WindowControl color="#22c55e" />
            </WindowControls>
            <WindowTitle>Smart Flashcards</WindowTitle>
          </WindowHeader>
          
          <WindowContent>
            <FlashcardContainer>
              <FlashcardInner flipped={false}>
                <FlashcardFace>
                  <FlashcardNumber>Card 3 of 20</FlashcardNumber>
                  <FlashcardText isQuestion>
                    What is the main purpose of backpropagation in neural networks?
                  </FlashcardText>
                  <FlashcardTip>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M2 12h10"></path>
                      <path d="m9 4 8 8-8 8"></path>
                      <path d="M22 12h-4"></path>
                    </svg>
                    <span>Click to flip card</span>
                  </FlashcardTip>
                </FlashcardFace>
                <FlashcardFace back>
                  <FlashcardNumber back>Card 3 of 20</FlashcardNumber>
                  <FlashcardText>
                    Backpropagation is an algorithm used to train neural networks by calculating gradients of the error function with respect to network weights, allowing the network to learn by updating weights to minimize error.
                  </FlashcardText>
                </FlashcardFace>
              </FlashcardInner>
            </FlashcardContainer>
            
            <FlashcardControls>
              <FlashcardButton>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m12 19-7-7 7-7"></path>
                  <path d="M19 12H5"></path>
                </svg>
                <span>Previous</span>
              </FlashcardButton>
              
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <FlashcardAction>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M9 11V8a3 3 0 1 1 6 0v3"></path>
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
                  </svg>
                </FlashcardAction>
                <FlashcardAction>
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M2 12h10"></path>
                    <path d="m9 4 8 8-8 8"></path>
                    <path d="M22 12h-4"></path>
                  </svg>
                </FlashcardAction>
              </div>
              
              <FlashcardButton primary>
                <span>Next</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m12 5 7 7-7 7"></path>
                  <path d="M5 12h14"></path>
                </svg>
              </FlashcardButton>
            </FlashcardControls>
            
            <DeckSelector>
              <DeckHeader>
                <DeckTitle>Your Flashcard Decks</DeckTitle>
              </DeckHeader>
              <DeckDescription>Select a deck to study or create a new one from your notes</DeckDescription>
              <DeckGrid>
                <DeckItem active>
                  <DeckName>Neural Networks</DeckName>
                  <DeckMeta>
                    <span>20 cards</span>
                    <span>75% mastered</span>
                  </DeckMeta>
                </DeckItem>
                <DeckItem>
                  <DeckName>Machine Learning Algorithms</DeckName>
                  <DeckMeta>
                    <span>42 cards</span>
                    <span>32% mastered</span>
                  </DeckMeta>
                </DeckItem>
                <DeckItem>
                  <DeckName>Data Structures</DeckName>
                  <DeckMeta>
                    <span>36 cards</span>
                    <span>90% mastered</span>
                  </DeckMeta>
                </DeckItem>
                <DeckItem>
                  <DeckName>+ Create New Deck</DeckName>
                  <DeckMeta>
                    <span>From notes or manually</span>
                  </DeckMeta>
                </DeckItem>
              </DeckGrid>
            </DeckSelector>
          </WindowContent>
        </PreviewWindow>
      </PreviewContainer>
    </Container>
  );
};

export default FeatureFlashcards; 