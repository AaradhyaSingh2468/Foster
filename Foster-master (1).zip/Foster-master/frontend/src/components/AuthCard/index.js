import React, { useState, useRef, useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import * as userService from '../../services/userService';

// Attempt to import the toast clearing function
let clearAllToasts;
try {
  // First approach: try direct import
  clearAllToasts = require("../../study-dashboard/lib/useToast").clearAllToasts;
} catch (e) {
  // Fallback: use window global if available
  if (typeof window !== 'undefined' && window.clearAllToasts) {
    clearAllToasts = window.clearAllToasts;
  } else {
    // Create a dummy function if not available
    clearAllToasts = () => {
      console.warn("Toast clear function not available");
    };
  }
}

const scaleIn = keyframes`
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
`;

const slideInRight = keyframes`
  from { opacity: 0; transform: translateX(30px); }
  to { opacity: 1; transform: translateX(0); }
`;

const slideOutLeft = keyframes`
  from { opacity: 1; transform: translateX(0); }
  to { opacity: 0; transform: translateX(-30px); }
`;

const Card = styled.div`
  width: 100%;
  max-width: 500px;
  background-color: rgba(30, 30, 40, 0.95);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  animation: ${scaleIn} 0.4s ease-out;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Title = styled.h2`
  color: var(--white);
  font-size: 1.8rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
  text-align: center;
`;

const Subtitle = styled.p`
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
  text-align: center;
  margin-bottom: 2rem;
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
`;

const Input = styled.input`
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 0.8rem 1rem;
  color: var(--white);
  font-size: 1rem;
  outline: none;
  
  &:focus {
    border-color: var(--purple);
  }
  
  &::placeholder {
    color: rgba(255, 255, 255, 0.4);
  }
`;

const SubmitButton = styled.button`
  background-color: var(--purple);
  border: none;
  border-radius: 8px;
  padding: 0.8rem;
  color: var(--white);
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  position: relative;
  
  &:hover:not(:disabled) {
    transform: translateY(-2px);
    background-color: #a55aff;
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
  
  &:after {
    content: "";
    display: ${props => props.disabled ? 'block' : 'none'};
    position: absolute;
    width: 18px;
    height: 18px;
    top: calc(50% - 9px);
    left: calc(50% - 9px);
    border: 2px solid transparent;
    border-top-color: var(--white);
    border-radius: 50%;
    animation: buttonSpinner 0.8s linear infinite;
  }
`;

const Divider = styled.div`
  position: relative;
  margin: 1.5rem 0;
  text-align: center;
  
  &:before {
    content: "";
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background-color: rgba(255, 255, 255, 0.1);
  }
  
  span {
    position: relative;
    background-color: rgba(30, 30, 40, 0.95);
    padding: 0 1rem;
    font-size: 0.8rem;
    color: rgba(255, 255, 255, 0.6);
  }
`;

const SocialButtonsContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-top: 0.5rem;
`;

const SocialButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  background-color: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 0.7rem;
  color: var(--white);
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  
  svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
  }
  
  &:hover:not(:disabled) {
    background-color: rgba(255, 255, 255, 0.1);
    transform: translateY(-2px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  &:after {
    content: "";
    display: ${props => props.disabled ? 'block' : 'none'};
    position: absolute;
    width: 16px;
    height: 16px;
    top: calc(50% - 8px);
    left: calc(50% - 8px);
    border: 2px solid transparent;
    border-top-color: var(--white);
    border-radius: 50%;
    animation: buttonSpinner 0.8s linear infinite;
  }
  
  @keyframes buttonSpinner {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`;

const ToggleText = styled.p`
  text-align: center;
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
  margin-top: 1.5rem;
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: var(--purple);
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  padding-left: 0.5rem;
  
  &:hover {
    color: #a55aff;
  }
`;

const FormContainer = styled.div`
  transition: all 0.3s ease-out;
  
  &.entering {
    animation: ${slideInRight} 0.3s ease-out forwards;
  }
  
  &.exiting {
    animation: ${slideOutLeft} 0.3s ease-out forwards;
  }
`;

const ErrorMessage = styled.div`
  color: #ff6b6b;
  font-size: 0.9rem;
  margin-top: 0.5rem;
  text-align: center;
`;

const SuccessMessage = styled.div`
  color: #51cf66;
  font-size: 0.9rem;
  margin-top: 0.5rem;
  text-align: center;
`;

const AuthCard = ({ initialMode = "signin" }) => {
  const [mode, setMode] = useState(initialMode);
  const [animationState, setAnimationState] = useState("entered");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [isNewUser, setIsNewUser] = useState(false);
  
  const { 
    signInWithEmail, 
    signUpWithEmail, 
    signInWithGoogle, 
    signInWithGithub, 
    loading, 
    // eslint-disable-next-line no-unused-vars
    error, 
    currentUser 
  } = useAuth();
  
  const navigate = useNavigate();
  const formRef = useRef(null);

  // Clear messages when changing modes
  useEffect(() => {
    setErrorMessage("");
    setSuccessMessage("");
  }, [mode]);

  // Clear toast messages when user logs in
  useEffect(() => {
    if (currentUser) {
      // Memoize the toast clearing function to avoid dependency issues
      const clearToasts = () => {
        try {
          if (clearAllToasts) {
            clearAllToasts();
          } else if (window.clearAllToasts) {
            window.clearAllToasts();
          } else if (window.dispatchToastAction) {
            window.dispatchToastAction({
              type: "REMOVE_TOAST",
              id: "all"
            });
          }
        } catch (err) {
          console.error("Error clearing toasts:", err);
        }
      };
      
      // Call the function
      clearToasts();
      
      // Check for signup intent in localStorage
      const signupIntent = localStorage.getItem('signupIntent') === 'true';
      console.log('Auth completed - Local storage signupIntent:', signupIntent);
      
      // Check for onboarding bypass in URL
      const url = new URL(window.location.href);
      const skipOnboarding = url.searchParams.get('skip_onboarding') === 'true';
      if (skipOnboarding) {
        console.log('Detected skip_onboarding flag, setting bypass...');
        localStorage.setItem('bypass_onboarding', 'true');
      }
      
      // Additional check: If this is a new user from Google, check their profile
      const checkOnboardingStatus = async () => {
        try {
          // Check for bypass flag
          const bypassOnboarding = localStorage.getItem('bypass_onboarding') === 'true';
          if (bypassOnboarding) {
            console.log('Bypassing onboarding check due to bypass flag');
            return false; // Skip onboarding
          }
          
          // Debug: Check auth status with backend
          try {
            const authStatus = await userService.checkAuthStatus();
            console.log('Auth status check:', authStatus);
          } catch (authError) {
            console.error('Auth status check failed, continuing with profile check:', authError);
          }
          
          // Get token from localStorage
          const token = localStorage.getItem('accessToken');
          if (!token) {
            console.error('No access token found for profile check');
            return true; // Default to requiring onboarding if no token
          }
          
          // Check for signup intent in localStorage - this is set for new users
          const signupIntent = localStorage.getItem('signupIntent') === 'true';
          
          // If this is explicitly marked as a new signup, always go to onboarding
          if (signupIntent) {
            console.log('Signup intent detected, user needs onboarding');
            return true;
          }
          
          // Get cached user data
          const userJson = localStorage.getItem('user');
          let userData = null;
          if (userJson) {
            try {
              userData = JSON.parse(userJson);
            } catch (e) {
              console.error('Error parsing user data:', e);
            }
          }
          
          // Ensure we're using the correct API URL
          const apiUrl = '/api/users/profile/';
          console.log('Fetching user profile from:', apiUrl);
          
          // Fetch the user's profile from the backend
          const response = await fetch(apiUrl, {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          
          // If profile request failed
          if (!response.ok) {
            console.warn(`Profile API returned ${response.status} from ${apiUrl}`);
            // If we have user data, assume they've completed onboarding already
            if (userData) {
              console.log('Profile API failed but user data exists, assuming onboarding completed');
              return false; // Don't need onboarding
            }
            // No user data and profile request failed = need onboarding
            return true;
          }
          
          // Successfully got the profile
          const userProfile = await response.json();
          console.log('User profile check result:', userProfile);
          console.log('Token used for profile fetch:', token.substring(0, 15) + '...');
          console.log('onboarding_completed value:', userProfile.onboarding_completed);
          console.log('onboarding_completed type:', typeof userProfile.onboarding_completed);
          
          // FORCE FIX: If this is a returning user with profile but onboarding_completed doesn't exist
          // Automatically set it to true to fix broken flows
          if (userProfile && 
              userProfile._id && 
              userProfile.onboarding_completed === undefined) {
            console.log('Found profile but onboarding_completed is missing - automatically fixing');
            
            // Try to update the profile to set onboarding_completed = true
            try {
              const updateResponse = await fetch(apiUrl, {
                method: 'PUT',
                headers: {
                  'Authorization': `Bearer ${token}`,
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  ...userProfile,
                  onboarding_completed: true
                })
              });
              
              if (updateResponse.ok) {
                console.log('Successfully updated profile with onboarding_completed=true');
              } else {
                console.error('Failed to update profile:', await updateResponse.text());
              }
            } catch (updateError) {
              console.error('Error updating profile:', updateError);
            }
            
            // Return false to bypass onboarding regardless of the update success
            return false;
          }
          
          // Check if onboarding is explicitly marked as completed (the source of truth)
          if (userProfile.onboarding_completed === true || 
              userProfile.onboarding_completed === 'true' || 
              userProfile.onboarding_completed === 'True') {
            console.log('User profile indicates onboarding is completed');
            return false; // Don't need onboarding
          }
          
          // If onboarding is explicitly marked as not completed
          if (userProfile.onboarding_completed === false || 
              userProfile.onboarding_completed === 'false' || 
              userProfile.onboarding_completed === 'False' || 
              userProfile.onboarding_completed === null || 
              userProfile.onboarding_completed === undefined) {
            console.log('User profile indicates onboarding is NOT completed');
            return true; // Need onboarding
          }
          
          // If we have a profile but onboarding status is null/undefined,
          // check if it's likely a returning user (has profile data)
          if (userProfile && 
              (userProfile.bio || userProfile.institution || userProfile.major)) {
            console.log('User has profile data, assuming onboarding completed');
            return false; // Has profile data, don't need onboarding
          }
          
          // Default fallback - go to onboarding to be safe
          console.log('No definitive onboarding status, defaulting to requiring onboarding');
          return true;
        } catch (error) {
          console.error('Error checking onboarding status:', error);
          // Default to dashboard for returning users, onboarding for new or uncertain cases
          return !localStorage.getItem('user'); // Need onboarding only if no user data
        }
      };
      
      const effectiveIsNewUser = signupIntent || isNewUser;
      
      setSuccessMessage("Authentication successful! Redirecting...");
      
      // First check profile, then redirect based on combined information
      checkOnboardingStatus().then(needsOnboarding => {
      setTimeout(() => {
        // Clear the signup intent
        localStorage.removeItem('signupIntent');
        
          // Redirect to onboarding if this is a new user OR onboarding not completed, otherwise go to dashboard
          if (effectiveIsNewUser || needsOnboarding) {
            console.log('Redirecting to onboarding - isNewUser:', effectiveIsNewUser, 'needsOnboarding:', needsOnboarding);
          navigate("/onboarding", { state: { isFromAuth: true } });
        } else {
            console.log('Redirecting to dashboard - isNewUser:', effectiveIsNewUser, 'needsOnboarding:', needsOnboarding);
          navigate("/study-dashboard");
        }
      }, 1500);
      });
    }
  }, [currentUser, navigate, isNewUser]);

  // Clear any toast messages when component mounts
  useEffect(() => {
    // Remove the logout toast flag when the login screen is shown
    localStorage.removeItem('logout_toast_shown');
    
    // Try to clear all toast notifications when auth card mounts
    // This ensures we don't see logout toast when returning to login screen
    try {
      if (clearAllToasts) {
        clearAllToasts();
      } else if (window.clearAllToasts) {
        window.clearAllToasts();
      } else if (window.dispatchToastAction) {
        window.dispatchToastAction({
          type: "REMOVE_TOAST",
          id: "all"
        });
      }
    } catch (err) {
      console.error("Error clearing toasts on mount:", err);
    }
  }, []);

  const validateForm = () => {
    setErrorMessage("");
    
    if (!email || !password) {
      setErrorMessage("Email and password are required.");
      return false;
    }
    
    if (mode === "signup") {
      if (password !== confirmPassword) {
        setErrorMessage("Passwords do not match.");
        return false;
      }
      
      if (password.length < 6) {
        setErrorMessage("Password must be at least 6 characters.");
        return false;
      }
    }
    
    return true;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      if (mode === "signin") {
        await signInWithEmail(email, password);
        setIsNewUser(false);
      } else {
        // Set signup intent in localStorage
        localStorage.setItem('signupIntent', 'true');
        await signUpWithEmail(email, password);
        setIsNewUser(true);
        // Here you would typically also update the user profile with their name
      }
    } catch (err) {
      console.error("Auth error:", err);
      setErrorMessage(err.message || "An error occurred during authentication.");
    }
  };

  const handleModeToggle = () => {
    if (animationState !== "entered" || loading) return;
    
    setAnimationState("exiting");
    
    setTimeout(() => {
      setMode(mode === "signin" ? "signup" : "signin");
      setAnimationState("entering");
      // Reset form fields
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setName("");
    }, 300);
    
    setTimeout(() => {
      setAnimationState("entered");
    }, 600);
  };

  const handleGoogleSignIn = async () => {
    try {
      // Check if we're already in signup mode with a flag to preserve isNewUser status
      const inSignupMode = mode === "signup";
      
      // Store signup intent in localStorage if in signup mode
      if (inSignupMode) {
        localStorage.setItem('signupIntent', 'true');
      } else {
        // Make sure to remove any previous signup intent if signing in
        localStorage.removeItem('signupIntent');
      }
      
      const result = await signInWithGoogle();
      
      // Log the result to help with debugging
      console.log("Google sign-in result:", result);
      
      // Check if user is new using various methods
      let isNewUser = false;
      
        // First try to check if user is new using additionalUserInfo
        if (result?.additionalUserInfo) {
        isNewUser = result.additionalUserInfo.isNewUser;
        console.log("User is new (additionalUserInfo):", isNewUser);
        } else if (result?.user) {
          // Fallback: Check metadata - if creation time and last sign-in time are close,
          // it's likely a new user (within 5 seconds)
          const user = result.user;
          const metadata = user.metadata;
        isNewUser = 
            metadata.creationTime && 
            metadata.lastSignInTime &&
          (Math.abs(new Date(metadata.creationTime).getTime() - new Date(metadata.lastSignInTime).getTime()) < 5000);
        console.log("User is new (metadata check):", isNewUser);
        }
      
      // Also check if we set the signup intent from signup mode
      if (inSignupMode) {
        isNewUser = true;
        console.log("User is new (signup intent):", isNewUser);
      }
      
      setIsNewUser(isNewUser);
      
      // Don't automatically redirect - let the useEffect handle redirections
      return result;
    } catch (err) {
      console.error("Google auth error:", err);
      setErrorMessage(err.message || "Error signing in with Google.");
    }
  };

  const handleGitHubSignIn = async () => {
    console.log("Starting GitHub authentication process...");
    try {
      // Check if we're already in signup mode with a flag to preserve isNewUser status
      const inSignupMode = mode === "signup";
      console.log("Sign-in mode:", inSignupMode ? "signup" : "signin");
      
      console.log("Calling signInWithGithub...");
      const result = await signInWithGithub();
      console.log("GitHub authentication result:", result);
      
      // Only determine if user is new if we're not in signup mode
      // In signup mode, isNewUser has already been set to true by getSocialSignupHandler
      if (!inSignupMode) {
        // First try to check if user is new using additionalUserInfo
        if (result?.additionalUserInfo) {
          setIsNewUser(result.additionalUserInfo.isNewUser);
          console.log("User is new (additionalUserInfo):", result.additionalUserInfo.isNewUser);
        } else if (result?.user) {
          // Fallback: Check metadata - if creation time and last sign-in time are close,
          // it's likely a new user (within 5 seconds)
          const user = result.user;
          const metadata = user.metadata;
          const isNewUser = 
            metadata.creationTime && 
            metadata.lastSignInTime &&
            (new Date(metadata.creationTime).getTime() - new Date(metadata.lastSignInTime).getTime() < 5000);
          setIsNewUser(isNewUser);
          console.log("User is new (metadata check):", isNewUser);
          console.log("User metadata:", metadata);
        }
      }
    } catch (err) {
      console.error("GitHub auth error:", err);
      console.error("Error object details:", JSON.stringify({
        code: err.code,
        message: err.message,
        name: err.name,
        stack: err.stack
      }, null, 2));
      
      // Display more user-friendly error messages based on the error code
      if (err.code === 'auth/account-exists-with-different-credential') {
        // The error.customData.email will contain the email of the account
        const email = err.customData?.email;
        
        if (email) {
          setEmail(email); // Set the email field with the existing email
          setMode("signin"); // Switch to signin mode to let the user sign in with original method
          setErrorMessage(
            "This email is already associated with an existing account. " +
            "Please sign in with your original method (Google or Email/Password), " +
            "then you can link your GitHub account from your profile settings."
          );
        } else {
          setErrorMessage("This email is already registered with a different sign-in method. Please use that method instead.");
        }
      } else if (err.code === 'auth/popup-closed-by-user') {
        setErrorMessage("You closed the sign-in window before completing. Please try again.");
      } else if (err.code === 'auth/popup-blocked') {
        setErrorMessage("Pop-up blocked. Please allow pop-ups for this website and try again.");
      } else if (err.code === 'auth/cancelled-popup-request') {
        setErrorMessage("Multiple sign-in attempts detected. Please try again.");
      } else if (err.code === 'auth/operation-not-allowed') {
        setErrorMessage("GitHub sign-in is not available at this time. Please try another method.");
      } else if (err.code === 'auth/invalid-credential') {
        setErrorMessage("Invalid GitHub credentials. Please try again or use another sign-in method.");
      } else {
        setErrorMessage(err.message || "Error signing in with GitHub. Please try again later.");
      }
    }
  };

  // Helper function to handle signup intent for social auth
  const getSocialSignupHandler = (originalHandler) => {
    return async () => {
      try {
        // Store signup intent in localStorage to persist through auth state changes
        localStorage.setItem('signupIntent', 'true');
        // Set component state for immediate use
        setIsNewUser(true);
        await originalHandler();
      } catch (err) {
        console.error("Social signup error:", err);
        setErrorMessage(err.message || "Error during social sign up.");
        throw err;
      }
    };
  };

  return (
    <Card>
      <Title>{mode === "signin" ? "Welcome back" : "Create account"}</Title>
      <Subtitle>
        {mode === "signin" 
          ? "Sign in to continue to Foster" 
          : "Sign up to get started with Foster"}
      </Subtitle>
      
      {errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
      {successMessage && <SuccessMessage>{successMessage}</SuccessMessage>}
      
      <FormContainer 
        ref={formRef}
        className={animationState}
      >
        <Form onSubmit={handleSubmit}>
          {mode === "signup" && (
            <FormGroup>
              <Label htmlFor="name">Name</Label>
              <Input 
                id="name" 
                placeholder="Enter your name" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={loading}
              />
            </FormGroup>
          )}
          
          <FormGroup>
            <Label htmlFor="email">Email</Label>
            <Input 
              id="email" 
              type="email" 
              placeholder="Enter your email" 
              autoComplete={mode === "signin" ? "email" : "new-email"}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
            />
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="password">Password</Label>
            <Input 
              id="password" 
              type="password" 
              placeholder={mode === "signin" ? "Enter your password" : "Create a password"}
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
            />
          </FormGroup>

          {mode === "signup" && (
            <FormGroup>
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input 
                id="confirmPassword" 
                type="password" 
                placeholder="Confirm your password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                disabled={loading}
              />
            </FormGroup>
          )}
          
          <SubmitButton type="submit" disabled={loading}>
            {loading ? "" : mode === "signin" ? "Sign In" : "Create Account"}
          </SubmitButton>

          <Divider>
            <span>Or continue with</span>
          </Divider>

          <SocialButtonsContainer>
            <SocialButton 
              type="button" 
              onClick={mode === "signup" ? getSocialSignupHandler(handleGoogleSignIn) : handleGoogleSignIn}
              disabled={loading}
            >
              {!loading && (
                <>
                  <svg viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"
                    />
                  </svg>
                  Google
                </>
              )}
            </SocialButton>
            <SocialButton 
              type="button"
              onClick={mode === "signup" ? getSocialSignupHandler(handleGitHubSignIn) : handleGitHubSignIn}
              disabled={loading}
            >
              {!loading && (
                <>
                  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 0C5.374 0 0 5.373 0 12C0 17.302 3.438 21.8 8.207 23.387C8.806 23.498 9 23.126 9 22.81V20.576C5.662 21.302 4.967 19.16 4.967 19.16C4.421 17.773 3.634 17.404 3.634 17.404C2.545 16.659 3.717 16.675 3.717 16.675C4.922 16.759 5.556 17.912 5.556 17.912C6.626 19.746 8.363 19.216 9.048 18.909C9.155 18.134 9.466 17.604 9.81 17.305C7.145 17 4.343 15.971 4.343 11.374C4.343 10.063 4.812 8.993 5.579 8.153C5.455 7.85 5.044 6.629 5.696 4.977C5.696 4.977 6.704 4.655 8.997 6.207C9.954 5.941 10.98 5.808 12 5.803C13.02 5.808 14.047 5.941 15.006 6.207C17.297 4.655 18.303 4.977 18.303 4.977C18.956 6.63 18.545 7.851 18.421 8.153C19.191 8.993 19.656 10.064 19.656 11.374C19.656 15.983 16.849 16.998 14.177 17.295C14.607 17.667 15 18.397 15 19.517V22.81C15 23.129 15.192 23.504 15.801 23.386C20.566 21.797 24 17.3 24 12C24 5.373 18.627 0 12 0Z" fill="currentColor"/>
                  </svg>
                  GitHub
                </>
              )}
            </SocialButton>
          </SocialButtonsContainer>
        </Form>
      </FormContainer>
      
      <ToggleText>
        {mode === "signin" ? "Don't have an account?" : "Already have an account?"}
        <ToggleButton onClick={handleModeToggle} disabled={loading}>
          {mode === "signin" ? "Sign up" : "Sign in"}
        </ToggleButton>
      </ToggleText>
    </Card>
  );
};

export default AuthCard; 