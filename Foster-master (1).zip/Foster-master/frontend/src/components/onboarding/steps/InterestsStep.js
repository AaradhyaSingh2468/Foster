import React from 'react';
import styled, { keyframes, css } from 'styled-components';
import OnboardingLayout from '../OnboardingLayout';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const StepContainer = styled.div`
  animation: ${props => props.direction === 'forward' 
    ? css`${fadeIn} 0.3s ease-out forwards` 
    : css`${fadeIn} 0.3s ease-out forwards`};
`;

const InterestsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 0.75rem;
  
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
  }
`;

const InterestOption = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  border-radius: 0.5rem;
  background-color: rgba(255, 255, 255, 0.05);
  transition: all 0.2s ease;
  cursor: pointer;
  
  &:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }
`;

const CheckboxContainer = styled.div`
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  position: relative;
`;

const HiddenCheckbox = styled.input.attrs({ type: 'checkbox' })`
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
`;

const StyledCheckbox = styled.div`
  width: 20px;
  height: 20px;
  background-color: ${props => props.checked ? 'var(--purple)' : 'transparent'};
  border: 2px solid ${props => props.checked ? 'var(--purple)' : 'rgba(255, 255, 255, 0.3)'};
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: ${props => props.checked ? 'var(--purple)' : 'rgba(255, 255, 255, 0.5)'};
  }
`;

const CheckIcon = styled.div`
  color: white;
  visibility: ${props => props.checked ? 'visible' : 'hidden'};
  
  svg {
    width: 14px;
    height: 14px;
  }
`;

const Label = styled.label`
  font-size: 0.95rem;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
`;

const InterestsStep = () => {
  const { onboardingData, updateOnboardingData, direction } = useOnboarding();
  
  // Predefined topics based on the reference design
  const interests = [
    { id: 'mathematics', label: 'Mathematics' },
    { id: 'physics', label: 'Physics' },
    { id: 'chemistry', label: 'Chemistry' },
    { id: 'biology', label: 'Biology' },
    { id: 'english', label: 'English' },
    { id: 'literature', label: 'Literature' },
    { id: 'history', label: 'History' },
    { id: 'programming', label: 'Programming' },
    { id: 'art', label: 'Art & Design' },
    { id: 'music', label: 'Music' },
    { id: 'economics', label: 'Economics' },
    { id: 'business', label: 'Business' },
    { id: 'psychology', label: 'Psychology' },
    { id: 'sociology', label: 'Sociology' },
    { id: 'health', label: 'Health & Fitness' },
    { id: 'language', label: 'Foreign Languages' },
  ];
  
  const toggleInterest = (interestId) => {
    const currentInterests = [...(onboardingData.interests || [])];
    const exists = currentInterests.includes(interestId);
    
    if (exists) {
      updateOnboardingData({
        interests: currentInterests.filter(item => item !== interestId)
      });
    } else {
      updateOnboardingData({
        interests: [...currentInterests, interestId]
      });
    }
  };

  return (
    <StepContainer direction={direction}>
      <OnboardingLayout 
        title="Select your topics of interest"
        description="Choose topics you'd like to explore (select at least one)"
        canContinue={(onboardingData.interests && onboardingData.interests.length > 0)}
      >
        <InterestsGrid>
          {interests.map((interest) => (
            <InterestOption 
              key={interest.id}
              onClick={() => toggleInterest(interest.id)}
            >
              <CheckboxContainer>
                <HiddenCheckbox 
                  checked={onboardingData.interests && onboardingData.interests.includes(interest.id)}
                  readOnly
                />
                <StyledCheckbox checked={onboardingData.interests && onboardingData.interests.includes(interest.id)}>
                  <CheckIcon checked={onboardingData.interests && onboardingData.interests.includes(interest.id)}>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </CheckIcon>
                </StyledCheckbox>
              </CheckboxContainer>
              <Label>{interest.label}</Label>
            </InterestOption>
          ))}
        </InterestsGrid>
      </OnboardingLayout>
    </StepContainer>
  );
};

export default InterestsStep; 