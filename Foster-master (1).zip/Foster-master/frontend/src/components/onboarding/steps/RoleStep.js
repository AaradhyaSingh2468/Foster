import React from 'react';
import styled, { keyframes, css } from 'styled-components';
import OnboardingLayout from '../OnboardingLayout';
import OnboardingOption from '../OnboardingOption';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';

// SVG Icons for each role
const GraduationCap = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 4L3 9L12 14L21 9L12 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M3 9V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 14V20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M20 10.5V15C20 16.6569 16.4183 18 12 18C7.58172 18 4 16.6569 4 15V9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const School = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M22 9L12 5L2 9L12 13L22 9Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M6 11.5V16.5C6 18 8.5 19.5 12 19.5C15.5 19.5 18 18 18 16.5V11.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Briefcase = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="7" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16 7V5C16 3.89543 15.1046 3 14 3H10C8.89543 3 8 3.89543 8 5V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 12V15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9 12H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const User = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 21V19C20 16.7909 18.2091 15 16 15H8C5.79086 15 4 16.7909 4 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const StepContainer = styled.div`
  animation: ${props => props.direction === 'forward' 
    ? css`${fadeIn} 0.4s ease-out forwards` 
    : css`${fadeIn} 0.4s ease-out forwards`};
`;

const OptionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const RoleStep = () => {
  const { onboardingData, updateOnboardingData, direction, UserRoles } = useOnboarding();
  
  const roles = [
    {
      id: UserRoles.STUDENT,
      title: 'Student',
      icon: <GraduationCap />,
      description: 'Currently enrolled in school or university',
    },
    {
      id: UserRoles.TEACHER,
      title: 'Teacher',
      icon: <School />,
      description: 'Educator at any level of education',
    },
    {
      id: UserRoles.PROFESSIONAL,
      title: 'Professional',
      icon: <Briefcase />,
      description: 'Looking to enhance skills for your career',
    },
    {
      id: UserRoles.PARENT,
      title: 'Parent',
      icon: <User />,
      description: 'Supporting a child\'s education',
    },
    {
      id: UserRoles.OTHER,
      title: 'Other',
      icon: <User />,
      description: 'None of the above applies to me',
    },
  ];

  const handleSelectRole = (role) => {
    updateOnboardingData({ role });
  };

  return (
    <StepContainer direction={direction}>
      <OnboardingLayout 
        title="Tell us about yourself"
        description="Help us tailor your learning experience"
        showBackButton={false}
        canContinue={!!onboardingData.role}
      >
        <OptionsContainer>
          {roles.map((role, index) => (
            <OnboardingOption
              key={role.id}
              id={role.id}
              icon={role.icon}
              title={role.title}
              description={role.description}
              selected={onboardingData.role === role.id}
              onClick={handleSelectRole}
              index={index}
            />
          ))}
        </OptionsContainer>
      </OnboardingLayout>
    </StepContainer>
  );
};

export default RoleStep; 