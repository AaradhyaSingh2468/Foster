import React from 'react';
import styled from 'styled-components';
import OnboardingLayout from '../OnboardingLayout';
import OnboardingOption from '../OnboardingOption';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';

// SVG Icons for each learning style
const Visual = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 12C2 12 5 5 12 5C19 5 22 12 22 12C22 12 19 19 12 19C5 19 2 12 2 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Reading = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4 19.5C4 18.837 4.26339 18.2011 4.73223 17.7322C5.20107 17.2634 5.83696 17 6.5 17H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M6.5 2H20V22H6.5C5.83696 22 5.20107 21.7366 4.73223 21.2678C4.26339 20.7989 4 20.163 4 19.5V4.5C4 3.83696 4.26339 3.20107 4.73223 2.73223C5.20107 2.26339 5.83696 2 6.5 2V2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Interactive = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 5L19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Auditory = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16 8C16 8 18 10.5 18 12C18 13.5 16 16 16 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 8C8 8 6 10.5 6 12C6 13.5 8 16 8 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 3V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Kinesthetic = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M21 16V8.00002C20.9996 7.6493 20.9071 7.30483 20.7315 7.00119C20.556 6.69754 20.3037 6.44539 20 6.27002L12 2.27002C11.696 2.09449 11.3511 2.00204 11 2.00204C10.6489 2.00204 10.304 2.09449 10 2.27002L2 6.27002C1.69626 6.44539 1.44398 6.69754 1.26846 7.00119C1.09294 7.30483 1.00036 7.6493 1 8.00002V16C1.00036 16.3508 1.09294 16.6952 1.26846 16.9989C1.44398 17.3025 1.69626 17.5547 2 17.73L10 21.73C10.304 21.9056 10.6489 21.998 11 21.998C11.3511 21.998 11.696 21.9056 12 21.73L20 17.73C20.3037 17.5547 20.556 17.3025 20.7315 16.9989C20.9071 16.6952 20.9996 16.3508 21 16Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M1.27002 6.96002L11 12.01L20.73 6.96002" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M11 22.08V12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const StepContainer = styled.div`
  animation: ${props => props.direction === 'forward' ? 'slideInRight' : 'slideInLeft'} 0.3s ease-out;
  
  @keyframes slideInRight {
    from { transform: translateX(20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideInLeft {
    from { transform: translateX(-20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;

const OptionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const LearningStyleStep = () => {
  const { onboardingData, updateOnboardingData, direction, LearningStyles } = useOnboarding();
  
  const styles = [
    {
      id: LearningStyles.VISUAL,
      label: 'Visual',
      icon: <Visual />,
      description: 'Learn best through images, videos, and diagrams',
    },
    {
      id: LearningStyles.READING,
      label: 'Reading/Writing',
      icon: <Reading />,
      description: 'Prefer reading text and taking notes',
    },
    {
      id: LearningStyles.INTERACTIVE,
      label: 'Interactive',
      icon: <Interactive />,
      description: 'Learn through quizzes and hands-on exercises',
    },
    {
      id: LearningStyles.AUDITORY,
      label: 'Auditory',
      icon: <Auditory />,
      description: 'Learn best through listening and discussion',
    },
    {
      id: LearningStyles.KINESTHETIC,
      label: 'Kinesthetic',
      icon: <Kinesthetic />,
      description: 'Prefer learning by doing and physical activities',
    },
  ];

  const handleSelectStyle = (style) => {
    updateOnboardingData({ learningStyle: style });
  };

  return (
    <StepContainer direction={direction}>
      <OnboardingLayout 
        title="How do you prefer to learn?"
        description="Select the learning style that works best for you"
        canContinue={!!onboardingData.learningStyle}
      >
        <OptionsContainer>
          {styles.map((style) => (
            <OnboardingOption
              key={style.id}
              id={style.id}
              icon={style.icon}
              label={style.label}
              description={style.description}
              selected={onboardingData.learningStyle === style.id}
              onClick={() => handleSelectStyle(style.id)}
            />
          ))}
        </OptionsContainer>
      </OnboardingLayout>
    </StepContainer>
  );
};

export default LearningStyleStep; 