import React from 'react';
import styled from 'styled-components';
import OnboardingLayout from '../OnboardingLayout';
import OnboardingOption from '../OnboardingOption';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';

// SVG Icons for each learning goal
const Academic = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M22 10V6C22 4.89543 21.1046 4 20 4H4C2.89543 4 2 4.89543 2 6V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 10V18C2 19.1046 2.89543 20 4 20H20C21.1046 20 22 19.1046 22 18V10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 10H22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 4V20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Career = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="2" y="7" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16 7V5C16 3.89543 15.1046 3 14 3H10C8.89543 3 8 3.89543 8 5V7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="12" y1="12" x2="12" y2="15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="9" y1="12" x2="15" y2="12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Personal = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 21V19C20 16.7909 18.2091 15 16 15H8C5.79086 15 4 16.7909 4 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="12" cy="7" r="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Certification = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 15C15.866 15 19 11.866 19 8C19 4.13401 15.866 1 12 1C8.13401 1 5 4.13401 5 8C5 11.866 8.13401 15 12 15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8.21 13.89L7 23L12 20L17 23L15.79 13.88" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Other = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 17V17.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 14C11.9816 13.3495 12.2672 12.7235 12.7793 12.3012C13.2914 11.8789 13.5 11.5899 13.5 11.0004C13.5 10.4108 13.0899 9.93631 12.5 9.86578C11.9203 9.79724 11.3681 10.0566 11.1213 10.5645C10.8744 11.0725 10.4602 11.4221 10.0143 11.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const StepContainer = styled.div`
  animation: ${props => props.direction === 'forward' ? 'slideInRight' : 'slideInLeft'} 0.3s ease-out;
  
  @keyframes slideInRight {
    from { transform: translateX(20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideInLeft {
    from { transform: translateX(-20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;

const OptionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const GoalStep = () => {
  const { onboardingData, updateOnboardingData, direction, LearningGoals } = useOnboarding();
  
  const goals = [
    {
      id: LearningGoals.ACADEMIC,
      label: 'Academic Growth',
      icon: <Academic />,
      description: 'Improve grades or academic performance',
    },
    {
      id: LearningGoals.CAREER,
      label: 'Career Advancement',
      icon: <Career />,
      description: 'Develop job-related skills or for a promotion',
    },
    {
      id: LearningGoals.PERSONAL,
      label: 'Personal Interest',
      icon: <Personal />,
      description: 'Learn for fun or personal enrichment',
    },
    {
      id: LearningGoals.CERTIFICATION,
      label: 'Certification',
      icon: <Certification />,
      description: 'Prepare for a specific certification or exam',
    },
    {
      id: LearningGoals.OTHER,
      label: 'Other',
      icon: <Other />,
      description: 'I have a different learning goal',
    },
  ];

  const handleSelectGoal = (goal) => {
    updateOnboardingData({ learningGoal: goal });
  };

  return (
    <StepContainer direction={direction}>
      <OnboardingLayout 
        title="What's your learning goal?"
        description="Tell us what you're hoping to achieve"
        canContinue={!!onboardingData.learningGoal}
      >
        <OptionsContainer>
          {goals.map((goal) => (
            <OnboardingOption
              key={goal.id}
              id={goal.id}
              icon={goal.icon}
              label={goal.label}
              description={goal.description}
              selected={onboardingData.learningGoal === goal.id}
              onClick={() => handleSelectGoal(goal.id)}
            />
          ))}
        </OptionsContainer>
      </OnboardingLayout>
    </StepContainer>
  );
};

export default GoalStep; 