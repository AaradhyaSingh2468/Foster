import React, { useEffect, useState } from 'react';
import styled, { keyframes } from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';
import { useAuth } from '../../../context/AuthContext';
import AnimatedBackground from '../AnimatedBackground';
import * as userService from '../../../services/userService';
import api from '../../../config/api';

// Access the global onboardingMemory if it exists
const setOnboardingComplete = () => {
  try {
    if (window.onboardingMemory && typeof window.onboardingMemory.setCompleted === 'function') {
      window.onboardingMemory.setCompleted();
      console.log('Set completion in global onboardingMemory');
    }
  } catch (e) {
    console.warn('Could not access global onboardingMemory:', e);
  }
};

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulse = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
`;

const Container = styled.div`
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  background-color: #0F0F0F;
  color: white;
  position: relative;
  overflow: hidden;
  text-align: center;
`;

const ContentWrapper = styled.div`
  max-width: 600px;
  z-index: 10;
  animation: ${fadeIn} 0.6s ease-out;
`;

const CheckmarkContainer = styled.div`
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #9B46FF 0%, #6E00FF 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 2rem;
  box-shadow: 0 0 30px rgba(155, 70, 255, 0.4);
  animation: ${pulse} 2s infinite ease-in-out;
`;

const Checkmark = () => (
  <svg width="60" height="60" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6L9 17L4 12" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const Title = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 1rem;
  background: linear-gradient(to right, #9B46FF, #FF56B1);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
`;

const Description = styled.p`
  font-size: 1.2rem;
  margin-bottom: 2rem;
  color: rgba(255, 255, 255, 0.8);
  line-height: 1.6;
`;

const DetailCard = styled.div`
  background-color: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 1rem;
  padding: 1.5rem;
  margin-bottom: 2rem;
  text-align: left;
  max-width: 500px;
  
  h3 {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    color: rgba(255, 255, 255, 0.9);
  }
  
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  li {
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    
    &:before {
      content: '•';
      color: var(--purple);
      margin-right: 0.5rem;
      font-size: 1.5rem;
      line-height: 1;
    }
  }
`;

const Button = styled.button`
  background: linear-gradient(135deg, #9B46FF 0%, #6E00FF 100%);
  border: none;
  border-radius: 2rem;
  padding: 1rem 2.5rem;
  font-size: 1.2rem;
  font-weight: 600;
  color: white;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 1rem;
  box-shadow: 0 4px 20px rgba(155, 70, 255, 0.4);
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 25px rgba(155, 70, 255, 0.6);
  }
  
  &:active {
    transform: translateY(-1px);
  }
`;

const LoadingSpinner = styled.div`
  border: 4px solid rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  border-top: 4px solid #9B46FF;
  width: 30px;
  height: 30px;
  margin-left: 15px;
  animation: spin 1s linear infinite;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;

const ButtonContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const OnboardingComplete = () => {
  const navigate = useNavigate();
  const { onboardingData } = useOnboarding();
  const { refreshProfile } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    const saveOnboardingData = async () => {
    console.log('Onboarding completed with data:', onboardingData);
    
      try {
        await userService.getUserProfile().then(async (profile) => {
          const { _id, ...profileWithoutId } = profile;
          const updatedProfile = {
            ...profileWithoutId,
            onboarding_completed: true,  // Explicitly boolean true
            role: onboardingData.role,
            experience_level: onboardingData.experienceLevel,
            learning_style: onboardingData.learningStyle,
            learning_goal: onboardingData.learningGoal,
            interests: onboardingData.interests
          };
          
          console.log('Updating profile with onboarding data, setting onboarding_completed to:', updatedProfile.onboarding_completed, 'Type:', typeof updatedProfile.onboarding_completed);
          
          try {
            const response = await api.put('/users/profile/', updatedProfile);
            console.log('Profile update API response:', response.status, response.data);
            console.log('Successfully updated profile with onboarding data');
          } catch (error) {
            console.error('Error updating profile via API:', error.response?.status, error.response?.data || error.message);
            throw error; // Re-throw for handling in the outer catch
          }
        });
        
        try {
          await userService.updateOnboardingStatus({
            onboarding_completed: true,
            onboarding_data: onboardingData
          });
          console.log('Updated onboarding status via dedicated endpoint');
        } catch (e) {
          console.warn('Onboarding endpoint not available, but profile was updated');
        }

        // Clear the signupIntent flag from localStorage
        localStorage.removeItem('signupIntent');
        console.log('Cleared signupIntent flag from localStorage on component mount');
        
        // Refresh the profile in AuthContext
        await refreshProfile();
        console.log('User profile refreshed in AuthContext');
      } catch (error) {
        console.error('Error saving onboarding data:', error);
      }
    };
    
    saveOnboardingData();
  }, [onboardingData, refreshProfile]);
  
  const handleContinue = async () => {
    setIsLoading(true);
    
    try {
      // First, set the direct navigation flag IMMEDIATELY
      // This ensures that even if there's an error later, the navigation will still work
      localStorage.setItem('directDashboardNavigation', 'true');
      localStorage.setItem('onboardingCompleted', 'true');
      
      // Also set in global memory if available
      setOnboardingComplete();
      
      // Make the onboardingMemory available globally for ProtectedRoute to access
      try {
        window.onboardingMemory = { 
          hasCompletedOnboarding: true, 
          setCompleted: function() { this.hasCompletedOnboarding = true; },
          isCompleted: function() { return this.hasCompletedOnboarding; }
        };
      } catch (e) {
        console.warn('Could not set global onboardingMemory:', e);
      }
      
      const profile = await userService.getUserProfile();
      console.log('Final profile check before navigation:', profile);
      
      if (profile && profile.onboarding_completed !== true) {
        const { _id, ...profileWithoutId } = profile;
        const updatedProfile = {
          ...profileWithoutId,
          onboarding_completed: true  // Explicitly boolean true
        };
        
        console.log('Final check - setting onboarding_completed to:', updatedProfile.onboarding_completed, 'Type:', typeof updatedProfile.onboarding_completed);
        
        try {
          const response = await api.put('/users/profile/', updatedProfile);
          console.log('Final profile update response:', response.status, response.data);
          console.log('Marked onboarding as completed before navigating to dashboard');
        } catch (error) {
          console.error('Error in final profile update:', error.response?.status, error.response?.data || error.message);
          // Continue anyway - flags are already set
        }
      } else {
        console.log('Profile already has onboarding_completed set to true');
      }
      
      // Clear the signupIntent flag from localStorage to prevent redirection loops
      localStorage.removeItem('signupIntent');
      console.log('Cleared signupIntent flag from localStorage');
      
      // Force refresh the user profile in context before navigation
      try {
        await refreshProfile();
        console.log('User profile refreshed in context before navigation');
      } catch (refreshError) {
        console.error('Could not refresh user profile in context:', refreshError);
        // Continue anyway - flags are already set
      }
      
      // Add a delay for better user experience
      console.log('Adding delay before navigation for better user experience');
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Final check to ensure onboardingMemory is set
      setOnboardingComplete();
      
      // Navigate to dashboard - This will happen no matter what since we set the flags at the beginning
      console.log('Navigating directly to dashboard with bypass flags set');
      navigate('/study-dashboard');
    } catch (error) {
      console.error('Error during onboarding completion:', error);
      // Navigate to dashboard anyway - flags are already set
      navigate('/study-dashboard');
    } finally {
      setIsLoading(false);
    }
  };
  
  const getRoleName = (role) => {
    const roleMap = {
      'student': 'Student',
      'teacher': 'Teacher',
      'professional': 'Professional',
      'parent': 'Parent',
      'other': 'Other'
    };
    return roleMap[role] || 'User';
  };

  return (
    <Container>
      <AnimatedBackground />
      
      <ContentWrapper>
        <CheckmarkContainer>
          <Checkmark />
        </CheckmarkContainer>
        
        <Title>You're all set!</Title>
        <Description>
          Your personalized learning experience is ready. We've tailored your dashboard based on your preferences.
        </Description>
        
        <DetailCard>
          <h3>Your Learning Profile:</h3>
          <ul>
            <li>Role: {getRoleName(onboardingData.role)}</li>
            <li>Experience: {onboardingData.experienceLevel}</li>
            <li>Learning style: {onboardingData.learningStyle}</li>
            <li>Goal: {onboardingData.learningGoal}</li>
            <li>Interests: {onboardingData.interests.join(', ')}</li>
          </ul>
        </DetailCard>
        
        <Button onClick={handleContinue} disabled={isLoading}>
          <ButtonContent>
            {isLoading ? 'Finalizing your setup...' : 'Go to Dashboard'}
            {isLoading && <LoadingSpinner />}
          </ButtonContent>
        </Button>
      </ContentWrapper>
    </Container>
  );
};

export default OnboardingComplete; 