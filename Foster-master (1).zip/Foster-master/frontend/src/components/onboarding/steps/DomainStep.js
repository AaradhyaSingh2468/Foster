import React from 'react';
import styled from 'styled-components';
import OnboardingLayout from '../OnboardingLayout';
import OnboardingOption from '../OnboardingOption';
import { useOnboarding } from '../../../context/onboarding/OnboardingContext';

// SVG Icons for each experience level
const Beginner = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 14.5C8 14.5 9.5 16 12 16C14.5 16 16 14.5 16 14.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9 10C9 9.44772 8.55228 9 8 9C7.44772 9 7 9.44772 7 10C7 10.5523 7.44772 11 8 11C8.55228 11 9 10.5523 9 10Z" fill="currentColor"/>
    <path d="M17 10C17 9.44772 16.5523 9 16 9C15.4477 9 15 9.44772 15 10C15 10.5523 15.4477 11 16 11C16.5523 11 17 10.5523 17 10Z" fill="currentColor"/>
  </svg>
);

const Intermediate = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 12C8 12 9.5 13 12 13C14.5 13 16 12 16 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9 9C9 8.44772 8.55228 8 8 8C7.44772 8 7 8.44772 7 9C7 9.55228 7.44772 10 8 10C8.55228 10 9 9.55228 9 9Z" fill="currentColor"/>
    <path d="M17 9C17 8.44772 16.5523 8 16 8C15.4477 8 15 8.44772 15 9C15 9.55228 15.4477 10 16 10C16.5523 10 17 9.55228 17 9Z" fill="currentColor"/>
  </svg>
);

const Advanced = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 13C8 13 9.5 16 12 16C14.5 16 16 13 16 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9 9C9 8.44772 8.55228 8 8 8C7.44772 8 7 8.44772 7 9C7 9.55228 7.44772 10 8 10C8.55228 10 9 9.55228 9 9Z" fill="currentColor"/>
    <path d="M17 9C17 8.44772 16.5523 8 16 8C15.4477 8 15 8.44772 15 9C15 9.55228 15.4477 10 16 10C16.5523 10 17 9.55228 17 9Z" fill="currentColor"/>
  </svg>
);

const Expert = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M9 9C9.33333 9.66667 10.2 10.8 12 10C13.8 9.2 14.6667 9.66667 15 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 15C8 15 9.5 18 12 18C14.5 18 16 15 16 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const NotSure = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 17V17.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 14C12 11 15 12 15 9.5C15 7.5 13.5 6 12 6C10.5 6 9 7.5 9 9.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const StepContainer = styled.div`
  animation: ${props => props.direction === 'forward' ? 'slideInRight' : 'slideInLeft'} 0.3s ease-out;
  
  @keyframes slideInRight {
    from { transform: translateX(20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  
  @keyframes slideInLeft {
    from { transform: translateX(-20px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
`;

const OptionsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const DomainStep = () => {
  const { onboardingData, updateOnboardingData, direction, ExperienceLevels } = useOnboarding();
  
  const levels = [
    {
      id: ExperienceLevels.BEGINNER,
      label: 'Beginner',
      icon: <Beginner />,
      description: 'New to the subject, little to no prior knowledge',
    },
    {
      id: ExperienceLevels.INTERMEDIATE,
      label: 'Intermediate',
      icon: <Intermediate />,
      description: 'Familiar with basics, some practical experience',
    },
    {
      id: ExperienceLevels.ADVANCED,
      label: 'Advanced',
      icon: <Advanced />,
      description: 'Solid understanding, significant experience',
    },
    {
      id: ExperienceLevels.EXPERT,
      label: 'Expert',
      icon: <Expert />,
      description: 'Deep expertise, looking for advanced content',
    },
    {
      id: ExperienceLevels.NOT_SURE,
      label: 'Not Sure',
      icon: <NotSure />,
      description: 'Unsure about my current level',
    },
  ];

  const handleSelectLevel = (level) => {
    updateOnboardingData({ experienceLevel: level });
  };

  return (
    <StepContainer direction={direction}>
      <OnboardingLayout 
        title="What's your experience level?"
        description="We'll customize content based on your expertise"
        canContinue={!!onboardingData.experienceLevel}
      >
        <OptionsContainer>
          {levels.map((level) => (
            <OnboardingOption
              key={level.id}
              id={level.id}
              icon={level.icon}
              label={level.label}
              description={level.description}
              selected={onboardingData.experienceLevel === level.id}
              onClick={() => handleSelectLevel(level.id)}
            />
          ))}
        </OptionsContainer>
      </OnboardingLayout>
    </StepContainer>
  );
};

export default DomainStep; 