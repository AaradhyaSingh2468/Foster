import React from 'react';
import styled, { keyframes, css } from 'styled-components';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const pulseAnimation = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(0.97); }
  100% { transform: scale(1); }
`;

const glow = keyframes`
  0% { box-shadow: 0 0 0 rgba(155, 70, 255, 0); }
  100% { box-shadow: 0 0 20px rgba(155, 70, 255, 0.25); }
`;

const OptionContainer = styled.div`
  opacity: 0;
  animation: ${fadeIn} 0.5s ease-out forwards;
  animation-delay: ${props => props.index * 0.08}s;
`;

const OptionWrapper = styled.button`
  display: flex;
  align-items: center;
  gap: 1rem;
  width: 100%;
  padding: 1rem;
  border-radius: 12px;
  background-color: ${props => props.selected ? 'rgba(155, 70, 255, 0.1)' : 'rgba(255, 255, 255, 0.05)'};
  border: 1px solid ${props => props.selected ? 'var(--purple)' : 'rgba(255, 255, 255, 0.1)'};
  color: white;
  text-align: left;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
  cursor: pointer;
  
  ${props => props.selected && css`
    animation: ${glow} 0.5s forwards;
  `}
  
  &:hover {
    transform: translateY(-2px);
    border-color: ${props => props.selected ? 'var(--purple)' : 'rgba(255, 255, 255, 0.2)'};
    background-color: ${props => props.selected ? 'rgba(155, 70, 255, 0.15)' : 'rgba(255, 255, 255, 0.08)'};
  }
  
  &:active {
    animation: ${pulseAnimation} 0.3s;
  }
`;

const IconContainer = styled.div`
  width: 42px;
  height: 42px;
  min-width: 42px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${props => props.selected 
    ? 'linear-gradient(135deg, var(--purple), #FF56B1)'
    : 'rgba(255, 255, 255, 0.08)'};
  color: white;
  transition: all 0.3s ease;
  
  svg {
    width: 22px;
    height: 22px;
    transition: transform 0.2s ease;
  }
  
  ${OptionWrapper}:hover & svg {
    transform: scale(1.1);
  }
`;

const ContentContainer = styled.div`
  flex: 1;
`;

const Title = styled.h3`
  font-size: 1rem;
  font-weight: 600;
  margin: 0 0 0.25rem 0;
  color: white;
`;

const Description = styled.p`
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.7);
  margin: 0;
  line-height: 1.4;
`;

const CheckIndicator = styled.div`
  width: 18px;
  height: 18px;
  border-radius: 50%;
  margin-left: auto;
  border: 2px solid ${props => props.selected ? 'var(--purple)' : 'rgba(255, 255, 255, 0.2)'};
  background-color: ${props => props.selected ? 'var(--purple)' : 'transparent'};
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  flex-shrink: 0;
  
  svg {
    width: 10px;
    height: 10px;
    color: white;
    opacity: ${props => props.selected ? 1 : 0};
    transition: opacity 0.2s ease;
  }
`;

const OnboardingOption = ({ 
  id, 
  icon, 
  title,
  label = null, // For backward compatibility
  description, 
  selected, 
  onClick,
  index = 0
}) => {
  // Support both 'title' and 'label' props for backward compatibility
  const displayTitle = title || label;
  
  return (
    <OptionContainer index={index}>
      <OptionWrapper 
        selected={selected} 
        onClick={() => onClick(id)}
        type="button"
      >
        <IconContainer selected={selected}>
          {icon}
        </IconContainer>
        
        <ContentContainer>
          <Title>{displayTitle}</Title>
          {description && <Description>{description}</Description>}
        </ContentContainer>
        
        <CheckIndicator selected={selected}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </CheckIndicator>
      </OptionWrapper>
    </OptionContainer>
  );
};

export default OnboardingOption; 