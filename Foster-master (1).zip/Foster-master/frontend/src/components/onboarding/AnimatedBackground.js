import React from 'react';
import styled, { keyframes, css } from 'styled-components';

const float = keyframes`
  0% { transform: translate(0, 0); }
  50% { transform: translate(10px, -10px); }
  100% { transform: translate(0, 0); }
`;

const floatDelayed = keyframes`
  0% { transform: translate(0, 0); }
  50% { transform: translate(-15px, 15px); }
  100% { transform: translate(0, 0); }
`;

const pulseSlow = keyframes`
  0% { transform: scale(1); opacity: 0.4; }
  50% { transform: scale(1.1); opacity: 0.6; }
  100% { transform: scale(1); opacity: 0.4; }
`;

const BackgroundWrapper = styled.div`
  position: fixed;
  inset: 0;
  z-index: -1;
  overflow: hidden;
`;

const GradientOrb = styled.div`
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  
  &.purple {
    top: 25%;
    left: 25%;
    width: 250px;
    height: 250px;
    background-color: rgba(155, 70, 255, 0.3);
    animation: ${float} 20s ease-in-out infinite;
    opacity: 0.6;
  }
  
  &.blue {
    top: 75%;
    left: 66%;
    width: 350px;
    height: 350px;
    background-color: rgba(65, 105, 225, 0.2);
    animation: ${floatDelayed} 25s ease-in-out infinite;
    opacity: 0.5;
  }
  
  &.pink {
    top: 50%;
    left: 33%;
    width: 300px;
    height: 300px;
    background-color: rgba(255, 86, 177, 0.2);
    animation: ${pulseSlow} 15s ease-in-out infinite;
    opacity: 0.4;
  }
`;

const Grid = styled.div`
  position: absolute;
  inset: 0;
  background-image: 
    linear-gradient(rgba(20, 20, 30, 0.8) 2px, transparent 2px),
    linear-gradient(90deg, rgba(20, 20, 30, 0.8) 2px, transparent 2px);
  background-size: 40px 40px;
  opacity: 0.05;
`;

const Overlay = styled.div`
  position: absolute;
  inset: 0;
  background: radial-gradient(
    circle at center,
    rgba(15, 15, 15, 0.8) 0%,
    rgba(15, 15, 15, 0.95) 50%,
    rgba(15, 15, 15, 0.9) 100%
  );
`;

const AnimatedBackground = () => {
  return (
    <BackgroundWrapper>
      {/* Animated gradient orbs */}
      <GradientOrb className="purple" />
      <GradientOrb className="blue" />
      <GradientOrb className="pink" />
      
      {/* Grid pattern */}
      <Grid />
      
      {/* Overlay for better readability */}
      <Overlay />
    </BackgroundWrapper>
  );
};

export default AnimatedBackground; 