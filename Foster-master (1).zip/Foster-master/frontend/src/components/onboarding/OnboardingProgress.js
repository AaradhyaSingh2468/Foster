import React, { useEffect } from 'react';
import styled, { keyframes, css } from 'styled-components';
import { useOnboarding } from '../../context/onboarding/OnboardingContext';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const scaleX = keyframes`
  from { transform: scaleX(0); opacity: 0; }
  to { transform: scaleX(1); opacity: 1; }
`;

const ProgressContainer = styled.div`
  margin-bottom: 2rem;
  width: 100%;
  animation: ${fadeIn} 0.5s ease forwards;
`;

const ProgressHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.5rem;
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.6);
  animation: ${fadeIn} 0.5s ease forwards;
`;

const ProgressBarContainer = styled.div`
  width: 100%;
  height: 8px;
  background-color: rgba(30, 30, 40, 0.6);
  border-radius: 4px;
  overflow: hidden;
  position: relative;
  transform-origin: left;
  animation: ${scaleX} 0.5s ease forwards;
`;

const ProgressBarFill = styled.div`
  height: 100%;
  background: linear-gradient(90deg, var(--purple), #ff56b1);
  border-radius: 4px;
  transition: width 0.5s ease;
  width: ${props => props.progress}%;
  transform-origin: left;
`;

const GlowEffect = styled.div`
  position: absolute;
  bottom: -3px;
  left: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--purple), transparent);
  filter: blur(4px);
  opacity: 0.5;
  transition: width 0.5s ease;
  width: ${props => props.progress}%;
  transform-origin: left;
  animation: ${scaleX} 0.5s ease forwards;
`;

const StepLabels = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 12px;
  padding: 0 2px;
`;

const StepLabel = styled.span`
  font-size: 0.75rem;
  color: ${props => props.active ? 'white' : 'rgba(255, 255, 255, 0.5)'};
  transition: color 0.3s ease;
  animation: ${fadeIn} 0.6s ease forwards;
  animation-delay: ${props => props.index * 0.1}s;
  opacity: 0;
`;

const OnboardingProgress = () => {
  const { currentStep, totalSteps } = useOnboarding();
  
  // Calculate progress percentage for the visual bar
  const progressPercentage = (currentStep / totalSteps) * 100;
  
  // Labels for steps (excluding final completion step)
  const stepLabels = ['Role', 'Domain', 'Interests', 'Learning Style', 'Goals'];

  return (
    <ProgressContainer>
      <ProgressHeader>
        <span>Getting Started</span>
        <span>{currentStep} of {totalSteps}</span>
      </ProgressHeader>
      
      <ProgressBarContainer>
        <ProgressBarFill progress={progressPercentage} />
      </ProgressBarContainer>
      
      <GlowEffect progress={progressPercentage} />
      
      <StepLabels>
        {stepLabels.map((label, index) => (
          <StepLabel 
            key={index} 
            active={currentStep > index} 
            index={index}
          >
            {label}
          </StepLabel>
        ))}
      </StepLabels>
    </ProgressContainer>
  );
};

export default OnboardingProgress; 