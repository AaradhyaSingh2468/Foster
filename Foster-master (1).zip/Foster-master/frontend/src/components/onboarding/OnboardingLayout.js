import React, { useEffect } from 'react';
import styled, { keyframes, css, createGlobalStyle } from 'styled-components';
import { useOnboarding } from '../../context/onboarding/OnboardingContext';
import OnboardingProgress from './OnboardingProgress';
import AnimatedBackground from './AnimatedBackground';

// Global style to ensure no white flash during transitions
const GlobalBackground = createGlobalStyle`
  body {
    background-color: #0F0F0F;
    margin: 0;
    overflow-x: hidden;
  }
`;

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const scaleIn = keyframes`
  from { opacity: 0; transform: scale(0.98); }
  to { opacity: 1; transform: scale(1); }
`;

const Container = styled.div`
  min-height: 100vh;
  min-width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  background-color: #0F0F0F;
  color: white;
  position: relative;
  overflow: hidden;
  animation: ${fadeIn} 0.5s ease-out;
  
  @media only screen and (min-width: 768px) {
    padding: 1.5rem;
  }
`;

const ContentWrapper = styled.div`
  width: 100%;
  max-width: 36rem; // 576px
  margin: 0 auto;
  z-index: 10;
  position: relative;
  animation: ${scaleIn} 0.5s ease-out;
  will-change: transform, opacity;
`;

const Card = styled.div`
  overflow: hidden;
  backdrop-filter: blur(12px);
  background-color: rgba(0, 0, 0, 0.25);
  padding: 1.5rem;
  border-radius: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.3);
  transition: all 0.3s ease;

  &:hover {
    box-shadow: 0 15px 30px rgba(155, 70, 255, 0.2);
    border-color: rgba(155, 70, 255, 0.2);
  }
  
  @media only screen and (min-width: 768px) {
    padding: 2rem;
  }
`;

const Header = styled.div`
  margin-bottom: 2rem;
  animation: ${fadeIn} 0.6s ease-out;
`;

const Title = styled.h1`
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  background: linear-gradient(to right, #9B46FF, #FF56B1);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  
  @media only screen and (min-width: 768px) {
    font-size: 2rem;
  }
`;

const Description = styled.p`
  color: rgba(255, 255, 255, 0.7);
  font-size: 1rem;
  line-height: 1.5;
`;

const Content = styled.div`
  margin-bottom: 2rem;
  animation: ${fadeIn} 0.7s ease-out;
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
  animation: ${fadeIn} 0.8s ease-out;
`;

const buttonHover = keyframes`
  0% { box-shadow: 0 0 0 rgba(155, 70, 255, 0); }
  100% { box-shadow: 0 0 20px rgba(155, 70, 255, 0.4); }
`;

const Button = styled.button`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.25rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.95rem;
  cursor: pointer;
  transition: all 0.2s ease;

  &:hover:not(:disabled) {
    transform: scale(1.05);
  }

  &:active:not(:disabled) {
    transform: scale(0.98);
  }

  &:focus {
    outline: none;
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;

const BackButton = styled(Button)`
  background-color: transparent;
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: white;

  &:hover:not(:disabled) {
    border-color: rgba(255, 255, 255, 0.3);
    background-color: rgba(255, 255, 255, 0.05);
  }
`;

const NextButton = styled(Button)`
  background-color: var(--purple);
  border: none;
  color: white;
  margin-left: auto;
  position: relative;
  overflow: hidden;

  &:hover:not(:disabled) {
    background-color: #a55aff;
    animation: ${buttonHover} 0.3s forwards;
  }
  
  &:after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, rgba(255, 255, 255, 0) 70%);
    opacity: 0;
    transform: scale(0);
    transition: transform 0.5s, opacity 0.5s;
  }
  
  &:hover:not(:disabled):after {
    opacity: 0.1;
    transform: scale(1);
  }
`;

const OnboardingLayout = ({
  title,
  description,
  children,
  showBackButton = true,
  canContinue = true,
  nextButtonText = 'Continue',
}) => {
  const { goToNextStep, goToPreviousStep, currentStep, totalSteps } = useOnboarding();
  
  // Last step before completion
  const isLastStep = currentStep === 5;

  // Ensure the background color is applied to the body
  useEffect(() => {
    // Save the original body background
    const originalBackground = document.body.style.backgroundColor;
    document.body.style.backgroundColor = "#0F0F0F";
    
    // Clean up when component unmounts
    return () => {
      document.body.style.backgroundColor = originalBackground;
    };
  }, []);

  return (
    <>
      <GlobalBackground />
      <Container>
        <AnimatedBackground />
        
        <ContentWrapper>
          <OnboardingProgress />
          
          <Card>
            <Header>
              <Title>{title}</Title>
              <Description>{description}</Description>
            </Header>
            
            <Content>
              {children}
            </Content>
            
            <ButtonGroup>
              {showBackButton && currentStep > 1 ? (
                <BackButton 
                  onClick={goToPreviousStep}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  Back
                </BackButton>
              ) : (
                <div></div> // Empty div to maintain spacing
              )}
              
              <NextButton 
                onClick={goToNextStep} 
                disabled={!canContinue}
              >
                {isLastStep ? 'Finish' : nextButtonText}
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 6L15 12L9 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </NextButton>
            </ButtonGroup>
          </Card>
        </ContentWrapper>
      </Container>
    </>
  );
};

export default OnboardingLayout; 