import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import { GithubAuthProvider } from 'firebase/auth';

const Container = styled.div`
  margin-top: 1.5rem;
  padding: 1.5rem;
  background-color: rgba(255, 255, 255, 0.05);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
`;

const Title = styled.h3`
  font-size: 1.2rem;
  color: var(--white);
  margin-bottom: 1rem;
`;

const Description = styled.p`
  color: rgba(255, 255, 255, 0.7);
  font-size: 0.9rem;
  margin-bottom: 1.5rem;
`;

const LinkedAccountsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const AccountItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.8rem;
  background-color: rgba(255, 255, 255, 0.08);
  border-radius: 8px;
`;

const AccountInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const IconContainer = styled.div`
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const AccountName = styled.span`
  color: var(--white);
  font-size: 0.95rem;
`;

const LinkButton = styled.button`
  background-color: ${props => props.linked ? 'transparent' : 'var(--purple)'};
  color: ${props => props.linked ? 'rgba(255, 255, 255, 0.6)' : 'var(--white)'};
  border: ${props => props.linked ? '1px solid rgba(255, 255, 255, 0.2)' : 'none'};
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-size: 0.85rem;
  cursor: ${props => props.disabled ? 'not-allowed' : 'pointer'};
  opacity: ${props => props.disabled ? 0.6 : 1};
  transition: all 0.2s;
  
  &:hover:not(:disabled) {
    background-color: ${props => props.linked ? 'rgba(255, 255, 255, 0.1)' : '#a55aff'};
  }
`;

const ErrorMessage = styled.div`
  color: #ff6b6b;
  font-size: 0.9rem;
  margin-top: 1rem;
`;

const SuccessMessage = styled.div`
  color: #51cf66;
  font-size: 0.9rem;
  margin-top: 1rem;
`;

const AccountLinking = () => {
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLinking, setIsLinking] = useState(false);
  const { currentUser, linkAccounts, signInWithGithub } = useAuth();
  
  // Providers linked status
  const [providers, setProviders] = useState({
    google: false,
    github: false,
    email: false
  });
  
  // Check which providers are linked
  useEffect(() => {
    if (currentUser) {
      const providerData = currentUser.providerData || [];
      
      const linkedProviders = {
        google: providerData.some(p => p.providerId === 'google.com'),
        github: providerData.some(p => p.providerId === 'github.com'),
        email: providerData.some(p => p.providerId === 'password')
      };
      
      setProviders(linkedProviders);
    }
  }, [currentUser]);
  
  const handleGitHubLink = async () => {
    try {
      setIsLinking(true);
      setErrorMessage('');
      setSuccessMessage('');
      
      const result = await signInWithGithub();
      // If we got here without error, GitHub account was successfully linked
      setSuccessMessage('GitHub account successfully linked!');
      
      // Update the providers state
      setProviders(prev => ({
        ...prev,
        github: true
      }));
    } catch (error) {
      console.error('Error linking GitHub account:', error);
      if (error.code === 'auth/credential-already-in-use') {
        setErrorMessage('This GitHub account is already linked to another user.');
      } else if (error.code === 'auth/email-already-in-use') {
        setErrorMessage('The email associated with this GitHub account is already linked to another user.');
      } else {
        setErrorMessage(error.message || 'Failed to link GitHub account. Please try again.');
      }
    } finally {
      setIsLinking(false);
    }
  };
  
  return (
    <Container>
      <Title>Linked Accounts</Title>
      <Description>
        Link your accounts to sign in with different providers. 
        Linking accounts provides additional sign-in options and enhances account security.
      </Description>
      
      <LinkedAccountsContainer>
        {currentUser?.email && (
          <AccountItem>
            <AccountInfo>
              <IconContainer>
                <svg viewBox="0 0 24 24" fill="none" width="24" height="24">
                  <path d="M20 4H4C2.895 4 2 4.895 2 6V18C2 19.105 2.895 20 4 20H20C21.105 20 22 19.105 22 18V6C22 4.895 21.105 4 20 4Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M2 8L12 14L22 8" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </IconContainer>
              <AccountName>{currentUser.email}</AccountName>
            </AccountInfo>
            <LinkButton disabled linked>
              Primary Email
            </LinkButton>
          </AccountItem>
        )}
        
        <AccountItem>
          <AccountInfo>
            <IconContainer>
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" width="24" height="24">
                <path d="M12 0C5.374 0 0 5.373 0 12C0 17.302 3.438 21.8 8.207 23.387C8.806 23.498 9 23.126 9 22.81V20.576C5.662 21.302 4.967 19.16 4.967 19.16C4.421 17.773 3.634 17.404 3.634 17.404C2.545 16.659 3.717 16.675 3.717 16.675C4.922 16.759 5.556 17.912 5.556 17.912C6.626 19.746 8.363 19.216 9.048 18.909C9.155 18.134 9.466 17.604 9.81 17.305C7.145 17 4.343 15.971 4.343 11.374C4.343 10.063 4.812 8.993 5.579 8.153C5.455 7.85 5.044 6.629 5.696 4.977C5.696 4.977 6.704 4.655 8.997 6.207C9.954 5.941 10.98 5.808 12 5.803C13.02 5.808 14.047 5.941 15.006 6.207C17.297 4.655 18.303 4.977 18.303 4.977C18.956 6.63 18.545 7.851 18.421 8.153C19.191 8.993 19.656 10.064 19.656 11.374C19.656 15.983 16.849 16.998 14.177 17.295C14.607 17.667 15 18.397 15 19.517V22.81C15 23.129 15.192 23.504 15.801 23.386C20.566 21.797 24 17.3 24 12C24 5.373 18.627 0 12 0Z" fill="white"/>
              </svg>
            </IconContainer>
            <AccountName>GitHub</AccountName>
          </AccountInfo>
          <LinkButton 
            linked={providers.github} 
            disabled={isLinking || providers.github}
            onClick={handleGitHubLink}
          >
            {providers.github ? 'Linked' : 'Link Account'}
          </LinkButton>
        </AccountItem>
        
        <AccountItem>
          <AccountInfo>
            <IconContainer>
              <svg viewBox="0 0 24 24" width="24" height="24">
                <path
                  fill="white"
                  d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"
                />
              </svg>
            </IconContainer>
            <AccountName>Google</AccountName>
          </AccountInfo>
          <LinkButton 
            linked={providers.google} 
            disabled={true}
          >
            {providers.google ? 'Linked' : 'Link Account'}
          </LinkButton>
        </AccountItem>
      </LinkedAccountsContainer>
      
      {errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
      {successMessage && <SuccessMessage>{successMessage}</SuccessMessage>}
    </Container>
  );
};

export default AccountLinking; 