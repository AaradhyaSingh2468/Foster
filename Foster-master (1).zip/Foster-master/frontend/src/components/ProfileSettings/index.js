import React from 'react';
import styled from 'styled-components';
import { useAuth } from '../../context/AuthContext';
import AccountLinking from './AccountLinking';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
`;

const Title = styled.h2`
  color: var(--white);
  font-size: 2rem;
  margin-bottom: 2rem;
`;

const Card = styled.div`
  background-color: rgba(30, 30, 40, 0.95);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
`;

const Section = styled.div`
  margin-bottom: 2rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

const SectionTitle = styled.h3`
  color: var(--white);
  font-size: 1.5rem;
  margin-bottom: 1rem;
`;

const ProfileSettings = () => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return (
      <Container>
        <Card>
          <Title>You need to be signed in to access profile settings</Title>
        </Card>
      </Container>
    );
  }
  
  return (
    <Container>
      <Title>Profile Settings</Title>
      
      <Card>
        <Section>
          <SectionTitle>Account</SectionTitle>
          <p style={{ color: 'rgba(255, 255, 255, 0.7)', marginBottom: '1rem' }}>
            Manage your account settings and linked providers
          </p>
          
          <AccountLinking />
        </Section>
      </Card>
    </Container>
  );
};

export default ProfileSettings; 