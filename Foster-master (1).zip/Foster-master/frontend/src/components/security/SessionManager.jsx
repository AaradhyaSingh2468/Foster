import React, { useState, useEffect } from 'react';
import { getUserSessions, terminateSession, logoutAll } from '../../services/userService';
import { formatDistanceToNow } from 'date-fns';

const SessionManager = () => {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [terminating, setTerminating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch sessions on component mount
  useEffect(() => {
    fetchSessions();
  }, []);

  // Fetch all user sessions
  const fetchSessions = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await getUserSessions();
      setSessions(response.sessions || []);
    } catch (err) {
      console.error('Failed to load sessions:', err);
      setError('Failed to load your active sessions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle session termination
  const handleTerminateSession = async (sessionId) => {
    try {
      setTerminating(true);
      await terminateSession(sessionId);
      // Remove the terminated session from the list
      setSessions(sessions.filter(session => session.id !== sessionId));
    } catch (err) {
      console.error('Failed to terminate session:', err);
      setError('Failed to terminate session. Please try again.');
    } finally {
      setTerminating(false);
    }
  };

  // Handle terminating all other sessions
  const handleTerminateAllOther = async () => {
    try {
      setTerminating(true);
      await logoutAll(true); // Keep current session
      // Refresh sessions after logout
      await fetchSessions();
    } catch (err) {
      console.error('Failed to terminate all sessions:', err);
      setError('Failed to terminate other sessions. Please try again.');
    } finally {
      setTerminating(false);
    }
  };

  // Format date for display
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (err) {
      return 'Unknown';
    }
  };

  // Get device info from user agent
  const getDeviceInfo = (userAgent) => {
    if (!userAgent) return 'Unknown device';
    
    if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
      return 'iOS Device';
    } else if (userAgent.includes('Android')) {
      return 'Android Device';
    } else if (userAgent.includes('Windows')) {
      return 'Windows Device';
    } else if (userAgent.includes('Mac')) {
      return 'Mac Device';
    } else if (userAgent.includes('Linux')) {
      return 'Linux Device';
    } else {
      return 'Unknown device';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-4xl mx-auto text-white">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Active Sessions</h2>
        <div className="flex space-x-4">
          <button 
            onClick={fetchSessions}
            disabled={loading || refreshing}
            className="px-4 py-2 bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </button>
          <button 
            onClick={handleTerminateAllOther}
            disabled={loading || terminating || sessions.length <= 1}
            className="px-4 py-2 bg-red-600 rounded-md hover:bg-red-700 disabled:opacity-50"
          >
            {terminating ? 'Terminating...' : 'Logout All Other Devices'}
          </button>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-600 text-white p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      {loading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto"></div>
          <p className="mt-4">Loading your sessions...</p>
        </div>
      ) : sessions.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <p>No active sessions found.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {sessions.map(session => (
            <div 
              key={session.id} 
              className={`border rounded-lg p-4 ${session.is_current ? 'border-purple-500 bg-gray-700' : 'border-gray-600'}`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center">
                    <span className="font-semibold text-lg">{getDeviceInfo(session.user_agent)}</span>
                    {session.is_current && (
                      <span className="ml-2 px-2 py-1 bg-purple-600 text-xs rounded-full">Current</span>
                    )}
                  </div>
                  <p className="text-gray-400 text-sm mt-1">
                    IP: {session.ip_address || 'Unknown'}
                  </p>
                  <div className="mt-2 text-sm text-gray-300">
                    <div>Created: {formatDate(session.created_at)}</div>
                    <div>Last activity: {formatDate(session.last_activity)}</div>
                  </div>
                </div>
                {!session.is_current && (
                  <button
                    onClick={() => handleTerminateSession(session.id)}
                    disabled={terminating}
                    className="px-3 py-1 bg-red-600 text-sm rounded hover:bg-red-700 disabled:opacity-50"
                  >
                    Logout
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SessionManager; 