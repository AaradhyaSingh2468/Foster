import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const AccountSettings = () => {
  const { userProfile, deleteAccount } = useAuth();
  const [isDeleting, setIsDeleting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const navigate = useNavigate();

  const handleDeleteRequest = () => {
    setShowConfirmation(true);
  };

  const handleCancelDelete = () => {
    setShowConfirmation(false);
  };

  const handleConfirmDelete = async () => {
    try {
      setIsDeleting(true);
      await deleteAccount();
      // Redirect to home page after successful deletion
      navigate('/');
    } catch (error) {
      console.error('Failed to delete account:', error);
      // Show error message
    } finally {
      setIsDeleting(false);
      setShowConfirmation(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Profile Information</h2>
        {userProfile && (
          <div className="bg-white shadow rounded-lg p-4">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Username</label>
              <div className="mt-1">{userProfile.username}</div>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <div className="mt-1">{userProfile.email}</div>
            </div>
          </div>
        )}
      </div>
      
      <div className="mt-12 border-t pt-6">
        <h2 className="text-xl font-semibold mb-4 text-red-600">Danger Zone</h2>
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="font-medium text-red-800">Delete Account</h3>
          <p className="mt-1 text-sm text-red-700">
            Once you delete your account, there is no going back. All your data will be permanently removed.
          </p>
          <div className="mt-3">
            {!showConfirmation ? (
              <button
                onClick={handleDeleteRequest}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                disabled={isDeleting}
              >
                Delete Account
              </button>
            ) : (
              <div className="bg-red-100 p-3 rounded">
                <p className="font-medium text-red-800 mb-2">Are you sure you want to delete your account?</p>
                <div className="flex space-x-3">
                  <button
                    onClick={handleConfirmDelete}
                    className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                    disabled={isDeleting}
                  >
                    {isDeleting ? 'Deleting...' : 'Yes, Delete My Account'}
                  </button>
                  <button
                    onClick={handleCancelDelete}
                    className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400"
                    disabled={isDeleting}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings; 