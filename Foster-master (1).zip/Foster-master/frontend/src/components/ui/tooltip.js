import React from 'react';
import styled from 'styled-components';

// Simple placeholder for TooltipProvider
// In a real implementation, this would be a more complex component

export const TooltipProvider = ({ children }) => {
  return <>{children}</>;
}; 