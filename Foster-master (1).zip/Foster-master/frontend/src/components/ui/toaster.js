import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
`;

const fadeOut = keyframes`
  from { opacity: 1; transform: translateY(0); }
  to { opacity: 0; transform: translateY(-10px); }
`;

const ToastContainer = styled.div`
  position: fixed !important;
  top: auto !important;
  bottom: 5% !important;
  right: 5% !important;
  left: auto !important;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

const Toast = styled.div`
  background: rgba(15, 15, 20, 0.9);
  color: white;
  border-left: 4px solid var(--purple);
  padding: 16px;
  border-radius: 8px;
  min-width: 300px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  animation: ${props => props.isClosing ? fadeOut : fadeIn} 0.3s ease-in-out;
`;

const ToastHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
`;

const ToastTitle = styled.h3`
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  cursor: pointer;
  
  &:hover {
    color: white;
  }
`;

const ToastDescription = styled.p`
  margin: 0;
  font-size: 0.875rem;
  color: rgba(255, 255, 255, 0.8);
`;

// Context for toast functionality
export const ToastContext = React.createContext({
  toast: () => {},
});

// Custom hook to use toast
export const useToast = () => {
  const context = React.useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const Toaster = () => {
  const [toasts, setToasts] = useState([]);
  
  // Add toast function that gets passed through context
  const addToast = ({ title, description }) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast = { id, title, description, isClosing: false };
    setToasts(prevToasts => [...prevToasts, newToast]);
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
      dismissToast(id);
    }, 5000);
  };
  
  // Set up context value that includes the toast function
  const contextValue = React.useMemo(() => ({ toast: addToast }), []);
  
  // Remove toast after animation completes
  const removeToast = (id) => {
    setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
  };
  
  // Start closing animation
  const dismissToast = (id) => {
    setToasts(prevToasts => 
      prevToasts.map(toast => 
        toast.id === id ? { ...toast, isClosing: true } : toast
      )
    );
    
    // Wait for animation before removing
    setTimeout(() => {
      removeToast(id);
    }, 300);
  };
  
  return (
    <ToastContext.Provider value={contextValue}>
      <ToastContainer>
        {toasts.map((toast) => (
          <Toast key={toast.id} isClosing={toast.isClosing} onAnimationEnd={() => toast.isClosing && removeToast(toast.id)}>
            <ToastHeader>
              <ToastTitle>{toast.title}</ToastTitle>
              <CloseButton onClick={() => dismissToast(toast.id)}>✕</CloseButton>
            </ToastHeader>
            {toast.description && (
              <ToastDescription>{toast.description}</ToastDescription>
            )}
          </Toast>
        ))}
      </ToastContainer>
    </ToastContext.Provider>
  );
};

// Helper component to export the toast function
export const ToastProvider = ({ children }) => {
  return <Toaster>{children}</Toaster>;
}; 