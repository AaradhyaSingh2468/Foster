import React from 'react';
import styled from 'styled-components';

// Simple placeholder for the Sonner component
// In a real implementation, you would use the actual Sonner library

const SonnerContainer = styled.div`
  position: fixed;
  top: 16px;
  right: 16px;
  z-index: 9999;
  pointer-events: none;
`;

export const Toaster = () => {
  return <SonnerContainer />;
}; 