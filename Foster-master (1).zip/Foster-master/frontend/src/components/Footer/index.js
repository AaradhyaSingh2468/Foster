import styled from "styled-components";
import Twitter from "../../assets/twitter-square-brands.svg";
import Instagram from "../../assets/instagram-square-brands.svg";
import Gmail from "../../assets/envelope-open-solid.svg";

const FOOTER = styled.footer`
  width: 100vw;
  height: 50vh;
  background-color: #0a0b10;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  position: relative;
  z-index: 1;
`;

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 80%;
  max-width: 1200px;
  margin: 0 auto;
`;

const QuickLinks = styled.div`
  display: flex;
  gap: 2rem;
  a {
    text-decoration: none;
    color: var(--white);
    font-size: 1.1rem;
    &:hover {
      color: var(--pink);
    }
  }
`;

const SocialLinks = styled.div`
  display: flex;
  gap: 2rem;
  a {
    text-decoration: none;
    color: var(--white);
    font-size: 1.1rem;
    &:hover {
      color: var(--pink);
    }
  }
`;

const Footer = () => {
  return (
    <FOOTER>
      <Container>
        <QuickLinks>
          <a href="#home">Home</a>
          <a href="#services">Features</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </QuickLinks>
        <SocialLinks>
          <a href="https://www.linkedin.com/company/fosterai" target="_blank" rel="noopener noreferrer">
            LinkedIn
          </a>
          <a href="https://www.instagram.com/fosterai" target="_blank" rel="noopener noreferrer">
            Instagram
          </a>
          <a href="https://twitter.com/fosterai" target="_blank" rel="noopener noreferrer">
            Twitter
          </a>
        </SocialLinks>
      </Container>
    </FOOTER>
  );
};

export default Footer;

//© 2021 by CodeBucks. Design by @CodeBucks.
