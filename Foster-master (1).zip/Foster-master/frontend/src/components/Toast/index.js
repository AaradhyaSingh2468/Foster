import React, { useState, useEffect } from 'react';
import styled, { keyframes } from 'styled-components';

// Animation for toast entry
const slideIn = keyframes`
  from { 
    transform: translateX(100%); 
    opacity: 0;
  }
  to { 
    transform: translateX(0); 
    opacity: 1;
  }
`;

// Animation for toast exit
const slideOut = keyframes`
  from { 
    transform: translateX(0); 
    opacity: 1;
  }
  to { 
    transform: translateX(100%); 
    opacity: 0;
  }
`;

// Base toast container
const ToastContainer = styled.div`
  position: fixed;
  bottom: 5%;
  right: 5%;
  width: 350px;
  max-width: 90vw;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  pointer-events: none;
  box-sizing: border-box;
  overflow: visible;
`;

// Individual toast
const ToastItem = styled.div`
  background-color: ${props => {
    switch(props.type) {
      case 'success': return 'rgba(46, 160, 67, 0.95)';
      case 'error': return 'rgba(218, 54, 51, 0.95)';
      case 'warning': return 'rgba(246, 190, 0, 0.95)';
      default: return 'rgba(30, 30, 30, 0.95)';
    }
  }};
  color: white;
  padding: 16px 20px;
  border-radius: 8px;
  margin-bottom: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  min-width: 300px;
  max-width: 350px;
  animation: ${props => props.exiting ? slideOut : slideIn} 0.3s ease;
  animation-fill-mode: forwards;
  display: flex;
  flex-direction: column;
  pointer-events: auto;
  border-left: 4px solid ${props => {
    switch(props.type) {
      case 'success': return '#2EA043';
      case 'error': return '#DA3633';
      case 'warning': return '#F6BE00';
      default: return '#9F9F9F';
    }
  }};
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
`;

const ToastTitle = styled.div`
  font-weight: 600;
  font-size: 16px;
  margin-bottom: 4px;
`;

const ToastMessage = styled.div`
  font-size: 14px;
  opacity: 0.9;
`;

const CloseButton = styled.button`
  position: absolute;
  top: 8px;
  right: 8px;
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 20px;
  cursor: pointer;
  padding: 0;
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
    color: white;
  }
`;

// Component for an individual toast
const Toast = ({ id, title, message, type = 'default', duration = 5000, onClose }) => {
  const [exiting, setExiting] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setExiting(true);
      
      setTimeout(() => {
        onClose(id);
      }, 300);
    }, duration);
    
    return () => clearTimeout(timer);
  }, [id, duration, onClose]);
  
  const handleClose = () => {
    setExiting(true);
    
    setTimeout(() => {
      onClose(id);
    }, 300);
  };
  
  return (
    <ToastItem type={type} exiting={exiting}>
      <CloseButton onClick={handleClose}>&times;</CloseButton>
      {title && <ToastTitle>{title}</ToastTitle>}
      {message && <ToastMessage>{message}</ToastMessage>}
    </ToastItem>
  );
};

// Global toast manager
const toastManager = {
  toasts: [],
  listeners: [],
  
  addToast(toast) {
    const id = Date.now().toString();
    const newToast = { ...toast, id };
    this.toasts = [...this.toasts, newToast];
    this.notifyListeners();
    return id;
  },
  
  removeToast(id) {
    this.toasts = this.toasts.filter(toast => toast.id !== id);
    this.notifyListeners();
  },
  
  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  },
  
  notifyListeners() {
    this.listeners.forEach(listener => listener(this.toasts));
  },
  
  dismiss() {
    this.toasts = [];
    this.notifyListeners();
  }
};

// Toast provider component
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  
  useEffect(() => {
    return toastManager.subscribe(newToasts => {
      setToasts(newToasts);
    });
  }, []);
  
  const handleClose = (id) => {
    toastManager.removeToast(id);
  };
  
  return (
    <>
      {children}
      <ToastContainer>
        {toasts.map(toast => (
          <Toast
            key={toast.id}
            id={toast.id}
            title={toast.title}
            message={toast.message}
            type={toast.type}
            duration={toast.duration}
            onClose={handleClose}
          />
        ))}
      </ToastContainer>
    </>
  );
};

// Toast function
export const toast = (options) => {
  return toastManager.addToast(options);
};

// Add the dismiss method to the toast function
toast.dismiss = () => {
  toastManager.dismiss();
};

export default toast; 