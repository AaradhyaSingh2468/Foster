import React from 'react';
import { Button } from './study-dashboard/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { getStudySets, getFlashcards } from './services/studyService';
import { useToast } from './study-dashboard/lib/useToast';

interface RefreshButtonProps {
  selectedDeckId?: string;
  onRefresh?: (cards: any[]) => void;
}

const RefreshButton: React.FC<RefreshButtonProps> = ({ selectedDeckId, onRefresh }) => {
  const { toast } = useToast();

  const handleRefresh = async () => {
    console.log("Manual refresh triggered");
    try {
      // First fetch all decks
      const studySets = await getStudySets();
      console.log(`Fetched ${studySets.length} study sets from server`);
      
      // If we have a selected deck, fetch its cards
      if (selectedDeckId) {
        const cards = await getFlashcards(selectedDeckId);
        console.log(`Fetched ${cards.length} cards for deck ${selectedDeckId}`);
        
        // Format cards properly
        const formattedCards = cards.map((card: any) => ({
          id: card.id,
          front: card.question || card.front || "No question",
          back: card.answer || card.back || "No answer"
        }));
        
        // Call the callback with the fetched cards
        if (onRefresh) {
          onRefresh(formattedCards);
        }
        
        toast({
          title: "Refreshed",
          description: `Loaded ${formattedCards.length} flashcards`,
          variant: "default"
        });
      } else {
        toast({
          title: "No deck selected",
          description: "Please select a deck first",
          variant: "default"
        });
      }
    } catch (error) {
      console.error("Error refreshing flashcards:", error);
      toast({
        title: "Error",
        description: "Failed to refresh flashcards",
        variant: "destructive"
      });
    }
  };

  return (
    <Button 
      variant="outline" 
      size="sm"
      onClick={handleRefresh}
      className="flex items-center gap-1"
    >
      <RefreshCw className="w-4 h-4" />
      <span>Refresh Cards</span>
    </Button>
  );
};

export default RefreshButton; 