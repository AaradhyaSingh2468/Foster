import { useState, useEffect, createContext, useContext } from 'react';
import { toast as defaultToast } from '../components/Toast';
import { useToast, clearAllToasts } from '../study-dashboard/lib/useToast';

// Create a context for the toast system
const GlobalToastContext = createContext(null);

// Create a provider component
export const GlobalToastProvider = ({ children }) => {
  const [toastQueue, setToastQueue] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast: uiToast } = useToast();
  
  // Process queued toasts one at a time
  useEffect(() => {
    if (toastQueue.length > 0 && !isProcessing) {
      setIsProcessing(true);
      
      const currentToast = toastQueue[0];
      console.log('GlobalToast: Showing toast:', currentToast);
      
      // Always clear existing toasts first
      clearAllToasts();
      
      // Show toast using the UI library
      uiToast({
        title: currentToast.title,
        description: currentToast.message || currentToast.description,
        variant: currentToast.type || 'default',
        duration: currentToast.duration || 5000,
      });
      
      // Remove this toast from the queue after it's displayed
      setTimeout(() => {
        setToastQueue(prev => prev.slice(1));
        setIsProcessing(false);
      }, 300);
    }
  }, [toastQueue, isProcessing, uiToast]);
  
  // Function to show a toast
  const showToast = (options) => {
    // Add toast to queue
    setToastQueue(prev => [...prev, options]);
    
    // Also try using the default toast as a backup
    try {
      defaultToast({
        title: options.title,
        message: options.message || options.description,
        type: options.type,
        duration: options.duration
      });
    } catch (err) {
      console.error('Error showing default toast:', err);
    }
  };
  
  // Function to clear all toasts
  const clearToasts = () => {
    setToastQueue([]);
    clearAllToasts();
    
    // Try to clear default toasts as well
    try {
      if (typeof defaultToast.dismiss === 'function') {
        defaultToast.dismiss();
      }
    } catch (err) {
      console.error('Error dismissing default toasts:', err);
    }
  };
  
  // Expose methods globally for components that can't use the hook
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.globalToast = {
        show: showToast,
        clear: clearToasts
      };
    }
    
    return () => {
      // Clean up global references when component unmounts
      if (typeof window !== 'undefined') {
        window.globalToast = undefined;
      }
    };
  }, []);
  
  // Create the context value
  const contextValue = {
    showToast,
    clearToasts
  };
  
  return (
    <GlobalToastContext.Provider value={contextValue}>
      {children}
    </GlobalToastContext.Provider>
  );
};

// Hook to use the global toast system
export const useGlobalToast = () => {
  const context = useContext(GlobalToastContext);
  if (!context) {
    throw new Error('useGlobalToast must be used within a GlobalToastProvider');
  }
  return context;
};

// Special logout toast function
export const showLogoutToast = () => {
  // Try directly with the global object first
  if (typeof window !== 'undefined' && window.globalToast?.show) {
    window.globalToast.show({
      title: 'Logged out successfully',
      message: 'You have been securely logged out of your account',
      type: 'success',
      duration: 5000
    });
    return;
  }
  
  // Fallback to the default toast
  try {
    defaultToast({
      title: 'Logged out successfully',
      message: 'You have been securely logged out of your account',
      type: 'success',
      duration: 5000
    });
  } catch (err) {
    console.error('Error showing fallback logout toast:', err);
    
    // Last resort - try to use the UI toast directly
    try {
      const { toast, clearAllToasts } = require('../study-dashboard/lib/useToast');
      clearAllToasts();
      toast({
        title: 'Logged out successfully',
        description: 'You have been securely logged out of your account',
        variant: 'success',
        duration: 5000
      });
    } catch (finalErr) {
      console.error('All toast methods failed:', finalErr);
    }
  }
}; 