import { useState, useEffect } from 'react';
import { auth } from '../config/firebase';
import type { User } from 'firebase/auth';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(
      (user: User | null) => {
        setAuthState({
          user,
          isLoading: false,
          error: null,
        });
      },
      (error: Error) => {
        setAuthState({
          user: null,
          isLoading: false,
          error,
        });
      }
    );

    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  return authState;
};

export default useAuth; 