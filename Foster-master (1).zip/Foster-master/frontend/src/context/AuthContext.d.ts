import { ReactNode } from 'react';
import { User, UserCredential } from 'firebase/auth';

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  [key: string]: any;
}

export interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  signInWithEmail: (email: string, password: string) => Promise<UserCredential>;
  signUpWithEmail: (userData: any) => Promise<any>;
  signInWithGoogle: () => Promise<any>;
  signInWithGithub: () => Promise<any>;
  linkAccounts: (credential: any) => Promise<any>;
  logout: () => Promise<void>;
  updateProfile: (profileData: any) => Promise<UserProfile>;
  deleteAccount: () => Promise<{ success: boolean }>;
  clearError: () => void;
}

export const AuthProvider: React.FC<{ children: ReactNode }>;
export const useAuth: () => AuthContextType; 