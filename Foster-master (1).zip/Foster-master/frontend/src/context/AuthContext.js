import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  fetchSignInMethodsForEmail,
  linkWithCredential,
  GithubAuthProvider,
  GoogleAuthProvider,
  // eslint-disable-next-line no-unused-vars
  EmailAuthProvider,
  // eslint-disable-next-line no-unused-vars
  signInWithCredential
} from 'firebase/auth';
import { auth, googleProvider, githubProvider, browserPopupRedirectResolver } from '../config/firebase';
import * as userService from '../services/userService';
// Keep the API import for potential future use with direct API calls
// Used in debugging and development
// eslint-disable-next-line no-unused-vars
import api from '../config/api';

// Create auth context
const AuthContext = createContext();

// Create provider component
export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isUsingRedirect, setIsUsingRedirect] = useState(false);

  // Clear any previous errors
  const clearError = () => setError(null);

  // Check for redirect results
  useEffect(() => {
    const checkRedirectResult = async () => {
      if (isUsingRedirect) {
        try {
          const result = await getRedirectResult(auth);
          if (result) {
            // Handle Google auth
            if (result.providerId === GoogleAuthProvider.PROVIDER_ID) {
              const idToken = await result.user.getIdToken();
              const apiResult = await userService.authenticateWithGoogle(idToken);
              if (apiResult.user) {
                setUserProfile({
                  ...apiResult.user,
                  provider: 'google'
                });
              }
            }
            // Handle GitHub auth
            else if (result.providerId === GithubAuthProvider.PROVIDER_ID) {
              const credential = GithubAuthProvider.credentialFromResult(result);
              const token = credential.accessToken;
              const apiResult = await userService.authenticateWithGithub(token);
              if (apiResult.user) {
                setUserProfile({
                  ...apiResult.user,
                  provider: 'github'
                });
              }
            }
            setIsUsingRedirect(false);
          }
        } catch (err) {
          console.error("Error processing redirect result:", err);
          setError("Error signing in after redirect");
          setIsUsingRedirect(false);
        }
      }
    };
    
    checkRedirectResult();
  }, [isUsingRedirect]);

  // Fetch user profile from API
  const fetchUserProfile = async (user) => {
    if (!user) return;
    
    try {
      const profile = await userService.getUserProfile();
      setUserProfile(profile);
      return profile;
    } catch (err) {
      console.error("Error fetching user profile:", err);
      // Don't set error state here to avoid disrupting auth flow
      return null;
    }
  };

  // Sign in with email and password
  const signInWithEmail = async (email, password) => {
    setLoading(true);
    clearError();
    try {
      // Authenticate directly with our backend
      const result = await userService.loginWithEmail(email, password);
      
      // userService already stores tokens in localStorage
      
      // Set user profile from response
      if (result.user) {
        setUserProfile(result.user);
      }
      
      // Set current user for Firebase (optional, can be removed if not using Firebase)
      try {
        await signInWithEmailAndPassword(auth, email, password);
      } catch (firebaseError) {
        console.warn("Firebase auth error (non-critical):", firebaseError);
      }
      
      return result;
    } catch (err) {
      setError(err.message || "Invalid email or password");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign up with email and password
  const signUpWithEmail = async (userData) => {
    // eslint-disable-next-line no-unused-vars
    const { email, password, name } = userData;
    setLoading(true);
    clearError();
    try {
      // Register directly with our backend
      const result = await userService.registerWithEmail(userData);
      
      // userService already stores tokens in localStorage
      
      // Set user profile from response
      if (result.user) {
        setUserProfile(result.user);
      }
      
      // Create user in Firebase (optional, can be removed if not using Firebase)
      try {
        await createUserWithEmailAndPassword(auth, email, password);
      } catch (firebaseError) {
        console.warn("Firebase auth error (non-critical):", firebaseError);
      }
      
      return result;
    } catch (err) {
      setError(err.message || "Registration failed");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign in with Google
  const signInWithGoogle = async () => {
    setLoading(true);
    clearError();
    try {
      // First try with popup
      try {
        console.log("Starting Google sign-in with popup...");
        const result = await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
        console.log("Firebase Google sign-in successful:", result);
        
        // Get ID token for backend authentication
        const idToken = await result.user.getIdToken();
        console.log("Got ID token from Firebase, length:", idToken?.length);
        
        // Authenticate with our backend
        console.log("Sending token to backend...");
        const apiResult = await userService.authenticateWithGoogle(idToken);
        console.log("Backend authentication successful:", apiResult);
        
        // Check if this is a new user from the backend response
        if (apiResult.is_new_user) {
          console.log("Backend indicates this is a new user");
          localStorage.setItem('signupIntent', 'true');
        }
        
        // Save the profile picture if provided by Google
        if (result.user?.photoURL) {
          try {
            console.log("Setting avatar from Google:", result.user.photoURL);
            await userService.setAvatarFromOAuth(result.user.photoURL);
          } catch (avatarError) {
            console.warn("Error setting avatar from Google:", avatarError);
            // Continue even if avatar update fails
          }
        }
        
        // Set user profile from the backend response
        if (apiResult.user) {
          setUserProfile({
            ...apiResult.user,
            provider: 'google',
            is_new_user: apiResult.is_new_user
          });
        } else {
          // Fetch user profile if not included in response
          await fetchUserProfile(result.user);
        }
        
        return {
          ...result,
          additionalUserInfo: {
            ...result.additionalUserInfo,
            isNewUser: apiResult.is_new_user || result.additionalUserInfo?.isNewUser
          }
        };
      } catch (popupError) {
        console.warn("Popup auth failed, falling back to redirect:", popupError);
        // Check if it's a COOP error
        if (popupError.message && popupError.message.includes("Cross-Origin-Opener-Policy")) {
          // Fall back to redirect method
          setIsUsingRedirect(true);
          await signInWithRedirect(auth, googleProvider);
          // The result will be handled in the useEffect above
          return null;
        } else {
          // Re-throw other errors
          throw popupError;
        }
      }
    } catch (err) {
      console.error("Google Authentication Error:", err);
      setError(err.message || "Error signing in with Google");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Sign in with GitHub
  const signInWithGithub = async () => {
    console.log("AuthContext: Starting GitHub authentication...");
    setLoading(true);
    clearError();
    try {
      // First try with popup
      try {
        const result = await signInWithPopup(auth, githubProvider, browserPopupRedirectResolver);
        console.log("AuthContext: GitHub authentication success:", result);
        
        // Get access token from result
        const credential = GithubAuthProvider.credentialFromResult(result);
        const token = credential.accessToken;
        
        // Authenticate with our backend
        const apiResult = await userService.authenticateWithGithub(token);
        
        // Save the profile picture if provided by GitHub
        if (result.user?.photoURL) {
          try {
            console.log("Setting avatar from GitHub:", result.user.photoURL);
            await userService.setAvatarFromOAuth(result.user.photoURL);
          } catch (avatarError) {
            console.warn("Error setting avatar from GitHub:", avatarError);
            // Continue even if avatar update fails
          }
        }
        
        // Set user profile from the backend response
        if (apiResult.user) {
          setUserProfile({
            ...apiResult.user,
            provider: 'github'
          });
        } else {
          // Fetch user profile if not included in response
          await fetchUserProfile(result.user);
        }
        
        return result;
      } catch (popupError) {
        console.warn("Popup auth failed, falling back to redirect:", popupError);
        // Check if it's a COOP error
        if (popupError.message && popupError.message.includes("Cross-Origin-Opener-Policy")) {
          // Fall back to redirect method
          setIsUsingRedirect(true);
          await signInWithRedirect(auth, githubProvider);
          // The result will be handled in the useEffect above
          return null;
        } else {
          // Re-throw other errors
          throw popupError;
        }
      }
    } catch (err) {
      console.error("GitHub Authentication Error:", err);
      console.error("Error code:", err.code);
      console.error("Error message:", err.message);
      console.error("Error details:", {
        name: err.name,
        stack: err.stack,
        customData: err.customData
      });
      
      if (err.customData) {
        console.error("Custom data email:", err.customData.email);
        console.error("Custom data tenant:", err.customData.tenantId);
      }
      
      // Handle the account-exists-with-different-credential error
      if (err.code === 'auth/account-exists-with-different-credential') {
        try {
          // Get email from the error
          const email = err.customData.email;
          console.log("Attempting to resolve credential conflict for email:", email);
          
          // Fetch sign-in methods for this email
          const methods = await fetchSignInMethodsForEmail(auth, email);
          console.log("Available sign-in methods for this email:", methods);
          
          // Store the GitHub credential for later use
          // eslint-disable-next-line no-unused-vars
          const githubCredential = GithubAuthProvider.credentialFromError(err);
          
          if (methods.includes('google.com')) {
            // User has previously signed in with Google
            setError("This email is already registered with Google. Please sign in with Google to link your GitHub account.");
          } 
          else if (methods.includes('password')) {
            // User has previously signed in with email/password
            setError("This email is already registered with email/password. Please sign in with your email and password to link your GitHub account.");
          }
          else {
            // Handle other providers if needed
            setError(`This email is already registered with another method. Please sign in with one of these methods: ${methods.join(', ')}`);
          }
        } catch (linkError) {
          console.error("Error linking credentials:", linkError);
          setError("Error linking your accounts. Please try signing in with your original method.");
        }
      } else if (err.code === 'auth/popup-closed-by-user') {
        setError("Sign-in popup was closed before completing the sign-in process.");
      } else if (err.code === 'auth/popup-blocked') {
        setError("Sign-in popup was blocked by the browser. Please allow popups for this website.");
      } else if (err.code === 'auth/cancelled-popup-request') {
        setError("Multiple popup requests were made. Only the latest popup is shown.");
      } else if (err.code === 'auth/operation-not-allowed') {
        setError("GitHub authentication is not enabled in Firebase Console.");
      } else {
        setError(err.message || "Error signing in with GitHub");
      }
      
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Helper function to link accounts
  const linkAccounts = async (credential) => {
    if (!currentUser) return null;
    
    try {
      const result = await linkWithCredential(currentUser, credential);
      console.log("Accounts successfully linked!");
      return result;
    } catch (error) {
      console.error("Error linking accounts:", error);
      throw error;
    }
  };

  // Sign out
  const logout = async () => {
    setLoading(true);
    clearError();
    
    let backendLogoutSuccess = false;
    let firebaseLogoutSuccess = false;
    
    try {
      // First try to log out from the backend to terminate the session
      try {
        console.log("Attempting to log out from backend...");
        await userService.logout();
        console.log("Backend logout successful");
        backendLogoutSuccess = true;
      } catch (backendError) {
        console.error("Error during backend logout:", backendError);
        // Continue with Firebase logout even if backend logout fails
      }
      
      // Then sign out from Firebase
      try {
        console.log("Attempting to sign out from Firebase...");
        await signOut(auth);
        console.log("Firebase sign out successful");
        firebaseLogoutSuccess = true;
      } catch (firebaseError) {
        console.error("Error during Firebase sign out:", firebaseError);
        // Continue with cleanup even if Firebase sign out fails
      }
      
      // Clear tokens and user data from localStorage regardless of errors
      console.log("Clearing localStorage data...");
      localStorage.removeItem('authToken');
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      localStorage.removeItem('sessionId');
      localStorage.removeItem('signupIntent');
      localStorage.removeItem('onboardingCompleted');
      
      // Clear user profile
      setUserProfile(null);
      
      // Log final status
      if (backendLogoutSuccess && firebaseLogoutSuccess) {
        console.log("Logout completed successfully");
      } else {
        console.warn("Logout completed with some errors:", 
          { backendLogoutSuccess, firebaseLogoutSuccess });
      }
      
      return { success: true };
    } catch (err) {
      console.error("Unhandled error during logout:", err);
      setError("Error during logout process. Please try again.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Update user profile
  const updateProfile = async (profileData) => {
    setLoading(true);
    clearError();
    try {
      const updatedProfile = await userService.updateUserProfile(profileData);
      setUserProfile(updatedProfile);
      return updatedProfile;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Refresh user profile
  const refreshProfile = async () => {
    setLoading(true);
    clearError();
    try {
      const profile = await userService.refreshUserProfile();
      setUserProfile(profile);
      return profile;
    } catch (err) {
      console.error("Error refreshing user profile:", err);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Delete user account
  const deleteAccount = async () => {
    setLoading(true);
    clearError();
    try {
      // Get the current Firebase user for deletion
      const user = auth.currentUser;
      
      // Call the backend to delete the account from MongoDB
      const backendResponse = await userService.deleteUserAccount();
      console.log("Backend delete response:", backendResponse);
      
      // Try to delete the user from Firebase directly if possible
      if (user) {
        try {
          console.log("Attempting to delete Firebase user");
          // We can't delete the user directly from client-side Firebase SDK
          // Instead, we need to reauthenticate the user and then delete
          // This is why we handle this on the backend
          
          // However, we can still try to sign out properly
          await signOut(auth);
          console.log("Successfully signed out Firebase user");
        } catch (firebaseError) {
          console.error("Error with Firebase during account deletion:", firebaseError);
          // Continue anyway as the backend should have deleted the MongoDB user
        }
      } else {
        console.warn("No Firebase user found to delete");
      }
      
      // Clear user data
      setCurrentUser(null);
      setUserProfile(null);
      
      // Clear all auth data from localStorage
      localStorage.removeItem('accessToken');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('user');
      localStorage.removeItem('sessionId');
      localStorage.removeItem('authToken');
      
      return { success: true, message: "Account successfully deleted" };
    } catch (err) {
      console.error("Error deleting account:", err);
      setError(err.message || "Failed to delete account");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Function to directly clear all toast notifications by accessing the internal memoryState
  const clearAllToasts = () => {
    try {
      // Try to directly dispatch a clear all toasts action
      // This works with the toast implementation in study-dashboard
      if (typeof window !== 'undefined') {
        // Find any toast dispatch function in the window
        if (window.dispatchToastAction) {
          window.dispatchToastAction({
            type: "REMOVE_TOAST",
            id: "all"
          });
        } else {
          // Direct access to the toast's internal state
          const toastModule = require('../study-dashboard/lib/useToast');
          if (toastModule && toastModule.dispatch) {
            toastModule.dispatch({
              type: "REMOVE_TOAST",
              id: "all"
            });
          }
        }
      }
    } catch (error) {
      console.error("Failed to clear toasts:", error);
    }
  };

  // Handle Firebase auth state changes
  useEffect(() => {
    setLoading(true);
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      console.log("AuthContext: Auth state changed", firebaseUser ? "User authenticated" : "User signed out");
      
      if (firebaseUser) {
        // User is signed in
        try {
          // Store Firebase user info
          setCurrentUser(firebaseUser);
          localStorage.setItem('firebaseUser', JSON.stringify({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName,
            photoURL: firebaseUser.photoURL
          }));
          
          // Check if we need to fix the profile picture
          try {
            // Wait a moment to ensure auth is fully processed
            setTimeout(async () => {
              await userService.checkAndFixProfilePicture();
            }, 2000);
          } catch (profileError) {
            console.error("Error fixing profile picture:", profileError);
          }
          
          // Try to get user profile from backend
          try {
            const profile = await userService.getUserProfile();
            setUserProfile(profile);
          } catch (profileError) {
            console.error("Error fetching user profile:", profileError);
          }
        } catch (error) {
          console.error("Error in auth state change handler:", error);
        } finally {
          setLoading(false);
        }
      } else {
        // User is signed out
        setCurrentUser(null);
        setUserProfile(null);
        localStorage.removeItem('user');
        localStorage.removeItem('firebaseUser');
        localStorage.removeItem('token');
        setLoading(false);
      }
    });
    
    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  // Context value
  const value = {
    currentUser,
    userProfile,
    loading,
    error,
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    signInWithGithub,
    linkAccounts,
    logout,
    updateProfile,
    refreshProfile,
    deleteAccount,
    clearError
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

// Custom hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext);
}; 