import React, { createContext, useContext, useState } from 'react';

// Define types
const UserRoles = {
  STUDENT: 'student',
  TEACHER: 'teacher',
  PROFESSIONAL: 'professional',
  PARENT: 'parent',
  OTHER: 'other'
};

const ExperienceLevels = {
  BEGINNER: 'beginner',
  INTERMEDIATE: 'intermediate',
  ADVANCED: 'advanced',
  EXPERT: 'expert',
  NOT_SURE: 'not-sure'
};

const LearningStyles = {
  VISUAL: 'visual',
  READING: 'reading',
  INTERACTIVE: 'interactive',
  AUDITORY: 'auditory',
  KINESTHETIC: 'kinesthetic'
};

const LearningGoals = {
  ACADEMIC: 'academic',
  CAREER: 'career',
  PERSONAL: 'personal',
  CERTIFICATION: 'certification',
  OTHER: 'other'
};

// Initial state for onboarding data
const defaultOnboardingData = {
  interests: [],
};

// Create the context
const OnboardingContext = createContext();

// Custom hook to use the onboarding context
export const useOnboarding = () => {
  const context = useContext(OnboardingContext);
  if (context === undefined) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
};

// Provider component
export const OnboardingProvider = ({ children }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState(defaultOnboardingData);
  const [direction, setDirection] = useState('forward');
  const totalSteps = 6;  // Updated to include completion step

  const updateOnboardingData = (data) => {
    setOnboardingData((prev) => ({ ...prev, ...data }));
  };

  const goToNextStep = () => {
    if (currentStep <= totalSteps) {
      setDirection('forward');
      setCurrentStep((prev) => prev + 1);
    }
  };

  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setDirection('backward');
      setCurrentStep((prev) => prev - 1);
    }
  };

  const goToStep = (step) => {
    if (step >= 1 && step <= totalSteps) {
      setDirection(step > currentStep ? 'forward' : 'backward');
      setCurrentStep(step);
    }
  };

  const isStepComplete = (step) => {
    switch (step) {
      case 1: // Role selection
        return !!onboardingData.role;
      case 2: // Experience level selection
        return !!onboardingData.experienceLevel;
      case 3: // Interests selection
        return onboardingData.interests && onboardingData.interests.length > 0;
      case 4: // Learning style
        return !!onboardingData.learningStyle;
      case 5: // Learning goal
        return !!onboardingData.learningGoal;
      default:
        return false;
    }
  };

  const value = {
    currentStep,
    totalSteps,
    onboardingData,
    direction,
    updateOnboardingData,
    goToNextStep,
    goToPreviousStep,
    goToStep,
    isStepComplete,
    // Export constants
    UserRoles,
    ExperienceLevels,
    LearningStyles,
    LearningGoals,
  };

  return <OnboardingContext.Provider value={value}>{children}</OnboardingContext.Provider>;
};

export default OnboardingContext; 