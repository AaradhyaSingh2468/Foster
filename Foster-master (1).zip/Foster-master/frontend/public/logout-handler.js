/**
 * Logout Handler Script
 * 
 * This script runs outside of React to ensure logout toasts are
 * displayed even when React components are unmounted or during navigation.
 */

(function() {
  console.log("Logout handler initialized");
  let lastToastAttempt = 0;
  let attemptCount = 0;
  const MAX_ATTEMPTS = 5;
  
  // Check on both load and DOM content loaded for maximum coverage
  function checkLogoutFlags() {
    // Multiple indicators to check
    const showLogoutMessage = localStorage.getItem('show_logout_message');
    const justLoggedOut = sessionStorage.getItem('just_logged_out');
    const logoutTimestamp = localStorage.getItem('logout_timestamp');
    const toastShown = localStorage.getItem('logout_toast_shown') === 'true';
    
    // If toast was recently shown, don't show it again
    if (toastShown) {
      // Clean up flags
      localStorage.removeItem('show_logout_message');
      sessionStorage.removeItem('just_logged_out');
      return;
    }
    
    // If any indicator is present
    if (showLogoutMessage || justLoggedOut || logoutTimestamp) {
      console.log("Logout handler: Detected logout flags");
      
      // Try to show toast with several strategies
      const success = tryShowLogoutToast();
      
      if (success) {
        // Clean up flags to prevent duplicates
        localStorage.removeItem('show_logout_message');
        sessionStorage.removeItem('just_logged_out');
        
        // Keep timestamp for a short time to support other components
        if (logoutTimestamp) {
          setTimeout(() => {
            localStorage.removeItem('logout_timestamp');
          }, 5000);
        }
      } else {
        // If not successful and we haven't tried too many times, retry after a delay
        attemptCount++;
        if (attemptCount < MAX_ATTEMPTS) {
          console.log(`Logout handler: Toast attempt ${attemptCount} failed, will retry`);
          setTimeout(checkLogoutFlags, 1000);
        } else {
          console.log("Logout handler: Maximum attempts reached, giving up");
          // Clean up anyway to prevent future attempts
          localStorage.removeItem('show_logout_message');
          sessionStorage.removeItem('just_logged_out');
        }
      }
    }
  }
  
  // Try multiple approaches to show toast
  function tryShowLogoutToast() {
    // Avoid trying too frequently
    const now = Date.now();
    if (now - lastToastAttempt < 1000) {
      return false;
    }
    lastToastAttempt = now;
    
    console.log("Logout handler: Attempting to show toast");
    
    // Strategy 1: Direct call to window.showLogoutToast
    if (typeof window.showLogoutToast === 'function') {
      try {
        window.showLogoutToast();
        console.log("Logout handler: Successfully called window.showLogoutToast");
        return true;
      } catch (err) {
        console.error("Error calling showLogoutToast:", err);
      }
    }
    
    // Strategy 2: Use toast dispatch directly
    if (window.dispatchToastAction) {
      try {
        // Record that we're showing the toast
        localStorage.setItem('logout_toast_timestamp', Date.now().toString());
        localStorage.setItem('logout_toast_shown', 'true');
        
        // Clear existing toasts first if possible
        if (window.clearAllToasts) {
          try {
            window.clearAllToasts();
          } catch (err) {
            console.error("Error clearing toasts:", err);
          }
        }
        
        // Show the toast
        window.dispatchToastAction({
          type: "ADD_TOAST",
          toast: {
            id: "logout-" + Date.now(),
            title: "Logged out successfully",
            description: "You have been securely logged out of your account",
            variant: "success",
            duration: 5000,
            open: true
          }
        });
        console.log("Logout handler: Successfully dispatched toast action");
        return true;
      } catch (err) {
        console.error("Error dispatching toast action:", err);
      }
    }
    
    // Strategy 3: Store data for when toast system is available
    localStorage.setItem('logout_toast_data', JSON.stringify({
      title: "Logged out successfully",
      description: "You have been securely logged out of your account",
      variant: "success",
      timestamp: Date.now()
    }));
    
    // Strategy 4: Dispatch event for listeners
    try {
      document.dispatchEvent(new CustomEvent('userLoggedOut', {
        detail: {
          timestamp: Date.now()
        }
      }));
      console.log("Logout handler: Dispatched userLoggedOut event");
    } catch (err) {
      console.error("Error dispatching logout event:", err);
    }
    
    // Strategy 5: Alert as a last resort if more than 3 attempts
    if (attemptCount > 3) {
      console.log("Logout handler: Using alert as last resort");
      try {
        setTimeout(() => {
          // Only show if toast still not shown
          if (!localStorage.getItem('logout_toast_shown')) {
            alert("You have been successfully logged out.");
            localStorage.setItem('logout_toast_shown', 'true');
          }
        }, 1000);
      } catch (err) {
        console.error("Error showing alert:", err);
      }
    }
    
    return false;
  }
  
  // Check on page load
  window.addEventListener('load', function() {
    console.log("Logout handler: Window loaded");
    setTimeout(checkLogoutFlags, 500);
  });
  
  // Also check when DOM is ready (earlier than load)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      console.log("Logout handler: DOM content loaded");
      setTimeout(checkLogoutFlags, 300);
    });
  } else {
    console.log("Logout handler: DOM already loaded, checking now");
    setTimeout(checkLogoutFlags, 100);
  }
  
  // Check periodically for logout flags in case of navigation
  const intervalId = setInterval(function() {
    // Check for flags
    const showLogoutMessage = localStorage.getItem('show_logout_message');
    const justLoggedOut = sessionStorage.getItem('just_logged_out');
    
    if (showLogoutMessage || justLoggedOut) {
      checkLogoutFlags();
    }
  }, 2000);
  
  // Listen for logout event from React
  document.addEventListener('userLogout', function() {
    console.log("Logout handler: Received userLogout event");
    attemptCount = 0; // Reset attempt count for new logout
    setTimeout(checkLogoutFlags, 100);
  });
  
  // Clear the logout_toast_shown flag after 30 seconds
  setInterval(function() {
    const shownTimestamp = parseInt(localStorage.getItem('logout_toast_timestamp') || '0', 10);
    const now = Date.now();
    
    if (now - shownTimestamp > 30000) {
      localStorage.removeItem('logout_toast_shown');
    }
  }, 10000);
})(); 