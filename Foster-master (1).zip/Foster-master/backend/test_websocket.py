#!/usr/bin/env python
"""
WebSocket Test Client

This script establishes a WebSocket connection to the local server
to test WebSocket functionality.

Usage:
    python test_websocket.py [endpoint] [token]

Example:
    python test_websocket.py echo
    python test_websocket.py flashcards eyJhbGc...token
"""

import asyncio
import json
import sys
import websockets
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Default values
DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8000
DEFAULT_ENDPOINT = "echo"

async def test_websocket_connection(endpoint, token=None):
    """Test WebSocket connection to the specified endpoint."""
    
    # Construct WebSocket URL
    ws_url = f"ws://{DEFAULT_HOST}:{DEFAULT_PORT}/ws/{endpoint}/"
    if token:
        ws_url += f"?token={token}"
    
    logger.info(f"Connecting to: {ws_url}")
    
    try:
        async with websockets.connect(ws_url) as websocket:
            logger.info("WebSocket connection established!")
            
            # Send a ping message
            ping_msg = json.dumps({"type": "ping", "data": "Testing connection"})
            logger.info(f"Sending: {ping_msg}")
            await websocket.send(ping_msg)
            
            # Wait for a response
            response = await websocket.recv()
            logger.info(f"Received: {response}")
            
            # Keep connection open for a while to observe behavior
            logger.info("Connection is stable. Waiting for 5 seconds...")
            await asyncio.sleep(5)
            
            # Send another message
            status_msg = json.dumps({"type": "status", "data": "Test completed"})
            logger.info(f"Sending: {status_msg}")
            await websocket.send(status_msg)
            
            # Wait for response
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=2.0)
                logger.info(f"Received: {response}")
            except asyncio.TimeoutError:
                logger.warning("No response received within timeout")
            
            logger.info("Test completed successfully!")
    
    except websockets.exceptions.ConnectionClosed as e:
        logger.error(f"WebSocket connection closed: {e}")
    except Exception as e:
        logger.error(f"Error during WebSocket test: {e}")

if __name__ == "__main__":
    # Get endpoint from command line args or use default
    endpoint = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_ENDPOINT
    
    # Get token from command line args if provided
    token = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Run the test
    asyncio.run(test_websocket_connection(endpoint, token)) 