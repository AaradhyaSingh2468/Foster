from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
import firebase_admin
from firebase_admin import auth as firebase_auth
from foster.mongodb import get_collection, delete_document, get_documents
from bson.objectid import ObjectId
import logging
import traceback
import datetime
from .models import UserStreak, UserObjective, StudyEvent
from study.models import StudySet, Flashcard, StudyProgress, Quiz, QuizQuestion
from foster.authentication import MongoDBUser

# Set up logging
logger = logging.getLogger(__name__)

class UserProfileView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        try:
            # Get user ID from request
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            logger.info(f"Fetching profile for user ID: {user_id}")
            
            # Get user profile from MongoDB
            profile_collection = get_collection('user_profiles')
            profile = profile_collection.find_one({"user_id": user_id})
            
            if not profile:
                # If profile doesn't exist, get the user and create an empty profile
                users_collection = get_collection('users')
                user = users_collection.find_one({"_id": ObjectId(user_id)})
                
                if not user:
                    logger.warning(f"User {user_id} not found in database")
                    return Response(
                        {"error": "User not found"},
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                logger.info(f"Creating new profile for user {user_id}")
                
                # Create an empty profile
                profile = {
                    "user_id": user_id,
                    "avatar": user.get('oauth_picture', None),
                    "bio": "",
                    "date_of_birth": None,
                    "education_level": "",
                    "institution": "",
                    "major": "",
                    "created_at": datetime.datetime.now(),
                    "updated_at": datetime.datetime.now(),
                    "onboarding_completed": False
                }
                
                # Insert profile into database
                profile_id = profile_collection.insert_one(profile).inserted_id
                profile["_id"] = str(profile_id)
                logger.info(f"Created new profile for user {user_id} with onboarding_completed=False")
            else:
                # Convert ObjectId to string for JSON serialization
                profile["_id"] = str(profile["_id"])
                logger.info(f"Found existing profile for user {user_id}")
                logger.info(f"Current onboarding status: {profile.get('onboarding_completed')}")
                
                # Auto-update onboarding_completed if not set but profile has data
                if profile.get("onboarding_completed") is None:
                    has_profile_data = (
                        profile.get("bio") or 
                        profile.get("education_level") or 
                        profile.get("institution") or 
                        profile.get("major")
                    )
                    
                    logger.info(f"Profile data check - bio: {bool(profile.get('bio'))}, education: {bool(profile.get('education_level'))}, institution: {bool(profile.get('institution'))}, major: {bool(profile.get('major'))}")
                    
                    if has_profile_data:
                        # This user has profile data but onboarding_completed isn't set
                        profile["onboarding_completed"] = True
                        # Update the profile in the database
                        profile_collection.update_one(
                            {"_id": ObjectId(profile["_id"])},
                            {"$set": {"onboarding_completed": True}}
                        )
                        logger.info(f"Auto-updated onboarding_completed to True for user {user_id}")
            
            # Get user info to include in response
            users_collection = get_collection('users')
            user = users_collection.find_one({"_id": ObjectId(user_id)})
            
            if user:
                # Add user fields to profile response
                profile["username"] = user.get("username", "")
                profile["email"] = user.get("email", "")
                profile["provider"] = user.get("oauth_provider", "")
            
            # Ensure onboarding_completed is a proper boolean
            if "onboarding_completed" in profile:
                # Convert to boolean value
                if isinstance(profile["onboarding_completed"], bool):
                    pass  # Already a boolean
                elif isinstance(profile["onboarding_completed"], str):
                    # Convert string to boolean
                    profile["onboarding_completed"] = profile["onboarding_completed"].lower() == 'true'
                else:
                    # Convert other values using Python's truth testing
                    profile["onboarding_completed"] = bool(profile["onboarding_completed"])
                
                logger.info(f"Normalized onboarding_completed to {profile['onboarding_completed']} (type: {type(profile['onboarding_completed']).__name__})")
            
            logger.info(f"Returning profile with onboarding_completed={profile.get('onboarding_completed')}")
            return Response(profile)
        except Exception as e:
            logger.error(f"Error getting user profile: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to get user profile: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def put(self, request):
        try:
            # Get user ID from request
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Get profile data from request
            profile_data = request.data
            
            # Add updated_at timestamp
            profile_data["updated_at"] = datetime.datetime.now()
            
            # Update profile in MongoDB
            profile_collection = get_collection('user_profiles')
            result = profile_collection.update_one(
                {"user_id": user_id},
                {"$set": profile_data},
                upsert=True
            )
            
            if result.modified_count > 0 or result.upserted_id:
                # Get updated profile
                updated_profile = profile_collection.find_one({"user_id": user_id})
                if updated_profile:
                    # Convert ObjectId to string for JSON serialization
                    updated_profile["_id"] = str(updated_profile["_id"])
                    return Response(updated_profile)
            
            return Response(
                {"message": "No changes made to profile"},
                status=status.HTTP_200_OK
            )
        except Exception as e:
            logger.error(f"Error updating user profile: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update user profile: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class UserAvatarView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            # Get user ID from request
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Check if avatar file was uploaded
            if 'avatar' not in request.FILES:
                return Response(
                    {"error": "No avatar file provided"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            avatar_file = request.FILES['avatar']
            
            # Save the file to media directory
            # You might want to use a cloud storage service in production
            from django.conf import settings
            import os
            from datetime import datetime
            
            # Create a unique filename
            filename = f"avatar_{user_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}{os.path.splitext(avatar_file.name)[1]}"
            filepath = os.path.join(settings.MEDIA_ROOT, 'avatars', filename)
            
            # Ensure the directory exists
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            # Save the file
            with open(filepath, 'wb+') as destination:
                for chunk in avatar_file.chunks():
                    destination.write(chunk)
            
            # Generate URL for the avatar
            avatar_url = f"{settings.MEDIA_URL}avatars/{filename}"
            
            # Update user profile in MongoDB
            profile_collection = get_collection('user_profiles')
            result = profile_collection.update_one(
                {"user_id": user_id},
                {"$set": {"avatar": avatar_url, "updated_at": datetime.datetime.now()}}
            )
            
            # If no profile exists, create one
            if result.matched_count == 0:
                profile_data = {
                    "user_id": user_id,
                    "avatar": avatar_url,
                    "bio": "",
                    "date_of_birth": None,
                    "education_level": "",
                    "institution": "",
                    "major": "",
                    "created_at": datetime.datetime.now(),
                    "updated_at": datetime.datetime.now(),
                    "onboarding_completed": False
                }
                profile_collection.insert_one(profile_data)
            
            # Also update the avatar in the users collection if it exists
            users_collection = get_collection('users')
            users_collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": {"oauth_picture": avatar_url}}
            )
            
            return Response({
                "message": "Avatar updated successfully",
                "avatar_url": avatar_url
            })
        except Exception as e:
            logger.error(f"Error updating avatar: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update avatar: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class UserAvatarUrlView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            # Get user ID from request
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Get avatar URL from request data
            avatar_url = request.data.get('avatarUrl')
            if not avatar_url:
                return Response(
                    {"error": "No avatar URL provided"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Update user profile in MongoDB
            profile_collection = get_collection('user_profiles')
            result = profile_collection.update_one(
                {"user_id": user_id},
                {"$set": {"avatar": avatar_url, "updated_at": datetime.datetime.now()}}
            )
            
            # If no profile exists, create one
            if result.matched_count == 0:
                profile_data = {
                    "user_id": user_id,
                    "avatar": avatar_url,
                    "bio": "",
                    "date_of_birth": None,
                    "education_level": "",
                    "institution": "",
                    "major": "",
                    "created_at": datetime.datetime.now(),
                    "updated_at": datetime.datetime.now(),
                    "onboarding_completed": False
                }
                profile_collection.insert_one(profile_data)
            
            # Also update the avatar in the users collection if it exists
            users_collection = get_collection('users')
            users_collection.update_one(
                {"_id": ObjectId(user_id)},
                {"$set": {"oauth_picture": avatar_url}}
            )
            
            return Response({
                "message": "Avatar URL updated successfully",
                "avatar_url": avatar_url
            })
        except Exception as e:
            logger.error(f"Error updating avatar URL: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update avatar URL: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class UserPreferencesView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        # Placeholder
        return Response({"message": "User preferences endpoint"})
    
    def put(self, request):
        # Placeholder
        return Response({"message": "User preferences update endpoint"})

class OnboardingStatusView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            # Get user ID from request
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Get onboarding data from request
            onboarding_data = request.data.get('onboarding_data', {})
            onboarding_completed = request.data.get('onboarding_completed', True)
            
            # Log the onboarding data
            logger.info(f"Updating onboarding status for user {user_id}: {onboarding_completed}")
            logger.debug(f"Onboarding data: {onboarding_data}")
            
            # Update user profile in MongoDB
            profile_collection = get_collection('user_profiles')
            
            # First get the current profile
            profile = profile_collection.find_one({"user_id": user_id})
            
            if not profile:
                # Create a new profile if it doesn't exist
                profile = {
                    "user_id": user_id,
                    "created_at": datetime.datetime.now(),
                    "updated_at": datetime.datetime.now(),
                }
            
            # Update the profile with onboarding data
            update_data = {
                "onboarding_completed": onboarding_completed,
                "updated_at": datetime.datetime.now()
            }
            
            # Add onboarding data fields if provided
            if onboarding_data:
                if 'role' in onboarding_data:
                    update_data['role'] = onboarding_data['role']
                if 'experienceLevel' in onboarding_data:
                    update_data['experience_level'] = onboarding_data['experienceLevel']
                if 'learningStyle' in onboarding_data:
                    update_data['learning_style'] = onboarding_data['learningStyle']
                if 'learningGoal' in onboarding_data:
                    update_data['learning_goal'] = onboarding_data['learningGoal']
                if 'interests' in onboarding_data:
                    update_data['interests'] = onboarding_data['interests']
            
            # Update the profile
            result = profile_collection.update_one(
                {"user_id": user_id},
                {"$set": update_data},
                upsert=True
            )
            
            if result.modified_count > 0 or result.upserted_id:
                logger.info(f"Successfully updated onboarding status for user {user_id}")
                return Response({
                    "message": "Onboarding status updated successfully",
                    "onboarding_completed": onboarding_completed
                })
            else:
                logger.warning(f"No changes made to onboarding status for user {user_id}")
                return Response({
                    "message": "No changes made to onboarding status",
                    "onboarding_completed": onboarding_completed
                })
                
        except Exception as e:
            logger.error(f"Error updating onboarding status: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update onboarding status: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class UserStatisticsView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        # If user is not authenticated, return empty statistics
        if not request.user.is_authenticated:
            return Response({
                "streak": 0,
                "study_sets_count": 0,
                "flashcards_count": 0,
                "completed_sets": 0,
                "upcoming_events": 0,
                "objectives": {
                    "completed": 0,
                    "total": 0,
                    "items": []
                },
                "study_time": {
                    "total_minutes": 0,
                    "this_week": 0,
                    "last_week": 0
                },
                "accuracy": {
                    "overall": 0,
                    "this_week": 0
                }
            })
            
        try:
            user = request.user
            
            # Check if this is a MongoDB user or regular Django user
            is_mongodb_user = isinstance(user, MongoDBUser)
            
            # Get streak info
            streak = 0
            if not is_mongodb_user:
                try:
                    streak_obj, created = UserStreak.objects.get_or_create(user=user)
                    if created or not streak_obj.last_activity_date:
                        streak = 0
                    else:
                        streak = streak_obj.current_streak
                except Exception as e:
                    logger.error(f"Error getting user streak: {str(e)}", exc_info=True)
            
            # For MongoDB users, use MongoDB collections directly
            if is_mongodb_user:
                # Get MongoDB collections
                study_sets_collection = get_collection('study_sets')
                flashcards_collection = get_collection('flashcards')
                study_events_collection = get_collection('study_events')
                objectives_collection = get_collection('user_objectives')
                
                # Get user ID string
                user_id = user.user_id
                
                # Get study sets count
                study_sets_count = study_sets_collection.count_documents({"user_id": user_id})
                
                # Get flashcards count
                study_set_ids = [doc['_id'] for doc in study_sets_collection.find({"user_id": user_id}, {"_id": 1})]
                flashcards_count = flashcards_collection.count_documents({"study_set_id": {"$in": study_set_ids}})
                
                # Get completed sets
                completed_sets = 0
                
                # Get upcoming events
                from datetime import datetime, timedelta
                today = datetime.now()
                next_week = today + timedelta(days=7)
                upcoming_events_count = study_events_collection.count_documents({
                    "user_id": user_id,
                    "start_time": {"$gte": today, "$lte": next_week}
                })
                
                # Get objectives
                objectives = list(objectives_collection.find({
                    "user_id": user_id,
                    "$or": [
                        {"due_date": {"$gte": today.date().isoformat()}},
                        {"due_date": None},
                        {"due_date": {"$exists": False}}
                    ]
                }))
                
                # Count completed objectives
                completed_objectives = sum(1 for obj in objectives if obj.get('completed', False))
                total_objectives = len(objectives)
                
                # Format objectives for response
                objective_items = []
                for obj in objectives:
                    objective_items.append({
                        "id": str(obj['_id']),
                        "title": obj.get('title', ''),
                        "completed": obj.get('completed', False)
                    })
                    
                # Get all objectives if there are none with future due date
                if len(objectives) == 0:
                    # Fetch all objectives regardless of due date as fallback
                    all_objectives = list(objectives_collection.find({"user_id": user_id}))
                    completed_objectives = sum(1 for obj in all_objectives if obj.get('completed', False))
                    total_objectives = len(all_objectives)
                    
                    # Format the fallback objectives
                    for obj in all_objectives:
                        objective_items.append({
                            "id": str(obj['_id']),
                            "title": obj.get('title', ''),
                            "completed": obj.get('completed', False)
                        })
                    
                # Add debug output
                logger.debug(f"Found {len(objective_items)} objectives for user {user_id}")
                if objective_items:
                    logger.debug(f"Sample objective: {objective_items[0]}")
                
                # Use default values for study time and accuracy
                total_study_time = 0
                week_study_time = 0
                last_week_study_time = 0
                overall_accuracy = 0
                week_accuracy = 0
            else:
                # Get study sets count (Django ORM)
                study_sets = StudySet.objects.filter(user=user)
                study_sets_count = study_sets.count()
                
                # Get flashcards count
                flashcards_count = Flashcard.objects.filter(study_set__user=user).count()
                
                # Get completed study sets (with progress)
                completed_sets = 0
                if study_sets_count > 0:
                    for study_set in study_sets:
                        flashcards = study_set.flashcards.all()
                        if flashcards.count() > 0:
                            progress_items = StudyProgress.objects.filter(
                                user=user, 
                                flashcard__in=flashcards
                            )
                            if progress_items.count() == flashcards.count():
                                completed_sets += 1
                
                # Get upcoming events
                from datetime import datetime, timedelta
                today = datetime.now()
                next_week = today + timedelta(days=7)
                upcoming_events_count = StudyEvent.objects.filter(
                    user=user,
                    start_time__gte=today,
                    start_time__lte=next_week
                ).count()
                
                # Get objectives
                objectives = UserObjective.objects.filter(user=user, due_date__gte=today.date())
                completed_objectives = objectives.filter(completed=True).count()
                total_objectives = objectives.count()
                
                # Format objectives for response
                objective_items = []
                for obj in objectives:
                    objective_items.append({
                        "id": str(obj.id),
                        "title": obj.title,
                        "completed": obj.completed
                    })
                
                # Calculate study time and accuracy from quiz results
                
                # Calculate overall stats
                total_study_time = 0
                total_questions = 0
                total_correct = 0
                
                # Calculate this week's stats
                week_start = today - timedelta(days=today.weekday())
                week_study_time = 0
                week_questions = 0
                week_correct = 0
                
                # Calculate last week's stats
                last_week_start = week_start - timedelta(days=7)
                last_week_end = week_start - timedelta(seconds=1)
                last_week_study_time = 0
                
                # Get quizzes
                quizzes = Quiz.objects.filter(user=user)
                for quiz in quizzes:
                    # Skip quizzes without completion time
                    if not quiz.completed_at:
                        continue
                    
                    # Add to total time (estimating 1 minute per question)
                    questions = QuizQuestion.objects.filter(quiz=quiz)
                    quiz_time = questions.count()
                    total_study_time += quiz_time
                    
                    # Add to accuracy calculation
                    quiz_questions = questions.count()
                    correct_answers = questions.filter(is_correct=True).count()
                    total_questions += quiz_questions
                    total_correct += correct_answers
                    
                    # Check if quiz was completed this week
                    if quiz.completed_at.date() >= week_start.date():
                        week_study_time += quiz_time
                        week_questions += quiz_questions
                        week_correct += correct_answers
                    # Check if quiz was completed last week
                    elif last_week_start.date() <= quiz.completed_at.date() <= last_week_end.date():
                        last_week_study_time += quiz_time
                
                # Calculate accuracy percentages
                overall_accuracy = round((total_correct / total_questions * 100) if total_questions > 0 else 0)
                week_accuracy = round((week_correct / week_questions * 100) if week_questions > 0 else 0)
            
            # Construct response (same format for both user types)
            data = {
                "streak": streak,
                "study_sets_count": study_sets_count,
                "flashcards_count": flashcards_count,
                "completed_sets": completed_sets,
                "upcoming_events": upcoming_events_count,
                "objectives": {
                    "completed": completed_objectives,
                    "total": total_objectives,
                    "items": objective_items
                },
                "study_time": {
                    "total_minutes": total_study_time,
                    "this_week": week_study_time,
                    "last_week": last_week_study_time if 'last_week_study_time' in locals() else 0
                },
                "accuracy": {
                    "overall": overall_accuracy,
                    "this_week": week_accuracy if 'week_accuracy' in locals() else 0
                }
            }
            
            # Log the objectives data for debugging
            logger.info(f"Returning statistics with {len(objective_items)} objectives")
            logger.info(f"Objectives summary: total={total_objectives}, completed={completed_objectives}")
            
            return Response(data)
            
        except Exception as e:
            logger.error(f"Error getting user statistics: {str(e)}", exc_info=True)
            # Fallback to default values on error
            return Response({
                "streak": 0,
                "study_sets_count": 0,
                "flashcards_count": 0,
                "completed_sets": 0,
                "upcoming_events": 0,
                "objectives": {
                    "completed": 0,
                    "total": 0,
                    "items": []
                },
                "study_time": {
                    "total_minutes": 0,
                    "this_week": 0,
                    "last_week": 0
                },
                "accuracy": {
                    "overall": 0,
                    "this_week": 0
                }
            })

class UserDeleteView(APIView):
    permission_classes = [IsAuthenticated]
    
    def delete(self, request):
        try:
            # Get the MongoDB user ID
            user_id = request.user.user_id
            if not user_id:
                return Response(
                    {"error": "User ID not found"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Get the Firebase UID
            users_collection = get_collection('users')
            user = users_collection.find_one({"_id": ObjectId(user_id)})
            
            if not user:
                return Response(
                    {"error": "User not found in database"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            firebase_uid = user.get('firebase_uid')
            logger.info(f"Deleting user {user_id} with Firebase UID {firebase_uid}")
            
            # Delete user data from MongoDB
            # 1. Delete user profile
            profile_collection = get_collection('user_profiles')
            profile_collection.delete_many({"user_id": user_id})
            logger.info(f"Deleted user profile for {user_id}")
            
            # 2. Delete user preferences
            prefs_collection = get_collection('user_preferences')
            prefs_collection.delete_many({"user_id": user_id})
            logger.info(f"Deleted user preferences for {user_id}")
            
            # 3. Delete user sessions
            sessions_collection = get_collection('sessions')
            sessions_collection.delete_many({"user_id": user_id})
            logger.info(f"Deleted user sessions for {user_id}")
            
            # 4. Delete study sets
            study_sets_collection = get_collection('study_sets')
            study_sets_collection.delete_many({"user_id": user_id})
            logger.info(f"Deleted study sets for {user_id}")
            
            # 5. Delete the user document
            users_collection.delete_one({"_id": ObjectId(user_id)})
            logger.info(f"Deleted user document for {user_id}")
            
            # Delete user from Firebase if UID exists
            firebase_user_deleted = False
            if firebase_uid:
                try:
                    # Make sure Firebase Admin is initialized
                    if not firebase_admin._apps:
                        logger.warning("Firebase Admin not initialized, attempting to initialize...")
                        from django.conf import settings
                        import os
                        
                        # Look for credentials file in multiple locations
                        cred_paths = [
                            os.path.join(settings.BASE_DIR, 'foster', 'credentials', 'firebase-service-account.json'),
                            os.path.join(settings.BASE_DIR, 'firebase-service-account.json'),
                            os.path.join(settings.BASE_DIR, 'credentials', 'firebase-service-account.json'),
                        ]
                        
                        # Find first existing credentials file
                        cred_file = None
                        for path in cred_paths:
                            if os.path.exists(path):
                                cred_file = path
                                break
                        
                        if cred_file:
                            # Use the credentials file
                            logger.info(f"Found Firebase credentials at {cred_file}")
                            cred = firebase_admin.credentials.Certificate(cred_file)
                            firebase_admin.initialize_app(cred)
                            logger.info("Firebase Admin SDK initialized successfully")
                    
                    # Delete the Firebase user
                    logger.info(f"Attempting to delete Firebase user with UID: {firebase_uid}")
                    firebase_auth.delete_user(firebase_uid)
                    logger.info(f"Successfully deleted Firebase user {firebase_uid}")
                    firebase_user_deleted = True
                except firebase_admin.exceptions.FirebaseError as fe:
                    logger.error(f"Firebase error deleting user: {str(fe)}")
                    logger.error(traceback.format_exc())
                    # If the user doesn't exist in Firebase, that's actually okay
                    if "USER_NOT_FOUND" in str(fe):
                        logger.info(f"Firebase user {firebase_uid} not found, already deleted or never existed")
                        firebase_user_deleted = True
                except Exception as e:
                    logger.error(f"Error deleting Firebase user: {str(e)}")
                    logger.error(traceback.format_exc())
                    # Continue even if Firebase deletion fails
            
            return Response(
                {
                    "message": "User account deleted successfully",
                    "mongodb_deleted": True,
                    "firebase_deleted": firebase_user_deleted,
                    "firebase_uid": firebase_uid
                },
                status=status.HTTP_200_OK
            )
            
        except Exception as e:
            logger.error(f"Error deleting user: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to delete user: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            ) 

class StudyEventView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request, event_id=None):
        try:
            user = request.user
            
            # Convert MongoDBUser to Firebase UID
            user_id = user.user_id if isinstance(user, MongoDBUser) else user.username
            
            # Get specific event if ID provided
            if event_id:
                from .mongo_models import StudyEventMongo
                event = StudyEventMongo.get_event(event_id)
                
                if not event or event.get('user_id') != user_id:
                    return Response(
                        {"error": f"Event with ID {event_id} not found"},
                        status=status.HTTP_404_NOT_FOUND
                    )
                
                # Format the response
                try:
                    # Ensure start_time and end_time are valid datetime objects
                    start_time = event.get('start_time')
                    end_time = event.get('end_time')
                    
                    # Use consistent ISO format for dates with explicit UTC timezone
                    # Make sure we handle both datetime objects and strings
                    if isinstance(start_time, datetime.datetime):
                        start_time_iso = start_time.isoformat()
                        # Add Z to indicate UTC if no timezone info is present
                        if not (start_time_iso.endswith('Z') or '+' in start_time_iso or '-' in start_time_iso[-6:]):
                            start_time_iso += 'Z'
                    else:
                        start_time_iso = str(start_time) if start_time else None
                        logger.warning(f"Non-datetime start_time: {start_time_iso}")
                        
                    if isinstance(end_time, datetime.datetime):
                        end_time_iso = end_time.isoformat()
                        # Add Z to indicate UTC if no timezone info is present
                        if not (end_time_iso.endswith('Z') or '+' in end_time_iso or '-' in end_time_iso[-6:]):
                            end_time_iso += 'Z'
                    else:
                        end_time_iso = str(end_time) if end_time else None
                        logger.warning(f"Non-datetime end_time: {end_time_iso}")
                    
                    # If dates are invalid, return an error
                    if not start_time_iso or not end_time_iso:
                        logger.warning(f"Invalid date in event {event.get('_id')}: start_time={start_time}, end_time={end_time}")
                        return Response(
                            {"error": "Invalid date format in event"},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR
                        )
                    
                    # Log the actual format being returned
                    logger.info(f"Returning event with dates: start={start_time_iso}, end={end_time_iso}")
                    
                    return Response({
                        "id": event.get('event_id', str(event.get('_id'))),  # Always use event_id, fallback to _id as string
                        "title": event.get('title', 'Untitled Event'),
                        "description": event.get('description', ''),
                        "event_type": event.get('event_type', 'study_session'),
                        "start_time": start_time_iso,
                        "end_time": end_time_iso,
                        "location": event.get('location', ''),
                        "reminder": event.get('reminder', True),
                        "reminder_time": event.get('reminder_time', 15),
                        "created_at": event.get('created_at').isoformat() if event.get('created_at') else datetime.datetime.now().isoformat()
                    })
                except Exception as e:
                    logger.error(f"Error formatting event {event.get('_id')}: {str(e)}")
                    return Response(
                        {"error": f"Failed to format event: {str(e)}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )
            
            # Get events with date filtering
            from .mongo_models import StudyEventMongo
            
            start_date = request.query_params.get('start_date')
            end_date = request.query_params.get('end_date')
            
            events = StudyEventMongo.get_events_for_user(user_id, start_date, end_date)
            
            # Format the response
            formatted_events = []
            for event in events:
                try:
                    # Ensure start_time and end_time are valid datetime objects
                    start_time = event.get('start_time')
                    end_time = event.get('end_time')
                    
                    # Use consistent ISO format for dates with explicit UTC timezone
                    # Make sure we handle both datetime objects and strings
                    if isinstance(start_time, datetime.datetime):
                        start_time_iso = start_time.isoformat()
                        # Add Z to indicate UTC if no timezone info is present
                        if not (start_time_iso.endswith('Z') or '+' in start_time_iso or '-' in start_time_iso[-6:]):
                            start_time_iso += 'Z'
                    else:
                        start_time_iso = str(start_time) if start_time else None
                        logger.warning(f"Non-datetime start_time: {start_time_iso}")
                        
                    if isinstance(end_time, datetime.datetime):
                        end_time_iso = end_time.isoformat()
                        # Add Z to indicate UTC if no timezone info is present
                        if not (end_time_iso.endswith('Z') or '+' in end_time_iso or '-' in end_time_iso[-6:]):
                            end_time_iso += 'Z'
                    else:
                        end_time_iso = str(end_time) if end_time else None
                        logger.warning(f"Non-datetime end_time: {end_time_iso}")
                    
                    # If dates are invalid, log and skip this event
                    if not start_time_iso or not end_time_iso:
                        logger.warning(f"Invalid date in event {event.get('_id')}: start_time={start_time}, end_time={end_time}")
                        continue
                    
                    formatted_events.append({
                        "id": event.get('event_id', str(event.get('_id'))),  # Always use event_id, fallback to _id as string
                        "title": event.get('title', 'Untitled Event'),
                        "description": event.get('description', ''),
                        "event_type": event.get('event_type', 'study_session'),
                        "start_time": start_time_iso,
                        "end_time": end_time_iso,
                        "location": event.get('location', ''),
                        "reminder": event.get('reminder', True),
                        "reminder_time": event.get('reminder_time', 15),
                        "created_at": event.get('created_at').isoformat() if event.get('created_at') else datetime.datetime.now().isoformat()
                    })
                except Exception as e:
                    logger.error(f"Error formatting event {event.get('_id')}: {str(e)}")
                    # Skip this event if there's an error
                    continue
            
            return Response(formatted_events)
            
        except Exception as e:
            logger.error(f"Error getting events: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to get events: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request):
        try:
            user = request.user
            
            # Get user_id from the user
            user_id = user.user_id if isinstance(user, MongoDBUser) else user.username
            
            # Get event data
            event_data = request.data
            
            # Validate required fields
            required_fields = ['title', 'start_time', 'end_time']
            for field in required_fields:
                if field not in event_data:
                    return Response(
                        {"error": f"Missing required field: {field}"},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            
            # Create the event in MongoDB
            from .mongo_models import StudyEventMongo
            event = StudyEventMongo.create_event(
                user_id=user_id,
                title=event_data['title'],
                description=event_data.get('description', ''),
                event_type=event_data.get('event_type', 'study_session'),
                start_time=event_data['start_time'],
                end_time=event_data['end_time'],
                location=event_data.get('location', ''),
                reminder=event_data.get('reminder', True),
                reminder_time=event_data.get('reminder_time', 15)
            )
            
            # Return created event
            return Response({
                "id": str(event['event_id']),  # Use the custom event_id
                "title": event['title'],
                "description": event.get('description', ''),
                "event_type": event.get('event_type', 'study_session'),
                "start_time": event['start_time'].isoformat(),
                "end_time": event['end_time'].isoformat(),
                "location": event.get('location', ''),
                "reminder": event.get('reminder', True),
                "reminder_time": event.get('reminder_time', 15),
                "created_at": event['created_at'].isoformat()
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            logger.error(f"Error creating event: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to create event: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def put(self, request, event_id):
        try:
            user = request.user
            
            # Get user_id from the user
            user_id = user.user_id if isinstance(user, MongoDBUser) else user.username
            
            # Check if event exists and belongs to the user
            from .mongo_models import StudyEventMongo
            event = StudyEventMongo.get_event(event_id)
            
            if not event:
                return Response(
                    {"error": f"Event with ID {event_id} not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
                
            if event.get('user_id') != user_id:
                return Response(
                    {"error": "You don't have permission to update this event"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # Update fields
            update_data = {}
            for field in ['title', 'description', 'event_type', 'start_time', 'end_time', 'location', 'reminder', 'reminder_time']:
                if field in request.data:
                    update_data[field] = request.data[field]
            
            # Update the event
            updated_event = StudyEventMongo.update_event(event_id, update_data)
            
            if not updated_event:
                return Response(
                    {"error": "Failed to update event"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Return updated event
            return Response({
                "id": str(updated_event.get('event_id', updated_event.get('_id'))),
                "title": updated_event['title'],
                "description": updated_event.get('description', ''),
                "event_type": updated_event.get('event_type', 'study_session'),
                "start_time": updated_event['start_time'].isoformat(),
                "end_time": updated_event['end_time'].isoformat(),
                "location": updated_event.get('location', ''),
                "reminder": updated_event.get('reminder', True),
                "reminder_time": updated_event.get('reminder_time', 15),
                "created_at": updated_event['created_at'].isoformat()
            })
            
        except Exception as e:
            logger.error(f"Error updating event: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update event: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def delete(self, request, event_id):
        try:
            user = request.user
            
            # Get user_id from the user
            user_id = user.user_id if isinstance(user, MongoDBUser) else user.username
            
            # Log the delete request
            logger.info(f"Delete request for event {event_id} from user {user_id}")
            
            # Check if event exists and belongs to the user
            from .mongo_models import StudyEventMongo
            event = StudyEventMongo.get_event(event_id)
            
            if not event:
                logger.warning(f"Event {event_id} not found for deletion")
                return Response(
                    {"error": f"Event with ID {event_id} not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
                
            if event.get('user_id') != user_id:
                logger.warning(f"User {user_id} attempted to delete event {event_id} belonging to {event.get('user_id')}")
                return Response(
                    {"error": "You don't have permission to delete this event"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # Delete the event - try with both event_id and _id for backwards compatibility
            success = StudyEventMongo.delete_event(event.get('event_id', event_id)) or StudyEventMongo.delete_event(event.get('_id'))
            
            if not success:
                logger.error(f"Failed to delete event {event_id}")
                return Response(
                    {"error": "Failed to delete event"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            logger.info(f"Successfully deleted event {event_id}")
            return Response(
                {"message": "Event deleted successfully"},
                status=status.HTTP_200_OK
            )
            
        except Exception as e:
            logger.error(f"Error deleting event {event_id}: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to delete event: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class QuickEventView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        """Quickly create a simple study event with default values"""
        try:
            user = request.user
            
            # Get user_id from the user
            user_id = user.user_id if isinstance(user, MongoDBUser) else user.username
            
            # Validate required fields
            if 'title' not in request.data:
                return Response(
                    {"error": "Title is required"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Get start time or default to current time rounded to next hour
            start_time = None
            if 'start_time' in request.data:
                start_time = request.data['start_time']
                logger.info(f"QuickEvent: Received start_time from frontend: {start_time}")
                
                # Ensure we handle the time correctly by parsing as ISO format
                if isinstance(start_time, str):
                    try:
                        # Parse the ISO string to datetime
                        start_time = datetime.datetime.fromisoformat(start_time.replace('Z', '+00:00'))
                        logger.info(f"QuickEvent: Parsed start_time to: {start_time}")
                        
                        # Log additional timezone information for debugging
                        logger.info(f"QuickEvent: UTC timestamp: {start_time.timestamp()}")
                        logger.info(f"QuickEvent: Timezone info: {start_time.tzinfo}")
                    except ValueError:
                        logger.error(f"QuickEvent: Invalid start_time format: {start_time}")
                        return Response(
                            {"error": "Invalid start_time format. Use ISO format."},
                            status=status.HTTP_400_BAD_REQUEST
                        )
            else:
                # Default to next hour
                start_time = datetime.datetime.now().replace(minute=0, second=0, microsecond=0)
                if start_time.hour == 23:
                    # If it's 11 PM, schedule for 9 AM next day
                    start_time = start_time + datetime.timedelta(days=1)
                    start_time = start_time.replace(hour=9)
                else:
                    # Otherwise schedule for next hour
                    start_time = start_time + datetime.timedelta(hours=1)
            
            # Get duration or default to 1 hour
            duration_minutes = int(request.data.get('duration_minutes', 60))
            
            # Calculate end time - at this point start_time should be a proper datetime object
            end_time = start_time + datetime.timedelta(minutes=duration_minutes)
            
            logger.info(f"QuickEvent: Creating event for user {user_id} at {start_time} for {duration_minutes} minutes")
            logger.info(f"QuickEvent: Event end time: {end_time}")
            
            # Create event in MongoDB
            from .mongo_models import StudyEventMongo
            event = StudyEventMongo.create_event(
                user_id=user_id,
                title=request.data['title'],
                description=request.data.get('description', ''),
                event_type=request.data.get('event_type', 'study_session'),
                start_time=start_time,
                end_time=end_time,
                location=request.data.get('location', ''),
                reminder=request.data.get('reminder', True),
                reminder_time=request.data.get('reminder_time', 15)
            )
            
            # Return created event
            return Response({
                "id": str(event['event_id']),  # Use the secure event_id
                "title": event['title'],
                "description": event.get('description', ''),
                "event_type": event.get('event_type', 'study_session'),
                "start_time": event['start_time'].isoformat(),
                "end_time": event['end_time'].isoformat(),
                "location": event.get('location', ''),
                "reminder": event.get('reminder', True),
                "reminder_time": event.get('reminder_time', 15),
                "created_at": event['created_at'].isoformat()
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            logger.error(f"Error creating quick event: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to create quick event: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class UserObjectiveView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request, objective_id=None):
        try:
            user = request.user
            
            # Get MongoDB user ID
            user_id = None
            if isinstance(user, MongoDBUser):
                user_id = user.user_id
            else:
                # If Django user, try to find corresponding MongoDB user
                try:
                    users_collection = get_collection('users')
                    mongo_user = users_collection.find_one({"username": user.username})
                    if mongo_user:
                        user_id = mongo_user['_id']
                except Exception as e:
                    logger.error(f"Error finding MongoDB user: {str(e)}", exc_info=True)
            
            if not user_id:
                logger.error("Could not find user_id for MongoDB query")
                return Response(
                    {"error": "Failed to identify user for MongoDB query"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Get collection
            objectives_collection = get_collection('user_objectives')
            
            # Get specific objective if ID provided
            if objective_id:
                try:
                    from bson import ObjectId
                    objective = objectives_collection.find_one({
                        "_id": ObjectId(objective_id), 
                        "user_id": user_id
                    })
                    
                    if not objective:
                        return Response(
                            {"error": "Objective not found"},
                            status=status.HTTP_404_NOT_FOUND
                        )
                    
                    # Format for response
                    return Response({
                        "id": str(objective["_id"]),
                        "title": objective["title"],
                        "description": objective.get("description", ""),
                        "objective_type": objective.get("objective_type", "custom"),
                        "completed": objective.get("completed", False),
                        "due_date": objective.get("due_date"),
                        "created_at": objective.get("created_at"),
                        "completed_at": objective.get("completed_at")
                    })
                except Exception as e:
                    return Response(
                        {"error": f"Error retrieving objective: {str(e)}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )
            
            # Get all objectives with filtering
            completed = request.query_params.get('completed')
            due_date = request.query_params.get('due_date')
            
            # Build MongoDB query
            query = {"user_id": user_id}
            
            if completed is not None:
                query["completed"] = completed.lower() == 'true'
                
            if due_date:
                query["due_date"] = due_date
            
            # Execute query
            objectives_cursor = objectives_collection.find(query)
            objectives_list = list(objectives_cursor)
            
            # Format for response
            formatted_objectives = []
            for objective in objectives_list:
                formatted_objectives.append({
                    "id": str(objective["_id"]),
                    "title": objective["title"],
                    "description": objective.get("description", ""),
                    "objective_type": objective.get("objective_type", "custom"),
                    "completed": objective.get("completed", False),
                    "due_date": objective.get("due_date"),
                    "created_at": objective.get("created_at"),
                    "completed_at": objective.get("completed_at")
                })
            
            return Response(formatted_objectives)
            
        except Exception as e:
            logger.error(f"Error getting objectives: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to get objectives: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request):
        try:
            user = request.user
            
            # Get MongoDB user ID
            user_id = None
            if isinstance(user, MongoDBUser):
                user_id = user.user_id
            else:
                # If Django user, try to find corresponding MongoDB user
                try:
                    users_collection = get_collection('users')
                    mongo_user = users_collection.find_one({"username": user.username})
                    if mongo_user:
                        user_id = mongo_user['_id']
                except Exception as e:
                    logger.error(f"Error finding MongoDB user: {str(e)}", exc_info=True)
                    
            if not user_id:
                logger.error("Could not find user_id for MongoDB storage")
                return Response(
                    {"error": "Failed to identify user for MongoDB storage"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
                
            # Get objective data
            objective_data = request.data
            
            # Validate required fields
            if 'title' not in objective_data:
                return Response(
                    {"error": "Missing required field: title"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Parse date field
            due_date = None
            if 'due_date' in objective_data and objective_data['due_date']:
                try:
                    due_date = objective_data['due_date']
                except ValueError:
                    return Response(
                        {"error": "Invalid due_date format. Use YYYY-MM-DD."},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            
            # Prepare MongoDB document
            now = datetime.datetime.now().isoformat()
            objective_doc = {
                "user_id": user_id,
                "title": objective_data['title'],
                "description": objective_data.get('description', ''),
                "objective_type": objective_data.get('objective_type', 'custom'),
                "completed": objective_data.get('completed', False),
                "due_date": due_date,
                "created_at": now,
                "completed_at": now if objective_data.get('completed', False) else None
            }
            
            # Store in MongoDB
            objectives_collection = get_collection('user_objectives')
            result = objectives_collection.insert_one(objective_doc)
            
            if not result.inserted_id:
                logger.error("Failed to insert objective into MongoDB")
                return Response(
                    {"error": "Failed to save objective"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Update the document with the ID
            objective_doc["id"] = str(result.inserted_id)
            
            # Handle if objective is already completed
            if objective_doc["completed"]:
                # Update user streak
                try:
                    if not isinstance(user, MongoDBUser):
                        streak, created = UserStreak.objects.get_or_create(user=user)
                        streak.update_streak()
                        streak.save()
                except Exception as e:
                    logger.error(f"Error updating streak: {str(e)}")
            
            # Return created objective
            return Response({
                "id": str(result.inserted_id),
                "title": objective_doc["title"],
                "description": objective_doc["description"],
                "objective_type": objective_doc["objective_type"],
                "completed": objective_doc["completed"],
                "due_date": objective_doc["due_date"],
                "created_at": objective_doc["created_at"],
                "completed_at": objective_doc["completed_at"]
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            logger.error(f"Error creating objective: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to create objective: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def put(self, request, objective_id):
        try:
            user = request.user
            
            # Get MongoDB user ID
            user_id = None
            if isinstance(user, MongoDBUser):
                user_id = user.user_id
            else:
                # If Django user, try to find corresponding MongoDB user
                try:
                    users_collection = get_collection('users')
                    mongo_user = users_collection.find_one({"username": user.username})
                    if mongo_user:
                        user_id = mongo_user['_id']
                except Exception as e:
                    logger.error(f"Error finding MongoDB user: {str(e)}", exc_info=True)
            
            if not user_id:
                logger.error("Could not find user_id for MongoDB update")
                return Response(
                    {"error": "Failed to identify user for MongoDB update"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Get collection and find the objective
            objectives_collection = get_collection('user_objectives')
            from bson import ObjectId
            
            # Try to find the objective
            objective = objectives_collection.find_one({
                "_id": ObjectId(objective_id),
                "user_id": user_id
            })
            
            if not objective:
                return Response(
                    {"error": "Objective not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Update objective fields
            objective_data = request.data
            
            # Check if completion status is changing
            was_completed = objective.get("completed", False)
            now_completed = objective_data.get('completed', was_completed)
            
            # Prepare update document
            update_fields = {}
            
            if 'title' in objective_data:
                update_fields["title"] = objective_data['title']
            if 'description' in objective_data:
                update_fields["description"] = objective_data['description']
            if 'objective_type' in objective_data:
                update_fields["objective_type"] = objective_data['objective_type']
            if 'completed' in objective_data:
                update_fields["completed"] = now_completed
            
            # Parse date field
            if 'due_date' in objective_data:
                update_fields["due_date"] = objective_data["due_date"]
            
            # If objective was just completed, update completion time
            if not was_completed and now_completed:
                update_fields["completed_at"] = datetime.datetime.now().isoformat()
                
                # Update streak for newly completed objective
                try:
                    if not isinstance(user, MongoDBUser):
                        streak, created = UserStreak.objects.get_or_create(user=user)
                        streak.update_streak()
                        streak.save()
                except Exception as e:
                    logger.error(f"Error updating streak: {str(e)}")
            elif was_completed and not now_completed:
                # If marking as incomplete, clear completed_at
                update_fields["completed_at"] = None
            
            # Perform the update
            result = objectives_collection.update_one(
                {"_id": ObjectId(objective_id)},
                {"$set": update_fields}
            )
            
            if result.modified_count == 0 and len(update_fields) > 0:
                logger.warning(f"Objective update didn't modify any documents: {objective_id}")
            
            # Get the updated objective
            updated_objective = objectives_collection.find_one({"_id": ObjectId(objective_id)})
            if not updated_objective:
                return Response(
                    {"error": "Failed to retrieve updated objective"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Return updated objective
            return Response({
                "id": str(updated_objective["_id"]),
                "title": updated_objective["title"],
                "description": updated_objective.get("description", ""),
                "objective_type": updated_objective.get("objective_type", "custom"),
                "completed": updated_objective.get("completed", False),
                "due_date": updated_objective.get("due_date"),
                "created_at": updated_objective.get("created_at"),
                "completed_at": updated_objective.get("completed_at")
            })
            
        except Exception as e:
            logger.error(f"Error updating objective: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to update objective: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def delete(self, request, objective_id):
        try:
            user = request.user
            
            # Get MongoDB user ID
            user_id = None
            if isinstance(user, MongoDBUser):
                user_id = user.user_id
            else:
                # If Django user, try to find corresponding MongoDB user
                try:
                    users_collection = get_collection('users')
                    mongo_user = users_collection.find_one({"username": user.username})
                    if mongo_user:
                        user_id = mongo_user['_id']
                except Exception as e:
                    logger.error(f"Error finding MongoDB user: {str(e)}", exc_info=True)
            
            if not user_id:
                logger.error("Could not find user_id for MongoDB deletion")
                return Response(
                    {"error": "Failed to identify user for MongoDB deletion"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Get collection
            objectives_collection = get_collection('user_objectives')
            from bson import ObjectId
            
            # Verify objective exists and belongs to user
            objective = objectives_collection.find_one({
                "_id": ObjectId(objective_id),
                "user_id": user_id
            })
            
            if not objective:
                return Response(
                    {"error": "Objective not found"},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Delete objective
            result = objectives_collection.delete_one({
                "_id": ObjectId(objective_id),
                "user_id": user_id
            })
            
            if result.deleted_count == 0:
                return Response(
                    {"error": "Failed to delete objective"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            return Response(
                {"message": "Objective deleted successfully"},
                status=status.HTTP_200_OK
            )
            
        except Exception as e:
            logger.error(f"Error deleting objective: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to delete objective: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def complete(self):
        """Mark objective as completed"""
        if not self.completed:
            self.completed = True
            self.completed_at = datetime.now()
            # Update user streak
            try:
                # Check if this is a MongoDB user or regular Django user
                if not isinstance(self.user, MongoDBUser):
                    streak, created = UserStreak.objects.get_or_create(user=self.user)
                    streak.update_streak()
                    streak.save()
            except Exception as e:
                print(f"Error updating streak: {e}") 