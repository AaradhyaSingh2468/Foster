from bson.objectid import ObjectId
from foster.mongodb_utils import get_collection, get_db
from datetime import datetime
import logging
import random
import uuid
import hashlib
import time
import secrets

logger = logging.getLogger(__name__)

class StudyEventMongo:
    """MongoDB model for study events"""
    
    @staticmethod
    def get_collection():
        return get_collection("study_events")
    
    @staticmethod
    def get_next_event_id(user_id=None):
        """Generate a secure event ID using a combination of:
        - Random secure token
        - Timestamp
        - User-specific hash (if provided)
        - UUID
        
        This ensures IDs are:
        1. Not sequential or predictable
        2. Unique across the system 
        3. Not easily guessable
        """
        # Generate a random secure token (32 bytes = 64 hex chars)
        random_token = secrets.token_hex(8)
        
        # Current timestamp in milliseconds
        timestamp = int(time.time() * 1000)
        
        # Generate a UUID component
        uuid_component = str(uuid.uuid4()).replace('-', '')[:8]
        
        # User-specific component (if user_id provided)
        user_component = ""
        if user_id:
            # Create a hash of the user ID to include in the event ID
            user_hash = hashlib.sha256(str(user_id).encode()).hexdigest()[:6]
            user_component = f"-{user_hash}"
        
        # Combine components into a single ID
        event_id = f"{timestamp}-{random_token}{user_component}-{uuid_component}"
        
        # Ensure the ID is unique by checking the database
        collection = StudyEventMongo.get_collection()
        while collection.find_one({"event_id": event_id}):
            # In the extremely unlikely case of collision, regenerate
            random_token = secrets.token_hex(8)
            uuid_component = str(uuid.uuid4()).replace('-', '')[:8]
            event_id = f"{timestamp}-{random_token}{user_component}-{uuid_component}"
        
        logger.debug(f"Generated secure event ID: {event_id}")
        return event_id
    
    @staticmethod
    def create_event(user_id, title, description="", event_type="study_session", 
                     start_time=None, end_time=None, location="", reminder=True,
                     reminder_time=15):
        """Create a new study event in MongoDB"""
        if not start_time:
            start_time = datetime.now()
        if not end_time:
            end_time = start_time
            
        # Ensure we have proper datetime objects with UTC timezone info
        if isinstance(start_time, str):
            try:
                # Handle various ISO formats by normalizing
                if 'Z' in start_time:
                    # ISO format with Z (UTC)
                    start_time = start_time.replace('Z', '+00:00')
                
                # Parse the string to a datetime, with explicit UTC handling
                start_time = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
                logger.info(f"Parsed start_time: {start_time} (UTC)")
            except ValueError:
                logger.error(f"Invalid start_time format: {start_time}")
                start_time = datetime.now()
                logger.info(f"Using current time instead: {start_time}")
                
        if isinstance(end_time, str):
            try:
                # Handle various ISO formats by normalizing
                if 'Z' in end_time:
                    # ISO format with Z (UTC)
                    end_time = end_time.replace('Z', '+00:00')
                    
                # Parse the string to a datetime, with explicit UTC handling
                end_time = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
                logger.info(f"Parsed end_time: {end_time} (UTC)")
            except ValueError:
                logger.error(f"Invalid end_time format: {end_time}")
                # Default to start_time + 1 hour
                end_time = start_time
                if hasattr(end_time, 'replace'):
                    try:
                        end_time = end_time.replace(hour=end_time.hour + 1)
                    except Exception:
                        end_time = start_time
                logger.info(f"Using start_time + 1 hour instead: {end_time}")
        
        # Get the next available event_id - pass user_id for user-specific component
        event_id = StudyEventMongo.get_next_event_id(user_id)

        event_data = {
            "event_id": event_id,  # Add custom event_id
            "user_id": user_id,
            "title": title,
            "description": description,
            "event_type": event_type,
            "start_time": start_time,
            "end_time": end_time,
            "location": location,
            "reminder": reminder,
            "reminder_time": reminder_time,
            "created_at": datetime.now()
        }
        
        # Debug log to confirm what's being stored
        logger.info(f"Creating event: {event_id}")
        logger.info(f"  - Title: {title}")
        logger.info(f"  - Start time (UTC): {start_time}")
        logger.info(f"  - End time (UTC): {end_time}")
        
        result = StudyEventMongo.get_collection().insert_one(event_data)
        event_data["_id"] = result.inserted_id
        return event_data
    
    @staticmethod
    def get_events_for_user(user_id, start_date=None, end_date=None):
        """Get study events for a user with optional date filtering"""
        query = {"user_id": user_id}
        
        if start_date:
            if isinstance(start_date, str):
                try:
                    start_date = datetime.fromisoformat(start_date.replace("Z", "+00:00"))
                except ValueError:
                    logger.error(f"Invalid start_date format: {start_date}")
                    start_date = None
                    
            if start_date:
                query["start_time"] = {"$gte": start_date}
                
        if end_date:
            if isinstance(end_date, str):
                try:
                    end_date = datetime.fromisoformat(end_date.replace("Z", "+00:00"))
                except ValueError:
                    logger.error(f"Invalid end_date format: {end_date}")
                    end_date = None
                    
            if end_date:
                if "start_time" in query:
                    query["start_time"]["$lte"] = end_date
                else:
                    query["start_time"] = {"$lte": end_date}
        
        events = list(StudyEventMongo.get_collection().find(query).sort("start_time", 1))
        return events
    
    @staticmethod
    def get_event(event_id):
        """Get a specific event by ID"""
        collection = StudyEventMongo.get_collection()
        
        # First try to find by string event_id 
        event = collection.find_one({"event_id": event_id})
        if event:
            return event
            
        # If that didn't work, try by ObjectId
        try:
            if not isinstance(event_id, ObjectId):
                try:
                    event_id_obj = ObjectId(event_id)
                except Exception:
                    logger.warning(f"Could not convert '{event_id}' to ObjectId")
                    return None
                
            return collection.find_one({"_id": event_id_obj})
        except Exception as e:
            logger.warning(f"Error when trying to get event by ObjectId: {str(e)}")
            return None
    
    @staticmethod
    def update_event(event_id, update_data):
        """Update an existing event"""
        # First find the event to get its ID
        event = StudyEventMongo.get_event(event_id)
        if not event:
            return None
                
        # Handle datetime fields
        for field in ["start_time", "end_time"]:
            if field in update_data and isinstance(update_data[field], str):
                try:
                    update_data[field] = datetime.fromisoformat(update_data[field].replace("Z", "+00:00"))
                except ValueError:
                    logger.error(f"Invalid {field} format: {update_data[field]}")
                    del update_data[field]
        
        # Update the event
        result = StudyEventMongo.get_collection().update_one(
            {"_id": event["_id"]},
            {"$set": update_data}
        )
        
        if result.modified_count > 0:
            return StudyEventMongo.get_event(event_id)
        return None
    
    @staticmethod
    def delete_event(event_id):
        """Delete an event"""
        collection = StudyEventMongo.get_collection()
        
        # Try to delete by event_id (string format from our secure generator)
        try:
            result = collection.delete_one({"event_id": event_id})
            if result.deleted_count > 0:
                logger.info(f"Successfully deleted event with event_id {event_id}")
                return True
        except Exception as e:
            logger.warning(f"Error when trying to delete by event_id: {str(e)}")
            
        # If that didn't work, try by ObjectId
        try:
            if not isinstance(event_id, ObjectId):
                try:
                    event_id_obj = ObjectId(event_id)
                except Exception:
                    logger.warning(f"Could not convert '{event_id}' to ObjectId")
                    return False
                    
                result = collection.delete_one({"_id": event_id_obj})
                if result.deleted_count > 0:
                    logger.info(f"Successfully deleted event with _id {event_id}")
                    return True
        except Exception as e:
            logger.error(f"Error when trying to delete by ObjectId: {str(e)}")
        
        logger.error(f"Event with ID {event_id} not found for deletion")
        return False 