from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import datetime, timedelta

class UserProfile(models.Model):
    """Extended user profile information"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    education_level = models.CharField(max_length=50, blank=True)
    institution = models.CharField(max_length=100, blank=True)
    major = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    onboarding_completed = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.user.username}'s profile"

class UserPreferences(models.Model):
    """User preferences for app settings"""
    THEME_CHOICES = [
        ('light', 'Light'),
        ('dark', 'Dark'),
        ('system', 'System'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='preferences')
    theme = models.CharField(max_length=10, choices=THEME_CHOICES, default='system')
    email_notifications = models.BooleanField(default=True)
    study_reminder_frequency = models.IntegerField(default=3)  # days
    calendar_default_view = models.CharField(max_length=10, default='week')
    ai_features_enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s preferences"

class UserStreak(models.Model):
    """Model to track user's daily study streak"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='streak')
    current_streak = models.IntegerField(default=0)
    longest_streak = models.IntegerField(default=0)
    last_activity_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s streak: {self.current_streak} days"
    
    def update_streak(self):
        """Update streak based on today's activity"""
        today = datetime.now().date()
        
        # First activity ever
        if not self.last_activity_date:
            self.current_streak = 1
            self.longest_streak = 1
            self.last_activity_date = today
            return
        
        # Same day activity, no change
        if self.last_activity_date == today:
            return
            
        # Activity after 1 day, continue streak
        if self.last_activity_date == today - timedelta(days=1):
            self.current_streak += 1
            if self.current_streak > self.longest_streak:
                self.longest_streak = self.current_streak
        # Activity after more than 1 day, reset streak
        else:
            self.current_streak = 1
            
        self.last_activity_date = today

class UserObjective(models.Model):
    """Model to track user's daily learning objectives"""
    OBJECTIVE_TYPES = [
        ('video', 'Watch AI Video'),
        ('flashcard', 'Review Flashcards'),
        ('quiz', 'Complete Quiz'),
        ('pdf', 'Read PDF'),
        ('custom', 'Custom Objective'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='objectives')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    objective_type = models.CharField(max_length=20, choices=OBJECTIVE_TYPES, default='custom')
    completed = models.BooleanField(default=False)
    due_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        status = "Completed" if self.completed else "Pending"
        return f"{self.user.username}'s objective: {self.title} ({status})"
    
    def complete(self):
        """Mark objective as completed"""
        if not self.completed:
            self.completed = True
            self.completed_at = datetime.now()
            # Update user streak
            try:
                streak, created = UserStreak.objects.get_or_create(user=self.user)
                streak.update_streak()
                streak.save()
            except Exception as e:
                print(f"Error updating streak: {e}")

class StudyEvent(models.Model):
    """Model for calendar events related to studying"""
    EVENT_TYPES = [
        ('study_session', 'Study Session'),
        ('video_watch', 'Watch Video'),
        ('flashcard_review', 'Review Flashcards'),
        ('quiz', 'Take Quiz'),
        ('deadline', 'Assignment Deadline'),
        ('custom', 'Custom Event'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_events')
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES, default='study_session')
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    location = models.CharField(max_length=200, blank=True)
    reminder = models.BooleanField(default=True)
    reminder_time = models.IntegerField(default=15)  # minutes before event
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.username}'s event: {self.title} on {self.start_time.strftime('%Y-%m-%d')}"

# Create user profile, preferences, and streak when a user is created
@receiver(post_save, sender=User)
def create_user_profile_and_preferences(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
        UserPreferences.objects.create(user=instance)
        UserStreak.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile_and_preferences(sender, instance, **kwargs):
    instance.profile.save()
    instance.preferences.save()
    if hasattr(instance, 'streak'):
        instance.streak.save() 