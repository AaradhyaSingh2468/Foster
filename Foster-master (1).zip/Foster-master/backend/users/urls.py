from django.urls import path
from .views import (
    UserProfileView,
    UserAvatarView,
    UserAvatarUrlView,
    UserPreferencesView,
    OnboardingStatusView,
    UserStatisticsView,
    UserDeleteView,
    StudyEventView,
    UserObjectiveView,
    QuickEventView
)

urlpatterns = [
    path('profile/', UserProfileView.as_view(), name='user-profile'),
    path('avatar/', UserAvatarView.as_view(), name='user-avatar'),
    path('avatar-url/', UserAvatarUrlView.as_view(), name='user-avatar-url'),
    path('preferences/', UserPreferencesView.as_view(), name='user-preferences'),
    path('onboarding/', OnboardingStatusView.as_view(), name='user-onboarding'),
    path('statistics/', UserStatisticsView.as_view(), name='user-statistics'),
    path('delete/', UserDeleteView.as_view(), name='user-delete'),
    path('events/', StudyEventView.as_view(), name='study-events'),
    path('events/<str:event_id>/', StudyEventView.as_view(), name='study-event-detail'),
    path('quick-event/', QuickEventView.as_view(), name='quick-event'),
    path('objectives/', UserObjectiveView.as_view(), name='user-objectives'),
    path('objectives/<str:objective_id>/', UserObjectiveView.as_view(), name='user-objective-detail'),
    path('profile', UserProfileView.as_view(), name='user_profile_no_slash'),
    path('avatar', UserAvatarView.as_view(), name='user_avatar_no_slash'),
    path('avatar-url', UserAvatarUrlView.as_view(), name='user_avatar_url_no_slash'),
    path('preferences', UserPreferencesView.as_view(), name='user_preferences_no_slash'),
    path('onboarding', OnboardingStatusView.as_view(), name='onboarding_status_no_slash'),
    path('statistics', UserStatisticsView.as_view(), name='user_statistics_no_slash'),
    path('delete', UserDeleteView.as_view(), name='user_delete_no_slash'),
    path('quick-event', QuickEventView.as_view(), name='quick_event_no_slash'),
] 