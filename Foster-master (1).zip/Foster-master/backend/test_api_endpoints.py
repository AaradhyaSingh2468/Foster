"""
Script to test the API endpoints for the Foster application.
Run this script with: python test_api_endpoints.py

This script will test all the API endpoints that are being used by the frontend
to ensure they are properly working with trailing slashes.
"""

import requests
import json
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8000/api"
SUCCESS_SYMBOL = "✅"
ERROR_SYMBOL = "❌"

def test_endpoint(method, endpoint, params=None, data=None):
    """Test a specific API endpoint and report results."""
    url = f"{BASE_URL}{endpoint}"
    headers = {"Content-Type": "application/json"}
    
    print(f"\nTesting {method.upper()} {url}")
    
    try:
        if method.lower() == "get":
            response = requests.get(url, params=params, headers=headers)
        elif method.lower() == "post":
            response = requests.post(url, json=data, headers=headers)
        elif method.lower() == "put":
            response = requests.put(url, json=data, headers=headers)
        elif method.lower() == "delete":
            response = requests.delete(url, headers=headers)
        else:
            print(f"{ERROR_SYMBOL} Unsupported method: {method}")
            return False
        
        # Print status code and response
        if response.status_code >= 200 and response.status_code < 300:
            print(f"{SUCCESS_SYMBOL} Status: {response.status_code}")
            try:
                print(f"Response: {json.dumps(response.json(), indent=2)}")
            except:
                print(f"Response: {response.text[:100]}...")
            return True
        else:
            print(f"{ERROR_SYMBOL} Status: {response.status_code}")
            print(f"Response: {response.text}")
            return False
    
    except Exception as e:
        print(f"{ERROR_SYMBOL} Error: {str(e)}")
        return False

def main():
    """Run tests for all key API endpoints."""
    print("=" * 50)
    print("Foster API Endpoint Test")
    print("=" * 50)
    
    # Track success and failure counts
    success_count = 0
    failure_count = 0
    
    # Test health endpoint
    if test_endpoint("get", "/health/"):
        success_count += 1
    else:
        failure_count += 1
    
    # Test study sets endpoint
    if test_endpoint("get", "/study-sets/"):
        success_count += 1
    else:
        failure_count += 1
    
    # Test users statistics endpoint
    if test_endpoint("get", "/users/statistics/"):
        success_count += 1
    else:
        failure_count += 1
    
    # Test calendar events endpoint
    today = datetime.now().isoformat()
    next_week = (datetime.now() + timedelta(days=7)).isoformat()
    if test_endpoint("get", "/calendar/events/", params={"startDate": today, "endDate": next_week}):
        success_count += 1
    else:
        failure_count += 1
    
    # Print summary
    print("\n" + "=" * 50)
    print(f"Test Summary: {success_count} succeeded, {failure_count} failed")
    print("=" * 50)
    
    if failure_count == 0:
        print(f"{SUCCESS_SYMBOL} All tests passed! API endpoints are working correctly.")
    else:
        print(f"{ERROR_SYMBOL} Some tests failed. Please check the API endpoints.")

if __name__ == "__main__":
    main() 