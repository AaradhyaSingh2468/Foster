from django.urls import path
from .views import (
    ChatMessageView,
    ChatHistoryView,
    ConversationListView,
    ConversationDetailView,
    ExamGenerationView,
    ExamDetailView,
    SaveExamView,
    VideoGenerationView,
    VideoGenerationStatusView,
    VideoDetailView,
    SketchboardEnhanceView,
    SketchboardGenerateView,
    StudyInsightsView,
    RecommendationsView,
)
from study.views import upload_document, ask_question, generate_flashcards, generate_exam, grade_exam, get_documents, get_document_by_id, create_study_set_from_pdf, cleanup_associated_data, check_flashcard_job_status

urlpatterns = [
    # Chat
    path('chat', ChatMessageView.as_view(), name='chat_message'),
    path('chat/<int:conversation_id>', ChatHistoryView.as_view(), name='chat_history'),
    path('chat/conversations', ConversationListView.as_view(), name='conversation_list'),
    path('chat/conversations/<int:id>', ConversationDetailView.as_view(), name='conversation_detail'),
    
    # Exam Generation
    path('exam-generation', ExamGenerationView.as_view(), name='exam_generation'),
    path('exam-generation/<int:id>', ExamDetailView.as_view(), name='exam_detail'),
    path('exam-generation/<int:id>/save', SaveExamView.as_view(), name='save_exam'),
    
    # Video Generation
    path('video-generation', VideoGenerationView.as_view(), name='video_generation'),
    path('video-generation/<int:id>/status', VideoGenerationStatusView.as_view(), name='video_status'),
    path('video-generation/<int:id>', VideoDetailView.as_view(), name='video_detail'),
    
    # Sketchboard AI
    path('sketchboard/enhance', SketchboardEnhanceView.as_view(), name='sketchboard_enhance'),
    path('sketchboard/generate', SketchboardGenerateView.as_view(), name='sketchboard_generate'),
    
    # Insights and Recommendations
    path('insights', StudyInsightsView.as_view(), name='study_insights'),
    path('recommendations', RecommendationsView.as_view(), name='recommendations'),

    path('study-buddy/upload', upload_document, name='upload_document'),
    path('study-buddy/ask', ask_question, name='ask_question'),
    path('study-buddy/generate-flashcards', generate_flashcards, name='generate_flashcards'),
    path('study-buddy/flashcard-job/<str:job_id>', check_flashcard_job_status, name='check_flashcard_job_status'),
    path('study-buddy/generate-exam', generate_exam, name='generate_exam'),
    path('study-buddy/grade-exam', grade_exam, name='grade_exam'),
    path('documents/', get_documents, name='get_documents'),
    path('documents/<str:document_id>', get_document_by_id, name='get_document_by_id'),
    path('documents/create-study-set', create_study_set_from_pdf, name='create_study_set_from_pdf'),
    path('cleanup', cleanup_associated_data, name='cleanup_associated_data'),
] 