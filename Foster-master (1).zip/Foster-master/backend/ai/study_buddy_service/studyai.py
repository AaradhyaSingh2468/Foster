"""
Core implementation of the StudyBuddy AI system.
This module provides the AI functionality for document processing, Q&A, flashcard generation, and exam creation.
"""

import os
import json
import math
from datetime import datetime
from typing import List, Dict, Tuple, Any, Optional, Union
import pandas as pd

# LangChain imports with fallbacks
try:
    # Try modern imports first
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    from langchain.prompts import PromptTemplate
except ImportError:
    # Fall back to older imports if needed
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    try:
        from langchain.prompts import PromptTemplate
    except ImportError:
        pass

# Community imports that should be stable
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import Ollama

# Import different versions of QA chains to handle API changes
try:
    # For version 0.0.334
    from langchain.chains import RetrievalQA
except ImportError:
    # For newer versions
    try:
        from langchain.chains.retrieval_qa.base import RetrievalQA
    except ImportError:
        pass

class AdvancedStudyBuddyAI:
    # Class-level conversation history store for all instances
    _global_conversation_histories = {}
    
    def __init__(self, pdf_directory: str, db_path: str = "studybuddy_vectordb", user_id: str = None):
        """
        Initialize the StudyBuddy AI system.
        
        Args:
            pdf_directory (str): Directory containing PDF documents
            db_path (str): Path to store the vector database
            user_id (str): Unique identifier for the user
        """
        self.pdf_directory = pdf_directory
        self.db_path = db_path
        self.user_id = user_id
        self.embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.vectorstore = None
        self.qa_chain = None
        
        # Dictionary to store conversation histories per user and document
        # Format: {user_id: {document_id: [(question, answer), ...]}}
        self._conversation_histories = self._global_conversation_histories
        
        # Initialize conversation dictionary for this user if provided
        if user_id:
            print(f"Initializing conversation history for user {user_id}")
            if user_id not in self._conversation_histories:
                self._conversation_histories[user_id] = {}
                # Try to load existing conversations for this user
                self._load_conversations_from_disk()
            else:
                print(f"Found existing conversation history for user {user_id} with {len(self._conversation_histories[user_id])} documents")
        
        # Create LLM with proper configuration for Runnable compatibility
        try:
            # Use only mistral model
            print("Initializing Ollama with mistral model...")
            self.llm = Ollama(model="mistral", temperature=0.2)
            print(f"Using Ollama with mistral model")
        
        except Exception as e:
            print(f"Failed to initialize mistral model: {str(e)}")
            
            # Fallback to custom LLM with simpler setup
            from langchain.llms.base import LLM
            
            class CustomLLM(LLM):
                def _call(self, prompt, **kwargs):
                    import requests
                    try:
                        # Try with mistral model using simpler API
                        response = requests.post(
                            "http://localhost:11434/api/generate",
                            json={"model": "mistral", "prompt": prompt, "temperature": 0.2},
                            timeout=30  # Add timeout to avoid hanging
                        )
                        return response.json().get("response", "No response from Ollama")
                    except Exception as req_error:
                        return f"Error generating response: {str(req_error)}"
                
                @property
                def _identifying_params(self):
                    return {"name": "CustomLLM"}
            
            try:
                self.llm = CustomLLM()
                print("Using custom LLM as fallback with mistral model")
            except Exception as e2:
                print(f"Custom LLM initialization failed: {str(e2)}")
                self.llm = None
                print("All mistral LLM initializations failed.")

    def _get_conversation_key(self, document_id: str = None) -> str:
        """
        Generate a unique key for storing conversation history.
        
        Args:
            document_id (str): Identifier for the document being discussed
            
        Returns:
            str: Unique conversation key combining user_id and document_id
        """
        if not self.user_id:
            raise ValueError("User ID is required for conversation history management")
            
        # If no document_id is provided, use the current db_path as identifier
        doc_id = document_id or self.db_path
        return f"{self.user_id}:{doc_id}"

    def get_conversation_history(self, document_id: str = None) -> list:
        """
        Get conversation history for a specific document and user.
        
        Args:
            document_id (str): Identifier for the document being discussed
            
        Returns:
            list: List of (question, answer) tuples for this user and document
        """
        if not self.user_id:
            return []  # Return empty history if no user_id is set
            
        # Get user's conversation histories
        user_histories = self._conversation_histories.get(self.user_id, {})
        
        # Use a consistent key for the document ID
        doc_id = document_id or self.db_path
        
        # Debug logging to track document_id usage
        print(f"Looking for conversation history with doc_id: {doc_id}")
        print(f"Available conversation keys: {list(user_histories.keys())}")
        
        return user_histories.get(doc_id, [])

    def add_to_conversation_history(self, question: str, answer: str, document_id: str = None) -> None:
        """
        Add a Q&A pair to the conversation history.
        
        Args:
            question (str): The question asked
            answer (str): The answer provided
            document_id (str): Identifier for the document being discussed
        """
        if not self.user_id:
            print("Warning: No user_id set, conversation history not stored")
            return  # Don't store history if no user_id is set
            
        # Initialize nested dictionaries if they don't exist
        if self.user_id not in self._conversation_histories:
            self._conversation_histories[self.user_id] = {}
            
        # Use a consistent key for the document ID
        doc_id = document_id or self.db_path
        
        if doc_id not in self._conversation_histories[self.user_id]:
            self._conversation_histories[self.user_id][doc_id] = []
            
        # Add the new Q&A pair
        self._conversation_histories[self.user_id][doc_id].append((question, answer))
        # Keep only the last 5 exchanges for each conversation
        self._conversation_histories[self.user_id][doc_id] = self._conversation_histories[self.user_id][doc_id][-5:]
        print(f"Added to conversation history for user {self.user_id}, document {doc_id}")
        print(f"Conversation history now has {len(self._conversation_histories[self.user_id][doc_id])} entries")
        
        # Save to disk for persistence
        self._save_conversations_to_disk()

    def clear_conversation_history(self, document_id: str = None, all_documents: bool = False) -> None:
        """
        Clear conversation history for a specific document or all documents.
        
        Args:
            document_id (str): Identifier for the document being discussed
            all_documents (bool): If True, clear all conversation history for the user
        """
        if not self.user_id:
            return  # Nothing to clear if no user_id is set
            
        if all_documents:
            # Clear all conversation history for this user
            if self.user_id in self._conversation_histories:
                del self._conversation_histories[self.user_id]
                print(f"Cleared all conversation history for user {self.user_id}")
        else:
            # Clear history for specific document
            doc_id = document_id or self.db_path
            if self.user_id in self._conversation_histories:
                if doc_id in self._conversation_histories[self.user_id]:
                    del self._conversation_histories[self.user_id][doc_id]
                    print(f"Cleared conversation history for user {self.user_id}, document {doc_id}")
        
        # Save changes to disk
        self._save_conversations_to_disk()

    def get_all_conversations(self) -> Dict[str, List[Tuple[str, str]]]:
        """
        Get all conversations for the current user.
        
        Returns:
            Dict[str, List[Tuple[str, str]]]: Dictionary mapping document IDs to their conversation histories
        """
        if not self.user_id:
            return {}
            
        return self._conversation_histories.get(self.user_id, {})

    def load_and_process_pdfs(self) -> None:
        """Process PDF documents and create vector store."""
        documents = []
        
        # Ensure the directory exists
        if not os.path.exists(self.pdf_directory):
            os.makedirs(self.pdf_directory, exist_ok=True)
            raise ValueError(f"PDF directory '{self.pdf_directory}' was created but contains no documents")
        
        # Get all PDF files
        pdf_files = [f for f in os.listdir(self.pdf_directory) if f.endswith('.pdf')]
        
        if not pdf_files:
            raise ValueError(f"No PDF files found in directory: {self.pdf_directory}")
            
        for filename in pdf_files:
            file_path = os.path.join(self.pdf_directory, filename)
            try:
                loader = PyPDFLoader(file_path)
                docs = loader.load()
                for doc in docs:
                    doc.metadata['source'] = filename
                documents.extend(docs)
                print(f"Processed '{filename}' - {len(docs)} pages")
            except Exception as e:
                print(f"Error processing '{filename}': {str(e)}")

        if not documents:
            raise ValueError("No document content could be extracted from the PDFs")

        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        chunks = text_splitter.split_documents(documents)

        for chunk in chunks:
            if 'page' not in chunk.metadata:
                chunk.metadata['page'] = chunk.metadata.get('page', 1)

        print(f"Created {len(chunks)} text chunks for indexing")
        
        # Ensure the database directory exists
        if not os.path.exists(self.db_path):
            os.makedirs(self.db_path, exist_ok=True)
            
        self.vectorstore = FAISS.from_documents(chunks, self.embeddings)
        self.vectorstore.save_local(self.db_path)
        print(f"Successfully saved vector database to {self.db_path}")

    def load_vectorstore(self) -> None:
        """Load the vector store from disk."""
        if os.path.exists(self.db_path):
            try:
                # Allow deserialization since we trust our own files
                self.vectorstore = FAISS.load_local(
                    self.db_path, 
                    self.embeddings,
                    allow_dangerous_deserialization=True
                )
                print(f"Successfully loaded vector database from {self.db_path}")
            except Exception as e:
                print(f"Error loading vector database: {str(e)}")
                # If loading fails, try to recreate the database
                try:
                    print("Attempting to recreate vector database...")
                    self.load_and_process_pdfs()
                except Exception as e2:
                    raise ValueError(f"Failed to load or recreate vector database: {str(e)} -> {str(e2)}")
        else:
            raise FileNotFoundError("No existing vector database found. Please process PDFs first.")

    def setup_qa_chain(self) -> None:
        """Set up the question-answering chain."""
        if self.vectorstore is None:
            raise ValueError("Please load or process documents before setting up the QA chain.")

        # Method 1: Try using the most modern approach
        try:
            print("Attempting modern QA chain setup (Method 1)")
            # Deliberately raise an error to test other methods
            raise ValueError("Deliberately skipping Method 1 for testing purposes")
            
            from langchain.chains.retrieval_qa.base import RetrievalQA
            from langchain.schema import StrOutputParser
            from langchain.schema.runnable import RunnablePassthrough
            from langchain.prompts import ChatPromptTemplate
            
            retriever = self.vectorstore.as_retriever(search_kwargs={"k": 4})
            
            # Create a custom prompt template that includes conversation history
            template = """Answer the question based on the following context and conversation history.
            If you don't know the answer, just say that you don't know, don't try to make up an answer.
            
            Context: {context}
            
            Previous conversation:
            {chat_history}
            
            Question: {input}
            
            Answer:"""
            
            # Create the prompt using ChatPromptTemplate for better compatibility
            prompt = ChatPromptTemplate.from_template(template)

            # Create a formatting function to combine retriever results
            def format_docs(docs):
                return "\n\n".join(doc.page_content for doc in docs)
                
            def get_chat_history(input_dict):
                # Get history based on the current document if available
                history = self.get_conversation_history()
                formatted_history = "\n".join([
                    f"Q: {q}\nA: {a}" for q, a in history[-3:]  # Keep last 3 exchanges
                ])
                return formatted_history if formatted_history else "No previous conversation."

            # Try the modern LCEL approach first
            try:
                print("Attempting modern LCEL chain creation")
                
                # Create the chain using the new LCEL syntax
                chain = (
                    {
                        "context": retriever | format_docs,
                        "input": RunnablePassthrough(),
                        "chat_history": get_chat_history
                    }
                    | prompt
                    | self.llm
                    | StrOutputParser()
                )
                
                # Test the chain
                test_result = chain.invoke("test question")
                print("LCEL chain creation successful")
                self.qa_chain = chain
                return
            except Exception as e_lcel:
                print(f"Modern LCEL chain creation failed: {str(e_lcel)}")
                print("Falling back to traditional RetrievalQA")
                
                try:
                    # Create a simpler chain without custom parameters
                    self.qa_chain = RetrievalQA.from_chain_type(
                        llm=self.llm,
                        chain_type="stuff",
                        retriever=retriever,
                        return_source_documents=True
                    )
                    
                    # Test the chain
                    test_result = self.qa_chain.invoke({"query": "test question"})
                    print("Traditional RetrievalQA setup successful")
                    return
                except Exception as e_retrieval:
                    print(f"Traditional RetrievalQA failed: {str(e_retrieval)}")
                    raise  # Re-raise to try next method
                    
        except Exception as e1:
            print(f"Modern QA chain setup failed with detailed error: {str(e1)}")
            if hasattr(e1, '__cause__'):
                print(f"Caused by: {str(e1.__cause__)}")
        
        # Method 2: Try using the alternative modern approach
        try:
            print("Attempting alternative modern QA chain setup (Method 2)")
            # Deliberately fail Method 2 to test Method 3
            raise ValueError("Deliberately skipping Method 2 to test Method 3")
            
            try:
                from langchain.chains.combine_documents import create_stuff_documents_chain
                from langchain.chains import create_retrieval_chain
                from langchain.prompts import ChatPromptTemplate
                from langchain.schema import StrOutputParser
            except ImportError as e:
                print(f"Failed to import required modules for Method 2: {str(e)}")
                raise  # Re-raise to try next method
            
            try:
                # Create a prompt template that includes conversation history
                from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
                from langchain.chains import create_stuff_documents_chain, create_retrieval_chain
                from langchain_core.runnables import RunnablePassthrough

                # Create the system prompt for question answering
                qa_system_prompt = """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, just say that you don't know. 
Use three sentences maximum and keep the answer concise.

Context: {context}"""

                # Create the QA prompt with chat history support
                qa_prompt = ChatPromptTemplate.from_messages([
                    ("system", qa_system_prompt),
                    MessagesPlaceholder(variable_name="chat_history"),
                    ("human", "{question}")  # Use question as the input key
                ])

                # Create the retriever
                retriever = self.vectorstore.as_retriever(search_kwargs={"k": 4})
            
            # Create the document chain
                document_chain = create_stuff_documents_chain(
                    llm=self.llm,
                    prompt=qa_prompt,
                    document_variable_name="context",
                )
            
                # Create a wrapper to standardize the interface and handle conversation
                class StandardizedRetrievalQA:
                    def __init__(self, retriever, document_chain, parent):
                        self.retriever = retriever
                        self.document_chain = document_chain
                        self.parent = parent
                    
                    def invoke(self, query_dict):
                        # Extract document_id if provided
                        document_id = query_dict.get("document_id")
                        
                        # Handle both question and query keys
                        question = query_dict.get("question", query_dict.get("query", query_dict.get("input", "")))
                        if not question:
                            raise ValueError("No question/query provided in input dictionary")
                        
                        # Add conversation history for specific document
                        history = self.parent.get_conversation_history(document_id)
                        chat_history = "\n".join([
                            f"Q: {q}\nA: {a}" for q, a in history[-3:]  # Last 3 exchanges
                        ]) if history else ""
                        
                        try:
                            # Retrieve relevant documents
                            docs = self.retriever.get_relevant_documents(question)
                            
                            # Format the context
                            context = "\n\n".join(doc.page_content for doc in docs)
                            
                            # Create the input dictionary
                            input_dict = {
                                "question": question,
                                "chat_history": chat_history,
                                "context": context
                            }
                            
                            # Run the chain
                            result = self.document_chain.invoke(input_dict)
                            
                            # Store the Q&A pair in conversation history
                            self.parent.add_to_conversation_history(question, result, document_id)
                            
                            return {
                                "answer": result,
                                "source_documents": docs,
                                "result": result  # Keep original result for debugging
                            }
                            
                        except Exception as e:
                            print(f"Chain invocation failed: {str(e)}")
                            # Try with minimal context as fallback
                            try:
                                # Get just one document as fallback
                                docs = self.retriever.get_relevant_documents(question)[:1]
                                
                                # Create a simpler prompt without conversation history
                                simple_question = question
                                
                                # Log the fallback attempt
                                print(f"Trying fallback with simplified prompt: {simple_question}")
                                
                                # Run the chain with the simplified question
                                answer = self.chain.invoke(simple_question)
                                
                                # Store the Q&A pair even in fallback mode
                                self.parent.add_to_conversation_history(question, answer, document_id)
                                
                                return {
                                    "answer": answer,
                                    "source_documents": docs,
                                    "result": {"result": answer},
                                    "document_id": document_id
                                }
                            except Exception as e2:
                                print(f"Fallback chain invocation failed: {str(e2)}")
                                raise ValueError(f"Both chain invocation attempts failed: {str(e)} -> {str(e2)}")
                
                # Create and test the chain
                qa_chain = StandardizedRetrievalQA(retriever, document_chain, self)
            
                # Test with a simple verification question that doesn't need document retrieval
                try:
                    test_result = qa_chain.invoke({
                        "question": "Verify the QA system is working - this is a test.",
                        "test_mode": True  # Add a flag to indicate this is just a test
                    })
                    if not isinstance(test_result, dict):
                        raise ValueError("Chain returned invalid response format")
                    print("QA chain verification successful")
                except Exception as e:
                    print(f"QA chain verification failed: {str(e)}")
                    raise ValueError("Failed to initialize QA chain")
                
                self.qa_chain = qa_chain
                print("Traditional QA chain setup successful")
                return
                
            except Exception as chain_error:
                print(f"Failed to create or test chain in Method 2: {str(chain_error)}")
                print(f"Chain error type: {type(chain_error)}")
                if hasattr(chain_error, '__cause__'):
                    print(f"Caused by: {str(chain_error.__cause__)}")
                raise ValueError(f"Chain creation failed: {str(chain_error)}")
                
        except Exception as e2:
            print(f"Alternative modern QA chain setup failed with detailed error: {str(e2)}")
            if hasattr(e2, '__cause__'):
                print(f"Caused by: {str(e2.__cause__)}")
            
        # Method 3: Fallback to the traditional approach
        try:
            print("Attempting traditional QA chain setup (Method 3)")
            # Deliberately fail Method 3 to test Method 4
            raise ValueError("Deliberately skipping Method 3 to test Method 4")
            
            # Import the necessary modules
            try:
                from langchain.chains import RetrievalQA
            except ImportError:
                from langchain_community.chains import RetrievalQA
                
            # Create the retriever
            retriever = self.vectorstore.as_retriever(search_kwargs={"k": 4})
            
            # Create the chain
            try:
                from langchain.chains import RetrievalQA
                from langchain.schema.runnable import RunnablePassthrough
                from langchain.schema import StrOutputParser
            except ImportError:
                from langchain_community.chains import RetrievalQA
                from langchain_core.runnables import RunnablePassthrough
                from langchain_core.output_parsers import StrOutputParser

            # Create a prompt template that includes conversation history
            from langchain.prompts import PromptTemplate

            # Create the system prompt for question answering
            template = """Use the following pieces of context to answer the question. 
If you don't know the answer, just say that you don't know. Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""

            # Create the prompt using PromptTemplate
            qa_prompt = PromptTemplate(
                template=template,
                input_variables=["context", "question"]
            )

            # Create formatting functions
            def format_docs(docs):
                return "\n\n".join(doc.page_content for doc in docs)

            # Create the retrieval chain using LCEL
            retriever = self.vectorstore.as_retriever(search_kwargs={"k": 4})
            
            # Build the chain using LCEL
            qa_chain = (
                {
                    "context": retriever | format_docs,
                    "question": RunnablePassthrough()
                }
                | qa_prompt
                | self.llm
                | StrOutputParser()
            )

            # Create a wrapper to standardize the interface and handle conversation
            class StandardizedRetrievalQA:
                def __init__(self, qa_chain, retriever, parent):
                    self.chain = qa_chain
                    self.retriever = retriever
                    self.parent = parent
                
                def invoke(self, query_dict):
                    # Check if this is a test invocation
                    if query_dict.get("test_mode", False):
                        return {
                            "answer": "QA system initialization successful",
                            "source_documents": [],
                            "result": {"result": "QA system initialization successful"}
                        }
                    
                    # Extract document_id if provided
                    document_id = query_dict.get("document_id")
                    
                    # Handle both question and query keys
                    question = query_dict.get("question", query_dict.get("query", query_dict.get("input", "")))
                    if not question:
                        raise ValueError("No question/query provided in input dictionary")
                    
                    try:
                        # Get conversation history for this specific document
                        history = self.parent.get_conversation_history(document_id)
                        print(f"Found {len(history)} previous conversations for document {document_id}")
                        
                        # Get relevant documents
                        docs = self.retriever.get_relevant_documents(question)
                        
                        # Format context with conversation history for improved contextual awareness
                        context_parts = [doc.page_content for doc in docs]
                        
                        # Add conversation context if available
                        if history:
                            # Format the last 3 exchanges
                            conv_context = "\n".join([
                                f"Previous Q: {q}\nPrevious A: {a}" 
                                for q, a in history[-3:]
                            ])
                            # Add conversation context first for better context
                            if conv_context:
                                context_parts.insert(0, f"Previous conversation:\n{conv_context}")
                                print(f"Added conversation context to prompt: {conv_context}")
                        
                        # Join all context parts
                        full_context = "\n\n".join(context_parts)
                        
                        # Create a context-aware question that explicitly includes previous conversation
                        if history:
                            context_aware_question = f"""Based on our previous conversation and the document context, please answer this question: {question}"""
                        else:
                            context_aware_question = question
                        
                        # Run the chain with the enhanced context
                        answer = self.chain.invoke(context_aware_question)
                        
                        # Store the Q&A pair in conversation history
                        self.parent.add_to_conversation_history(question, answer, document_id)
                        
                        return {
                            "answer": answer,
                            "source_documents": docs,
                            "result": {"result": answer},
                            "document_id": document_id
                        }
                        
                    except Exception as e:
                        print(f"Chain invocation failed: {str(e)}")
                        # Try with minimal context as fallback
                        try:
                            # Get just one document as fallback
                            docs = self.retriever.get_relevant_documents(question)[:1]
                            
                            # Create a simpler prompt without conversation history
                            simple_question = question
                            
                            # Log the fallback attempt
                            print(f"Trying fallback with simplified prompt: {simple_question}")
                            
                            # Run the chain with the simplified question
                            answer = self.chain.invoke(simple_question)
                            
                            # Store the Q&A pair even in fallback mode
                            self.parent.add_to_conversation_history(question, answer, document_id)
                            
                            return {
                                "answer": answer,
                                "source_documents": docs,
                                "result": {"result": answer},
                                "document_id": document_id
                            }
                        except Exception as e2:
                            print(f"Fallback chain invocation failed: {str(e2)}")
                            raise ValueError(f"Both chain invocation attempts failed: {str(e)} -> {str(e2)}")
            
            # Create and test the chain
            chain_wrapper = StandardizedRetrievalQA(qa_chain, retriever, self)
            
            # Test with a simple verification question that doesn't need document retrieval
            try:
                test_result = chain_wrapper.invoke({
                    "question": "Verify the QA system is working - this is a test.",
                    "test_mode": True
                })
                if not isinstance(test_result, dict):
                    raise ValueError("Chain returned invalid response format")
                print("QA chain verification successful")
            except Exception as e:
                print(f"QA chain verification failed: {str(e)}")
                raise ValueError("Failed to initialize QA chain")
            
            self.qa_chain = chain_wrapper
            print("Traditional QA chain setup successful")
            return
            
        except Exception as e3:
            print(f"Traditional QA chain setup failed with detailed error: {str(e3)}")
            if hasattr(e3, '__cause__'):
                print(f"Caused by: {str(e3.__cause__)}")
        
        # Method 4: Last resort - create a manual chain
        try:
            print("Attempting manual QA chain creation (Method 4)")
            # Simple class to emulate QA chain behavior
            class SimpleQAChain:
                def __init__(self, vectorstore, llm, parent):
                    self.vectorstore = vectorstore
                    self.llm = llm
                    self.parent = parent
                    self.prompt_template = """Answer the following question based on this context and previous conversation:
                    
                    Previous Conversation:
                    {conversation_history}
                    
                    Context: {context}
                    Question: {question}
                    Answer:"""
                
                def _process_query(self, query_dict):
                    # Handle both 'query' and 'question' keys
                    question = query_dict.get("query", query_dict.get("question", ""))
                    if not question:
                        raise ValueError("No question provided in query dictionary")
                    
                    # Extract document_id for conversation isolation
                    document_id = query_dict.get("document_id")
                    
                    # Get conversation history for this document
                    history = self.parent.get_conversation_history(document_id)
                    
                    # Format conversation history
                    conversation_history = ""
                    if history:
                        # Get last 3 exchanges for context
                        conversation_history = "\n".join([
                            f"Q: {q}\nA: {a}" for q, a in history[-3:]
                        ])
                    
                    # Retrieve relevant documents
                    docs = self.vectorstore.similarity_search(question, k=4)
                    
                    # Format context
                    context = "\n\n".join([doc.page_content for doc in docs])
                    
                    # Create prompt with conversation history
                    prompt = self.prompt_template.format(
                        conversation_history=conversation_history if conversation_history else "No previous conversation.",
                        context=context,
                        question=question
                    )
                    
                    # Get response from LLM
                    response = self.llm(prompt)
                    
                    # Store the Q&A pair in conversation history
                    self.parent.add_to_conversation_history(question, response, document_id)
                    
                    return {
                        "answer": response,
                        "source_documents": docs,
                        "question": question,
                        "context": context,
                        "document_id": document_id
                    }
                
                def invoke(self, query_dict):
                    return self._process_query(query_dict)
            
            self.qa_chain = SimpleQAChain(self.vectorstore, self.llm, self)
            
            # Test the chain
            test_result = self.qa_chain.invoke({"question": "test question"})
            if not isinstance(test_result, dict):
                raise ValueError("Chain returned invalid response format")
            
            print("Manual QA chain creation successful")
            return
        except Exception as e4:
            print(f"Manual QA chain setup failed with detailed error: {str(e4)}")
            if hasattr(e4, '__cause__'):
                print(f"Caused by: {str(e4.__cause__)}")
            raise ValueError(f"All QA chain setup methods failed: Method 1 -> Method 2 -> Method 3 -> Method 4")

    def query(self, question: str, document_id: str = None) -> Dict:
        """
        Query the system with a question.
        
        Args:
            question (str): The question to ask
            document_id (str): Identifier for the document being discussed
            
        Returns:
            Dict: Answer and source information
        """
        if self.qa_chain is None:
            raise ValueError("Please set up the QA chain before querying.")

        try:
            # Use a consistent document ID across the entire conversation
            doc_id = document_id or self.db_path
            print(f"Querying with question for document ID {doc_id}: {question}")
            
            # Check for existing conversation history with this document
            history = self.get_conversation_history(doc_id)
            if history:
                print(f"Using existing conversation history with {len(history)} entries")
                if len(history) > 0:
                    print(f"Last conversation: Q: {history[-1][0]}, A: {history[-1][1][:50]}...")
            
            # Use the standardized interface with document_id
            result = self.qa_chain.invoke({
                "question": question,
                "document_id": doc_id  # Pass consistent document_id to the chain
            })
            
            # Extract answer and sources
            answer = result.get("answer", "")
            sources = result.get("source_documents", [])
            
            # No need to store history again here as the chain already did it
            # This would cause duplicate entries
            # self.add_to_conversation_history(question, answer, doc_id)
            
            return {
                "answer": answer,
                "sources": sources,
                "document_id": doc_id
            }
            
        except Exception as e:
            print(f"Query failed with error: {str(e)}")
            if hasattr(e, '__cause__'):
                print(f"Caused by: {str(e.__cause__)}")
            raise ValueError(f"Could not execute query: {str(e)}")

    def generate_and_save_flashcards(self, topic: str, num_cards: int) -> None:
        """
        Generate and save flashcards for a topic.
        
        Args:
            topic (str): The topic to generate flashcards for
            num_cards (int): Number of flashcards to generate
        """
        if self.vectorstore is None:
            raise ValueError("Please load or process documents before generating flashcards.")

        relevant_chunks = self.vectorstore.similarity_search(topic, k=6)
        combined_content = "\n\n".join([chunk.page_content for chunk in relevant_chunks])

        chunk_metadata = [
            {
                "source": chunk.metadata['source'],
                "page": chunk.metadata['page']
            } for chunk in relevant_chunks
        ]

        num_easy = max(1, int(num_cards * 0.1))
        num_medium = int(num_cards * 0.4)
        num_hard = num_cards - num_easy - num_medium

        flashcard_prompt = f"""
        Based on the following content about '{topic}', generate {num_cards} flashcards:

        {combined_content}

        Create flashcards with the following distribution:
        - {num_easy} Easy flashcard(s)
        - {num_medium} Medium flashcards
        - {num_hard} Hard flashcards

        Format the response as a JSON array with 'question', 'answer', 'difficulty', and 'chunk_indices' keys for each flashcard.
        """

        response = self.llm(flashcard_prompt)
        flashcards = json.loads(response)

        for card in flashcards:
            valid_indices = [i for i in card['chunk_indices'] if 0 <= i < len(chunk_metadata)]
            if not valid_indices:
                valid_indices = [0]
            card['metadata'] = [chunk_metadata[i] for i in valid_indices]
            del card['chunk_indices']

        if not os.path.exists("flashcards"):
            os.makedirs("flashcards")
        
        filename = os.path.join("flashcards", f"{topic.replace(' ', '_')}.json")
        with open(filename, "w") as f:
            json.dump(flashcards, f, indent=2)

    def generate_exam(
        self,
        start_page: int,
        end_page: int,
        num_questions: int,
        question_types: List[str]
    ) -> List[Dict]:
        """
        Generate an exam based on document content.
        
        Args:
            start_page (int): Starting page number
            end_page (int): Ending page number
            num_questions (int): Number of questions to generate
            question_types (List[str]): Types of questions to include
            
        Returns:
            List[Dict]: Generated exam questions
        """
        if self.vectorstore is None:
            raise ValueError("Please load or process documents before generating an exam.")

        all_chunks = self.vectorstore.similarity_search("", k=10000)
        relevant_chunks = [chunk for chunk in all_chunks if start_page <= chunk.metadata['page'] <= end_page]

        if not relevant_chunks:
            raise ValueError(f"No content found between pages {start_page} and {end_page}.")

        chunks_per_question = math.ceil(len(relevant_chunks) / num_questions)
        chunk_groups = [relevant_chunks[i:i+chunks_per_question] 
                       for i in range(0, len(relevant_chunks), chunks_per_question)]

        exam_questions = []
        for i, chunk_group in enumerate(chunk_groups[:num_questions]):
            combined_content = "\n\n".join([chunk.page_content for chunk in chunk_group])
            question_type = question_types[i % len(question_types)]

            exam_prompt = f"""
            Based on the following content, generate a {question_type} question:

            {combined_content}

            Format the response as a JSON object with 'question_type', 'question', 'correct_answer',
            'options' (for multiple choice), and 'explanation' fields.
            """

            response = self.llm(exam_prompt)
            question_data = json.loads(response)
            exam_questions.append(question_data)

        return exam_questions

    def score_exam(
        self,
        exam_data: List[Dict],
        user_answers: List[str]
    ) -> Tuple[int, float]:
        """
        Score a completed exam.
        
        Args:
            exam_data (List[Dict]): The exam questions and correct answers
            user_answers (List[str]): The user's answers
            
        Returns:
            Tuple[int, float]: Number of correct answers and percentage score
        """
        correct_answers = 0
        
        for i, (question, answer) in enumerate(zip(exam_data, user_answers)):
            if question['question_type'].lower() == 'multiple choice':
                correct_answers += int(answer.lower() == question['correct_answer'].lower())
            else:
                # For other question types, use AI to evaluate the answer
                eval_prompt = f"""
                Question: {question['question']}
                Correct Answer: {question['correct_answer']}
                User Answer: {answer}

                Evaluate if the user's answer is correct. Consider partial credit.
                Return a score between 0 and 1, where:
                1.0 = Completely correct
                0.75 = Mostly correct
                0.5 = Partially correct
                0.25 = Mostly incorrect
                0.0 = Completely incorrect

                Return only the numerical score.
                """
                
                score = float(self.llm(eval_prompt))
                correct_answers += score

        percentage_score = (correct_answers / len(exam_data)) * 100
        return int(correct_answers), percentage_score

    def update_exam_history(
        self,
        exam_file: str,
        num_questions: int,
        correct_answers: int,
        score: float
    ) -> None:
        """
        Update the exam history with new results.
        
        Args:
            exam_file (str): Path to the exam file
            num_questions (int): Total number of questions
            correct_answers (int): Number of correct answers
            score (float): Percentage score
        """
        history_file = "exam_history.csv"
        
        data = {
            'timestamp': datetime.now(),
            'exam_file': exam_file,
            'num_questions': num_questions,
            'correct_answers': correct_answers,
            'score': score
        }
        
        if os.path.exists(history_file):
            df = pd.read_csv(history_file)
            df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
        else:
            df = pd.DataFrame([data])
            
        df.to_csv(history_file, index=False) 

    def _get_conversation_file_path(self) -> str:
        """Get the path to the conversation history file for this user."""
        if not self.user_id:
            return None
            
        # Create a base conversation directory in the same path as the DB
        conv_dir = os.path.join(os.path.dirname(self.db_path), "conversations")
        os.makedirs(conv_dir, exist_ok=True)
        
        # Create a file for this user's conversations
        return os.path.join(conv_dir, f"{self.user_id}_conversations.json")
        
    def _save_conversations_to_disk(self) -> None:
        """Save current conversation history to disk."""
        if not self.user_id:
            return
            
        file_path = self._get_conversation_file_path()
        if not file_path:
            return
            
        try:
            # Get this user's conversations
            user_conversations = self._conversation_histories.get(self.user_id, {})
            
            # Convert to a serializable format (handles tuple conversion)
            serializable_convs = {}
            for doc_id, convs in user_conversations.items():
                serializable_convs[doc_id] = [
                    {"question": q, "answer": a} for q, a in convs
                ]
                
            # Save to file
            with open(file_path, 'w') as f:
                json.dump(serializable_convs, f)
                
            print(f"Saved conversation history for user {self.user_id} to {file_path}")
        except Exception as e:
            print(f"Error saving conversation history: {e}")
            
    def _load_conversations_from_disk(self) -> None:
        """Load conversation history from disk."""
        if not self.user_id:
            return
            
        file_path = self._get_conversation_file_path()
        if not file_path or not os.path.exists(file_path):
            print(f"No conversation history file found at {file_path}")
            return
            
        try:
            with open(file_path, 'r') as f:
                serializable_convs = json.load(f)
                
            # Convert back to our internal format
            user_conversations = {}
            for doc_id, convs in serializable_convs.items():
                user_conversations[doc_id] = [
                    (conv["question"], conv["answer"]) for conv in convs
                ]
                
            # Update the in-memory store
            self._conversation_histories[self.user_id] = user_conversations
            
            # Log what we loaded
            total_convs = sum(len(convs) for convs in user_conversations.values())
            print(f"Loaded {total_convs} conversation entries for user {self.user_id} across {len(user_conversations)} documents")
        except Exception as e:
            print(f"Error loading conversation history: {e}") 