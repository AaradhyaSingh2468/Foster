"""
StudyBuddy AI Service for Foster platform.
This service wraps the StudyBuddy AI functionality and provides API endpoints.
"""

import os
import json
from datetime import datetime
from typing import List, Dict, Optional
from pathlib import Path

from .studyai import AdvancedStudyBuddyAI

class StudyBuddyService:
    def __init__(self, storage_path: str = "storage", user_id: str = None):
        """
        Initialize the StudyBuddy AI Service.
        
        Args:
            storage_path (str): Base path for storing documents and generated content
            user_id (str): Unique identifier for the user
        """
        self.storage_path = Path(storage_path)
        self.documents_path = self.storage_path / "documents"
        self.flashcards_path = self.storage_path / "flashcards"
        self.exams_path = self.storage_path / "exams"
        self.vectordb_path = self.storage_path / "vectordb"
        self.user_id = user_id
        
        # Create necessary directories
        for path in [self.documents_path, self.flashcards_path, self.exams_path, self.vectordb_path]:
            path.mkdir(parents=True, exist_ok=True)
            
        self.ai = AdvancedStudyBuddyAI(
            pdf_directory=str(self.documents_path),
            db_path=str(self.vectordb_path),
            user_id=user_id
        )
        
        if user_id:
            print(f"StudyBuddyService initialized with user_id: {user_id}")
        
    async def process_document(self, file_path: str) -> Dict[str, str]:
        """
        Process a new document and add it to the vector database.
        
        Args:
            file_path (str): Path to the PDF file
            
        Returns:
            Dict[str, str]: Status of the operation
        """
        try:
            # Copy file to documents directory if it's not already there
            if not file_path.startswith(str(self.documents_path)):
                dest_path = self.documents_path / Path(file_path).name
                with open(file_path, 'rb') as src, open(dest_path, 'wb') as dst:
                    dst.write(src.read())
                file_path = str(dest_path)
            
            self.ai.load_and_process_pdfs()
            return {"status": "success", "message": "Document processed successfully"}
        except Exception as e:
            return {"status": "error", "message": str(e)}
            
    async def ask_question(self, question: str) -> Dict[str, any]:
        """
        Ask a question about the processed documents.
        
        Args:
            question (str): The question to ask
            
        Returns:
            Dict: Answer and source information
        """
        try:
            if not self.ai.vectorstore:
                self.ai.load_vectorstore()
            if not self.ai.qa_chain:
                self.ai.setup_qa_chain()
                
            result = self.ai.query(question)
            return {
                "status": "success",
                "answer": result["answer"],
                "sources": result["sources"]
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}
            
    async def generate_flashcards(self, topic: str, num_cards: int) -> Dict[str, any]:
        """
        Generate flashcards for a specific topic.
        
        Args:
            topic (str): The topic to generate flashcards for
            num_cards (int): Number of flashcards to generate
            
        Returns:
            Dict: Generated flashcards and metadata
        """
        try:
            if not self.ai.vectorstore:
                self.ai.load_vectorstore()
                
            self.ai.generate_and_save_flashcards(topic, num_cards)
            
            # Read the generated flashcards
            flashcard_file = self.flashcards_path / f"{topic.replace(' ', '_')}.json"
            with open(flashcard_file, 'r') as f:
                flashcards = json.load(f)
                
            return {
                "status": "success",
                "flashcards": flashcards
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}
            
    async def generate_exam(
        self,
        start_page: int,
        end_page: int,
        num_questions: int,
        question_types: List[str]
    ) -> Dict[str, any]:
        """
        Generate an exam based on the processed documents.
        
        Args:
            start_page (int): Starting page number
            end_page (int): Ending page number
            num_questions (int): Number of questions to generate
            question_types (List[str]): Types of questions to include
            
        Returns:
            Dict: Generated exam questions and metadata
        """
        try:
            if not self.ai.vectorstore:
                self.ai.load_vectorstore()
                
            exam = self.ai.generate_exam(start_page, end_page, num_questions, question_types)
            
            # Save the exam
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            exam_file = self.exams_path / f"exam_{timestamp}.json"
            with open(exam_file, 'w') as f:
                json.dump(exam, f, indent=2)
                
            return {
                "status": "success",
                "exam": exam,
                "exam_id": exam_file.name
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}
            
    async def grade_exam(
        self,
        exam_id: str,
        answers: List[str]
    ) -> Dict[str, any]:
        """
        Grade a completed exam.
        
        Args:
            exam_id (str): ID of the exam to grade
            answers (List[str]): User's answers to the exam questions
            
        Returns:
            Dict: Grading results and feedback
        """
        try:
            exam_file = self.exams_path / exam_id
            if not exam_file.exists():
                return {"status": "error", "message": "Exam not found"}
                
            with open(exam_file, 'r') as f:
                exam_data = json.load(f)
                
            correct_answers, score = self.ai.score_exam(exam_data, answers)
            
            # Update exam history
            self.ai.update_exam_history(
                str(exam_file),
                len(exam_data),
                correct_answers,
                score
            )
            
            return {
                "status": "success",
                "score": score,
                "correct_answers": correct_answers,
                "total_questions": len(exam_data)
            }
        except Exception as e:
            return {"status": "error", "message": str(e)} 