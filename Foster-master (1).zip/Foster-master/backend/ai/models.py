from django.db import models
from django.contrib.auth.models import User

class Conversation(models.Model):
    """Model for AI chat conversations"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_conversations')
    title = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Conversation: {self.title}"
    
    class Meta:
        ordering = ['-updated_at']

class ChatMessage(models.Model):
    """Model for individual chat messages"""
    MESSAGE_TYPES = [
        ('user', 'User'),
        ('ai', 'AI'),
    ]
    
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPES)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.message_type} message in {self.conversation.title}"
    
    class Meta:
        ordering = ['created_at']

class ExamGeneration(models.Model):
    """Model for AI-generated exams"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_exams')
    study_set = models.ForeignKey('study.StudySet', on_delete=models.SET_NULL, null=True, blank=True, related_name='ai_exams')
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    question_count = models.IntegerField(default=10)
    difficulty = models.CharField(max_length=20, default='medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Exam: {self.title}"

class ExamQuestion(models.Model):
    """Model for AI-generated exam questions"""
    QUESTION_TYPES = [
        ('multiple_choice', 'Multiple Choice'),
        ('true_false', 'True/False'),
        ('short_answer', 'Short Answer'),
        ('essay', 'Essay'),
    ]
    
    exam = models.ForeignKey(ExamGeneration, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    options = models.JSONField(null=True, blank=True)  # For multiple choice questions
    correct_answer = models.TextField()
    explanation = models.TextField(blank=True)
    
    def __str__(self):
        return f"Question in {self.exam.title}"

class VideoGeneration(models.Model):
    """Model for AI-generated educational videos"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_videos')
    title = models.CharField(max_length=100)
    description = models.TextField()
    topic = models.CharField(max_length=100)
    duration = models.IntegerField(default=300)  # seconds
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    video_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Video: {self.title}"

class StudyInsight(models.Model):
    """Model for AI-generated study insights"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_insights')
    study_set = models.ForeignKey('study.StudySet', on_delete=models.SET_NULL, null=True, blank=True, related_name='ai_insights')
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Insight: {self.title}"

class LearningRecommendation(models.Model):
    """Model for AI-generated learning recommendations"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ai_recommendations')
    title = models.CharField(max_length=100)
    description = models.TextField()
    recommendation_type = models.CharField(max_length=50)
    resource_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Recommendation: {self.title}" 