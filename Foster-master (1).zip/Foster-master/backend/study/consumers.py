import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.conf import settings
import logging
import asyncio
from bson import ObjectId
from datetime import datetime

logger = logging.getLogger(__name__)

# Maintain active connections per user
active_connections = {}

class FlashcardConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for handling flashcard generation notifications.
    """
    
    async def connect(self):
        """
        Called when the websocket is handshaking.
        """
        logger.info(f"WebSocket connection attempt received: {self.scope.get('path', 'unknown path')}")
        logger.info(f"WebSocket scope: {self.scope}")
        logger.info(f"WebSocket connection headers: {self.scope.get('headers', [])}")
        
        # Extract token from query string if available
        query_string = self.scope.get('query_string', b'').decode('utf-8')
        token = None
        if 'token=' in query_string:
            token_part = query_string.split('token=')[1]
            token = token_part.split('&')[0] if '&' in token_part else token_part
            logger.info(f"Token received in WebSocket connection: {token[:20]}...")
        
        # Get the user from the scope
        self.user = self.scope.get("user")
        
        # If user is not authenticated, try to authenticate using token
        if not self.user or not getattr(self.user, 'is_authenticated', False):
            logger.warning("User not authenticated via Django channels auth")
            
            if token:
                # Attempt to verify Firebase token
                try:
                    from foster.firebase import verify_firebase_token
                    user_data = verify_firebase_token(token)
                    if user_data:
                        # Extract Firebase UID from token verification
                        firebase_uid = user_data.get('uid')
                        if firebase_uid:
                            # Look up user in MongoDB
                            user_record = await self.get_user_from_firebase_uid(firebase_uid)
                            if user_record:
                                self.user_id = str(user_record.get('_id'))
                                logger.info(f"Authenticated WebSocket connection via Firebase token for user: {self.user_id}")
                            else:
                                logger.warning(f"Firebase user {firebase_uid} not found in database")
                                await self.close(code=4003)
                                return
                        else:
                            logger.warning("Firebase token valid but no UID found")
                            await self.close(code=4002)
                            return
                    else:
                        logger.warning("Invalid Firebase token")
                        await self.close(code=4001)
                        return
                except Exception as e:
                    logger.error(f"Error authenticating WebSocket with Firebase token: {str(e)}")
                    await self.close(code=4000)
                    return
            else:
                logger.warning("No authentication token provided for WebSocket")
                await self.close(code=1008)
                return
        else:
            # Get user ID from authenticated user
            self.user_id = getattr(self.user, 'uid', None)
            if not self.user_id:
                self.user_id = getattr(self.user, 'id', None)
            
            logger.info(f"Authenticated WebSocket connection via Django channels auth for user: {self.user_id}")
            
        if not getattr(self, 'user_id', None):
            logger.warning("Could not determine user ID for WebSocket connection")
            await self.close(code=1008)
            return
            
        # Add to the group for this user
        self.group_name = f"flashcards_{self.user_id}"
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        
        # Store the connection
        if self.user_id not in active_connections:
            active_connections[self.user_id] = []
            
        active_connections[self.user_id].append(self)
        logger.info(f"WebSocket connection established for user {self.user_id}")
        
        # Accept the connection
        await self.accept()
        
        # Send a connection confirmation message
        await self.send(text_data=json.dumps({
            'type': 'connection_established',
            'message': 'Connected to flashcard generation notifications',
            'user_id': self.user_id
        }))

    @database_sync_to_async
    def get_user_from_firebase_uid(self, firebase_uid):
        """
        Get user record from Firebase UID.
        """
        try:
            from foster.mongodb import get_collection
            users_collection = get_collection('users')
            return users_collection.find_one({'firebase_uid': firebase_uid})
        except Exception as e:
            logger.error(f"Error fetching user by Firebase UID: {str(e)}")
            return None

    async def disconnect(self, close_code):
        """
        Called when the WebSocket closes.
        """
        # Remove from active connections
        if hasattr(self, 'user_id') and self.user_id in active_connections:
            if self in active_connections[self.user_id]:
                active_connections[self.user_id].remove(self)
                
            # Clean up if no more connections for this user
            if not active_connections[self.user_id]:
                del active_connections[self.user_id]
                
            # Leave the group
            if hasattr(self, 'group_name'):
                await self.channel_layer.group_discard(
                    self.group_name,
                    self.channel_name
                )
            
            logger.info(f"WebSocket connection closed for user {self.user_id} with code {close_code}")
        else:
            logger.info(f"WebSocket connection closed with code {close_code} (no user ID)")

    async def receive(self, text_data):
        """
        Called when we get a message from the client.
        """
        # First check for plain text messages
        if text_data == 'ping':
            logger.info(f"Received ping from user {self.user_id}")
            await self.send(text_data=json.dumps({
                'type': 'pong',
                'timestamp': datetime.now().isoformat()
            }))
            return
        elif text_data == 'subscribe':
            logger.info(f"User {self.user_id} subscribed to notifications (plain text)")
            await self.send(text_data=json.dumps({
                'type': 'subscription_confirmed',
                'message': 'Successfully subscribed to flashcard notifications',
                'user_id': self.user_id,
                'timestamp': datetime.now().isoformat(),
                'keep_alive': True
            }))
            
            # Send an immediate ping to maintain the connection
            await self.send(text_data=json.dumps({
                'type': 'ping',
                'timestamp': datetime.now().isoformat()
            }))
            return
            
        # Then try to parse as JSON for other messages
        try:
            data = json.loads(text_data)
            message_type = data.get('type') if isinstance(data, dict) else text_data
            
            # Only log non-ping messages or first occurrence of JSON ping
            if message_type != 'ping' or text_data != 'ping':
                logger.info(f"WebSocket message received from user {self.user_id}: {message_type} {text_data}")
            
            if message_type == 'ping':
                # Respond to ping messages to keep the connection alive
                await self.send(text_data=json.dumps({
                    'type': 'pong',
                    'timestamp': datetime.now().isoformat()
                }))
            elif message_type == 'check_job':
                # Check job status and send back immediately
                job_id = data.get('job_id')
                if job_id:
                    logger.info(f"Job status check requested for {job_id} by user {self.user_id}")
                    job_status = await self.get_job_status(job_id)
                    await self.send(text_data=json.dumps({
                        'type': 'job_status',
                        'job_id': job_id,
                        'status': job_status
                    }))
            elif message_type == 'subscribe':
                # Handle subscribe message - client is requesting to subscribe to notifications
                logger.info(f"User {self.user_id} subscribed to notifications")
                
                # Respond with confirmation but don't close the connection
                await self.send(text_data=json.dumps({
                    'type': 'subscription_confirmed',
                    'message': 'Successfully subscribed to flashcard notifications',
                    'user_id': self.user_id,
                    'timestamp': datetime.now().isoformat(),
                    'keep_alive': True
                }))
                
                # Send an immediate ping to maintain the connection
                await self.send(text_data=json.dumps({
                    'type': 'ping',
                    'timestamp': datetime.now().isoformat()
                }))
            else:
                logger.warning(f"Received unknown message type: {message_type} from user {self.user_id}")
                
        except json.JSONDecodeError:
            # Don't log JSON decode errors for plain text messages that we already handled
            if text_data not in ['ping', 'subscribe']:
                logger.error(f"Received invalid JSON from user {self.user_id}: {text_data}")
        except Exception as e:
            logger.error(f"Error processing WebSocket message from user {self.user_id}: {str(e)}")

    async def flashcard_notification(self, event):
        """
        Called when a message is sent to the group.
        """
        try:
            logger.info(f"Sending notification to user {self.user_id}: {event.get('notification_type')}")
            
            # Remove the type key used for channel layer routing
            message = {k: v for k, v in event.items() if k != 'type'}
            
            # Ensure frontend required fields are provided
            if message.get('notification_type') == 'job_completed':
                if not message.get('study_set_id') and message.get('document_id'):
                    message['study_set_id'] = message['document_id']
                
                if not message.get('title') and message.get('document_id'):
                    # Try to get document title from database
                    try:
                        from foster.mongodb import get_collection
                        docs_collection = get_collection('documents')
                        doc = None
                        
                        # Try as ObjectId first
                        try:
                            doc = docs_collection.find_one({'_id': ObjectId(message['document_id'])})
                        except:
                            # Then try as string ID
                            doc = docs_collection.find_one({'id': message['document_id']})
                            
                        if doc and doc.get('title'):
                            message['title'] = f"{doc['title']} Flashcards"
                        else:
                            message['title'] = "Generated Flashcards"
                    except Exception as e:
                        logger.error(f"Error retrieving document title: {str(e)}")
                        message['title'] = "Generated Flashcards"
                
                if not message.get('description'):
                    message['description'] = "AI-generated flashcards"
            
            # Send the message to the WebSocket
            await self.send(text_data=json.dumps(message))
            
            logger.info(f"Successfully sent notification to user {self.user_id}")
        except Exception as e:
            logger.error(f"Error sending flashcard notification to user {self.user_id}: {str(e)}")

    @database_sync_to_async
    def get_job_status(self, job_id):
        """
        Get the status of a flashcard job from MongoDB.
        """
        try:
            from foster.mongodb import get_collection
            jobs_collection = get_collection('flashcard_jobs')
            
            # Find job - try both the MongoDB ID and Firebase UID
            job = jobs_collection.find_one({
                'job_id': job_id,
                'user_id': self.user_id
            })
            
            # If job not found by MongoDB ID, try with Firebase UID
            if not job:
                # Try to get the user's Firebase UID from user collection
                users_collection = get_collection('users')
                user = users_collection.find_one({'_id': ObjectId(self.user_id)})
                if user and 'firebase_uid' in user:
                    firebase_uid = user['firebase_uid']
                    # Try again with Firebase UID
                    job = jobs_collection.find_one({
                        'job_id': job_id,
                        'user_id': firebase_uid
                    })
                    
                    if job:
                        logger.info(f"Found job {job_id} using Firebase UID {firebase_uid} instead of MongoDB ID")
                    else:
                        # If still not found, try with the reverse lookup
                        user_by_firebase = users_collection.find_one({'firebase_uid': self.user_id})
                        if user_by_firebase:
                            mongo_id = str(user_by_firebase['_id'])
                            job = jobs_collection.find_one({
                                'job_id': job_id,
                                'user_id': mongo_id
                            })
                            if job:
                                logger.info(f"Found job {job_id} using MongoDB ID {mongo_id} from Firebase UID")
            
            if not job:
                logger.warning(f"Job {job_id} not found for user {self.user_id}")
                return {'error': 'Job not found'}
            
            # Convert MongoDB ObjectId to string for serialization
            job_status = {
                'status': job.get('status', 'unknown'),
                'message': job.get('message', ''),
                'completed': job.get('status') == 'completed',
                'failed': job.get('status') == 'failed',
                'error': job.get('error', ''),
            }
            
            # Only include flashcards if the job is completed
            if job.get('status') == 'completed':
                job_status['flashcards'] = job.get('flashcards', [])
            
            logger.info(f"Retrieved job status for {job_id}: {job.get('status', 'unknown')}")
            return job_status
            
        except Exception as e:
            logger.error(f"Error getting job status for {job_id}: {str(e)}")
            return {'error': str(e)}


# Helper function to send a notification to a specific user
async def send_flashcard_notification(user_id, notification_type, data):
    """
    Send a notification to all WebSocket connections for a user.
    
    Args:
        user_id (str): The user ID to send the notification to
        notification_type (str): The type of notification (e.g., 'job_completed')
        data (dict): The data to send
    """
    from channels.layers import get_channel_layer
    
    try:
        logger.info(f"Preparing to send {notification_type} notification to user {user_id}")
        
        # Get the channel layer
        channel_layer = get_channel_layer()
        if not channel_layer:
            logger.error("Failed to get channel layer")
            return False
        
        # Prepare the message
        message = {
            'type': 'flashcard_notification',
            'notification_type': notification_type,
            **data
        }
        
        # Send to the group for this user
        group_name = f"flashcards_{user_id}"
        logger.info(f"Sending notification to group: {group_name}")
        
        await channel_layer.group_send(group_name, message)
        
        logger.info(f"Successfully dispatched {notification_type} notification to user {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error sending WebSocket notification to user {user_id}: {str(e)}")
        if hasattr(e, '__cause__'):
            logger.error(f"Caused by: {str(e.__cause__)}")
        return False

# Add after FlashcardConsumer class

class EchoConsumer(AsyncWebsocketConsumer):
    """
    Simple Echo WebSocket consumer for testing connectivity.
    """
    
    async def connect(self):
        """
        Called when the websocket is handshaking.
        """
        logger.info(f"Echo WebSocket connection attempt received: {self.scope.get('path', 'unknown path')}")
        
        # Accept all connections without authentication for testing
        await self.accept()
        logger.info("Echo WebSocket connection established")
        
        # Send a connection confirmation message
        await self.send(text_data=json.dumps({
            'type': 'connection_established',
            'message': 'Connected to echo service'
        }))

    async def disconnect(self, close_code):
        """
        Called when the WebSocket closes.
        """
        logger.info(f"Echo WebSocket connection closed with code {close_code}")

    async def receive(self, text_data):
        """
        Echo back any received message.
        """
        try:
            # Parse the JSON message
            data = json.loads(text_data)
            logger.info(f"Echo received message: {data}")
            
            # Echo the message back with a timestamp
            response = {
                'type': 'echo',
                'original': data,
                'timestamp': datetime.now().isoformat()
            }
            
            # Send the response
            await self.send(text_data=json.dumps(response))
            logger.info("Echo response sent")
            
        except json.JSONDecodeError:
            # Handle invalid JSON
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': 'Invalid JSON received',
                'received': text_data
            }))
        except Exception as e:
            # Handle other errors
            logger.error(f"Error in echo consumer: {str(e)}")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': f'Error processing message: {str(e)}'
            })) 