from django.urls import path, re_path
from . import consumers

# Define WebSocket URL patterns at the app level
websocket_urlpatterns = [
    path('ws/flashcards/', consumers.FlashcardConsumer.as_asgi()),
    path('ws/flashcards', consumers.FlashcardConsumer.as_asgi()),
    path('ws/echo/', consumers.EchoConsumer.as_asgi()),
    path('ws/echo', consumers.EchoConsumer.as_asgi()),
] 