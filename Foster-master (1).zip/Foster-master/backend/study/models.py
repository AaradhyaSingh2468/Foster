from django.db import models
from django.contrib.auth.models import User

class StudySet(models.Model):
    """Model for study sets"""
    SOURCE_CHOICES = [
        ('manual', 'Manually Created'),
        ('pdf', 'PDF Upload'),
        ('api', 'API Generated')
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_sets')
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    subject = models.CharField(max_length=50)
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, default='manual')
    is_public = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.title} by {self.user.username}"
    
    class Meta:
        ordering = ['-updated_at']

class Flashcard(models.Model):
    """Model for flashcards in a study set"""
    study_set = models.ForeignKey(StudySet, on_delete=models.CASCADE, related_name='flashcards')
    question = models.TextField()
    answer = models.TextField()
    image = models.ImageField(upload_to='flashcards/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Flashcard in {self.study_set.title}: {self.question[:30]}"

class StudyProgress(models.Model):
    """Model to track user's study progress with flashcards"""
    DIFFICULTY_CHOICES = [
        (1, 'Easy'),
        (2, 'Medium'),
        (3, 'Hard'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_progress')
    flashcard = models.ForeignKey(Flashcard, on_delete=models.CASCADE, related_name='progress')
    last_studied = models.DateTimeField(auto_now=True)
    correct_count = models.IntegerField(default=0)
    incorrect_count = models.IntegerField(default=0)
    difficulty_rating = models.IntegerField(choices=DIFFICULTY_CHOICES, default=2)
    next_review_date = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ('user', 'flashcard')
    
    def __str__(self):
        return f"Progress for {self.user.username} on {self.flashcard}"

class Quiz(models.Model):
    """Model for quizzes generated from study sets"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quizzes')
    study_set = models.ForeignKey(StudySet, on_delete=models.CASCADE, related_name='quizzes')
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    score = models.FloatField(null=True, blank=True)  # percentage
    
    def __str__(self):
        return f"Quiz on {self.study_set.title} for {self.user.username}"

class QuizQuestion(models.Model):
    """Model for individual quiz questions"""
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='questions')
    flashcard = models.ForeignKey(Flashcard, on_delete=models.CASCADE, related_name='quiz_questions')
    user_answer = models.TextField(null=True, blank=True)
    is_correct = models.BooleanField(null=True, blank=True)
    
    def __str__(self):
        return f"Question in {self.quiz.title}" 