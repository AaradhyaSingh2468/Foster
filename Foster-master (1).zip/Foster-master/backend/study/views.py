from rest_framework.permissions import IsAuthenticated, AllowAny  
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import StudySet
from django.db.models import Count
from django.conf import settings
from datetime import datetime
import json
from bson import ObjectId
from django.views.decorators.csrf import csrf_exempt
import os
from foster.file_security import secure_file_path, validate_file_access
import logging
from rest_framework.decorators import api_view, permission_classes
from django.core.files.storage import FileSystemStorage

# Set up logging
logger = logging.getLogger(__name__)

# Custom JSON encoder to handle MongoDB ObjectId
class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)

# Helper function to ensure dates are in ISO format
def format_datetime(dt):
    """Convert datetime objects to ISO format strings for better JS compatibility"""
    if dt is None:
        return None
    if isinstance(dt, datetime):
        return dt.isoformat()
    try:
        # Try to parse the string as a datetime if it's not already
        parsed_dt = datetime.fromisoformat(str(dt))
        return parsed_dt.isoformat()
    except (ValueError, TypeError):
        print(f"Warning: Invalid date format: {dt}")
        return None

class StudySetListView(APIView):
    # Remove permission_classes restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def get(self, request):
        # Log authentication info
        logger.info(f"User authenticated: {request.user.is_authenticated}")
        logger.info(f"User info: {request.user}")
        
        # If user is not authenticated, return empty list instead of error
        if not request.user.is_authenticated:
            logger.info("User not authenticated, returning empty study sets list")
            return Response([])
            
        # Get query params
        source = request.query_params.get('source')
        
        # Get MongoDB connection
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Get user ID - Firebase/MongoDB users have uid not id
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
            
        # If still no user ID, return empty list for security
        if not user_id:
            logger.info("Could not determine user ID, returning empty list")
            return Response([])
        
        # Filter by user - this is critical for security
        query = {'user_id': user_id}
        
        # Filter out preserved documents that aren't active decks
        query['$or'] = [
            {'is_preserved': {'$exists': False}},  # Documents without is_preserved field
            {'is_preserved': False}                # Documents explicitly marked as not preserved
        ]
        
        # If source param is provided, filter by source (for PDF library)
        if source == 'pdf':
            query['source'] = 'pdf'
        
        # Log query for debugging
        logger.info(f"StudySetListView query: {query}")
        
        try:
            # Fetch study sets from MongoDB
            cursor = collection.find(query)
            
            # Convert to list of dictionaries
            study_sets = []
            for doc in cursor:
                # Get flashcards count
                flashcards_count = 0
                flashcards_collection = get_collection('flashcards')
                flashcards_count = flashcards_collection.count_documents({'study_set_id': str(doc['_id'])})
                
                # Ensure dates are properly formatted
                created_at = format_datetime(doc.get('created_at', datetime.now()))
                updated_at = format_datetime(doc.get('updated_at', datetime.now()))
                
                # Only include non-sensitive fields
                study_sets.append({
                    "id": str(doc['_id']),
                    "title": doc.get('title', ''),
                    "description": doc.get('description', ''),
                    "source": doc.get('source', 'manual'),
                    "cards_count": flashcards_count,
                    "created_at": created_at,
                    "updated_at": updated_at,
                    "tags": doc.get('tags', []),
                    "owner": getattr(request.user, 'username', 'User'),
                    "stats": {
                        "mastered": doc.get('stats', {}).get('mastered', 0)
                    }
                })
            
            logger.info(f"Found {len(study_sets)} study sets for user {user_id}")
            return Response(study_sets)
            
        except Exception as e:
            logger.error(f"Error fetching study sets: {str(e)}", exc_info=True)
            return Response(
                {'error': 'Error fetching study sets'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request):
        # Placeholder
        return Response({"message": "Study set create endpoint", "status": "success"}, status=status.HTTP_201_CREATED)

class StudySetDetailView(APIView):
    # Remove permission_classes restriction
    
    def get(self, request, id):
        # Get MongoDB connection
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Try to convert id to ObjectId
        try:
            obj_id = ObjectId(id)
        except Exception as e:
            return Response(
                {'error': f'Invalid ID format: {id}'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # For unauthenticated requests
        if not request.user.is_authenticated:
            # For unauthenticated requests, check if study set is public
            study_set = collection.find_one({
                '_id': obj_id,
                'is_public': True  # Only return publicly accessible study sets
            })
            
            if not study_set:
                # Return empty response for unauthenticated requests
                return Response({})
        else:
            # Get user ID - Firebase/MongoDB users have uid not id
            user_id = getattr(request.user, 'uid', None)
            if not user_id:
                user_id = getattr(request.user, 'id', None)
                
            if not user_id:
                return Response({})
                
            # Get the study set - include explicit user_id check for security
            study_set = collection.find_one({
                '_id': obj_id,
                'user_id': user_id  # Ensure only the owner can access
            })
            
            if not study_set:
                return Response(
                    {'error': 'Study set not found or you do not have permission to access it'},
                    status=status.HTTP_404_NOT_FOUND
                )
        
        # Get flashcards count
        flashcards_collection = get_collection('flashcards')
        flashcards_count = flashcards_collection.count_documents({'study_set_id': id})
        
        # Format the response - don't include sensitive data like file_path
        response_data = {
            "id": str(study_set['_id']),
            "title": study_set.get('title', ''),
            "description": study_set.get('description', ''),
            "subject": study_set.get('subject', ''),
            "source": study_set.get('source', 'manual'),
            "is_public": study_set.get('is_public', False),
            "cards_count": flashcards_count,
            "created_at": format_datetime(study_set.get('created_at', datetime.now())),
            "updated_at": format_datetime(study_set.get('updated_at', datetime.now())),
            "tags": study_set.get('tags', []),
            "owner": getattr(request.user, 'username', 'User'),
            "stats": study_set.get('stats', {'mastered': 0})
        }
        
        return Response(response_data)
    
    def put(self, request, id):
        # Get MongoDB connection
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Try to convert id to ObjectId
        try:
            obj_id = ObjectId(id)
        except:
            return Response(
                {'error': 'Invalid ID format'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get user ID - Firebase/MongoDB users have uid not id
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
        
        # Check if study set exists and belongs to user
        existing = collection.find_one({
            '_id': obj_id,
            'user_id': user_id
        })
        
        if not existing:
            return Response(
                {'error': 'Study set not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Update the study set
        update_data = {
            k: v for k, v in request.data.items() 
            if k in ['title', 'description', 'subject', 'is_public', 'tags']
        }
        
        # Always update the updated_at field
        update_data['updated_at'] = datetime.now()
        
        collection.update_one(
            {'_id': obj_id},
            {'$set': update_data}
        )
        
        # Return the updated study set
        updated = collection.find_one({'_id': obj_id})
        
        return Response({
            "id": str(updated['_id']),
            "title": updated.get('title', ''),
            "description": updated.get('description', ''),
            "subject": updated.get('subject', ''),
            "source": updated.get('source', 'manual'),
            "is_public": updated.get('is_public', False),
            "created_at": format_datetime(updated.get('created_at', datetime.now())),
            "updated_at": format_datetime(updated.get('updated_at', datetime.now())),
            "tags": updated.get('tags', []),
            "owner": getattr(request.user, 'username', 'User')
        })
    
    def delete(self, request, id):
        # Get MongoDB connection
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Try to convert id to ObjectId
        try:
            obj_id = ObjectId(id)
        except Exception as e:
            print(f"Error converting ID: {e}")
            return Response(
                {'error': f'Invalid ID format: {id}'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get user ID - Firebase/MongoDB users have uid not id
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
            
        # If still no user ID, return error
        if not user_id:
            return Response(
                {'error': 'Could not determine user ID'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Check if study set exists and belongs to user
        existing = collection.find_one({
            '_id': obj_id,
            'user_id': user_id
        })
        
        if not existing:
            return Response(
                {'error': f'Study set not found with ID: {id} or you do not have permission to delete it'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Get relevant information for logging and reference
        title = existing.get('title', '')
        description = existing.get('description', '')
        file_path = existing.get('file_path', '')
        source = existing.get('source', 'manual')
        
        # Check for preservePdf parameter - explicitly parse from query params
        # The client sends it as a URL parameter: ?preservePdf=true
        preserve_pdf_param = request.query_params.get('preservePdf', 'true')
        preserve_pdf = preserve_pdf_param.lower() in ['true', '1', 'yes']
        
        logger.info(f"----------- PDF DELETION DEBUG -----------")
        logger.info(f"Deleting study set: {title}, source: {source}, preserve PDF: {preserve_pdf}")
        logger.info(f"Original preservePdf parameter: {preserve_pdf_param}")
        logger.info(f"Query params: {request.query_params}")
        
        # Check if this is a PDF-based deck and log info
        is_pdf_deck = source == 'pdf'
        if is_pdf_deck and file_path:
            logger.info(f"This is a PDF-based deck with file path: {file_path}")
            logger.info(f"File exists before deletion: {os.path.exists(file_path)}")
        
        # Delete associated flashcards
        flashcards_collection = get_collection('flashcards')
        flashcards_deleted = flashcards_collection.delete_many({'study_set_id': str(obj_id)}).deleted_count
        logger.info(f"Deleted {flashcards_deleted} flashcards associated with study set {id}")
        
        # Handle PDF-based decks specially
        if is_pdf_deck and preserve_pdf:
            # If preservePdf=true, don't delete the MongoDB document - just mark it as preserved
            logger.info(f"Preserving PDF in MongoDB: {title}")
            
            # Update the MongoDB document to mark it as preserved
            collection.update_one(
                {'_id': obj_id},
                {'$set': {
                    'is_preserved': True,
                    'is_deck': False,  # This is no longer a deck, just a preserved PDF
                    'updated_at': datetime.now()
                }}
            )
            
            logger.info(f"Study set {id} marked as preserved PDF (not deleted)")
            
            # Return success - the document is preserved
            return Response(status=status.HTTP_204_NO_CONTENT)
        else:
            # For non-PDF decks or when preservePdf=false, delete the MongoDB document
            result = collection.delete_one({'_id': obj_id})
            
            if result.deleted_count == 0:
                logger.error(f"Failed to delete study set with ID: {id}")
                return Response(
                    {'error': f'Failed to delete study set with ID: {id}'},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            logger.info(f"Study set {id} document deleted from MongoDB")
            
            # Delete the file if it exists and we're not preserving PDFs
            if is_pdf_deck and file_path and os.path.exists(file_path) and not preserve_pdf:
                try:
                    logger.info(f"Deleting PDF file as requested: {file_path}")
                    os.remove(file_path)
                    logger.info(f"PDF file deleted successfully: {file_path}")
                except Exception as e:
                    logger.error(f"Error deleting PDF file: {e}")
                    # Continue with the deletion of the study set even if file deletion fails
            
            # Try to clean up any other associated resources through the cleanup endpoint
            try:
                # This is an internal call, so we make a separate API call to cleanup endpoint
                logger.info("Performing additional cleanup for associated resources")
                cleanup_associated_data_internal(
                    user_id=user_id,
                    item_id=id,
                    item_type='study_set',
                    include_flashcards=False,  # We already deleted flashcards above
                    include_pdf=not preserve_pdf  # Only delete PDF if not preserving
                )
            except Exception as e:
                logger.warning(f"Additional cleanup failed (non-critical): {e}")
            
            return Response(status=status.HTTP_204_NO_CONTENT)

# Helper function for internal cleanup calls
def cleanup_associated_data_internal(user_id, item_id, item_type='study_set', include_flashcards=True, include_pdf=False):
    """
    Internal helper function for cleanup operations that can be called directly from other views
    without making a separate API request.
    """
    logger.info(f"Internal cleanup for {item_type} ID: {item_id}, include_flashcards={include_flashcards}, include_pdf={include_pdf}")
    
    try:
        # Get MongoDB connection
        from foster.mongodb import get_collection
        study_sets = get_collection('study_sets')
        flashcards = get_collection('flashcards')
        
        # Find the item 
        try:
            obj_id = ObjectId(item_id)
            item = study_sets.find_one({
                '_id': obj_id,
                'user_id': user_id
            })
        except Exception as e:
            logger.error(f"Error finding item for cleanup: {e}")
            return False
            
        if not item:
            logger.warning(f"Item not found for cleanup: {item_id}")
            return False
        
        # Process cleanup based on item type
        cleanup_results = {
            'flashcards_deleted': 0,
            'pdf_deleted': False
        }
        
        # Delete associated flashcards if requested
        if include_flashcards:
            # Delete all flashcards associated with the study set
            result = flashcards.delete_many({'study_set_id': item_id})
            cleanup_results['flashcards_deleted'] = result.deleted_count
            logger.info(f"Deleted {result.deleted_count} flashcards for study set {item_id}")
        
        # Delete PDF file if requested
        if include_pdf and item.get('file_path'):
            file_path = item.get('file_path')
            
            # Validate file path for security
            if not validate_file_access(file_path, user_id):
                logger.warning(f"Security validation failed for file: {file_path}")
                return False
            
            # Check if file exists
            if os.path.exists(file_path):
                try:
                    # Delete the file
                    os.remove(file_path)
                    cleanup_results['pdf_deleted'] = True
                    logger.info(f"Deleted PDF file: {file_path}")
                except Exception as e:
                    logger.error(f"Error deleting file {file_path}: {e}")
            else:
                logger.warning(f"File not found: {file_path}")
        
        # Update record if it still exists (for preserving PDF)
        if item_type == 'study_set' and include_pdf is False:
            # Mark the study set as preserved (for PDFs we want to keep)
            study_sets.update_one(
                {'_id': obj_id},
                {'$set': {
                    'is_preserved': True,
                    'is_deck': False,
                    'updated_at': datetime.now()
                }}
            )
            cleanup_results['study_set_preserved'] = True
            logger.info(f"Marked study set {item_id} as preserved")
        
        return cleanup_results
    except Exception as e:
        logger.error(f"ERROR during internal cleanup: {str(e)}", exc_info=True)
        return False

class FlashcardListView(APIView):
    permission_classes = [IsAuthenticated]  # Changed back to IsAuthenticated
    
    def get(self, request, study_set_id):
        """
        Get all flashcards for a specific study set
        """
        try:
            # Get MongoDB connection
            from foster.mongodb import get_collection
            flashcards_collection = get_collection('flashcards')
            study_sets_collection = get_collection('study_sets')
            
            # Get user ID - Firebase/MongoDB users have uid not id
            user_id = getattr(request.user, 'uid', None)
            if not user_id:
                user_id = getattr(request.user, 'id', None)
            
            if not user_id:
                return Response(
                    {'error': 'Could not determine user ID'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # First check if the study set exists and belongs to the user
            try:
                if len(study_set_id) == 24:  # Likely a MongoDB ObjectId
                    obj_id = ObjectId(study_set_id)
                    study_set = study_sets_collection.find_one({
                        '_id': obj_id,
                        'user_id': user_id  # Ensure only the owner can access
                    })
                else:
                    # Direct ID match
                    study_set = study_sets_collection.find_one({
                        'id': study_set_id,
                        'user_id': user_id  # Ensure only the owner can access
                    })
                
                if not study_set:
                    return Response(
                        {'error': 'Study set not found or you do not have permission to access it'},
                        status=status.HTTP_404_NOT_FOUND
                    )
            except Exception as e:
                logger.error(f"Error finding study set: {e}")
                return Response(
                    {'error': f'Invalid study set ID format: {study_set_id}'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Find all flashcards for this study set
            flashcards = list(flashcards_collection.find({'study_set_id': study_set_id}))
            
            # Convert ObjectIds to strings and format dates for JSON serialization
            formatted_flashcards = []
            for card in flashcards:
                formatted_card = {
                    'id': str(card['_id']),
                    'question': card.get('question', ''),
                    'answer': card.get('answer', ''),
                    'difficulty': card.get('difficulty', 'Medium'),
                    'created_at': format_datetime(card.get('created_at', datetime.now())),
                    'updated_at': format_datetime(card.get('updated_at', datetime.now())),
                }
                formatted_flashcards.append(formatted_card)
            
            logger.info(f"Returning {len(formatted_flashcards)} flashcards for study set {study_set_id}")
            return Response(formatted_flashcards)
            
        except Exception as e:
            logger.error(f"Error fetching flashcards: {str(e)}", exc_info=True)
            return Response(
                {'error': f'Failed to fetch flashcards: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
    
    def post(self, request, study_set_id):
        # Placeholder
        return Response({"message": f"Flashcard create endpoint for study set ID: {study_set_id}"})

class FlashcardDetailView(APIView):
    permission_classes = [IsAuthenticated]  # Changed back to IsAuthenticated
    
    def get(self, request, study_set_id, id):
        # Placeholder
        return Response({"message": f"Flashcard detail endpoint for ID: {id} in study set ID: {study_set_id}"})
    
    def put(self, request, study_set_id, id):
        # Placeholder
        return Response({"message": f"Flashcard update endpoint for ID: {id} in study set ID: {study_set_id}"})
    
    def delete(self, request, study_set_id, id):
        """
        Delete a flashcard from a study set.
        """
        try:
            # Get MongoDB connection
            from foster.mongodb import get_collection
            flashcards_collection = get_collection('flashcards')
            study_sets_collection = get_collection('study_sets')
            
            # Get user ID - Firebase/MongoDB users have uid not id
            user_id = getattr(request.user, 'uid', None)
            if not user_id:
                user_id = getattr(request.user, 'id', None)
            
            if not user_id:
                return Response(
                    {'error': 'Could not determine user ID'},
                    status=status.HTTP_400_BAD_REQUEST
                )
                
            # First check if the study set exists and belongs to the user
            try:
                if len(study_set_id) == 24:  # Likely a MongoDB ObjectId
                    obj_id = ObjectId(study_set_id)
                    study_set = study_sets_collection.find_one({
                        '_id': obj_id,
                        'user_id': user_id  # Ensure only the owner can access
                    })
                else:
                    # Direct ID match
                    study_set = study_sets_collection.find_one({
                        'id': study_set_id,
                        'user_id': user_id  # Ensure only the owner can access
                    })
                
                if not study_set:
                    return Response(
                        {'error': 'Study set not found or you do not have permission to access it'},
                        status=status.HTTP_404_NOT_FOUND
                    )
            except Exception as e:
                logger.error(f"Error finding study set: {e}")
                return Response(
                    {'error': f'Invalid study set ID format: {study_set_id}'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Try to convert flashcard ID to ObjectId
            try:
                flashcard_id = ObjectId(id)
            except:
                try:
                    # If it's not a valid ObjectId, try to find by string ID
                    flashcard = flashcards_collection.find_one({
                        'id': id,
                        'study_set_id': study_set_id,
                        'user_id': user_id
                    })
                    
                    if flashcard:
                        flashcard_id = flashcard['_id']
                    else:
                        return Response(
                            {'error': f'Flashcard not found with ID: {id}'},
                            status=status.HTTP_404_NOT_FOUND
                        )
                except Exception as e:
                    logger.error(f"Error finding flashcard by string ID: {e}")
                    return Response(
                        {'error': f'Invalid flashcard ID format: {id}'},
                        status=status.HTTP_400_BAD_REQUEST
                    )
            
            # Delete the flashcard
            result = flashcards_collection.delete_one({
                '_id': flashcard_id,
                'study_set_id': study_set_id,
                'user_id': user_id  # Ensure only the owner can delete their flashcards
            })
            
            if result.deleted_count == 0:
                return Response(
                    {'error': f'Flashcard not found or you do not have permission to delete it'},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Update the study set stats if needed
            # (This is optional, as the stats can be recalculated when fetching the study set)
            
            logger.info(f"Deleted flashcard {id} from study set {study_set_id} for user {user_id}")
            return Response(status=status.HTTP_204_NO_CONTENT)
            
        except Exception as e:
            logger.error(f"Error deleting flashcard: {str(e)}", exc_info=True)
            return Response(
                {'error': f'Failed to delete flashcard: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class GenerateQuizView(APIView):
    permission_classes = [IsAuthenticated]  # Changed back to IsAuthenticated
    
    def post(self, request, study_set_id):
        # Placeholder
        return Response({"message": f"Generate quiz endpoint for study set ID: {study_set_id}"})

class QuizResultsView(APIView):
    permission_classes = [IsAuthenticated]  # Changed back to IsAuthenticated
    
    def post(self, request, study_set_id, quiz_id):
        # Placeholder
        return Response({"message": f"Quiz results endpoint for quiz ID: {quiz_id} in study set ID: {study_set_id}"})

class UserStatisticsView(APIView):
    # Remove permission_classes restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def get(self, request):
        # If user is not authenticated, return empty statistics
        if not request.user.is_authenticated:
            return Response({
                "total_study_sets": 0,
                "total_flashcards": 0,
                "sets_completed": 0,
                "mastery_level": "Not Started",
                "study_time": {
                    "last_week": {
                        "total_minutes": 0,
                        "daily": [0, 0, 0, 0, 0, 0, 0]
                    },
                    "this_month": 0
                },
                "performance": {
                    "average_score": 0,
                    "weakest_topics": [],
                    "strongest_topics": []
                }
            })
        
        # Return sample statistics data
        statistics = {
            "total_study_sets": 5,
            "total_flashcards": 120,
            "sets_completed": 2,
            "mastery_level": "Intermediate",
            "study_time": {
                "last_week": {
                    "total_minutes": 320,
                    "daily": [60, 45, 0, 75, 50, 30, 60]
                },
                "this_month": 1250
            },
            "performance": {
                "average_score": 85,
                "weakest_topics": ["Advanced Algorithms", "Neural Networks"],
                "strongest_topics": ["Basic Python", "Data Structures"]
            }
        }
        return Response(statistics)

class StudyProgressView(APIView):
    permission_classes = [IsAuthenticated]  # Changed back to IsAuthenticated
    
    def post(self, request, study_set_id):
        # Placeholder
        return Response({"message": f"Study progress update endpoint for study set ID: {study_set_id}"})

"""
Views for the StudyBuddy AI functionality.
"""

import os
from typing import List
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.conf import settings
from django.core.files.storage import FileSystemStorage

from ai.study_buddy_service.service import StudyBuddyService

# Initialize a shared StudyBuddy service for simple operations
# Note: For user-specific operations, initialize with user_id
storage_path = os.path.join(settings.MEDIA_ROOT, 'studybuddy')
study_buddy_service = StudyBuddyService(storage_path=storage_path, user_id=None)

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def upload_document(request):
    """
    Upload and process a PDF document.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Enhanced debugging for authentication issues
    print("DEBUG: Authentication Information:")
    print(f"Authorization header: {request.META.get('HTTP_AUTHORIZATION', 'Not present')}")
    print(f"Content-Type header: {request.META.get('CONTENT_TYPE', 'Not present')}")
    print(f"User authenticated: {request.user.is_authenticated}")
    print(f"User type: {type(request.user).__name__}")
    print(f"User ID: {getattr(request.user, 'id', 'No ID')}")
    print(f"User UID: {getattr(request.user, 'uid', 'No UID')}")
    
    # Check for file in request
    if 'file' not in request.FILES:
        print("No file found in request.FILES")
        print(f"Request POST data: {request.POST}")
        print(f"Request FILES keys: {list(request.FILES.keys()) if request.FILES else 'None'}")
        return Response(
            {'error': 'No file provided'},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Ensure user is authenticated
    if not request.user.is_authenticated:
        return Response(
            {'error': 'Authentication required'},
            status=status.HTTP_401_UNAUTHORIZED
        )
    
    # Get user ID - Firebase/MongoDB users have uid not id
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    print(f"User ID for upload: {user_id}")
        
    # If still no user ID, block the upload
    if not user_id:
        # For debugging - create a temporary development user ID
        # This should be removed in production
        if settings.DEBUG:
            print("WARNING: Using temporary debug user ID since authentication is failing")
            user_id = 'debug_user_temp'
        else:
            return Response(
                {'error': 'Could not determine user ID'},
                status=status.HTTP_400_BAD_REQUEST
            )

    file = request.FILES['file']
    print(f"Processing file: {file.name}")
    
    if not file.name.endswith('.pdf'):
        return Response(
            {'error': 'Only PDF files are supported'},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        # Generate a secure file path for the upload
        file_path = secure_file_path(user_id, file.name)
        print(f"File will be stored at: {file_path}")
        
        # Save the file to the secure path
        from django.core.files.storage import FileSystemStorage
        fs = FileSystemStorage(location=os.path.dirname(file_path))
        filename = fs.save(os.path.basename(file_path), file)
        full_file_path = fs.path(filename)
        
        # Initialize the service with the user's storage path
        user_storage_path = os.path.join(settings.MEDIA_ROOT, 'study_buddy', str(user_id))
        os.makedirs(user_storage_path, exist_ok=True)
        
        # Process the document with AI (if needed)
        try:
            # Copy file to user's documents directory
            import shutil
            documents_path = os.path.join(user_storage_path, 'documents')
            os.makedirs(documents_path, exist_ok=True)
            user_file_path = os.path.join(documents_path, os.path.basename(full_file_path))
            shutil.copy2(full_file_path, user_file_path)
            print(f"Copied document for AI processing: {user_file_path}")
            
            # Initialize AI with user_id
            service = StudyBuddyService(storage_path=user_storage_path, user_id=user_id)
            # Process document if needed
            # service.ai.load_and_process_pdfs()
        except Exception as e:
            print(f"Warning: AI processing failed (continuing anyway): {e}")
        
        # Skip AI processing for now
        # Just create a StudySet document in MongoDB
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Create document with proper date objects and user ID
        title = os.path.splitext(file.name)[0]  # Remove file extension to get title
        now = datetime.now()
        
        # Create document with proper date objects
        study_set_data = {
            'user_id': user_id,
            'title': title,
            'description': f"Uploaded PDF: {file.name}",
            'subject': "Study",
            'source': 'pdf',
            'is_public': False,
            'created_at': now,
            'updated_at': now,
            'file_path': full_file_path,  # Store the file path but don't expose it directly in API
            'stats': {
                'mastered': 0
            }
        }
        
        study_set_id = collection.insert_one(study_set_data).inserted_id
        print(f"Created study set with ID: {study_set_id}")

        # Return only necessary information (not the full path)
        return Response({
            'message': 'Document processed successfully',
            'filename': filename,
            'study_set_id': str(study_set_id)
        })
    except Exception as e:
        print(f"ERROR processing document: {str(e)}")
        import traceback
        traceback.print_exc()
        return Response({
            'error': f'Failed to process document: {str(e)}',
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def ask_question(request):
    """
    Ask a question about the processed documents.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
        
    question = request.data.get('question')
    if not question:
        return Response(
            {'error': 'No question provided'},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Get the document ID if provided
    document_id = request.data.get('documentId')
    
    try:
        # Import the necessary modules
        from ai.study_buddy_service.service import StudyBuddyService
        import os
        import glob
        
        # Get the user's storage path
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
        
        if not user_id:
            return Response(
                {'error': 'Could not determine user ID'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Initialize the service with the user's storage path
        user_storage_path = os.path.join(settings.MEDIA_ROOT, 'study_buddy', str(user_id))
        documents_path = os.path.join(user_storage_path, 'documents')
        vectordb_path = os.path.join(user_storage_path, 'vectordb')
        
        # Create necessary directories if they don't exist
        os.makedirs(user_storage_path, exist_ok=True)
        os.makedirs(documents_path, exist_ok=True)
        os.makedirs(vectordb_path, exist_ok=True)
        
        # Check if there are any PDF documents in the user's directory
        pdf_files = glob.glob(os.path.join(documents_path, '*.pdf'))
        
        if not pdf_files:
            # If document_id is provided, try to get the document from MongoDB and copy it
            if document_id:
                from foster.mongodb import get_collection
                from bson import ObjectId
                
                try:
                    collection = get_collection('study_sets')
                    study_set = collection.find_one({
                        '_id': ObjectId(document_id),
                        'user_id': user_id
                    })
                    
                    if study_set and 'file_path' in study_set:
                        file_path = study_set['file_path']
                        if os.path.exists(file_path):
                            # Copy the file to the user's documents directory
                            import shutil
                            dest_path = os.path.join(documents_path, os.path.basename(file_path))
                            shutil.copy2(file_path, dest_path)
                            print(f"Copied document from {file_path} to {dest_path}")
                            pdf_files = [dest_path]
                        else:
                            print(f"File path in database does not exist: {file_path}")
                except Exception as e:
                    print(f"Error fetching document from MongoDB: {e}")
            
            if not pdf_files:
                return Response({
                    'status': 'error',
                    'error': 'No documents available',
                    'answer': "I don't have any documents to work with. Please upload a PDF document first.",
                    'sources': []
                }, status=status.HTTP_400_BAD_REQUEST)
        
        # Initialize the service
        service = StudyBuddyService(storage_path=user_storage_path, user_id=user_id)
        
        # Check if vectorstore exists
        vectorstore_index_path = os.path.join(vectordb_path, 'index.faiss')
        vectorstore_exists = os.path.exists(vectorstore_index_path)
        
        if not vectorstore_exists:
            print(f"Vector database not found at {vectorstore_index_path}. Processing documents...")
            # Process the documents to create the vectorstore
            try:
                # Load and process the documents
                service.ai.pdf_directory = documents_path
                service.ai.db_path = vectordb_path
                service.ai.load_and_process_pdfs()
                print("Documents processed successfully")
            except Exception as e:
                print(f"Error processing documents: {e}")
                return Response({
                    'status': 'error',
                    'error': f'Failed to process documents: {str(e)}',
                    'answer': "I encountered an error while processing your documents. Please try uploading them again.",
                    'sources': []
                }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Load the vectorstore if it exists now
        try:
            service.ai.vectorstore = None  # Reset vectorstore to force reload
            service.ai.load_vectorstore()
        except Exception as e:
            print(f"Error loading vector database: {e}")
            return Response({
                'status': 'error',
                'error': f'Failed to load the vector database: {str(e)}',
                'answer': "I had trouble accessing the document database. Please try again or re-upload your documents.",
                'sources': []
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Set up the QA chain
        try:
            service.ai.setup_qa_chain()
        except Exception as e:
            print(f"Error setting up QA chain: {e}")
            return Response({
                'status': 'error',
                'error': f'Failed to set up the QA system: {str(e)}',
                'answer': "I couldn't initialize the question-answering system. Please try again later.",
                'sources': []
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        # Query the AI
        try:
            result = service.ai.query(question)
            return Response({
                'status': 'success',
                'answer': result['answer'],
                'sources': result['sources']
            })
        except Exception as e:
            print(f"Error querying AI: {e}")
            return Response({
                'status': 'error',
                'error': str(e),
                'answer': f"I'm sorry, I encountered an error while processing your question: {str(e)}",
                'sources': []
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        
        return Response({
            'status': 'error',
            'error': str(e),
            'answer': f"I'm sorry, I encountered an error while processing your question: {str(e)}",
            'sources': []
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def generate_flashcards(request):
    """
    Generate flashcards for a specific topic using the AdvancedStudyBuddyAI.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
        
    topic = request.data.get('topic')
    num_cards = request.data.get('numCards', 10)
    document_id = request.data.get('documentId')

    if not topic:
        return Response(
            {'error': 'No topic provided'},
            status=status.HTTP_400_BAD_REQUEST
        )
        
    # Get user ID
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Get MongoDB connection for documents
    from foster.mongodb import get_collection
    documents_collection = get_collection('study_sets')
    
    # Get document information
    document = documents_collection.find_one({
        '_id': ObjectId(document_id),
        'user_id': user_id  # Ensure only the owner can access
    })
    
    if not document:
        return Response(
            {'error': 'Document not found or you do not have permission to access it'},
            status=status.HTTP_404_NOT_FOUND
        )
    
    # Get the file path from the document
    file_path = document.get('file_path', '')
    
    try:
        # Set up directories for the AI
        user_storage_path = os.path.join(settings.MEDIA_ROOT, 'study_buddy', str(user_id))
        os.makedirs(user_storage_path, exist_ok=True)
    
        # Create a directory for the PDF if it doesn't exist
        document_dir = os.path.dirname(file_path)
        os.makedirs(document_dir, exist_ok=True)
        
        # Import and initialize the AI
        from ai.study_buddy_service.studyai import AdvancedStudyBuddyAI
        
        # Set up vector database path for this document
        db_path = os.path.join(user_storage_path, f"vectordb_{document_id}")
        
        # Initialize the AI with the document
        ai = AdvancedStudyBuddyAI(
            pdf_directory=document_dir,
            db_path=db_path,
            user_id=user_id
        )
        
        # Try to load existing vectorstore or process PDFs if needed
        try:
            ai.load_vectorstore()
        except FileNotFoundError:
            try:
                ai.load_and_process_pdfs()
            except Exception as e:
                logger.error(f"Error processing PDFs for vectorstore: {e}")
                return Response(
                    {'error': f'Could not process document: {e}'},
                    status=status.HTTP_503_SERVICE_UNAVAILABLE
                )
        
        # Use AI to generate flashcards
        num_cards = int(num_cards)
        relevant_chunks = ai.vectorstore.similarity_search(topic, k=6)
        combined_content = "\n\n".join([chunk.page_content for chunk in relevant_chunks])

        chunk_metadata = [
            {
                "source": chunk.metadata['source'],
                "page": chunk.metadata['page']
            } for chunk in relevant_chunks
        ]

        num_easy = max(1, int(num_cards * 0.1))
        num_medium = int(num_cards * 0.4)
        num_hard = num_cards - num_easy - num_medium

        flashcard_prompt = f"""
        Based on the following content about '{topic}', generate EXACTLY {num_cards} flashcards - NO MORE, NO FEWER.

        {combined_content}

        Create flashcards with the following distribution:
        - {num_easy} Easy flashcard(s)
        - {num_medium} Medium flashcards
        - {num_hard} Hard flashcards

        For each flashcard:
        1. The question should be clear and focused on an important concept from the content
        2. The answer should be comprehensive yet concise (NOT just "Easy", "Medium", or "Hard")
        3. Label it with the appropriate difficulty level (Easy, Medium, Hard)

        FORMAT INSTRUCTIONS (CRITICAL):
        You must return ONLY valid JSON. Your entire response must be a single, syntactically valid JSON object.
        Format the response as a valid JSON object with a 'flashcards' array containing EXACTLY {num_cards} flashcard objects.
        
        Each flashcard object MUST have these exact fields:
        - "question": A detailed question about the content
        - "answer": A comprehensive answer to the question (NOT just the difficulty level)
        - "difficulty": One of exactly these values: "Easy", "Medium", or "Hard"
        
        EXACT JSON STRUCTURE TO USE:
        {{
          "flashcards": [
            {{
              "question": "First question here?",
              "answer": "First detailed answer here - NOT just 'Easy', 'Medium', or 'Hard'",
              "difficulty": "Easy"
            }},
            {{
              "question": "Second question here?",
              "answer": "Second detailed answer here - NOT just 'Easy', 'Medium', or 'Hard'",
              "difficulty": "Medium"
            }},
            ... ({num_cards-2} more flashcards) ...
          ]
        }}

        CRITICAL REQUIREMENTS:
        1. You MUST generate EXACTLY {num_cards} flashcards - count them carefully
        2. The "answer" field MUST contain detailed explanations, NOT just difficulty labels
        3. The "difficulty" field must be EXACTLY one of: "Easy", "Medium", or "Hard"
        4. Enclose all strings and keys in double quotes
        5. Always include commas between objects in the array
        6. Make sure opening and closing braces match correctly
        7. Do not include any text before or after the JSON
        8. No trailing commas after the last item
        9. The response must parse as valid JSON
        """

        # Get flashcards directly from the LLM
        try:
            # Check available memory before running the LLM
            try:
                import psutil
                available_memory_gb = psutil.virtual_memory().available / (1024 * 1024 * 1024)
                logger.info(f"Available memory before LLM call: {available_memory_gb:.2f} GB")
                
                # Warn if memory is low
                if available_memory_gb < 4:
                    logger.warning(f"Low memory available ({available_memory_gb:.2f} GB). May cause issues with LLM.")
                    
                    # If extremely low memory, reduce the request
                    if available_memory_gb < 2 and num_cards > 5:
                        original_num_cards = num_cards
                        num_cards = 5  # Reduce to minimum
                        logger.warning(f"Reducing request from {original_num_cards} to {num_cards} cards due to low memory")
            except ImportError:
                logger.warning("psutil not available, skipping memory check")
            except Exception as mem_error:
                logger.warning(f"Error checking memory: {str(mem_error)}")

            # Set up a background job for generating flashcards
            import threading
            import uuid
            import asyncio
            from foster.mongodb import get_collection
            
            # Generate a unique job ID
            job_id = str(uuid.uuid4())
            
            # Store job in MongoDB
            jobs_collection = get_collection('flashcard_jobs')

            # Get Firebase UID if available
            firebase_uid = None
            users_collection = get_collection('users')
            user = users_collection.find_one({'_id': ObjectId(user_id) if len(user_id) == 24 else None})
            if user and 'firebase_uid' in user:
                firebase_uid = user['firebase_uid']
                logger.info(f"Found Firebase UID {firebase_uid} for user {user_id}")

            jobs_collection.insert_one({
                'job_id': job_id,
                'user_id': user_id,
                'firebase_uid': firebase_uid,  # Store Firebase UID as well if available
                'document_id': document_id,
                'topic': topic,
                'num_cards': num_cards,
                'status': 'processing',
                'created_at': datetime.now(),
                'updated_at': datetime.now(),
            })
            
            # Define the background task function
            def generate_flashcards_task(job_id, ai, topic, num_cards, chunk_metadata):
                # Import and initialize database collection outside the try block
                from foster.mongodb import get_collection
                jobs_collection = get_collection('flashcard_jobs')
                
                try:
                    logger.info(f"Starting background generation for job {job_id}")
                    
                    # Generate flashcards without timeout
                    response = ai.llm.invoke(flashcard_prompt)
                    
                    try:
                        import json
                        import re
                        
                        # Define a function to extract complete JSON
                        def extract_complete_json(text):
                            """Extract a complete, properly nested JSON object from text"""
                            start_idx = text.find('{')
                            if start_idx == -1:
                                return None  # No JSON object found
                                
                            # Track nesting level of braces
                            level = 0
                            in_string = False
                            escape_next = False
                            
                            for i in range(start_idx, len(text)):
                                char = text[i]
                                
                                # Handle string detection (with escape character support)
                                if char == '\\' and not escape_next:
                                    escape_next = True
                                    continue
                                
                                if char == '"' and not escape_next:
                                    in_string = not in_string
                                
                                escape_next = False
                                
                                # Only count braces when not in a string
                                if not in_string:
                                    if char == '{':
                                        level += 1
                                    elif char == '}':
                                        level -= 1
                                        
                                    # If we've closed all open braces, we found the complete JSON
                                    if level == 0 and i > start_idx:
                                        return text[start_idx:i+1]
                            
                            # If we exit the loop without finding the end, JSON is incomplete
                            return None
                        
                        # Log full original response for debugging
                        logger.info(f"=== FULL LLM RESPONSE FOR JOB {job_id} ===")
                        logger.info(response)
                        logger.info(f"=== END FULL RESPONSE ===")
                        
                        # First try to extract a complete JSON object
                        cleaned_response = extract_complete_json(response)
                        
                        if cleaned_response:
                            logger.info(f"=== EXTRACTED COMPLETE JSON ===")
                            logger.info(cleaned_response)
                            logger.info(f"=== END EXTRACTED COMPLETE JSON ===")
                        else:
                            # Fallback to old method if new extraction fails
                            json_match = re.search(r'(\{|\[).*?(\}|\])', response, re.DOTALL)
                            if json_match:
                                cleaned_response = json_match.group(0)
                                logger.info(f"=== EXTRACTED JSON PORTION (FALLBACK METHOD) ===")
                                logger.info(cleaned_response)
                                logger.info(f"=== END EXTRACTED JSON ===")
                            else:
                                # If no valid JSON found, try to use the full response
                                cleaned_response = response
                                logger.info(f"=== NO JSON STRUCTURE DETECTED ===")
                        
                        flashcards = []
                        
                        # Step 1: Try direct JSON parsing
                        try:
                            parsed_data = json.loads(cleaned_response)
                            
                            # Check if the parsed JSON has flashcards key
                            if isinstance(parsed_data, dict) and 'flashcards' in parsed_data:
                                if isinstance(parsed_data['flashcards'], list):
                                    flashcards = parsed_data['flashcards']
                                    logger.info(f"Successfully parsed JSON with {len(flashcards)} flashcards")
                                    
                                    # Check for swapped answer and difficulty fields
                                    valid_difficulties = ["Easy", "Medium", "Hard"]
                                    for i, card in enumerate(flashcards):
                                        # Fix swapped fields if detected
                                        if (card.get('answer') in valid_difficulties and 
                                            card.get('difficulty') not in valid_difficulties):
                                            logger.warning(f"Card {i+1} has swapped answer and difficulty fields. Fixing...")
                                            # Swap the fields
                                            temp = card.get('answer')
                                            card['answer'] = card.get('difficulty', "This field was missing")
                                            card['difficulty'] = temp
                                            logger.info(f"Fixed card {i+1} - Answer: {card['answer'][:30]}..., Difficulty: {card['difficulty']}")
                                        
                                        # Ensure difficulty is valid
                                        if card.get('difficulty') not in valid_difficulties:
                                            logger.warning(f"Card {i+1} has invalid difficulty: {card.get('difficulty')}. Setting to Medium.")
                                            card['difficulty'] = "Medium"
                                    
                                    # Validate that we have the correct number of flashcards
                                    if len(flashcards) != num_cards:
                                        logger.warning(f"Expected {num_cards} flashcards but found {len(flashcards)}")
                                        
                                        # Add placeholder cards if we don't have enough
                                        if len(flashcards) < num_cards:
                                            cards_to_add = num_cards - len(flashcards)
                                            logger.info(f"Adding {cards_to_add} placeholder flashcards")
                                            
                                            difficulties = ["Easy", "Medium", "Hard"]
                                            for i in range(cards_to_add):
                                                difficulty = difficulties[i % 3]
                                                placeholder_card = {
                                                    "question": f"Additional question about {topic} #{i+1}?",
                                                    "answer": f"This is a generated placeholder answer about {topic} because the AI produced fewer cards than requested.",
                                                    "difficulty": difficulty
                                                }
                                                flashcards.append(placeholder_card)
                                                
                                            logger.info(f"Added placeholder cards. Now have {len(flashcards)} cards total.")
                                        
                                        # If we have too many, trim the excess
                                        elif len(flashcards) > num_cards:
                                            logger.info(f"Trimming excess flashcards from {len(flashcards)} to {num_cards}")
                                            flashcards = flashcards[:num_cards]
                                else:
                                    logger.warning(f"'flashcards' key does not contain a list: {type(parsed_data['flashcards'])}")
                            else:
                                logger.warning("Parsed JSON doesn't have the expected 'flashcards' key")
                        except json.JSONDecodeError as e:
                            logger.info(f"Initial JSON parsing failed: {str(e)}")
                            
                            # Step 2: If direct parsing fails, try to extract individual flashcard objects
                            if "question" in response and "answer" in response and "difficulty" in response:
                                logger.info("Attempting direct flashcard extraction from full response")
                                # Use regex to find all flashcard objects
                                flashcard_objects = re.findall(r'\{\s*"question".*?"difficulty":.*?\}', response, re.DOTALL)
                                
                                if flashcard_objects:
                                    logger.info(f"Found {len(flashcard_objects)} flashcard objects directly in response")
                                    # Try to parse each flashcard object
                                    for card_json in flashcard_objects:
                                        try:
                                            # Fix common JSON issues in the individual card
                                            fixed_card = card_json.strip()
                                            card = json.loads(fixed_card)
                                            if all(k in card for k in ["question", "answer", "difficulty"]):
                                                flashcards.append(card)
                                                logger.info(f"Successfully extracted flashcard: {card['question'][:30]}...")
                                        except Exception as card_error:
                                            logger.warning(f"Error parsing flashcard: {str(card_error)}")
                                    
                            # Step 3: If still no flashcards, try field-by-field extraction
                            if not flashcards:
                                # Extract individual fields directly as a last resort
                                questions = re.findall(r'"question"\s*:\s*"([^"]+)"', cleaned_response)
                                answers = re.findall(r'"answer"\s*:\s*"([^"]+)"', cleaned_response)
                                difficulties = re.findall(r'"difficulty"\s*:\s*"([^"]+)"', cleaned_response)
                                
                                if questions and answers and len(questions) == len(answers):
                                    # We found matching questions and answers, create our own structure
                                    logger.info(f"Creating manual flashcard structure with {len(questions)} cards")
                                    for i in range(len(questions)):
                                        card = {
                                            "question": questions[i],
                                            "answer": answers[i],
                                            "difficulty": difficulties[i] if i < len(difficulties) else "Medium"
                                        }
                                        flashcards.append(card)
                        
                        # If all methods failed, return a default error flashcard
                        if not flashcards:
                            logger.error(f"Failed to extract any valid flashcards from LLM response")
                            flashcards = [{
                                "question": "Error extracting flashcards",
                                "answer": "The system encountered an error generating flashcards. Please try again with a different topic or document.",
                                "difficulty": "Easy"
                            }]

                        # Here's where we need to save flashcards to MongoDB for the user's study set
                        # Get MongoDB connection
                        from foster.mongodb import get_collection
                        flashcards_collection = get_collection('flashcards')
                        jobs_collection = get_collection('flashcard_jobs')
                        
                        # Update job with completed status and flashcards
                        jobs_collection.update_one(
                            {'job_id': job_id},
                            {
                                '$set': {
                                    'status': 'completed',
                                    'flashcards': flashcards,
                                    'updated_at': datetime.now()
                                }
                            }
                        )
                        
                        # Save flashcards to MongoDB with proper relationships and convert to frontend format
                        saved_flashcards = []
                        for card in flashcards:
                            # Save to database
                            flashcard_data = {
                                'study_set_id': document_id,  # Link to study set
                                'user_id': user_id,  # Link to user
                                'question': card['question'], 
                                'answer': card['answer'],
                                'difficulty': card['difficulty'],
                                'created_at': datetime.now(),
                                'updated_at': datetime.now()
                            }
                            result = flashcards_collection.insert_one(flashcard_data)
                            
                            # Convert to frontend format with the correct field names
                            card_with_id = {
                                'id': str(result.inserted_id),
                                'question': card['question'],  # Frontend expects these original field names
                                'answer': card['answer'],      # to map them later
                                'difficulty': card['difficulty'],
                                'metadata': card.get('metadata', {})
                            }
                            saved_flashcards.append(card_with_id)
                            
                        # Replace original flashcards list with frontend-compatible version
                        flashcards = saved_flashcards
                            
                        logger.info(f"Saved {len(flashcards)} flashcards to MongoDB for study set {document_id} and user {user_id}")
                        
                        # Send WebSocket notification for job completion
                        try:
                            # Import the helper function for sending notifications
                            from study.consumers import send_flashcard_notification
                            import asyncio
                            
                            # Create notification data with all information needed by frontend
                            notification_data = {
                                'job_id': job_id,
                                'status': 'completed',
                                'flashcards': flashcards,
                                'document_id': document_id,
                                'timestamp': datetime.now().isoformat(),
                                'study_set_id': document_id,  # Same as document_id for consistency
                                'title': f"{topic} Flashcards",  # Include topic in title
                                'description': f"AI-generated flashcards about {topic}"  # Add description
                            }
                            
                            # Run the async notification function
                            asyncio.run(send_flashcard_notification(
                                user_id=user_id,
                                notification_type='job_completed',
                                data=notification_data
                            ))
                            logger.info(f"WebSocket notification sent successfully for job {job_id} completion")
                        except Exception as ws_error:
                            logger.error(f"Failed to send WebSocket notification for job {job_id}: {str(ws_error)}")
                            
                        return flashcards
                        
                    except Exception as e:
                        logger.error(f"Error processing flashcards: {str(e)}")
                        import traceback
                        logger.error(traceback.format_exc())
                        # Return at least one flashcard as fallback
                        return [{
                            "question": "Error processing response",
                            "answer": f"An error occurred: {str(e)}",
                            "difficulty": "Easy"
                        }]
                        
                except Exception as e:
                    logger.error(f"Error generating flashcards in background task for job {job_id}: {str(e)}")
                    import traceback
                    logger.error(traceback.format_exc())
                    
                    # Update job with error
                    jobs_collection.update_one(
                        {'job_id': job_id},
                        {
                            '$set': {
                                'status': 'failed',
                                'error': str(e),
                                'error_details': traceback.format_exc(),
                                'updated_at': datetime.now()
                            }
                        }
                    )
                    
                    # Send WebSocket notification for error
                    try:
                        # Import the helper function for sending notifications
                        from study.consumers import send_flashcard_notification
                        import asyncio
                        
                        # Create notification data
                        notification_data = {
                            'job_id': job_id,
                            'status': 'failed',
                            'error': str(e),
                            'error_details': traceback.format_exc(),
                            'timestamp': datetime.now().isoformat()
                        }
                        
                        # Run the async notification function
                        asyncio.run(send_flashcard_notification(
                            user_id=user_id,
                            notification_type='job_failed',
                            data=notification_data
                        ))
                        logger.info(f"WebSocket notification sent successfully for job {job_id} failure")
                    except Exception as ws_error:
                        logger.error(f"Failed to send WebSocket notification for job {job_id}: {str(ws_error)}")
                    return None
            
            # Start background thread
            thread = threading.Thread(
                target=generate_flashcards_task,
                args=(job_id, ai, topic, num_cards, chunk_metadata)
            )
            thread.daemon = True  # Allow the thread to be terminated when the main process exits
            thread.start()
            
            # Return job ID immediately
            return Response({
                'status': 'processing',
                'job_id': job_id,
                'message': 'Flashcard generation started. You will be notified when complete.',
                'useWebSocket': True  # Signal to the frontend to use WebSockets instead of polling
            })
            
        except Exception as e:
            logger.error(f"Error initiating flashcard generation: {str(e)}\n{traceback.format_exc()}")
            
            return Response(
                {
                    'error': 'Unable to start flashcard generation process',
                    'status': 'error',
                    'details': str(e)
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE
            )
    except Exception as e:
        logger.error(f"Error generating flashcards: {str(e)}\n{traceback.format_exc()}")
        
        return Response(
            {
                'error': 'Unable to generate flashcards',
                'status': 'error',
                'details': str(e)
            },
            status=status.HTTP_503_SERVICE_UNAVAILABLE
        )

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def generate_exam(request):
    """
    Generate an exam based on document content.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
        
    start_page = request.data.get('start_page')
    end_page = request.data.get('end_page')
    num_questions = request.data.get('num_questions', 10)
    question_types = request.data.get('question_types', ['multiple choice'])
    document_id = request.data.get('documentId')

    if not all([start_page, end_page]):
        return Response(
            {'error': 'Missing required parameters'},
            status=status.HTTP_400_BAD_REQUEST
        )
        
    # Get user ID
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Initialize the service with the user's storage path
    user_storage_path = os.path.join(settings.MEDIA_ROOT, 'study_buddy', str(user_id))
    
    # Create user directory if it doesn't exist
    os.makedirs(user_storage_path, exist_ok=True)
    
    
    # Initialize the service with user_id
    service = StudyBuddyService(storage_path=user_storage_path, user_id=user_id)

    # Return placeholder exam
    questions = [
        {
            "question": f"Question {i} from pages {start_page}-{end_page}",
            "type": question_types[0],
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "answer": "Option A"
        }
        for i in range(1, int(num_questions) + 1)
    ]
    
    return Response({
        'status': 'success',
        'exam': questions,
        'exam_id': 'placeholder_exam_id'
    })

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def grade_exam(request):
    """
    Grade a completed exam.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
        
    exam_id = request.data.get('exam_id')
    user_answers = request.data.get('answers', [])

    if not exam_id or not user_answers:
        return Response(
            {'error': 'Missing required parameters (exam_id or answers)'},
            status=status.HTTP_400_BAD_REQUEST
        )
        
    # Get user ID
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Initialize the service with the user's storage path
    user_storage_path = os.path.join(settings.MEDIA_ROOT, 'study_buddy', str(user_id))
    
    # Create user directory if it doesn't exist
    os.makedirs(user_storage_path, exist_ok=True)
    
    # Initialize the service with user_id
    service = StudyBuddyService(storage_path=user_storage_path, user_id=user_id)

    # Return placeholder exam results
    num_correct = len([1 for i in range(len(user_answers)) if i % 2 == 0])  # Every even question is correct
    percentage_score = (num_correct / len(user_answers)) * 100 if user_answers else 0
    
    return Response({
        'status': 'success',
        'correct_answers': num_correct,
        'total_questions': len(user_answers),
        'score': percentage_score,
        'feedback': [
            {
                'question_number': i + 1,
                'is_correct': i % 2 == 0,
                'feedback': "Correct answer!" if i % 2 == 0 else "Your answer was incorrect."
            }
            for i in range(len(user_answers))
        ]
    }) 

@csrf_exempt
@api_view(['GET', 'OPTIONS'])
@permission_classes([])  # Explicitly allow unauthenticated access
def get_documents(request):
    """
    Get all PDF documents uploaded by the current user.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Get user ID - attempt to get from authenticated user
    user_id = None
    if hasattr(request, 'user') and request.user and request.user.is_authenticated:
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
    
    # If no authenticated user but coming from Flashcards, return empty array gracefully
    if not user_id:
        print("No authenticated user for /documents/ endpoint, returning empty list")
        return Response([])
    
    try:
        # Get MongoDB connection
        from foster.mongodb import get_collection
        study_sets = get_collection('study_sets')
        
        # Query for all PDF documents from study sets, including both active decks and preserved PDFs
        documents_query = {
            'user_id': user_id,
            'source': 'pdf'
        }
        
        documents = list(study_sets.find(documents_query))
        
        print(f"Found {len(documents)} PDF documents in MongoDB for user {user_id}")
        
        # Transform documents for API response
        result = []
        for doc in documents:
            # For each document, determine if it's an active deck or preserved PDF
            is_preserved = doc.get('is_preserved', False)
            is_deck = doc.get('is_deck', True)  # Default to true for backward compatibility
            
            result.append({
                'id': str(doc['_id']),
                'title': doc.get('title', ''),
                'filename': doc.get('filename', ''),
                'description': doc.get('description', ''),
                'uploadDate': format_datetime(doc.get('created_at', '')),
                'fileType': 'pdf',
                'userId': doc.get('user_id', ''),
                'processingStatus': 'completed',
                'isPersistent': is_preserved or not is_deck,  # Mark as persistent if it's preserved or not a deck
                'isPreserved': is_preserved,  # Explicitly indicate if it was preserved from a deleted deck
                'stats': doc.get('stats', {}),
                'file_path': doc.get('file_path', '')  # Include file path for backend use
            })
            
        return Response(result)
    except Exception as e:
        print(f"ERROR retrieving documents: {str(e)}")
        import traceback
        traceback.print_exc()
        return Response(
            {'error': f'Failed to retrieve documents: {str(e)}'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@csrf_exempt
@api_view(['GET', 'DELETE', 'OPTIONS'])
@permission_classes([])  # Explicitly allow unauthenticated access
def get_document_by_id(request, document_id):
    """
    Get or delete a specific document by ID.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Get user ID - attempt to get from authenticated user
    user_id = None
    if hasattr(request, 'user') and request.user and request.user.is_authenticated:
        user_id = getattr(request.user, 'uid', None)
        if not user_id:
            user_id = getattr(request.user, 'id', None)
    
    # For DELETE requests, we must have a valid user ID
    if request.method == 'DELETE' and not user_id:
        return Response(
            {'error': 'Authentication required to delete documents'},
            status=status.HTTP_401_UNAUTHORIZED
        )
    
    try:
        # Get MongoDB connection
        from foster.mongodb import get_collection
        from bson import ObjectId
        
        study_sets = get_collection('study_sets')
        
        # For GET requests without authentication, try to get publicly available document
        if not user_id and request.method == 'GET':
            doc = study_sets.find_one({
                '_id': ObjectId(document_id),
                'is_public': True  # Only return publicly accessible documents
            })
        else:
            # For authenticated requests, check user ownership
            doc = study_sets.find_one({
                '_id': ObjectId(document_id),
                'user_id': user_id  # Ensure only the owner can access
            })
        
        if not doc:
            if request.method == 'GET' and not user_id:
                # For unauthenticated GET requests, return empty response
                return Response({})
            else:
                return Response(
                    {'error': 'Document not found or you do not have permission to access it'},
                    status=status.HTTP_404_NOT_FOUND
                )
        
        # For DELETE request
        if request.method == 'DELETE':
            # Delete the document
            study_sets.delete_one({'_id': ObjectId(document_id)})
            
            # TODO: Clean up associated files if needed
            
            return Response({'message': 'Document deleted successfully'})
        
        # For GET request
        document = {
            'id': str(doc['_id']),
            'title': doc.get('title', ''),
            'filename': doc.get('filename', ''),
            'description': doc.get('description', ''),
            'uploadDate': doc.get('created_at', ''),
            'fileType': 'pdf',
            'userId': doc.get('user_id', ''),
            'processingStatus': 'completed',
            'stats': doc.get('stats', {})
        }
        
        return Response(document)
    except Exception as e:
        print(f"ERROR processing document: {str(e)}")
        import traceback
        traceback.print_exc()
        return Response(
            {'error': f'Failed to process document: {str(e)}'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        ) 

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def create_study_set_from_pdf(request):
    """
    Create a new study set from an existing PDF file.
    This is used when we want to create a new deck from a preserved PDF
    whose study set was previously deleted with preservePdf=true.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Extract request data
    pdf_id = request.data.get('pdf_id')
    title = request.data.get('title')
    
    # Validate request data
    if not pdf_id:
        return Response(
            {'error': 'pdf_id must be provided'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Get user ID - Firebase/MongoDB users have uid not id
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    print(f"User ID for creating study set from PDF: {user_id}")
    
    # If still no user ID, block the operation
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        # Get MongoDB connection
        from foster.mongodb import get_collection
        collection = get_collection('study_sets')
        
        # Try to get the preserved PDF document
        try:
            obj_id = ObjectId(pdf_id)
            pdf_doc = collection.find_one({
                '_id': obj_id,
                'user_id': user_id,
                'source': 'pdf'
            })
        except Exception as e:
            print(f"Error searching for PDF: {e}")
            return Response(
                {'error': f'Invalid PDF ID format: {pdf_id}'},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        if not pdf_doc:
            return Response(
                {'error': f'PDF document not found or you do not have permission to access it'},
                status=status.HTTP_404_NOT_FOUND
            )
            
        # Extract information from the PDF document
        file_path = pdf_doc.get('file_path', '')
        if not file_path or not os.path.exists(file_path):
            return Response(
                {'error': f'PDF file not found at path: {file_path}'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Use the PDF document's title if not provided
        if not title:
            title = pdf_doc.get('title', os.path.splitext(os.path.basename(file_path))[0])
        
        # Create a new study set document based on the preserved PDF
        now = datetime.now()
        
        study_set_data = {
            'user_id': user_id,
            'title': title,
            'description': pdf_doc.get('description', f"Created from preserved PDF: {os.path.basename(file_path)}"),
            'subject': pdf_doc.get('subject', "Study"),
            'source': 'pdf',
            'is_public': False,
            'is_preserved': False,
            'is_deck': True,  # This is now an active deck
            'created_at': now,
            'updated_at': now,
            'file_path': file_path,  # Reuse the same file path
            'stats': {
                'mastered': 0
            }
        }
        
        study_set_id = collection.insert_one(study_set_data).inserted_id
        print(f"Created study set with ID: {study_set_id}")
        
        # Return the new study set information
        return Response({
            'message': 'Study set created successfully from preserved PDF',
            'id': str(study_set_id),
            'title': title,
            'description': study_set_data['description'],
            'file_path': file_path
        })
    except Exception as e:
        print(f"ERROR creating study set from PDF: {str(e)}")
        import traceback
        traceback.print_exc()
        return Response({
            'error': f'Failed to create study set from PDF: {str(e)}',
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['POST', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def cleanup_associated_data(request):
    """
    Cleanup associated data when a PDF or study set is deleted.
    This endpoint handles removal of:
    - Flashcards associated with a study set
    - PDF files associated with a study set (if specified)
    - Any other associated resources
    
    Request body should include:
    - id: The ID of the study set or document
    - type: Either 'study_set' or 'document' to specify what's being cleaned up
    - include_flashcards: Boolean to indicate if flashcards should be deleted
    - include_pdf: Boolean to indicate if PDF file should be deleted
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Extract request data
    item_id = request.data.get('id')
    item_type = request.data.get('type', 'study_set')
    include_flashcards = request.data.get('include_flashcards', True)
    include_pdf = request.data.get('include_pdf', False)
    
    # Validate request data
    if not item_id:
        return Response(
            {'error': 'id must be provided'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # Get user ID - Firebase/MongoDB users have uid not id
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    logger.info(f"Cleanup request for {item_type} ID: {item_id} by user: {user_id}")
    logger.info(f"Cleanup options: include_flashcards={include_flashcards}, include_pdf={include_pdf}")
    
    # If still no user ID, block the operation
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        # Get MongoDB connection
        from foster.mongodb import get_collection
        study_sets = get_collection('study_sets')
        flashcards = get_collection('flashcards')
        
        # Find the item to ensure it belongs to the user
        try:
            obj_id = ObjectId(item_id)
            item = study_sets.find_one({
                '_id': obj_id,
                'user_id': user_id
            })
        except Exception as e:
            logger.error(f"Error finding item: {e}")
            return Response(
                {'error': f'Invalid ID format: {item_id}'},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        if not item:
            return Response(
                {'error': f'Item not found or you do not have permission to access it'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Process cleanup based on item type
        cleanup_results = {
            'flashcards_deleted': 0,
            'pdf_deleted': False
        }
        
        # Delete associated flashcards if requested
        if include_flashcards:
            # Delete all flashcards associated with the study set
            result = flashcards.delete_many({'study_set_id': item_id})
            cleanup_results['flashcards_deleted'] = result.deleted_count
            logger.info(f"Deleted {result.deleted_count} flashcards for study set {item_id}")
        
        # Delete PDF file if requested
        if include_pdf and item.get('file_path'):
            file_path = item.get('file_path')
            
            # Validate file path for security
            if not validate_file_access(file_path, user_id):
                logger.warning(f"Security validation failed for file: {file_path}")
                return Response(
                    {'error': 'Security validation failed for file path'},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # Check if file exists
            if os.path.exists(file_path):
                try:
                    # Delete the file
                    os.remove(file_path)
                    cleanup_results['pdf_deleted'] = True
                    logger.info(f"Deleted PDF file: {file_path}")
                except Exception as e:
                    logger.error(f"Error deleting file {file_path}: {e}")
            else:
                logger.warning(f"File not found: {file_path}")
        
        # Update record if it still exists (for preserving PDF)
        if item_type == 'study_set' and include_pdf is False:
            # Mark the study set as preserved (for PDFs we want to keep)
            study_sets.update_one(
                {'_id': obj_id},
                {'$set': {
                    'is_preserved': True,
                    'is_deck': False,
                    'updated_at': datetime.now()
                }}
            )
            cleanup_results['study_set_preserved'] = True
            logger.info(f"Marked study set {item_id} as preserved")
        
        # Return cleanup results
        return Response({
            'message': 'Cleanup completed successfully',
            'results': cleanup_results
        })
    except Exception as e:
        logger.error(f"ERROR during cleanup: {str(e)}", exc_info=True)
        return Response({
            'error': f'Failed to complete cleanup: {str(e)}',
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@csrf_exempt
@api_view(['GET', 'OPTIONS'])
@permission_classes([IsAuthenticated])
def check_flashcard_job_status(request, job_id):
    """
    Check the status of an asynchronous flashcard generation job.
    Returns the current status, and flashcards if the job has completed.
    """
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return Response(status=status.HTTP_200_OK)
    
    # Get user ID
    user_id = getattr(request.user, 'uid', None)
    if not user_id:
        user_id = getattr(request.user, 'id', None)
    
    if not user_id:
        return Response(
            {'error': 'Could not determine user ID'},
            status=status.HTTP_400_BAD_REQUEST
        )
    
    try:
        # Get job from MongoDB
        from foster.mongodb import get_collection
        jobs_collection = get_collection('flashcard_jobs')
        
        # Find job - first try with the user ID
        job = jobs_collection.find_one({
            'job_id': job_id,
            'user_id': user_id
        })
        
        # If not found, check if this is a Firebase UID and try that way
        if not job:
            # Check if this user ID is a Firebase UID and try to find jobs that way
            job = jobs_collection.find_one({
                'job_id': job_id,
                'firebase_uid': user_id
            })
            
            if job:
                logger.info(f"Found job {job_id} using Firebase UID {user_id}")
            else:
                # If still not found, try to get Firebase UID from MongoDB user_id
                users_collection = get_collection('users')
                if len(user_id) == 24:  # Likely a MongoDB ObjectId
                    try:
                        user = users_collection.find_one({'_id': ObjectId(user_id)})
                        if user and 'firebase_uid' in user:
                            firebase_uid = user['firebase_uid']
                            # Try with Firebase UID
                            job = jobs_collection.find_one({
                                'job_id': job_id,
                                'user_id': firebase_uid
                            })
                            if job:
                                logger.info(f"Found job {job_id} by looking up Firebase UID {firebase_uid} from MongoDB ID {user_id}")
                    except Exception as e:
                        logger.error(f"Error looking up user by MongoDB ID: {str(e)}")
                else:  # Might be a Firebase UID
                    try:
                        user = users_collection.find_one({'firebase_uid': user_id})
                        if user:
                            mongo_id = str(user['_id'])
                            # Try with MongoDB ID
                            job = jobs_collection.find_one({
                                'job_id': job_id,
                                'user_id': mongo_id
                            })
                            if job:
                                logger.info(f"Found job {job_id} by looking up MongoDB ID {mongo_id} from Firebase UID {user_id}")
                    except Exception as e:
                        logger.error(f"Error looking up user by Firebase UID: {str(e)}")
        
        if not job:
            # If we have an error status already stored, return that
            error_job = jobs_collection.find_one({
                'job_id': job_id,
                'status': 'failed'
            })
            
            if error_job:
                logger.warning(f"Returning failed job status for job {job_id}: {error_job.get('error', 'Unknown error')}")
                return Response({
                    'job_id': job_id,
                    'status': 'failed',
                    'error': error_job.get('error', 'Unknown error')
                })
            
            return Response(
                {'error': 'Job not found or you do not have permission to access it'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Extract status and times
        job_status = job.get('status', 'unknown')
        created_at = job.get('created_at', datetime.now())
        updated_at = job.get('updated_at', datetime.now())
        
        # Calculate elapsed time in seconds
        current_time = datetime.now()
        elapsed_seconds = (current_time - created_at).total_seconds()
        last_updated_seconds = (current_time - updated_at).total_seconds()
        
        # Check for timeout - if job has been processing for more than 5 minutes with no updates
        timeout_threshold = 300  # 5 minutes
        if job_status == 'processing' and elapsed_seconds > timeout_threshold and last_updated_seconds > 60:
            # Mark job as timed out
            jobs_collection.update_one(
                {'job_id': job_id},
                {
                    '$set': {
                        'status': 'failed',
                        'error': 'Job timed out after 5 minutes',
                        'updated_at': current_time
                    }
                }
            )
            job_status = 'failed'
            
            # Log the timeout event
            logger.warning(f"Job {job_id} timed out after {elapsed_seconds:.1f} seconds")
        
        # Prepare response based on status
        response_data = {
            'job_id': job_id,
            'status': job_status,
            'topic': job.get('topic', ''),
            'document_id': job.get('document_id', ''),
            'created_at': created_at,
            'updated_at': updated_at,
            'elapsed_seconds': int(elapsed_seconds),
        }
        
        # Add appropriate data based on status
        if job_status == 'completed':
            # Include flashcards in response if job is completed
            response_data['flashcards'] = job.get('flashcards', [])
            response_data['message'] = 'Flashcards generated successfully'
            logger.info(f"Returning {len(job.get('flashcards', []))} completed flashcards for job {job_id}")
        elif job_status == 'failed':
            # Include error details if job failed
            response_data['error'] = job.get('error', 'Unknown error occurred')
            response_data['error_details'] = job.get('error_details', '')
            response_data['message'] = 'Flashcard generation failed'
            logger.error(f"Returning failed job status for job {job_id}: {response_data['error']}")
        elif job_status == 'processing':
            # Add progress message with elapsed time
            progress_message = f"Flashcards are being generated (running for {int(elapsed_seconds)} seconds). Please check again in a moment."
            response_data['message'] = progress_message
            response_data['progress_percent'] = min(95, int(elapsed_seconds / timeout_threshold * 100))
            logger.info(f"Job {job_id} is still processing after {elapsed_seconds:.1f} seconds")
        
        return Response(response_data)
        
    except Exception as e:
        logger.error(f"Error checking job status: {str(e)}")
        return Response(
            {
                'error': f'Failed to check job status: {str(e)}',
                'status': 'error'
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
