from django.urls import path
from .views import (
    StudySetListView,
    StudySetDetailView,
    FlashcardListView,
    FlashcardDetailView,
    GenerateQuizView,
    QuizResultsView,
    UserStatisticsView,
    StudyProgressView,
)
from . import views

urlpatterns = [
    # Study Sets
    path('', StudySetListView.as_view(), name='study_set_list'),
    path('<str:id>/', StudySetDetailView.as_view(), name='study_set_detail'),
    path('<str:id>', StudySetDetailView.as_view(), name='study_set_detail_no_slash'),
    
    # Flashcards
    path('<str:study_set_id>/flashcards/', FlashcardListView.as_view(), name='flashcard_list'),
    path('<str:study_set_id>/flashcards/<str:id>/', FlashcardDetailView.as_view(), name='flashcard_detail'),
    
    # Quizzes
    path('<str:study_set_id>/generate-quiz/', GenerateQuizView.as_view(), name='generate_quiz'),
    path('<str:study_set_id>/quizzes/<str:quiz_id>/results/', QuizResultsView.as_view(), name='quiz_results'),
    
    # Statistics and Progress
    path('statistics/', UserStatisticsView.as_view(), name='user_statistics'),
    path('<str:study_set_id>/progress/', StudyProgressView.as_view(), name='study_progress'),

    # StudyBuddy AI endpoints
    path('ai/upload-document/', views.upload_document, name='upload_document'),
    path('ai/ask-question/', views.ask_question, name='ask_question'),
    path('ai/generate-flashcards/', views.generate_flashcards, name='generate_flashcards'),
    path('ai/generate-exam/', views.generate_exam, name='generate_exam'),
    path('ai/grade-exam/', views.grade_exam, name='grade_exam'),
    
    # StudyBuddy AI endpoints - frontend compatible paths
    path('study-buddy/upload/', views.upload_document, name='upload_document_alt'),
    path('study-buddy/ask/', views.ask_question, name='ask_question_alt'),
    path('study-buddy/generate-flashcards/', views.generate_flashcards, name='generate_flashcards_alt'),
    path('study-buddy/generate-exam/', views.generate_exam, name='generate_exam_alt'),
    path('study-buddy/grade-exam/', views.grade_exam, name='grade_exam_alt'),

    # Document management endpoints
    path('documents/', views.get_documents, name='api_get_documents'),
    path('documents', views.get_documents, name='api_get_documents_no_slash'),
    path('documents/<str:document_id>/', views.get_document_by_id, name='api_get_document_by_id'),
    path('documents/<str:document_id>', views.get_document_by_id, name='api_get_document_by_id_no_slash'),
    
    # New endpoint for creating a study set from an existing PDF
    path('create-study-set-from-pdf/', views.create_study_set_from_pdf, name='create_study_set_from_pdf'),
    
    # Cleanup associated data endpoint
    path('cleanup-associated-data/', views.cleanup_associated_data, name='cleanup_associated_data'),
    path('cleanup-associated-data', views.cleanup_associated_data, name='cleanup_associated_data_no_slash'),
] 