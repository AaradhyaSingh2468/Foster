from django.db import models
from django.contrib.auth.models import User

class CalendarEvent(models.Model):
    """Model for calendar events"""
    EVENT_TYPES = [
        ('study', 'Study Session'),
        ('exam', 'Exam'),
        ('assignment', 'Assignment'),
        ('meeting', 'Meeting'),
        ('other', 'Other'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='calendar_events')
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    location = models.CharField(max_length=200, blank=True)
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES, default='other')
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    is_all_day = models.BooleanField(default=False)
    study_set = models.ForeignKey('study.StudySet', on_delete=models.SET_NULL, null=True, blank=True, related_name='events')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.title} on {self.start_time.date()}"

class RecurringEvent(models.Model):
    """Model for recurring events"""
    RECURRENCE_TYPES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('biweekly', 'Bi-weekly'),
        ('monthly', 'Monthly'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='recurring_events')
    base_event = models.ForeignKey(CalendarEvent, on_delete=models.CASCADE, related_name='recurrence')
    recurrence_type = models.CharField(max_length=20, choices=RECURRENCE_TYPES)
    recurrence_days = models.CharField(max_length=20, blank=True)  # comma-separated days for weekly
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.recurrence_type} event: {self.base_event.title}"

class Reminder(models.Model):
    """Model for reminders"""
    REMINDER_UNITS = [
        ('minutes', 'Minutes'),
        ('hours', 'Hours'),
        ('days', 'Days'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reminders')
    event = models.ForeignKey(CalendarEvent, on_delete=models.CASCADE, related_name='reminders')
    time_before = models.IntegerField(default=15)
    time_unit = models.CharField(max_length=10, choices=REMINDER_UNITS, default='minutes')
    is_sent = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Reminder for {self.event.title}: {self.time_before} {self.time_unit} before"

class CalendarSettings(models.Model):
    """Model for user calendar settings"""
    VIEW_OPTIONS = [
        ('day', 'Day'),
        ('week', 'Week'),
        ('month', 'Month'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='calendar_settings')
    default_view = models.CharField(max_length=10, choices=VIEW_OPTIONS, default='week')
    default_reminder_time = models.IntegerField(default=15)
    default_reminder_unit = models.CharField(max_length=10, choices=Reminder.REMINDER_UNITS, default='minutes')
    start_day_of_week = models.IntegerField(default=0)  # 0 for Sunday, 1 for Monday, etc.
    
    def __str__(self):
        return f"Calendar settings for {self.user.username}" 