from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from users.views import QuickEventView as UsersQuickEventView
from users.views import StudyEventView as UsersStudyEventView
import datetime

class CalendarEventListView(APIView):
    """
    This view forwards requests to the users.StudyEventView to maintain API consistency
    when frontend calls the calendar endpoints.
    """
    permission_classes = [IsAuthenticated]  
    
    def get(self, request):
        # Forward the request to the users app StudyEventView
        users_view = UsersStudyEventView()
        users_view.request = request
        return users_view.get(request)
    
    def post(self, request):
        # Forward the request to the users app StudyEventView
        users_view = UsersStudyEventView()
        users_view.request = request
        return users_view.post(request)

class CalendarEventDetailView(APIView):
    """
    This view forwards requests to the users.StudyEventView for specific events
    """
    permission_classes = [IsAuthenticated]
    
    def get(self, request, id):
        # Forward the request to the users app StudyEventView
        users_view = UsersStudyEventView()
        users_view.request = request
        return users_view.get(request, event_id=str(id))
    
    def put(self, request, id):
        # Forward the request to the users app StudyEventView
        users_view = UsersStudyEventView()
        users_view.request = request
        return users_view.put(request, event_id=str(id))
    
    def delete(self, request, id):
        # Forward the request to the users app StudyEventView
        users_view = UsersStudyEventView()
        users_view.request = request
        return users_view.delete(request, event_id=str(id))

class QuickEventView(APIView):
    """
    This view forwards the request to the users.QuickEventView to maintain API consistency
    when frontend calls the calendar endpoints.
    """
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        # Forward the request to the users app QuickEventView
        users_view = UsersQuickEventView()
        users_view.request = request
        return users_view.post(request)

class RecurringEventView(APIView):
    # Remove permission restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def post(self, request):
        # Placeholder
        return Response({"message": "Recurring event create endpoint"})
    
    def put(self, request, id=None):
        # Placeholder
        return Response({"message": f"Recurring event update endpoint for ID: {id}"})
    
    def delete(self, request, id=None):
        # Placeholder
        return Response({"message": f"Recurring event delete endpoint for ID: {id}"})

class ReminderListView(APIView):
    # Remove permission restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def get(self, request):
        # If user is not authenticated, return empty list
        if not request.user.is_authenticated:
            return Response([])
            
        # Placeholder
        return Response({"message": "Reminder list endpoint"})
    
    def post(self, request):
        # Placeholder
        return Response({"message": "Reminder create endpoint"})

class ReminderDetailView(APIView):
    # Remove permission restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def put(self, request, id):
        # Placeholder
        return Response({"message": f"Reminder update endpoint for ID: {id}"})
    
    def delete(self, request, id):
        # Placeholder
        return Response({"message": f"Reminder delete endpoint for ID: {id}"})

class CalendarSettingsView(APIView):
    # Remove permission restriction
    permission_classes = []  # Explicitly set empty permission classes
    
    def get(self, request):
        # If user is not authenticated, return empty settings
        if not request.user.is_authenticated:
            return Response({})
            
        # Placeholder
        return Response({"message": "Calendar settings endpoint"})
    
    def put(self, request):
        # Placeholder
        return Response({"message": "Calendar settings update endpoint"}) 