from django.urls import path
from .views import (
    CalendarEventListView,
    CalendarEventDetailView,
    RecurringEventView,
    ReminderListView,
    ReminderDetailView,
    CalendarSettingsView,
    QuickEventView
)

urlpatterns = [
    # Calendar Events
    path('events/', CalendarEventListView.as_view(), name='calendar_event_list'),
    path('events/<str:id>/', CalendarEventDetailView.as_view(), name='calendar_event_detail'),
    
    # Quick Event
    path('quick-event/', QuickEventView.as_view(), name='calendar_quick_event'),
    
    # Recurring Events
    path('recurring-events/', RecurringEventView.as_view(), name='recurring_event_list'),
    path('recurring-events/<str:id>/', RecurringEventView.as_view(), name='recurring_event_detail'),
    
    # Reminders
    path('reminders/', ReminderListView.as_view(), name='reminder_list'),
    path('reminders/<str:id>/', ReminderDetailView.as_view(), name='reminder_detail'),
    
    # Calendar Settings
    path('settings/', CalendarSettingsView.as_view(), name='calendar_settings'),
] 