"""
Simple script to test MongoDB connection and perform basic operations.
Run this script with: python test_mongodb.py
"""

import pymongo
import sys
import os
import datetime
import hashlib

# Simple password hasher
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def main():
    # MongoDB connection settings
    mongodb_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
    mongodb_name = os.environ.get('MONGO_DB_NAME', 'foster_db')
    
    print("="*50)
    print("MongoDB Connection Test")
    print("="*50)
    print(f"MongoDB URI: {mongodb_uri}")
    print(f"Database Name: {mongodb_name}")
    
    try:
        # Connect to MongoDB
        print("\nAttempting to connect to MongoDB...")
        client = pymongo.MongoClient(mongodb_uri)
        
        # Check connection
        server_info = client.server_info()
        print(f"Connected to MongoDB! Server version: {server_info['version']}")
        
        # Get database
        db = client[mongodb_name]
        print(f"Using database: {db.name}")
        
        # List collections
        collections = db.list_collection_names()
        print(f"\nCollections in database: {len(collections)}")
        for collection in collections:
            count = db[collection].count_documents({})
            print(f"  - {collection} ({count} documents)")
        
        # Create a test document
        print("\nCreating a test document...")
        test_collection = db['test_collection']
        result = test_collection.insert_one({
            'name': 'Test Document',
            'created_at': datetime.datetime.now(),
            'test_value': 42
        })
        print(f"Test document created with ID: {result.inserted_id}")
        
        # Retrieve the document
        print("\nRetrieving the test document...")
        document = test_collection.find_one({'_id': result.inserted_id})
        print(f"Retrieved document: {document}")
        
        # Create a test user
        print("\nCreating a test user...")
        users_collection = db['users']
        
        # Check if test user exists
        existing_user = users_collection.find_one({'username': 'testuser'})
        
        if not existing_user:
            user_data = {
                'username': 'testuser',
                'email': 'test@example.com',
                'password': hash_password('password123'),
                'date_joined': datetime.datetime.now(),
                'is_active': True
            }
            
            user_result = users_collection.insert_one(user_data)
            print(f"Test user created with ID: {user_result.inserted_id}")
        else:
            print(f"Test user already exists with ID: {existing_user['_id']}")
        
        # Count users
        users_count = users_collection.count_documents({})
        print(f"Total users in database: {users_count}")
        
        print("\nMongoDB test completed successfully!")
        return 0
        
    except pymongo.errors.ConnectionFailure as e:
        print(f"Error: Could not connect to MongoDB: {e}")
        return 1
    except Exception as e:
        print(f"Error: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 