#!/usr/bin/env python
"""
Test script for custom colored logging.
"""
import logging
import os
import sys

# Configure logger
logging.basicConfig(level=logging.INFO)

# Get loggers for different apps
foster_logger = logging.getLogger('foster')
study_logger = logging.getLogger('study')
user_logger = logging.getLogger('users')

# Test messages with different log levels
foster_logger.info("This is an INFO message from foster (should be BLUE)")
foster_logger.warning("This is a WARNING message from foster (should be YELLOW)")
foster_logger.error("This is an ERROR message from foster (should be RED)")
foster_logger.debug("This is a DEBUG message from foster (should be GREEN but might not show)")

# Success message
foster_logger.info("SUCCESS: This operation completed successfully (should be GREEN)")

# Messages from other loggers
study_logger.info("This is a message from the study logger")
user_logger.warning("This is a warning from the user logger")

print("\nNote: If you don't see colors, make sure your terminal supports ANSI color codes.") 