#!/usr/bin/env python
"""
Migration script to update events with secure event IDs in MongoDB.
This script should be run once to migrate existing data.
"""

import os
import sys
import django

# Set up Django environment
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'foster.settings')
django.setup()

from foster.mongodb import get_collection
from users.mongo_models import StudyEventMongo
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def migrate_events():
    """
    Update events with secure event IDs.
    """
    events_collection = get_collection('study_events')
    
    # Find all events that don't match our new ID format (timestamp-random-uuid)
    events_to_update = []
    total_events = 0
    
    # Find all events
    for event in events_collection.find():
        total_events += 1
        event_id = event.get('event_id')
        user_id = event.get('user_id')
        
        # Check if event_id exists and matches our new format pattern
        if not event_id or not isinstance(event_id, str) or '-' not in event_id:
            events_to_update.append({
                '_id': event['_id'],
                'user_id': user_id
            })
    
    if not events_to_update:
        logger.info(f"No events need migration. All {total_events} events already have secure IDs.")
        return
    
    logger.info(f"Found {len(events_to_update)} events out of {total_events} that need migration.")
    
    # Update each event with a secure event_id
    updated_count = 0
    for event in events_to_update:
        try:
            # Generate a secure ID for this event
            secure_id = StudyEventMongo.get_next_event_id(event.get('user_id'))
            
            # Update the event with the new ID
            events_collection.update_one(
                {"_id": event["_id"]},
                {"$set": {"event_id": secure_id}}
            )
            
            logger.info(f"Updated event {event['_id']} with secure event_id {secure_id}")
            updated_count += 1
        except Exception as e:
            logger.error(f"Error updating event {event['_id']}: {str(e)}")
    
    logger.info(f"Migration complete. Updated {updated_count} events with secure IDs.")
    logger.info(f"New IDs format: timestamp-randomtoken-userhash-uuidcomponent")

if __name__ == "__main__":
    logger.info("Starting secure event ID migration...")
    migrate_events()
    logger.info("Event ID migration completed.") 