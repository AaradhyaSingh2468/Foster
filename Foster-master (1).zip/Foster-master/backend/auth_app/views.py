from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password, check_password
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from datetime import datetime, timedelta
import uuid
from foster.mongodb import create_document, get_documents, get_document, update_document
from foster.sessions import (
    create_session, validate_session, deactivate_session, 
    get_user_sessions, deactivate_all_user_sessions
)
from rest_framework_simplejwt.views import TokenRefreshView
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.exceptions import InvalidToken
import requests
import jwt
import logging

# Login view
class LoginView(APIView):
    permission_classes = []
    
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')
        
        # Find user in MongoDB
        users = get_documents('users', {'email': email})
        
        if users and len(users) > 0:
            user = users[0]
            if check_password(password, user.get('password')):
                # Create a new session
                request_data = {
                    'ip_address': request.META.get('REMOTE_ADDR'),
                    'user_agent': request.META.get('HTTP_USER_AGENT'),
                    'device_info': request.data.get('device_info')
                }
                session_id = create_session(str(user['_id']), request_data)
                
                # Generate JWT token with session info
                refresh = RefreshToken()
                refresh['user_id'] = str(user['_id'])
                refresh['email'] = user['email']
                refresh['username'] = user['username']
                refresh['session_id'] = session_id
                
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'user': {
                        'id': str(user['_id']),
                        'email': user['email'],
                        'username': user['username']
                    },
                    'session_id': session_id
                })
        
        return Response(
            {'error': 'Invalid credentials'}, 
            status=status.HTTP_401_UNAUTHORIZED
        )

# Register view
class RegisterView(APIView):
    permission_classes = []
    
    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        
        # Check if user exists
        existing_users = get_documents('users', {'email': email})
        if existing_users and len(existing_users) > 0:
            return Response(
                {'error': 'Email already exists'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create new user
        user_data = {
            'username': username,
            'email': email,
            'password': make_password(password),
            'date_joined': datetime.now(),
            'is_active': True
        }
        
        user_id = create_document('users', user_data)
        
        # Create user profile
        profile_data = {
            'user_id': user_id,
            'avatar': None,
            'bio': '',
            'date_of_birth': None,
            'education_level': '',
            'institution': '',
            'major': '',
            'created_at': datetime.now(),
            'updated_at': datetime.now(),
            'onboarding_completed': False
        }
        create_document('user_profiles', profile_data)
        
        # Create user preferences
        preferences_data = {
            'user_id': user_id,
            'theme': 'system',
            'email_notifications': True,
            'study_reminder_frequency': 3,
            'calendar_default_view': 'week',
            'ai_features_enabled': True,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        create_document('user_preferences', preferences_data)
        
        # Create a new session
        request_data = {
            'ip_address': request.META.get('REMOTE_ADDR'),
            'user_agent': request.META.get('HTTP_USER_AGENT'),
            'device_info': request.data.get('device_info')
        }
        session_id = create_session(user_id, request_data)
        
        # Generate JWT token with session info
        refresh = RefreshToken()
        refresh['user_id'] = user_id
        refresh['email'] = email
        refresh['username'] = username
        refresh['session_id'] = session_id
        
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': {
                'id': user_id,
                'email': email,
                'username': username
            },
            'session_id': session_id
        }, status=status.HTTP_201_CREATED)

# Logout view
class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        # Get session ID from request
        session_id = getattr(request, 'session_id', None)
        
        if session_id:
            # Deactivate current session
            deactivate_session(session_id)
            
        return Response({'message': 'Successfully logged out'})

# Logout all sessions view
class LogoutAllView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        # Get user ID and current session ID
        user_id = request.user.user_id
        current_session_id = getattr(request, 'session_id', None)
        
        # Option to keep current session active
        keep_current = request.data.get('keep_current', False)
        
        if keep_current and current_session_id:
            # Logout from all sessions except current
            count = deactivate_all_user_sessions(user_id, current_session_id)
        else:
            # Logout from all sessions including current
            count = deactivate_all_user_sessions(user_id)
            
        return Response({
            'message': f'Logged out from all sessions',
            'sessions_terminated': count
        })

# Sessions view
class SessionsView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        # Get user ID
        user_id = request.user.user_id
        
        # Get user sessions
        sessions = get_user_sessions(user_id)
        
        # Current session ID
        current_session_id = getattr(request, 'session_id', None)
        
        # Format sessions for response
        formatted_sessions = []
        for session in sessions:
            formatted_sessions.append({
                'id': session['_id'],
                'created_at': session['created_at'],
                'last_activity': session['last_activity'],
                'ip_address': session['ip_address'],
                'user_agent': session['user_agent'],
                'is_current': session['_id'] == current_session_id
            })
            
        return Response({'sessions': formatted_sessions})
    
    def delete(self, request, session_id=None):
        # Get user ID
        user_id = request.user.user_id
        
        # If no session ID provided, use the one from the URL
        if not session_id:
            session_id = request.query_params.get('session_id')
            
        if not session_id:
            return Response(
                {'error': 'Session ID is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        # Get session
        session = validate_session(session_id)
        
        # Check if session exists and belongs to user
        if not session or session.get('user_id') != user_id:
            return Response(
                {'error': 'Invalid session'}, 
                status=status.HTTP_404_NOT_FOUND
            )
            
        # Current session ID
        current_session_id = getattr(request, 'session_id', None)
        
        # Prevent terminating current session through this endpoint
        if session_id == current_session_id:
            return Response(
                {'error': 'Cannot terminate current session. Use logout instead.'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        # Deactivate session
        deactivate_session(session_id)
        
        return Response({'message': 'Session terminated successfully'})

# Google auth view
class GoogleAuthView(APIView):
    permission_classes = []
    authentication_classes = []  # Explicitly disable auth for this endpoint
    
    def post(self, request):
        # Get token from frontend
        token_id = request.data.get('tokenId')
        
        # Log received data for debugging
        logger = logging.getLogger(__name__)
        logger.info(f"GoogleAuthView received request with data: {str(request.data)[:100]}...")
        
        if not token_id:
            logger.warning("No tokenId provided in the request")
            return Response(
                {'error': 'Token ID is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Check for null or invalid token
        if token_id == 'null' or token_id == 'undefined':
            logger.error(f"Invalid token value received: {token_id}")
            return Response(
                {'error': 'Invalid token value'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        try:
            # Log the token format for debugging
            logger.info(f"Processing token: {token_id[:20]}... (length: {len(token_id)})")
            
            # Verify the token with Google
            # Note: In a production environment, you should use google-auth-library
            # Here we'll simulate the verification for demonstration
            # import google.oauth2.id_token
            # import google.auth.transport.requests
            # request = google.auth.transport.requests.Request()
            # user_info = google.oauth2.id_token.verify_oauth2_token(token_id, request)
            
            # For demo purposes, extract user info from the token payload 
            # In production, use the commented code above instead
            # This is just for demonstration - in production use a proper verification
            try:
                user_info = jwt.decode(token_id, options={"verify_signature": False})
                logger.info(f"Successfully decoded token, user info: {str(user_info)[:100]}...")
            except Exception as decode_error:
                logger.error(f"Error decoding token: {str(decode_error)}")
                return Response(
                    {'error': f'Failed to decode token: {str(decode_error)}'}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Extract user information
            email = user_info.get('email')
            if not email:
                logger.warning("No email found in token data")
                return Response(
                    {'error': 'Email not provided by Google'}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
                
            name = user_info.get('name', '')
            picture = user_info.get('picture', '')
            firebase_uid = user_info.get('sub') or user_info.get('user_id')
            
            logger.info(f"User identified: {email} (Firebase UID: {firebase_uid})")
            
            # Check if user exists in database
            users = get_documents('users', {'email': email})
            
            if users and len(users) > 0:
                # User exists, update login information
                user = users[0]
                user_id = str(user['_id'])
                logger.info(f"Existing user found: {user_id}")
                
                # Update Firebase UID if needed
                updates = {
                    'last_login': datetime.now(),
                    'oauth_provider': 'google',
                    'oauth_picture': picture
                }
                
                # If Firebase UID is not set or different, update it
                if firebase_uid and ('firebase_uid' not in user or user.get('firebase_uid') != firebase_uid):
                    updates['firebase_uid'] = firebase_uid
                    logger.info(f"Updating Firebase UID for user {user_id}: {firebase_uid}")
                
                # Update user profile
                update_document('users', user_id, updates)
            else:
                # Create new user
                logger.info(f"Creating new user for: {email}")
                user_data = {
                    'username': name,
                    'email': email,
                    'password': make_password(str(uuid.uuid4())),  # Random secure password
                    'date_joined': datetime.now(),
                    'last_login': datetime.now(),
                    'is_active': True,
                    'oauth_provider': 'google',
                    'oauth_picture': picture,
                    'firebase_uid': firebase_uid  # Store the Firebase UID
                }
                
                logger.info(f"User data: {str(user_data)[:100]}...")
                user_id = create_document('users', user_data)
                logger.info(f"Created new user with ID: {user_id}")
                
                # Create user profile
                profile_data = {
                    'user_id': user_id,
                    'avatar': picture,  # Store the Google profile picture URL directly
                    'bio': '',
                    'date_of_birth': None,
                    'education_level': '',
                    'institution': '',
                    'major': '',
                    'created_at': datetime.now(),
                    'updated_at': datetime.now(),
                    'onboarding_completed': False
                }
                create_document('user_profiles', profile_data)
                logger.info(f"Created user profile for: {user_id} with avatar: {picture}")
                
                # Create user preferences
                preferences_data = {
                    'user_id': user_id,
                    'theme': 'system',
                    'email_notifications': True,
                    'study_reminder_frequency': 3,
                    'calendar_default_view': 'week',
                    'ai_features_enabled': True,
                    'created_at': datetime.now(),
                    'updated_at': datetime.now()
                }
                create_document('user_preferences', preferences_data)
                logger.info(f"Created user preferences for: {user_id}")
            
            # Create a new session
            request_data = {
                'ip_address': request.META.get('REMOTE_ADDR'),
                'user_agent': request.META.get('HTTP_USER_AGENT'),
                'device_info': request.data.get('device_info')
            }
            session_id = create_session(user_id, request_data)
            logger.info(f"Created new session: {session_id}")
            
            # Get the user data for the response
            user = get_document('users', user_id)
            
            # Generate JWT token with session info
            refresh = RefreshToken()
            refresh['user_id'] = user_id
            refresh['email'] = email
            refresh['username'] = user.get('username', name)
            refresh['session_id'] = session_id
            
            logger.info(f"Authentication successful for user: {user_id}")
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': {
                    'id': user_id,
                    'email': email,
                    'username': user.get('username', name)
                },
                'session_id': session_id,
                'is_new_user': len(users) == 0  # Indicate if this is a new user
            })
            
        except Exception as e:
            logger.error(f"Authentication failed: {str(e)}", exc_info=True)
            return Response(
                {'error': f'Authentication failed: {str(e)}'}, 
                status=status.HTTP_401_UNAUTHORIZED
            )

# Github auth view
class GithubAuthView(APIView):
    permission_classes = []
    authentication_classes = []  # Explicitly disable auth for this endpoint
    
    def post(self, request):
        # Get access token from frontend
        access_token = request.data.get('token')
        if not access_token:
            return Response(
                {'error': 'Access token is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        try:
            # Make request to GitHub API
            github_response = requests.get(
                'https://api.github.com/user',
                headers={'Authorization': f'token {access_token}'}
            )
            
            if github_response.status_code != 200:
                return Response(
                    {'error': 'Invalid GitHub token'}, 
                    status=status.HTTP_401_UNAUTHORIZED
                )
                
            # Get user info
            github_data = github_response.json()
            
            # Get email (GitHub might not expose it directly)
            github_email_response = requests.get(
                'https://api.github.com/user/emails',
                headers={'Authorization': f'token {access_token}'}
            )
            
            if github_email_response.status_code != 200:
                return Response(
                    {'error': 'Failed to get GitHub email'}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
                
            emails = github_email_response.json()
            primary_email = next((email.get('email') for email in emails if email.get('primary')), None)
            
            if not primary_email:
                return Response(
                    {'error': 'No primary email found in GitHub account'}, 
                    status=status.HTTP_400_BAD_REQUEST
                )
                
            # Extract GitHub user information
            github_id = str(github_data.get('id'))
            name = github_data.get('name') or github_data.get('login')
            avatar_url = github_data.get('avatar_url')
            
            # Check if user exists with this email
            users = get_documents('users', {'email': primary_email})
            
            if users and len(users) > 0:
                # User exists, update login information
                user = users[0]
                user_id = str(user['_id'])
                
                # Update user profile if needed
                update_document('users', user_id, {
                    'last_login': datetime.now(),
                    'oauth_provider': 'github',
                    'oauth_picture': avatar_url,
                    'github_id': github_id
                })
            else:
                # Create new user
                user_data = {
                    'username': name,
                    'email': primary_email,
                    'password': make_password(str(uuid.uuid4())),  # Random secure password
                    'date_joined': datetime.now(),
                    'last_login': datetime.now(),
                    'is_active': True,
                    'oauth_provider': 'github',
                    'oauth_picture': avatar_url,
                    'github_id': github_id
                }
                
                user_id = create_document('users', user_data)
                
                # Create user profile
                profile_data = {
                    'user_id': user_id,
                    'avatar': avatar_url,
                    'bio': github_data.get('bio', ''),
                    'date_of_birth': None,
                    'education_level': '',
                    'institution': '',
                    'major': '',
                    'created_at': datetime.now(),
                    'updated_at': datetime.now(),
                    'onboarding_completed': False
                }
                create_document('user_profiles', profile_data)
                
                # Create user preferences
                preferences_data = {
                    'user_id': user_id,
                    'theme': 'system',
                    'email_notifications': True,
                    'study_reminder_frequency': 3,
                    'calendar_default_view': 'week',
                    'ai_features_enabled': True,
                    'created_at': datetime.now(),
                    'updated_at': datetime.now()
                }
                create_document('user_preferences', preferences_data)
            
            # Create a new session
            request_data = {
                'ip_address': request.META.get('REMOTE_ADDR'),
                'user_agent': request.META.get('HTTP_USER_AGENT'),
                'device_info': request.data.get('device_info')
            }
            session_id = create_session(user_id, request_data)
            
            # Get the user for response
            user = get_document('users', user_id)
            
            # Generate JWT token with session info
            refresh = RefreshToken()
            refresh['user_id'] = user_id
            refresh['email'] = primary_email
            refresh['username'] = user.get('username', name)
            refresh['session_id'] = session_id
            
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'user': {
                    'id': user_id,
                    'email': primary_email,
                    'username': user.get('username', name)
                },
                'session_id': session_id
            })
            
        except Exception as e:
            return Response(
                {'error': f'Authentication failed: {str(e)}'}, 
                status=status.HTTP_401_UNAUTHORIZED
            )

# Reset password view
class ResetPasswordView(APIView):
    permission_classes = []
    
    def post(self, request):
        email = request.data.get('email')
        
        # Find user
        users = get_documents('users', {'email': email})
        
        if users and len(users) > 0:
            user = users[0]
            # Create password reset token
            token = str(uuid.uuid4())
            expires_at = datetime.now() + timedelta(hours=24)
            
            reset_token_data = {
                'user_id': str(user['_id']),
                'token': token,
                'created_at': datetime.now(),
                'expires_at': expires_at,
                'is_used': False
            }
            
            create_document('password_reset_tokens', reset_token_data)
            
            # In a real implementation, send email with reset link
            # For now, just return the token
            return Response({
                'message': 'Password reset link sent',
                'token': token  # Only for development
            })
        else:
            # Don't reveal that the user doesn't exist for security
            return Response({'message': 'If the email exists, a reset link has been sent'})

# Verify reset token view
class VerifyResetTokenView(APIView):
    permission_classes = []
    
    def get(self, request, token):
        # Find token
        tokens = get_documents('password_reset_tokens', {'token': token})
        
        if tokens and len(tokens) > 0:
            token_obj = tokens[0]
            # Check if token is valid
            is_valid = (not token_obj['is_used'] and 
                        datetime.now() < token_obj['expires_at'])
            
            if is_valid:
                return Response({'valid': True})
            else:
                return Response(
                    {'valid': False, 'message': 'Token expired or already used'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            return Response(
                {'valid': False, 'message': 'Invalid token'},
                status=status.HTTP_400_BAD_REQUEST
            )

# Set new password view
class SetNewPasswordView(APIView):
    permission_classes = []
    
    def post(self, request):
        token = request.data.get('token')
        password = request.data.get('password')
        
        # Find token
        tokens = get_documents('password_reset_tokens', {'token': token})
        
        if tokens and len(tokens) > 0:
            token_obj = tokens[0]
            
            # Check if token is valid
            is_valid = (not token_obj['is_used'] and 
                        datetime.now() < token_obj['expires_at'])
            
            if not is_valid:
                return Response(
                    {'error': 'Token expired or already used'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Update user's password
            user_id = token_obj['user_id']
            update_document('users', user_id, {'password': make_password(password)})
            
            # Mark token as used
            update_document('password_reset_tokens', str(token_obj['_id']), {'is_used': True})
            
            # Terminate all existing sessions for security
            deactivate_all_user_sessions(user_id)
            
            # Find user for response
            user = get_document('users', user_id)
            
            # Create a new session
            request_data = {
                'ip_address': request.META.get('REMOTE_ADDR'),
                'user_agent': request.META.get('HTTP_USER_AGENT')
            }
            session_id = create_session(user_id, request_data)
            
            # Generate JWT token with session info
            refresh = RefreshToken()
            refresh['user_id'] = user_id
            refresh['email'] = user['email']
            refresh['username'] = user['username']
            refresh['session_id'] = session_id
            
            return Response({
                'message': 'Password reset successful',
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'session_id': session_id
            })
        else:
            return Response(
                {'error': 'Invalid token'},
                status=status.HTTP_400_BAD_REQUEST
            )

# Custom token refresh serializer that preserves session info
class SessionAwareTokenRefreshSerializer(TokenRefreshSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        
        # Get the refresh token
        refresh = self.token_class(attrs['refresh'])
        
        # Extract session_id from the old token
        session_id = refresh.get('session_id')
        
        if session_id:
            # Validate the session
            session = validate_session(session_id)
            if not session:
                raise InvalidToken('Session expired or invalid')
                
            # Get the user information
            user_id = refresh.get('user_id')
            email = refresh.get('email')
            username = refresh.get('username')
            
            # Extract the new access token
            access_token = AccessToken(data['access'])
            
            # Add session and user info to the new access token
            access_token['session_id'] = session_id
            access_token['user_id'] = user_id
            access_token['email'] = email
            access_token['username'] = username
            
            # Update the access token in the response
            data['access'] = str(access_token)
        
        return data

# Custom token refresh view
class SessionAwareTokenRefreshView(TokenRefreshView):
    serializer_class = SessionAwareTokenRefreshSerializer 