from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    LoginView, 
    RegisterView, 
    LogoutView,
    LogoutAllView,
    SessionsView,
    GoogleAuthView, 
    GithubAuthView, 
    ResetPasswordView, 
    VerifyResetTokenView, 
    SetNewPasswordView,
    SessionAwareTokenRefreshView,
)

urlpatterns = [
    path('login', LoginView.as_view(), name='login'),
    path('register', RegisterView.as_view(), name='register'),
    path('logout', LogoutView.as_view(), name='logout'),
    path('logout-all', LogoutAllView.as_view(), name='logout_all'),
    path('sessions', SessionsView.as_view(), name='sessions'),
    path('sessions/<str:session_id>', SessionsView.as_view(), name='session_detail'),
    path('token/refresh', SessionAwareTokenRefreshView.as_view(), name='token_refresh'),
    path('google', GoogleAuthView.as_view(), name='google_auth'),
    path('github', GithubAuthView.as_view(), name='github_auth'),
    path('reset-password', ResetPasswordView.as_view(), name='reset_password'),
    path('verify-reset/<str:token>', VerifyResetTokenView.as_view(), name='verify_reset_token'),
    path('reset-password/confirm', SetNewPasswordView.as_view(), name='set_new_password'),
] 