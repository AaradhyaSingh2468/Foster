# MongoDB Integration for Foster Backend

This README provides instructions on how to set up and work with MongoDB for the Foster backend application.

## Setup MongoDB

### Windows

1. **Run the setup script**:
   ```
   setup_mongodb.bat
   ```
   This script will create the necessary data directories and configuration file.

2. **Download and Install MongoDB**:
   - Download MongoDB Community Server from: https://www.mongodb.com/try/download/community
   - Follow the installation instructions

3. **Start MongoDB**:
   Either use MongoDB as a service or start it manually:
   ```
   "C:\Program Files\MongoDB\Server\[version]\bin\mongod.exe" --config mongodb.conf
   ```

### Linux/macOS

1. **Install MongoDB**:
   ```
   # Ubuntu
   sudo apt-get install mongodb

   # macOS
   brew install mongodb-community
   ```

2. **Create data directories**:
   ```
   mkdir -p mongodb_data/db mongodb_data/log
   ```

3. **Create configuration file**:
   Create a file named `mongodb.conf` with the following content:
   ```
   systemLog:
     destination: file
     path: /path/to/foster/backend/mongodb_data/log/mongod.log
     logAppend: true
   storage:
     dbPath: /path/to/foster/backend/mongodb_data/db
     journal:
       enabled: true
   net:
     bindIp: 127.0.0.1
     port: 27017
   ```

4. **Start MongoDB**:
   ```
   mongod --config mongodb.conf
   ```

## Working with MongoDB

The backend is configured to use MongoDB through PyMongo. Django models have been adapted to work with MongoDB directly.

### MongoDB Service Layer

The `foster/mongodb.py` file provides helper functions to interact with MongoDB:

- `get_collection(collection_name)`: Get a MongoDB collection
- `create_document(collection_name, document)`: Create a new document
- `get_document(collection_name, document_id)`: Get a document by ID
- `get_documents(collection_name, query=None, sort=None, limit=None, skip=None)`: Get filtered documents
- `update_document(collection_name, document_id, update_data)`: Update a document
- `delete_document(collection_name, document_id)`: Delete a document
- `count_documents(collection_name, query=None)`: Count documents
- `aggregate(collection_name, pipeline)`: Run an aggregation pipeline

### Using MongoDB in Views

Here's an example of how to use MongoDB in your views:

```python
from foster.mongodb import (
    create_document, 
    get_documents, 
    get_document, 
    update_document,
    delete_document
)

# Create a user
user_data = {
    'username': 'johndoe',
    'email': 'john@example.com',
    'password': 'hashed_password'
}
user_id = create_document('users', user_data)

# Retrieve a user
user = get_document('users', user_id)

# Retrieve multiple users with filtering
active_users = get_documents('users', {'is_active': True})

# Update a user
update_document('users', user_id, {'email': 'new_email@example.com'})

# Delete a user
delete_document('users', user_id)
```

## Environment Variables

The MongoDB connection uses the following environment variables:

- `MONGO_URI`: The MongoDB connection URI (default: `mongodb://localhost:27017/`)
- `MONGO_DB_NAME`: The MongoDB database name (default: `foster_db`)

These can be set in the `.env` file in the backend directory. 