# Firebase Authentication Setup Guide

This guide will help you set up Firebase authentication for the Foster project. We'll cover both frontend and backend configuration.

## Step 1: Create a Firebase Project

1. Go to the [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project" and follow the setup wizard
3. Name your project (e.g., "Foster App")
4. Enable or disable Google Analytics as desired
5. Click "Create project"

## Step 2: Add a Web App to Your Firebase Project

1. In the Firebase console, click on the project you just created
2. Click on the web icon (</>) to add a web app
3. Name your app (e.g., "Foster Web App")
4. Check "Also set up Firebase Hosting" if desired
5. Click "Register app"
6. Copy the Firebase configuration object shown on the screen (we'll use this later)

## Step 3: Enable Authentication Methods

1. In the Firebase console, navigate to "Authentication" from the left menu
2. Click on "Get started" or "Sign-in method"
3. Enable the authentication methods you want to use (at minimum, enable Email/Password)
4. For each method, click "Enable" and save

## Step 4: Create a Service Account for Backend Integration

1. In the Firebase console, go to Project Settings (gear icon)
2. Navigate to the "Service accounts" tab
3. Click "Generate new private key"
4. Save the downloaded JSON file securely - this contains sensitive credentials

## Step 5: Configure the Frontend

1. Open the file `frontend/src/config/firebase.js`
2. Replace the Firebase configuration with your own:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};
```

## Step 6: Configure the Backend

1. Open the file `backend/foster/authentication.py`
2. Locate the Firebase Admin SDK initialization section
3. Update the projectId to match your Firebase project:

```python
firebase_admin.initialize_app(cred, {
    'projectId': 'your-project-id',
    'storageBucket': 'your-project-id.appspot.com'
})
```

4. Place your downloaded service account JSON file in one of these locations:
   - `backend/foster/credentials/firebase-service-account.json` (preferred)
   - `backend/firebase-service-account.json`

## Step 7: Test the Authentication

1. Start both the frontend and backend servers
2. Try to log in with a Firebase authentication method
3. Check the backend logs to ensure the authentication is working

## Troubleshooting

If you encounter any issues:

1. **Frontend Authentication Errors**: Check your Firebase configuration in `firebase.js`
2. **Backend Authentication Errors**: Ensure your service account JSON file is in the correct location
3. **CORS Issues**: Make sure your Firebase authentication domain is correctly configured
4. **Token Verification Errors**: Verify that the frontend and backend are using the same Firebase project

## Additional Resources

- [Firebase Authentication Documentation](https://firebase.google.com/docs/auth)
- [Firebase Admin SDK Documentation](https://firebase.google.com/docs/admin/setup)
- [React Firebase Authentication Tutorial](https://firebase.google.com/docs/auth/web/start) 