#!/usr/bin/env python
"""
Helper script to pull required Ollama models.
Run this script before starting the server to ensure all necessary models are available.
"""

import subprocess
import sys
import time
import os

def check_ollama_running():
    """Check if Ollama is running by making a request to the API"""
    import requests
    try:
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        return response.status_code == 200
    except:
        return False

def pull_model(model_name):
    """Pull a specific model"""
    print(f"Pulling model: {model_name}")
    result = subprocess.run(
        ["ollama", "pull", model_name],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print(f"✓ Successfully pulled {model_name}")
        return True
    else:
        print(f"✗ Failed to pull {model_name}: {result.stderr}")
        return False

def main():
    """Main function to pull all required models"""
    print("Checking if Ollama is running...")
    if not check_ollama_running():
        print("Ollama does not appear to be running. Please start Ollama first.")
        print("You can download Ollama from: https://ollama.com/download")
        return 1
    
    # List of models to pull in order of preference
    models = [
        "mistral",  # Smaller model with good performance
        "llama2",   # Good general model
        "tinyllama",  # Lightweight model
        "orca-mini",  # Another lightweight option
        "gemma:2b",  # Smaller Google gemma model
    ]
    
    total = len(models)
    successful = 0
    
    print(f"Starting to pull {total} models...")
    for model in models:
        if pull_model(model):
            successful += 1
        time.sleep(1)  # Brief pause between pulls
    
    print(f"Pull complete: {successful}/{total} models successfully pulled")
    
    if successful == 0:
        print("No models could be pulled. Please check your internet connection and Ollama installation.")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 