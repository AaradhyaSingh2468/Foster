# Foster Backend

This is the backend server for the Foster application, a learning platform with AI-powered features.

## Features

- User authentication (login, register, password reset)
- User profiles and preferences
- Study sets and flashcards management
- Calendar events and reminders
- AI features (chat, exam generation, video generation, study insights)
- MongoDB database integration with PyMongo

## API Endpoints

The backend provides API endpoints for:

- Authentication: `/api/auth/`
- User management: `/api/users/`
- Study materials: `/api/study-sets/`
- Calendar: `/api/calendar/`
- AI features: `/api/ai/`

## Getting Started

### Prerequisites

- Python 3.9+
- pip
- virtualenv
- MongoDB

### MongoDB Setup

For detailed instructions on setting up MongoDB, see [MongoDB_README.md](MongoDB_README.md).

Quick setup on Windows:
1. Run `setup_mongodb.bat` to create required directories and config
2. Install MongoDB Community Server
3. Start MongoDB server with the provided configuration

### Installation

1. Navigate to the backend directory:
   ```
   cd backend
   ```

2. Create and activate virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate  # Windows
   source venv/bin/activate  # Linux/Mac
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Start MongoDB (as described in MongoDB setup)

5. Start the development server:
   ```
   python manage.py runserver
   ```

### Environment Variables

Create a `.env` file in the backend directory with the following variables:

```
SECRET_KEY=your-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
CORS_ALLOWED_ORIGINS=http://localhost:3000
MONGO_URI=mongodb://localhost:27017/
MONGO_DB_NAME=foster_db
```

## Frontend Integration

The frontend is configured to work with this backend through the following:

1. API base URL is set to `http://localhost:8000/api`
2. JWT authentication tokens are used for secure communication
3. Tokens are automatically refreshed when expired

To test the integrated system:
1. Start the MongoDB server
2. Start the Django backend server
3. Start the React frontend development server

## API Documentation

Once the server is running, you can access the API documentation at:
- Admin interface: `http://localhost:8000/admin/` 