"""
Script to fix missing profile pictures in user profiles.

This script checks all users and ensures their profile pictures are correctly set
by copying the OAuth picture URL from the users collection to the user_profiles collection.

Usage:
    python fix_user_profiles.py
"""

import os
import django
import logging
import sys
from datetime import datetime

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'foster.settings')
django.setup()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Import after Django setup
from foster.mongodb import get_collection, update_document

def fix_user_profiles():
    """
    Fix missing profile pictures for all users.
    """
    logger.info("Starting user profile picture migration...")
    
    # Get collections
    users_collection = get_collection('users')
    profiles_collection = get_collection('user_profiles')
    
    # Count for stats
    total_users = 0
    fixed_profiles = 0
    skipped_profiles = 0
    errors = 0
    
    # Get all users
    users = users_collection.find({})
    
    for user in users:
        total_users += 1
        user_id = str(user['_id'])
        
        try:
            # Check if user has an OAuth picture
            oauth_picture = user.get('oauth_picture')
            
            # Get the user profile
            profile = profiles_collection.find_one({'user_id': user_id})
            
            if not profile:
                logger.warning(f"User {user_id} has no profile, creating one")
                # Create profile with picture if user has one
                profile_data = {
                    'user_id': user_id,
                    'avatar': oauth_picture,
                    'bio': '',
                    'date_of_birth': None,
                    'education_level': '',
                    'institution': '',
                    'major': '',
                    'created_at': datetime.now(),
                    'updated_at': datetime.now(),
                    'onboarding_completed': False
                }
                profiles_collection.insert_one(profile_data)
                logger.info(f"Created profile for user {user_id} with avatar: {oauth_picture}")
                fixed_profiles += 1
                continue
            
            # If user has OAuth picture but profile has no avatar, update it
            if oauth_picture and (not profile.get('avatar') or profile.get('avatar') is None):
                logger.info(f"Fixing missing avatar for user {user_id}")
                profiles_collection.update_one(
                    {'_id': profile['_id']},
                    {'$set': {
                        'avatar': oauth_picture,
                        'updated_at': datetime.now()
                    }}
                )
                fixed_profiles += 1
            else:
                # Profile already has an avatar or user has no OAuth picture
                skipped_profiles += 1
                
        except Exception as e:
            logger.error(f"Error processing user {user_id}: {str(e)}")
            errors += 1
    
    logger.info(f"Migration complete!")
    logger.info(f"Total users processed: {total_users}")
    logger.info(f"Fixed profiles: {fixed_profiles}")
    logger.info(f"Skipped profiles: {skipped_profiles}")
    logger.info(f"Errors: {errors}")

if __name__ == '__main__':
    fix_user_profiles() 