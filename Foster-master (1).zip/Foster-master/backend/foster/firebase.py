"""
Firebase authentication utilities for Foster.
This module provides functions for verifying Firebase tokens and handling Firebase authentication.
"""

import logging
import firebase_admin
from firebase_admin import auth
from django.conf import settings
import jwt

# Set up logging
logger = logging.getLogger(__name__)

def verify_firebase_token(token, clock_skew_seconds=5):
    """
    Verify a Firebase ID token and return the decoded token data.
    
    Args:
        token (str): The Firebase ID token to verify
        clock_skew_seconds (int): Tolerance for clock skew in seconds
        
    Returns:
        dict: The decoded token data if valid, None otherwise
    """
    try:
        # First try regular Firebase verification
        try:
            # Verify the Firebase token
            decoded_token = auth.verify_id_token(token, clock_skew_seconds=clock_skew_seconds)
            
            # Extract UID from token
            uid = decoded_token.get('uid')
            if not uid:
                logger.warning("Firebase token valid but no UID found")
                return None
                
            logger.info(f"Firebase token verified successfully. UID: {uid}")
            
            # Return the decoded token with specific fields for WebSocket auth
            return {
                'uid': uid,
                'email': decoded_token.get('email'),
                'name': decoded_token.get('name'),
                'picture': decoded_token.get('picture'),
            }
        except firebase_admin._auth_utils.InvalidIdTokenError as e:
            # Special handling for 'kid' claim errors which often happen with Google Auth flow
            if "kid claim" in str(e):
                logger.warning(f"Firebase token missing 'kid' claim: {str(e)}")
                
                # For Google OAuth tokens, we can try to decode without verification
                # to extract basic info and match with an existing user
                try:
                    logger.info("Attempting to decode token without verification as fallback...")
                    decoded_token = jwt.decode(token, options={"verify_signature": False})
                    
                    # For Google tokens, 'sub' is equivalent to Firebase's 'uid'
                    uid = decoded_token.get('sub') or decoded_token.get('user_id')
                    if not uid:
                        logger.warning("Fallback decoding: No subject/user ID found in token")
                        return None
                    
                    # Check for required fields
                    email = decoded_token.get('email')
                    if not email:
                        logger.warning("Fallback decoding: No email found in token")
                        return None
                    
                    logger.info(f"Fallback token decoding successful. Subject/UID: {uid}, Email: {email}")
                    
                    # Return the decoded token with basic fields
                    return {
                        'uid': uid,
                        'email': email,
                        'name': decoded_token.get('name'),
                        'picture': decoded_token.get('picture'),
                    }
                except Exception as decode_error:
                    logger.error(f"Fallback token decoding failed: {str(decode_error)}")
                    return None
            else:
                logger.warning(f"Firebase token validation failed: {str(e)}")
                return None
    except Exception as e:
        logger.error(f"Error verifying Firebase token: {str(e)}")
        return None 