"""
Management command to clean up expired sessions.
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
import logging
from foster.sessions import cleanup_expired_sessions

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Clean up expired user sessions'

    def handle(self, *args, **options):
        try:
            # Clean up expired sessions
            deleted_count = cleanup_expired_sessions()
            
            # Log result
            self.stdout.write(
                self.style.SUCCESS(f'Successfully cleaned up {deleted_count} expired sessions')
            )
            logger.info(f'Cleaned up {deleted_count} expired sessions')
            
        except Exception as e:
            # Log error
            self.stdout.write(
                self.style.ERROR(f'Error cleaning up sessions: {str(e)}')
            )
            logger.error(f'Error cleaning up sessions: {str(e)}') 