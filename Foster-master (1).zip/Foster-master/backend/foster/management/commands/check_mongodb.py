from django.core.management.base import BaseCommand
from django.conf import settings
import pymongo
import sys
import json

class Command(BaseCommand):
    help = 'Checks MongoDB connection and displays database information'

    def add_arguments(self, parser):
        parser.add_argument(
            '--create-test-data',
            action='store_true',
            help='Create test documents in MongoDB collections',
        )
        parser.add_argument(
            '--list-collections',
            action='store_true',
            help='List all collections in the MongoDB database',
        )
        parser.add_argument(
            '--list-documents',
            type=str,
            help='List documents in the specified collection',
        )

    def handle(self, *args, **options):
        try:
            # Get MongoDB connection from settings
            mongo_client = settings.mongo_client
            mongo_db = settings.mongo_db
            
            # Display connection info
            self.stdout.write(self.style.SUCCESS('='*50))
            self.stdout.write(self.style.SUCCESS('MongoDB Connection Information'))
            self.stdout.write(self.style.SUCCESS('='*50))
            self.stdout.write(f"MongoDB Connection URI: {settings.MONGO_URI}")
            self.stdout.write(f"MongoDB Database: {mongo_db.name}")
            self.stdout.write(f"MongoDB Server Info: {mongo_client.server_info()['version']}")
            
            # List collections if requested
            if options['list_collections']:
                self.stdout.write(self.style.SUCCESS('\nCollections:'))
                for collection in mongo_db.list_collection_names():
                    count = mongo_db[collection].count_documents({})
                    self.stdout.write(f"  - {collection} ({count} documents)")
            
            # List documents in a collection if requested
            if options['list_documents']:
                collection_name = options['list_documents']
                self.stdout.write(self.style.SUCCESS(f'\nDocuments in {collection_name}:'))
                
                if collection_name in mongo_db.list_collection_names():
                    documents = list(mongo_db[collection_name].find().limit(10))
                    
                    if documents:
                        for doc in documents:
                            # Convert ObjectId to string for display
                            doc['_id'] = str(doc['_id'])
                            self.stdout.write(json.dumps(doc, indent=2, default=str))
                            self.stdout.write('-'*30)
                    else:
                        self.stdout.write(self.style.WARNING(f"No documents found in {collection_name}"))
                else:
                    self.stdout.write(self.style.ERROR(f"Collection {collection_name} does not exist"))
            
            # Create test data if requested
            if options['create_test_data']:
                self.stdout.write(self.style.SUCCESS('\nCreating test data...'))
                
                # Create a test user
                from foster.mongodb import create_document
                
                # Check if users collection exists and has documents
                users_exist = 'users' in mongo_db.list_collection_names() and mongo_db['users'].count_documents({}) > 0
                
                if not users_exist:
                    from django.contrib.auth.hashers import make_password
                    from datetime import datetime
                    
                    # Create a test user
                    user_data = {
                        'username': 'testuser',
                        'email': 'test@example.com',
                        'password': make_password('password123'),
                        'date_joined': datetime.now(),
                        'is_active': True
                    }
                    
                    user_id = create_document('users', user_data)
                    self.stdout.write(f"Created test user with ID: {user_id}")
                    
                    # Create user profile
                    profile_data = {
                        'user_id': user_id,
                        'bio': 'Test user profile',
                        'created_at': datetime.now(),
                        'updated_at': datetime.now(),
                        'onboarding_completed': False
                    }
                    
                    profile_id = create_document('user_profiles', profile_data)
                    self.stdout.write(f"Created test profile with ID: {profile_id}")
                else:
                    self.stdout.write(self.style.WARNING("Users already exist. Skipping test data creation."))
            
            self.stdout.write(self.style.SUCCESS('\nMongoDB connection check completed successfully!'))
            
        except pymongo.errors.ConnectionFailure as e:
            self.stdout.write(self.style.ERROR(f"Could not connect to MongoDB: {str(e)}"))
            sys.exit(1)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error: {str(e)}"))
            sys.exit(1) 