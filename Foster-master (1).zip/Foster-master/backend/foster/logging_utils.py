"""
Logging utilities for the Foster backend.
"""
import logging

class ColoredFormatter(logging.Formatter):
    """
    Custom formatter to add colors to log messages based on their level.
    
    Colors:
    - INFO: Blue
    - WARNING: Yellow
    - ERROR: Red
    - SUCCESS/DEBUG: Green
    """
    # ANSI color codes
    COLORS = {
        'INFO': '\033[94m',      # Blue
        'WARNING': '\033[93m',   # Yellow
        'ERROR': '\033[91m',     # Red
        'DEBUG': '\033[92m',     # Green
        'SUCCESS': '\033[92m',   # Green - For custom success level
        'RESET': '\033[0m'       # Reset to default
    }
    
    def format(self, record):
        # Get the original formatted message
        formatted_message = super().format(record)
        
        # Determine the color based on the log level
        level_name = record.levelname
        color_code = self.COLORS.get(level_name, self.COLORS['RESET'])
        
        # Special case for SUCCESS messages
        if hasattr(record, 'msg') and isinstance(record.msg, str) and record.msg.startswith('SUCCESS:'):
            color_code = self.COLORS['SUCCESS']
            # Update the message to highlight the SUCCESS prefix
            record.msg = f"{color_code}SUCCESS{self.COLORS['RESET']}:{record.msg[8:]}"
            # Reformat the message with the updated record
            formatted_message = super().format(record)
        
        # Colorize the message - handle differently based on if it's a django message or a custom app message
        if record.name.startswith('django'):
            # For Django messages, just add color to level name
            colored_message = formatted_message.replace(
                level_name, 
                f"{color_code}{level_name}{self.COLORS['RESET']}", 
                1
            )
        else:
            # For custom app messages, color the entire message based on level
            colored_message = f"{color_code}{formatted_message}{self.COLORS['RESET']}"
        
        return colored_message 