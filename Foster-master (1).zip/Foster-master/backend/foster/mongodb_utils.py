import pymongo
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
import datetime
import logging
import os
from bson.objectid import ObjectId

logger = logging.getLogger('foster.mongodb')

# Global MongoDB connection
_mongo_client = None
_mongo_db = None

def get_client():
    """Get or initialize MongoDB client"""
    global _mongo_client
    if _mongo_client is None:
        mongo_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
        try:
            _mongo_client = MongoClient(mongo_uri)
            # Test the connection
            _mongo_client.admin.command('ping')
            logger.info("MongoDB Connection Established")
        except ConnectionFailure:
            logger.error("MongoDB Server not available")
            raise
    return _mongo_client

def get_db():
    """Get MongoDB database"""
    global _mongo_db
    if _mongo_db is None:
        client = get_client()
        db_name = os.environ.get('MONGO_DB_NAME', 'foster_db')
        _mongo_db = client[db_name]
        logger.info(f"MongoDB Database: {db_name}")
        
        # Log collections
        collections = _mongo_db.list_collection_names()
        logger.info(f"MongoDB Collections: {collections}")
        
        # Initialize collections if they don't exist
        initialize_collections()
    return _mongo_db

def get_collection(collection_name):
    """Get a specific MongoDB collection"""
    return get_db()[collection_name]

def initialize_collections():
    """Ensure all necessary collections exist with proper indexes"""
    db = get_db()
    required_collections = [
        "users", 
        "user_profiles", 
        "user_preferences", 
        "study_sets", 
        "flashcards",
        "study_events",  # Added study_events collection
        "sessions"
    ]
    
    # Create collections if they don't exist
    for collection_name in required_collections:
        if collection_name not in db.list_collection_names():
            logger.info(f"Creating collection: {collection_name}")
            db.create_collection(collection_name)
    
    # Create indexes for better performance
    
    # Users collection
    users_collection = db["users"]
    users_collection.create_index("firebase_uid", unique=True)
    
    # Study events collection (new)
    study_events_collection = db["study_events"]
    study_events_collection.create_index("user_id")
    study_events_collection.create_index([("start_time", pymongo.ASCENDING)])
    study_events_collection.create_index([("end_time", pymongo.ASCENDING)])
    
    # Study sets collection
    study_sets_collection = db["study_sets"]
    study_sets_collection.create_index("user_id")
    
    # Flashcards collection
    flashcards_collection = db["flashcards"]
    flashcards_collection.create_index("study_set_id") 