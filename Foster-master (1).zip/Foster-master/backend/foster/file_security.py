"""
File security utilities for the Foster application.
"""
import os
import logging
from django.conf import settings
from django.http import HttpResponseForbidden, Http404
from rest_framework.exceptions import PermissionDenied
from bson import ObjectId

logger = logging.getLogger(__name__)

def validate_file_access(user_id, study_set_id=None, file_path=None):
    """
    Validate that a user has access to a file.
    
    Args:
        user_id: The ID of the user requesting access
        study_set_id: The ID of the study set (optional)
        file_path: The absolute path to the file (optional)
        
    Returns:
        bool: True if access is allowed, False otherwise
    """
    # If no user ID, deny access
    if not user_id:
        logger.warning(f"File access denied: No user ID provided")
        return False
        
    # If study_set_id is provided, check MongoDB
    if study_set_id:
        try:
            from foster.mongodb import get_collection
            collection = get_collection('study_sets')
            
            # Try to convert id to ObjectId
            try:
                obj_id = ObjectId(study_set_id)
            except Exception as e:
                logger.warning(f"Invalid study set ID format: {study_set_id}")
                return False
                
            # Check if study set exists and belongs to user
            study_set = collection.find_one({
                '_id': obj_id,
                'user_id': user_id
            })
            
            if not study_set:
                logger.warning(f"File access denied: User {user_id} attempted to access study set {study_set_id}")
                return False
                
            # If a file path is also provided, ensure it matches the stored path
            if file_path and 'file_path' in study_set:
                stored_path = study_set['file_path']
                if os.path.normpath(file_path) != os.path.normpath(stored_path):
                    logger.warning(f"File path mismatch: {file_path} vs {stored_path}")
                    return False
                    
            return True
            
        except Exception as e:
            logger.error(f"Error validating file access: {str(e)}")
            return False
            
    # If only file_path is provided, check if it's in the user's directory
    if file_path:
        try:
            # Get the base storage path
            base_storage_path = getattr(settings, 'MEDIA_ROOT', '')
            if not base_storage_path:
                logger.error("MEDIA_ROOT not configured")
                return False
                
            # Construct the expected user path
            user_path = os.path.join(base_storage_path, 'studybuddy', 'documents', str(user_id))
            
            # Check if the file is within the user's directory
            norm_file_path = os.path.normpath(file_path)
            norm_user_path = os.path.normpath(user_path)
            
            if not norm_file_path.startswith(norm_user_path):
                logger.warning(f"File access denied: {file_path} is not in user {user_id}'s directory")
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Error validating file path: {str(e)}")
            return False
            
    # If neither study_set_id nor file_path provided, access can't be validated
    logger.warning("File access denied: Neither study_set_id nor file_path provided")
    return False

def secure_file_path(user_id, filename):
    """
    Generate a secure file path for a user's uploaded file
    
    Args:
        user_id: The ID of the user
        filename: The name of the file
        
    Returns:
        str: The secure path where the file should be stored
    """
    if not user_id:
        raise ValueError("User ID is required")
        
    # Get the base storage path
    base_storage_path = getattr(settings, 'MEDIA_ROOT', '')
    if not base_storage_path:
        raise ValueError("MEDIA_ROOT not configured")
        
    # Construct the user-specific path
    user_path = os.path.join(base_storage_path, 'studybuddy', 'documents', str(user_id))
    
    # Create the directory if it doesn't exist
    os.makedirs(user_path, exist_ok=True)
    
    # Return the full path
    return os.path.join(user_path, filename) 