"""
Utility functions for the Foster backend.
"""
import logging
from rest_framework.views import exception_handler
from rest_framework.response import Response
from foster.mongodb import get_collection
from bson.objectid import ObjectId

logger = logging.getLogger(__name__)

def custom_exception_handler(exc, context):
    """
    Custom exception handler for DRF to provide better error messages.
    """
    # Call REST framework's default exception handler first
    response = exception_handler(exc, context)
    
    if response is None:
        # Unhandled exception, log it
        logger.error(f"Unhandled exception: {str(exc)}")
        return Response({
            'error': 'An unexpected error occurred.',
            'detail': str(exc)
        }, status=500)
        
    # Add extra context to authentication errors
    if response.status_code == 401:
        response.data = {
            'error': 'Authentication error',
            'detail': 'You must be authenticated to access this resource.',
            **response.data
        }
        
    # Add extra context to permission errors
    elif response.status_code == 403:
        response.data = {
            'error': 'Permission denied',
            'detail': 'You do not have permission to perform this action.',
            **response.data
        }
        
    # Make validation errors more user-friendly
    elif response.status_code == 400:
        if 'detail' not in response.data:
            response.data = {
                'error': 'Invalid request',
                'validation_errors': response.data
            }
            
    return response

def is_resource_owner(user_id, collection_name, resource_id, owner_field='user_id'):
    """
    Check if the user is the owner of a resource.
    
    Args:
        user_id (str): The ID of the user
        collection_name (str): The MongoDB collection name
        resource_id (str): The ID of the resource to check
        owner_field (str): The field in the resource that contains the owner ID
        
    Returns:
        bool: True if the user is the owner, False otherwise
    """
    # Get the collection
    collection = get_collection(collection_name)
    if not collection:
        return False
    
    # Get the resource
    try:
        resource = collection.find_one({"_id": ObjectId(resource_id)})
    except Exception as e:
        logger.error(f"Error retrieving resource: {str(e)}")
        return False
    
    # If resource doesn't exist, return False
    if not resource:
        return False
        
    # Check if user is the owner
    resource_owner_id = resource.get(owner_field)
    return resource_owner_id == user_id 