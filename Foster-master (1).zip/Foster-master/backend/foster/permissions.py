"""
Custom permissions for the Foster backend.
"""
from rest_framework import permissions
from foster.utils import is_resource_owner

class IsResourceOwner(permissions.BasePermission):
    """
    Permission to only allow owners of a resource to access it.
    """
    
    # The MongoDB collection that contains the resource
    collection = None
    
    # The field in the URL that contains the resource ID
    id_field = 'id'
    
    # The field in the resource that contains the owner ID
    owner_field = 'user_id'
    
    def has_permission(self, request, view):
        # Allow read operations by default (will be checked in has_object_permission)
        if request.method in permissions.SAFE_METHODS:
            return True
            
        # Must be authenticated for write operations
        return request.user and request.user.is_authenticated
    
    def has_object_permission(self, request, view, obj):
        # If no user or no collection specified, deny access
        if not request.user or not self.collection:
            return False
            
        # Get resource ID from URL kwargs
        resource_id = view.kwargs.get(self.id_field)
        if not resource_id:
            return False
            
        # Check if user is the owner
        return is_resource_owner(
            request.user.user_id,
            self.collection,
            resource_id,
            self.owner_field
        )

class IsStudySetOwner(IsResourceOwner):
    """
    Permission to only allow owners of a study set to access it.
    """
    collection = 'study_sets'
    id_field = 'id'
    owner_field = 'user_id'

class IsFlashcardOwner(IsResourceOwner):
    """
    Permission to only allow owners of a flashcard to access it.
    Checks if the user owns the parent study set.
    """
    collection = 'study_sets'
    id_field = 'study_set_id'
    owner_field = 'user_id'

class IsCalendarEventOwner(IsResourceOwner):
    """
    Permission to only allow owners of a calendar event to access it.
    """
    collection = 'calendar_events'
    id_field = 'id'
    owner_field = 'user_id' 