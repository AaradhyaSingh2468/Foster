"""
Custom middleware for the Foster application.
"""
import logging
from django.utils.deprecation import MiddlewareMixin
from django.utils.functional import SimpleLazyObject
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from foster.mongodb import get_collection
from foster.sessions import validate_session
from bson.objectid import ObjectId

# Set up logging
logger = logging.getLogger(__name__)

class SecurityHeadersMiddleware(MiddlewareMixin):
    """
    Middleware to add security headers to all responses.
    """
    
    def process_response(self, request, response):
        # Add security headers
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        
        # For development only - in production, set to a more restrictive value
        response['Access-Control-Allow-Origin'] = request.META.get('HTTP_ORIGIN', '*')
        response['Access-Control-Allow-Credentials'] = 'true'
        response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Upload-Attempt'
        
        return response

class AuthenticationMiddleware(MiddlewareMixin):
    """
    Middleware to authenticate users via JWT or Firebase tokens.
    This allows backward compatibility with existing systems
    while adding Firebase authentication support.
    """
    
    def process_request(self, request):
        # Skip authentication for OPTIONS requests (CORS preflight)
        if request.method == 'OPTIONS':
            return None
            
        # Skip authentication for specific auth endpoints
        if self.should_skip_auth(request.path):
            return None
            
        # Check for Authorization header
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        
        # Skip authentication if no header present - don't invalidate existing session
        if not auth_header:
            logger.debug("No Authorization header found")
            return None
        
        if auth_header.startswith('Bearer '):
            # Try Firebase first, then JWT
            try:
                from foster.authentication import FirebaseAuthentication
                firebase_auth = FirebaseAuthentication()
                logger.info("Attempting Firebase authentication...")
                
                # Attempt Firebase auth - will return None if it fails
                user_auth = firebase_auth.authenticate(request)
                if user_auth and user_auth[0]:
                    request.user = user_auth[0]
                    logger.info(f"Firebase authentication successful for user: {request.user}")
                    return None
                else:
                    # Check for specific kid claim errors in request data for debugging
                    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                    if auth_header.startswith('Bearer '):
                        token = auth_header.split('Bearer ')[1].strip()
                        if token and len(token) > 20:
                            # Log the first part of the token for debugging token format issues
                            logger.debug(f"Firebase auth failed with token format: {token[:20]}...")
                        else:
                            logger.debug("Firebase auth failed with empty or short token")
                    
                    logger.info("Firebase authentication returned no user, trying JWT...")
                
                # Fallback to JWT - only attempt if Firebase didn't raise an exception
                try:
                    # Use JWTAuthentication as fallback
                    authentication = JWTAuthentication()
                    raw_token = authentication.get_raw_token(auth_header)
                    
                    if raw_token is not None:
                        validated_token = authentication.get_validated_token(raw_token)
                        request.jwt_token = validated_token
                        request.user = authentication.get_user(validated_token)
                        logger.info(f"JWT authentication successful for user: {request.user}")
                        return None
                except (InvalidToken, TokenError) as e:
                    logger.warning(f"JWT Authentication failed: {str(e)}")
                except Exception as e:
                    logger.error(f"Error in JWT middleware: {str(e)}", exc_info=True)
            except Exception as e:
                logger.error(f"Authentication middleware error: {str(e)}", exc_info=True)
        else:
            logger.debug("No Bearer token found in Authorization header")
        
        return None
        
    def should_skip_auth(self, path):
        """Skip authentication for authentication endpoints"""
        skip_paths = [
            '/admin/',
            '/api/auth/login',
            '/api/auth/register',
            '/api/auth/token/refresh',
            '/api/auth/reset-password',
            '/api/auth/verify-reset',
            '/api/auth/reset-password/confirm',
            '/api/auth/google',
            '/api/auth/github',
            '/api/health/',
            '/api/study-buddy/upload',
            '/api/study-buddy/ask',
            '/api/study-buddy/generate-flashcards',
            '/api/study-buddy/flashcards',
            '/api/study-buddy/generate-exam',
            '/api/study-buddy/grade-exam',
            '/api/study-sets',
            '/api/documents/',
            '/api/documents',
            '/api/users/statistics/',
            '/api/calendar/',
            '/api/users/profile/',
        ]
        
        # Check for exact matches first
        for skip_path in skip_paths:
            if path.startswith(skip_path):
                logger.info(f"Skipping authentication for exact match path: {path}")
                return True
        
        # Check for nested paths under study-sets and documents
        if (path.startswith('/api/study-sets/') or 
            path.startswith('/api/documents/') or
            path.startswith('/api/users/statistics/') or
            path.startswith('/api/users/profile/') or
            path.startswith('/api/calendar/events/')):
            logger.info(f"Skipping authentication for nested path: {path}")
            return True
                
        return False

class JWTUserMiddleware:
    """
    Middleware that adds user information to the request based on JWT token.
    This allows MongoDB-based user data to be available in the request object.
    Also validates user sessions for additional security.
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.jwt_authenticator = JWTAuthentication()
    
    def __call__(self, request):
        # Process request before view is called
        self.process_request(request)
        
        # Get response from view
        response = self.get_response(request)
        
        # Return the response
        return response
    
    def process_request(self, request):
        # Skip authentication for certain endpoints
        if self.should_skip_auth(request.path):
            return
            
        # Try to authenticate with JWT
        try:
            # Extract the header
            header = self.jwt_authenticator.get_header(request)
            if header is None:
                # No auth header, continue to view (will be rejected if auth is required)
                return
                
            # Get the raw token
            raw_token = self.jwt_authenticator.get_raw_token(header)
            if raw_token is None:
                # No raw token, continue to view
                return
                
            # Validate the token
            validated_token = self.jwt_authenticator.get_validated_token(raw_token)
            
            # Get user info from token
            user_id = validated_token.get('user_id')
            session_id = validated_token.get('session_id')
            
            if user_id:
                # Validate session if a session ID is present
                if session_id:
                    session = validate_session(session_id)
                    if session is None:
                        # Invalid or expired session
                        logger.warning(f"Invalid session for user ID {user_id}: {session_id}")
                        # We don't return here to allow the view to handle the authentication
                        # Just don't set the user on the request
                        request.invalid_session = True
                        return
                    
                    # Set session on request
                    request.session_id = session_id
                
                # Get user from MongoDB
                users_collection = get_collection('users')
                try:
                    user = users_collection.find_one({"_id": ObjectId(user_id)})
                    if user:
                        # Set MongoDB user on request
                        request.user_id = user_id
                        request.user = user
                        request.username = user.get('username')
                        
                        # Log successful authentication
                        logger.debug(f"Authenticated user: {user.get('username')} (ID: {user_id})")
                except Exception as e:
                    logger.error(f"Error retrieving user from MongoDB: {str(e)}")
                    
        except (InvalidToken, TokenError) as e:
            # Invalid token, log error but don't block request
            # (view will handle permission checks)
            logger.warning(f"JWT Authentication failed: {str(e)}")
            
        except Exception as e:
            # Other error, log it
            logger.error(f"Error processing JWT: {str(e)}")
    
    def should_skip_auth(self, path):
        """Skip authentication for certain paths like login/register"""
        skip_paths = [
            '/admin/',
            '/api/auth/login',
            '/api/auth/register',
            '/api/auth/token/refresh',
            '/api/auth/reset-password',
            '/api/auth/verify-reset',
            '/api/auth/reset-password/confirm',
            '/api/auth/google',
            '/api/auth/github',
            '/api/study-buddy/upload',
            '/api/study-buddy/ask',
            '/api/study-buddy/generate-flashcards',
            '/api/study-buddy/flashcards',
            '/api/study-buddy/generate-exam',
            '/api/study-buddy/grade-exam',
            '/api/study-sets',
            '/api/documents/',
            '/api/documents',
            '/api/users/statistics/',
            '/api/calendar/',
            '/api/health/',
            '/api/users/profile/',
        ]
        
        # Check for exact matches first
        for skip_path in skip_paths:
            if path.startswith(skip_path):
                return True
                
        # Check for nested paths under study-sets and documents
        if (path.startswith('/api/study-sets/') or 
            path.startswith('/api/documents/') or
            path.startswith('/api/users/statistics/') or
            path.startswith('/api/users/profile/') or
            path.startswith('/api/calendar/events/')):
            logger.info(f"Skipping authentication for nested path: {path}")
            return True
                
        return False 