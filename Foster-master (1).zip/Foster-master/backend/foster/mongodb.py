"""
MongoDB service layer for database operations.
This file provides functions to interact with MongoDB collections directly.
"""
from django.conf import settings
from bson.objectid import ObjectId
import logging
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [MongoDB] %(levelname)s: %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

# Get the MongoDB database instance
# Access mongo_db from django.conf.settings directly
from django.conf import settings
try:
    # Use getattr to safely get the mongodb client or provide fallback
    mongo_db = getattr(settings, 'mongo_db', None)
    if mongo_db is None:
        # If mongo_db not found, try to get it from the global namespace
        from pymongo import MongoClient
        mongo_uri = getattr(settings, 'MONGO_URI', 'mongodb://localhost:27017/')
        mongo_db_name = getattr(settings, 'MONGO_DB_NAME', 'foster_db')
        mongo_client = MongoClient(mongo_uri)
        mongo_db = mongo_client[mongo_db_name]
        logger.warning("Settings mongo_db not found, creating connection manually")
except Exception as e:
    logger.error(f"Failed to connect to MongoDB: {str(e)}")
    raise

# Log database connection information
logger.info(f"MongoDB Connection Established")
logger.info(f"MongoDB Database: {mongo_db.name}")
logger.info(f"MongoDB Collections: {mongo_db.list_collection_names()}")

def get_collection(collection_name):
    """Get a MongoDB collection by name"""
    logger.debug(f"Accessing collection: {collection_name}")
    return mongo_db[collection_name]

def create_document(collection_name, document):
    """Create a new document in the collection"""
    collection = get_collection(collection_name)
    logger.info(f"Creating document in collection: {collection_name}")
    result = collection.insert_one(document)
    logger.info(f"Document created with ID: {result.inserted_id}")
    return str(result.inserted_id)

def get_document(collection_name, document_id):
    """Get a document by ID"""
    collection = get_collection(collection_name)
    logger.debug(f"Fetching document {document_id} from {collection_name}")
    return collection.find_one({"_id": ObjectId(document_id)})

def get_documents(collection_name, query=None, sort=None, limit=None, skip=None):
    """Get documents with optional filtering, sorting, and pagination"""
    collection = get_collection(collection_name)
    query = query or {}
    logger.debug(f"Fetching documents from {collection_name} with query: {query}")
    cursor = collection.find(query)
    
    if sort:
        cursor = cursor.sort(sort)
    
    if skip:
        cursor = cursor.skip(skip)
    
    if limit:
        cursor = cursor.limit(limit)
    
    return list(cursor)

def update_document(collection_name, document_id, update_data):
    """Update a document by ID"""
    collection = get_collection(collection_name)
    logger.info(f"Updating document {document_id} in {collection_name}")
    result = collection.update_one(
        {"_id": ObjectId(document_id)},
        {"$set": update_data}
    )
    logger.info(f"Update affected {result.modified_count} document(s)")
    return result.modified_count > 0

def delete_document(collection_name, document_id):
    """Delete a document by ID"""
    collection = get_collection(collection_name)
    logger.info(f"Deleting document {document_id} from {collection_name}")
    result = collection.delete_one({"_id": ObjectId(document_id)})
    logger.info(f"Deletion affected {result.deleted_count} document(s)")
    return result.deleted_count > 0

def count_documents(collection_name, query=None):
    """Count documents in a collection with optional filtering"""
    collection = get_collection(collection_name)
    count = collection.count_documents(query or {})
    logger.debug(f"Count in {collection_name} with query {query}: {count}")
    return count

def aggregate(collection_name, pipeline):
    """Run an aggregation pipeline on a collection"""
    collection = get_collection(collection_name)
    logger.debug(f"Running aggregation on {collection_name} with pipeline: {pipeline}")
    return list(collection.aggregate(pipeline)) 