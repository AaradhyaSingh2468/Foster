"""
Session management utilities for MongoDB-based sessions.
"""
import uuid
import datetime
from django.conf import settings
from foster.mongodb import get_collection, get_document, mongo_db

# Session collection name
SESSION_COLLECTION = 'sessions'

def create_session(user_id, request_data=None):
    """
    Create a new session for a user.
    
    Args:
        user_id (str): The user ID
        request_data (dict, optional): Additional request data to store (IP, user agent, etc.)
        
    Returns:
        str: The session ID
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return None
        
    # Generate a new session ID
    session_id = str(uuid.uuid4())
    
    # Create session document
    session = {
        '_id': session_id,
        'user_id': user_id,
        'created_at': datetime.datetime.utcnow(),
        'last_activity': datetime.datetime.utcnow(),
        'expires_at': datetime.datetime.utcnow() + datetime.timedelta(days=7),
        'is_active': True,
        'ip_address': request_data.get('ip_address') if request_data else None,
        'user_agent': request_data.get('user_agent') if request_data else None,
        'device_info': request_data.get('device_info') if request_data else None
    }
    
    # Insert session into MongoDB
    collection.insert_one(session)
    
    return session_id

def validate_session(session_id):
    """
    Validate a session and update last activity.
    
    Args:
        session_id (str): The session ID
        
    Returns:
        dict: The session document if valid, None otherwise
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return None
        
    # Get session
    session = collection.find_one({'_id': session_id})
    
    # Check if session exists and is active
    if session is None or not session.get('is_active', False):
        return None
        
    # Check if session has expired
    expires_at = session.get('expires_at')
    if expires_at and expires_at < datetime.datetime.utcnow():
        # Deactivate expired session
        deactivate_session(session_id)
        return None
        
    # Update last activity
    collection.update_one(
        {'_id': session_id},
        {'$set': {'last_activity': datetime.datetime.utcnow()}}
    )
    
    return session

def deactivate_session(session_id):
    """
    Deactivate a session.
    
    Args:
        session_id (str): The session ID
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return False
        
    # Deactivate session
    result = collection.update_one(
        {'_id': session_id},
        {'$set': {'is_active': False}}
    )
    
    return result.modified_count > 0

def get_user_sessions(user_id, active_only=True):
    """
    Get all sessions for a user.
    
    Args:
        user_id (str): The user ID
        active_only (bool): Only return active sessions
        
    Returns:
        list: List of session documents
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return []
        
    # Create query
    query = {'user_id': user_id}
    if active_only:
        query['is_active'] = True
        
    # Get sessions
    sessions = list(collection.find(query))
    
    return sessions

def deactivate_all_user_sessions(user_id, except_session_id=None):
    """
    Deactivate all sessions for a user, except optionally one session.
    
    Args:
        user_id (str): The user ID
        except_session_id (str, optional): Session ID to exclude from deactivation
        
    Returns:
        int: Number of sessions deactivated
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return 0
        
    # Create query
    query = {'user_id': user_id, 'is_active': True}
    if except_session_id:
        query['_id'] = {'$ne': except_session_id}
        
    # Deactivate sessions
    result = collection.update_many(
        query,
        {'$set': {'is_active': False}}
    )
    
    return result.modified_count

def cleanup_expired_sessions():
    """
    Clean up expired sessions from the database.
    
    Returns:
        int: Number of sessions cleaned up
    """
    # Get MongoDB collection
    collection = get_collection(SESSION_COLLECTION)
    if collection is None:
        return 0
        
    # Delete expired sessions
    result = collection.delete_many({
        'expires_at': {'$lt': datetime.datetime.utcnow()}
    })
    
    return result.deleted_count 