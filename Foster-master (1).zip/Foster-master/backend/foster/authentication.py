"""
Custom authentication classes for MongoDB-based user authentication.
"""

from rest_framework import authentication
from rest_framework import exceptions
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from django.utils.functional import SimpleLazyObject
from foster.mongodb import get_collection
from foster.sessions import validate_session
from bson.objectid import ObjectId
import firebase_admin
from firebase_admin import credentials, auth
import os
from django.conf import settings
import json
import datetime
import logging
import uuid
from django.contrib.auth.hashers import make_password
import traceback
from .firebase import verify_firebase_token

# Set up logging
logger = logging.getLogger(__name__)

# Initialize Firebase Admin SDK
try:
    if not firebase_admin._apps:
        # Look for credentials file in multiple locations
        cred_paths = [
            os.path.join(settings.BASE_DIR, "foster", "credentials", "firebase-service-account.json"),
            os.path.join(settings.BASE_DIR, "firebase-service-account.json"),
            os.path.join(settings.BASE_DIR, "credentials", "firebase-service-account.json"),
        ]

        # Find first existing credentials file
        cred_file = None
        for path in cred_paths:
            if os.path.exists(path):
                cred_file = path
                break

        if cred_file:
            # Use the credentials file
            logger.info(f"Found Firebase credentials at {cred_file}")
            cred = credentials.Certificate(cred_file)
            firebase_admin.initialize_app(
                cred,
                {
                    "projectId": settings.FIREBASE_CONFIG["projectId"],
                    "storageBucket": settings.FIREBASE_CONFIG["storageBucket"],
                },
            )
            logger.info("Firebase Admin SDK initialized successfully with service account")
        else:
            # Fallback: Use application default credentials
            logger.warning("No service account file found, trying application default credentials")
            firebase_admin.initialize_app(
                options={
                    "projectId": settings.FIREBASE_CONFIG["projectId"],
                    "storageBucket": settings.FIREBASE_CONFIG["storageBucket"],
                }
            )
            logger.info("Firebase Admin SDK initialized with application default credentials")
except Exception as e:
    logger.error(f"Failed to initialize Firebase Admin SDK: {e}")


class FirebaseAuthentication(authentication.BaseAuthentication):
    """
    Custom authentication class for Firebase token verification.
    """

    def authenticate(self, request):
        # Skip authentication for specific paths like Google auth endpoint
        if request.path.startswith("/api/auth/google") or request.path.startswith("/api/auth/github"):
            logger.info(f"Skipping Firebase authentication for auth endpoint: {request.path}")
            return None

        auth_header = request.META.get("HTTP_AUTHORIZATION")
        # Return None immediately if no auth header (don't log a warning)
        if not auth_header:
            return None

        # Return None if not a Bearer token (don't log a warning)
        if "Bearer" not in auth_header:
            return None

        try:
            # Log request method and content type for debugging
            content_type = request.META.get("CONTENT_TYPE", "")
            logger.info(f"Request: {request.method} {request.path} Content-Type: {content_type}")

            # Get the Firebase token from the Authorization header
            id_token = auth_header.split("Bearer ")[-1].strip()

            # Skip empty or invalid tokens without logging warnings
            if not id_token or id_token == "null" or id_token == "undefined":
                return None

            # Skip token validation for debugging in dev environments
            # WARNING: This should NEVER be used in production
            if settings.DEBUG and "test-token-bypass" in id_token:
                logger.warning("⚠️ DEBUG MODE: Using test token bypass - INSECURE!")
                debug_uid = "debug_user_firebase"

                # Find or create debug user
                users_collection = get_collection("users")
                user = users_collection.find_one({"firebase_uid": debug_uid})

                if not user:
                    user_data = {
                        "firebase_uid": debug_uid,
                        "email": "debug@example.com",
                        "username": "debug_user",
                        "is_active": True,
                        "created_at": datetime.datetime.utcnow(),
                    }
                    result = users_collection.insert_one(user_data)
                    user = users_collection.find_one({"_id": result.inserted_id})

                mongo_user = MongoDBUser(str(user["_id"]))
                return (mongo_user, None)

            # Use our improved token verification function with fallback for Google tokens
            logger.info("Attempting to verify Firebase token...")
            decoded_token = verify_firebase_token(id_token)
            
            # If token verification failed, return None to try other auth methods
            if not decoded_token:
                logger.info("Firebase authentication returned no user, trying JWT...")
                return None
                
            logger.info(f"Firebase authentication successful for user: {decoded_token.get('uid')}")

            # Get user from MongoDB or create if doesn't exist
            users_collection = get_collection("users")
            logger.info(f"Looking up user with Firebase UID: {decoded_token['uid']}")
            user = users_collection.find_one({"firebase_uid": decoded_token["uid"]})

            if not user:
                # Log detailed information about the token for debugging
                logger.warning(f"User with Firebase UID {decoded_token['uid']} not found in MongoDB")
                logger.info(f"Decoded token content: {decoded_token}")

                # Check if user exists by email instead of Firebase UID
                if "email" in decoded_token:
                    logger.info(f"Checking if user exists with email: {decoded_token['email']}")
                    user_by_email = users_collection.find_one({"email": decoded_token["email"]})
                    if user_by_email:
                        # User exists with the email but without Firebase UID, update the user
                        logger.info(f"Found user by email, updating Firebase UID for user: {user_by_email['_id']}")
                        users_collection.update_one(
                            {"_id": user_by_email["_id"]}, {"$set": {"firebase_uid": decoded_token["uid"]}}
                        )
                        user = users_collection.find_one({"_id": user_by_email["_id"]})
                        logger.info(f"Updated user: {user}")

                # If still no user, create a new one instead of returning an error
                # This makes MongoDB the source of truth, not Firebase
                if not user and "email" in decoded_token:
                    logger.info(f"Creating new user in MongoDB for Firebase UID: {decoded_token['uid']}")

                    name = decoded_token.get("name", "")
                    email = decoded_token.get("email", "")
                    picture = decoded_token.get("picture", "")

                    # If name is missing, try to extract from email
                    if not name and email:
                        name = email.split("@")[0]  # Use part before @ as name

                    user_data = {
                        "firebase_uid": decoded_token["uid"],
                        "email": email,
                        "username": name,
                        "password": make_password(str(uuid.uuid4())),  # Random secure password
                        "date_joined": datetime.datetime.now(),
                        "last_login": datetime.datetime.now(),
                        "is_active": True,
                        "oauth_provider": "firebase",
                        "oauth_picture": picture,
                    }

                    result = users_collection.insert_one(user_data)
                    user_id = str(result.inserted_id)
                    logger.info(f"Created new user with ID: {user_id}")

                    # Create user profile with onboarding_completed = False
                    profile_data = {
                        "user_id": user_id,
                        "avatar": picture,
                        "bio": "",
                        "date_of_birth": None,
                        "education_level": "",
                        "institution": "",
                        "major": "",
                        "created_at": datetime.datetime.now(),
                        "updated_at": datetime.datetime.now(),
                        "onboarding_completed": False,
                    }
                    profile_collection = get_collection("user_profiles")
                    profile_collection.insert_one(profile_data)
                    logger.info(f"Created user profile for: {user_id}")

                    # Create user preferences
                    preferences_data = {
                        "user_id": user_id,
                        "theme": "system",
                        "email_notifications": True,
                        "study_reminder_frequency": 3,
                        "calendar_default_view": "week",
                        "ai_features_enabled": True,
                        "created_at": datetime.datetime.now(),
                        "updated_at": datetime.datetime.now(),
                    }
                    preferences_collection = get_collection("user_preferences")
                    preferences_collection.insert_one(preferences_data)
                    logger.info(f"Created user preferences for: {user_id}")

                    # Get the created user
                    user = users_collection.find_one({"_id": result.inserted_id})
                elif not user:
                    # Cannot create user without email
                    logger.error("User not found and email not provided in token")
                    return None
            else:
                logger.info(f"Found existing user with ID: {user['_id']}")

            # Create MongoDBUser instance
            mongo_user = MongoDBUser(str(user["_id"]))
            logger.info(f"Created MongoDBUser instance for user: {mongo_user.get_username()}")

            return (mongo_user, None)
        except Exception as e:
            logger.error(f"Error in Firebase authentication: {str(e)}")
            logger.error(traceback.format_exc())
            # Return None instead of raising an exception to allow other auth methods to try
            return None


class MongoDBJWTAuthentication(JWTAuthentication):
    """
    Custom JWT authentication that uses MongoDB users.
    """

    def authenticate(self, request):
        try:
            # First try standard JWT authentication
            result = super().authenticate(request)
            if result is None:
                return None

            # Get the raw token and decoded token
            raw_token, decoded_token = result
            
            # Extract user_id from JWT token
            user_id = decoded_token.get("user_id")
            if not user_id:
                logger.warning("JWT token missing user_id claim")
                return None
                
            # Get user from MongoDB
            users_collection = get_collection("users")
            user = users_collection.find_one({"_id": ObjectId(user_id)})
            
            if not user:
                logger.warning(f"User with ID {user_id} from JWT not found in MongoDB")
                return None
                
            # Check if user has a profile picture in the OAuth provider but not in their profile
            if user.get('oauth_picture') and user.get('oauth_provider'):
                # Check if user profile is missing avatar
                profile_collection = get_collection("user_profiles")
                profile = profile_collection.find_one({"user_id": user_id})
                
                if profile and (not profile.get('avatar') or profile.get('avatar') == ""):
                    # User has profile but missing avatar, update it
                    logger.info(f"Fixing missing avatar for user {user_id} from JWT auth")
                    profile_collection.update_one(
                        {"_id": profile["_id"]},
                        {"$set": {"avatar": user.get('oauth_picture'), "updated_at": datetime.datetime.now()}}
                    )
                    
            # Create MongoDBUser instance
            mongo_user = MongoDBUser(str(user["_id"]))
            
            # Return user and raw token
            return (mongo_user, raw_token)
        except InvalidToken as e:
            logger.warning(f"Invalid JWT token: {str(e)}")
            # Return None instead of raising an exception
            return None
        except Exception as e:
            logger.error(f"JWT authentication error: {str(e)}")
            logger.error(traceback.format_exc())
            # Return None instead of raising an exception
            return None


class MongoDBUser:
    """
    A user class for MongoDB authentication that mimics Django User
    just enough to work with DRF.
    """

    def __init__(self, user_id):
        self.user_id = user_id
        self.is_authenticated = True

        # Lazy-load user info to avoid unnecessary database calls
        self._user_data = None

    @property
    def user_data(self):
        if self._user_data is None:
            users_collection = get_collection("users")
            try:
                self._user_data = users_collection.find_one({"_id": ObjectId(self.user_id)}) or {}
            except Exception as e:
                # Handle errors gracefully
                self._user_data = {}
        return self._user_data

    @property
    def username(self):
        return self.user_data.get("username", "")

    @property
    def email(self):
        return self.user_data.get("email", "")

    @property
    def is_active(self):
        return self.user_data.get("is_active", False)

    @property
    def uid(self):
        """Return the Firebase UID for the user, needed for file storage paths"""
        return self.user_data.get("firebase_uid", self.user_id)

    def get_or_create_django_user(self):
        """
        Get or create a Django User instance that corresponds to this MongoDB user.
        This is needed for models that require a Django User foreign key.
        
        Returns:
            User: A Django User instance
        """
        from django.contrib.auth.models import User
        
        # Try to find a Django user with the same username first
        username = self.username
        email = self.email
        
        try:
            # Look for existing user with the same username
            django_user = User.objects.filter(username=username).first()
            if django_user:
                return django_user
                
            # Look for existing user with the same email if no username match
            if email:
                django_user = User.objects.filter(email=email).first()
                if django_user:
                    return django_user
            
            # No matching user, create new one
            django_user = User.objects.create(
                username=username or f"mongodb_user_{self.user_id}",
                email=email or "",
                password="",  # Can't be used for authentication, just a placeholder
            )
            
            # Update the user's last_login
            django_user.last_login = datetime.datetime.now()
            django_user.save()
            
            logger.info(f"Created Django User for MongoDB user: {self.user_id}")
            return django_user
            
        except Exception as e:
            logger.error(f"Error creating Django user for MongoDB user {self.user_id}: {str(e)}")
            logger.error(traceback.format_exc())
            # Create a fallback user as last resort
            try:
                django_user = User.objects.get_or_create(
                    username=f"mongodb_user_{self.user_id}"
                )[0]
                return django_user
            except Exception as inner_e:
                logger.error(f"Failed to create fallback Django user: {str(inner_e)}")
                # Raise to make the error obvious - this needs fixing
                raise

    def get_username(self):
        return self.username

    def __str__(self):
        return self.username

    def __eq__(self, other):
        if not isinstance(other, MongoDBUser):
            return False
        return self.user_id == other.user_id

    def __hash__(self):
        return hash(self.user_id)
