"""
ASGI config for foster project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""

import os
import sys
import django
import logging
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from channels.security.websocket import AllowedHostsOriginValidator
from django.urls import path, re_path

# Configure logging
logger = logging.getLogger(__name__)

# Set the Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'foster.settings')

# Initialize Django
try:
    django.setup()
    logger.info("Django successfully initialized in ASGI application")
except Exception as e:
    logger.error(f"Failed to initialize Django in ASGI application: {str(e)}")
    raise

# Import WebSocket routing after Django setup
try:
    # Import app-level WebSocket routing
    from study.routing import websocket_urlpatterns
    
    # Log the loaded patterns for debugging
    logger.info(f"Loaded WebSocket URL patterns: {websocket_urlpatterns}")
    print(f"Available WebSocket URL patterns: {websocket_urlpatterns}")
except Exception as e:
    logger.error(f"Failed to import WebSocket URL patterns: {str(e)}")
    websocket_urlpatterns = []
    print("WARNING: No WebSocket URL patterns found")

# Create ASGI application
application = ProtocolTypeRouter({
    # Django's ASGI application for HTTP requests
    "http": get_asgi_application(),
    
    # WebSocket handler with authentication
    "websocket": AllowedHostsOriginValidator(
        AuthMiddlewareStack(
            URLRouter(websocket_urlpatterns)
        )
    ),
})

# Debug the final application structure
logger.info("ASGI application configured with WebSocket support")
print("ASGI application configured - WebSocket support enabled") 