"""
URL configuration for foster project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
"""
from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from study import views
from study.consumers import FlashcardConsumer

from channels.routing import ProtocolTypeRouter, URLRouter
from django.core.asgi import get_asgi_application
from channels.auth import AuthMiddlewareStack
from channels.security.websocket import AllowedHostsOriginValidator

# Simple health check endpoint
@api_view(['GET', 'OPTIONS'])
@permission_classes([AllowAny])
def health_check(request):
    return JsonResponse({
        'status': 'success',
        'message': 'API is working correctly',
        'cors': 'enabled',
        'server': 'Foster Backend',
        'version': '1.0.0'
    })

# Debug endpoint to check auth status
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def debug_auth(request):
    # Get user info
    user = request.user
    
    # Return user data
    return JsonResponse({
        'authenticated': True,
        'user_id': user.user_id if hasattr(user, 'user_id') else None,
        'username': user.username if hasattr(user, 'username') else None,
        'email': user.email if hasattr(user, 'email') else None,
        'is_active': user.is_active if hasattr(user, 'is_active') else None,
        'session_id': request.session_id if hasattr(request, 'session_id') else None
    })

# API root patterns
api_patterns = [
    path('auth/', include('auth_app.urls')),
    path('users/', include('users.urls')),
    path('study-sets/', include('study.urls')),
    path('calendar/', include('calendar_app.urls')),
    path('ai/', include('ai.urls')),
    path('health/', health_check, name='health_check'),
    path('debug-auth/', debug_auth, name='debug_auth'),
    
    # Direct paths for study-buddy routes (no nesting)
    path('study-buddy/upload/', views.upload_document, name='api_upload_document'),
    path('study-buddy/ask/', views.ask_question, name='api_ask_question'),
    path('study-buddy/generate-flashcards/', views.generate_flashcards, name='api_generate_flashcards'),
    path('study-buddy/generate-exam/', views.generate_exam, name='api_generate_exam'),
    path('study-buddy/grade-exam/', views.grade_exam, name='api_grade_exam'),
    path('study-buddy/flashcard-job/<str:job_id>/', views.check_flashcard_job_status, name='api_check_flashcard_job'),
    path('study-buddy/flashcard-job/<str:job_id>', views.check_flashcard_job_status, name='api_check_flashcard_job_no_slash'),
    path('create-study-set-from-pdf/', views.create_study_set_from_pdf, name='api_create_study_set_from_pdf'),
    
    # Document management endpoints
    path('documents/', views.get_documents, name='api_get_documents'),
    path('documents', views.get_documents, name='api_get_documents_no_slash'),
    path('documents/<str:document_id>/', views.get_document_by_id, name='api_get_document_by_id'),
    path('documents/<str:document_id>', views.get_document_by_id, name='api_get_document_by_id_no_slash'),
    
    # Versions without trailing slashes
    path('study-buddy/upload', views.upload_document, name='api_upload_document_no_slash'),
    path('study-buddy/ask', views.ask_question, name='api_ask_question_no_slash'),
    path('study-buddy/generate-flashcards', views.generate_flashcards, name='api_generate_flashcards_no_slash'),
    path('study-buddy/generate-exam', views.generate_exam, name='api_generate_exam_no_slash'),
    path('study-buddy/grade-exam', views.grade_exam, name='api_grade_exam_no_slash'),
]

urlpatterns = [
    path('admin/', admin.site.urls),
    # API routes with /api/ prefix
    path('api/', include(api_patterns)),
    
    # Direct routes for troubleshooting
    path('api/study-buddy/generate-flashcards/', views.generate_flashcards, name='direct_generate_flashcards'),
    path('api/study-buddy/generate-flashcards', views.generate_flashcards, name='direct_generate_flashcards_no_slash'),
    path('api/study-buddy/flashcard-job/<str:job_id>/', views.check_flashcard_job_status, name='direct_check_flashcard_job'),
    path('api/study-buddy/flashcard-job/<str:job_id>', views.check_flashcard_job_status, name='direct_check_flashcard_job_no_slash'),
    
    # Add a redirect for the root URL
    path('', health_check, name='root_health_check'),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) 