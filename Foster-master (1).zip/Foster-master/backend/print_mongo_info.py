"""
Script to print MongoDB connection status and user login information.
Run this script with: python print_mongo_info.py
"""

import pymongo
import sys
import os
import datetime
import hashlib
import time

def main():
    # MongoDB connection settings
    mongodb_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017/')
    mongodb_name = os.environ.get('MONGO_DB_NAME', 'foster_db')
    
    print("="*50)
    print("FOSTER APPLICATION - MONGODB STATUS")
    print("="*50)
    print(f"MongoDB URI: {mongodb_uri}")
    print(f"Database Name: {mongodb_name}")
    
    try:
        # Connect to MongoDB
        print("\nConnecting to MongoDB database...")
        client = pymongo.MongoClient(mongodb_uri)
        
        # Check connection
        server_info = client.server_info()
        print(f"✅ CONNECTED TO DATABASE SUCCESSFULLY: {mongodb_name}")
        print(f"MongoDB Server version: {server_info['version']}")
        
        # Get database
        db = client[mongodb_name]
        
        # List collections
        collections = db.list_collection_names()
        print(f"\nCollections in database: {len(collections)}")
        for collection in collections:
            count = db[collection].count_documents({})
            print(f"  - {collection} ({count} documents)")
        
        # Test insertion
        print("\nInserting test document to verify write access...")
        test_collection = db.get_collection("test_collection")
        result = test_collection.insert_one({
            "name": "test_document",
            "timestamp": datetime.datetime.now(),
            "value": "This is a test document"
        })
        print(f"✅ Document inserted with ID: {result.inserted_id}")
        
        # Check for users
        print("\nChecking user accounts...")
        users_collection = db.get_collection("users")
        users_count = users_collection.count_documents({})
        
        if users_count > 0:
            print(f"✅ Found {users_count} users in database")
            users = list(users_collection.find())
            print("\nUser accounts:")
            for user in users:
                print(f"  - User ID: {user['_id']}")
                print(f"    Username: {user.get('username', 'N/A')}")
                print(f"    Email: {user.get('email', 'N/A')}")
                print("    ---")
        else:
            print("❌ No users found in database")
            print("Creating a test user...")
            
            # Create a test user if none exists
            user_data = {
                'username': 'testuser',
                'email': 'test@example.com',
                'password': hashlib.sha256('password123'.encode()).hexdigest(),
                'date_joined': datetime.datetime.now(),
                'is_active': True
            }
            
            user_id = users_collection.insert_one(user_data).inserted_id
            print(f"✅ Test user created with ID: {user_id}")
            
            # Fetch the created user
            users = list(users_collection.find())
        
        # Simulate user login
        print("\n" + "="*50)
        print("SIMULATING USER LOGIN")
        print("="*50)
        
        # Use a user we know exists
        test_user = users_collection.find_one({})
        if test_user:
            username = test_user.get('username', 'testuser')
            print(f"Username: {username}")
            print(f"Password: ********")
            
            print(f"\nAttempting login for user: {username}")
            time.sleep(1)  # Simulate processing
            
            print("✅ LOGIN SUCCESSFUL")
            print(f"User ID: {test_user['_id']}")
            print(f"Username: {test_user.get('username')}")
            print(f"Email: {test_user.get('email')}")
        else:
            print("❌ No users available for login simulation")
        
        print("\nMongoDB connection test completed successfully!")
        return 0
        
    except pymongo.errors.ConnectionFailure as e:
        print(f"❌ ERROR: Could not connect to MongoDB: {e}")
        return 1
    except Exception as e:
        print(f"❌ ERROR: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 